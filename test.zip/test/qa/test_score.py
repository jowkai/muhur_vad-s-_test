import copy
import json
import tempfile
import unittest
from pathlib import Path
from score import evaluate


class ScoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        (self.base / 'proof.json').write_text('{"passed":true}')
        self.rubric = json.loads(Path(__file__).with_name('SCORECARD.json').read_text())
        self.evidence = {'commit': 'abc',
            'gates': {k: {'status': 'PASS', 'artifacts': ['proof.json']} for k in self.rubric['hard_gates']},
            'criteria': {k: {'score': 90, 'artifacts': ['proof.json'], 'rationale': 'Measured'} for k in self.rubric['criteria']}}

    def result(self):
        return evaluate(self.evidence, self.rubric, 'abc', self.base)

    def test_complete(self):
        self.assertEqual(self.result()['status'], 'PASS')
        self.assertEqual(self.result()['score'], 90)

    def test_missing_never_scores(self):
        self.evidence['gates'].pop('performance')
        self.assertIsNone(self.result()['score'])
        self.assertEqual(self.result()['status'], 'INCOMPLETE')

    def test_hard_gate_cannot_average_away(self):
        self.evidence['gates']['save_integrity']['status'] = 'FAIL'
        self.assertEqual(self.result()['status'], 'FAIL')

    def test_failed_criterion_zero(self):
        self.evidence['criteria']['world_biomes_connectivity']['status'] = 'FAIL'
        self.assertEqual(self.result()['score'], 72)

    def test_wrong_commit(self):
        self.evidence['commit'] = 'different'
        self.assertEqual(self.result()['status'], 'FAIL')

    def test_source_binding(self):
        for source in [None, 'old-source']:
            self.evidence['source_sha256'] = source
            result = evaluate(self.evidence, self.rubric, 'abc', self.base, 'current-source')
            self.assertEqual(result['status'], 'FAIL')
            self.assertIsNone(result['score'])
        self.evidence['source_sha256'] = 'current-source'
        self.assertEqual(evaluate(self.evidence, self.rubric, 'abc', self.base, 'current-source')['status'], 'PASS')

    def test_missing_artifact(self):
        (self.base / 'proof.json').unlink()
        self.assertIsNone(self.result()['score'])

    def test_no_escape(self):
        self.evidence['gates']['build']['artifacts'] = ['../outside.json']
        self.assertEqual(self.result()['status'], 'INCOMPLETE')

    def test_invalid_scores(self):
        for value in [True, float('nan'), 101, -1, '90']:
            self.evidence['criteria']['save_recovery']['score'] = value
            self.assertIsNone(self.result()['score'])

    def test_low_single_criterion(self):
        self.evidence['criteria']['usability_visual_identity']['score'] = 59
        self.assertEqual(self.result()['status'], 'FAIL')

    def test_threshold(self):
        for value in self.evidence['criteria'].values():
            value['score'] = 84
        self.assertEqual(self.result()['status'], 'FAIL')


if __name__ == '__main__':
    unittest.main()
