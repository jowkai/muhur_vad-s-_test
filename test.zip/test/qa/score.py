"""Evidence completeness guard; trusted QA still verifies artifact contents."""
import argparse
import json
import math
from pathlib import Path


def evaluate(evidence, rubric, commit, base, source_sha256=None):
    missing, failures = [], []
    base = Path(base).resolve()
    if evidence.get('commit') != commit:
        failures.append('commit mismatch')
    source_mismatch = source_sha256 is not None and evidence.get('source_sha256') != source_sha256
    if source_mismatch:
        failures.append('source fingerprint mismatch')

    def artifacts_valid(record):
        paths = record.get('artifacts', [])
        if not isinstance(paths, list) or not paths:
            return False
        for name in paths:
            if not isinstance(name, str):
                return False
            path = (base / name).resolve()
            if not path.is_relative_to(base) or not path.is_file() or path.stat().st_size == 0:
                return False
        return True

    for name in rubric['hard_gates']:
        record = evidence.get('gates', {}).get(name, {})
        if record.get('status') == 'FAIL':
            failures.append(name)
        elif record.get('status') != 'PASS' or not artifacts_valid(record):
            missing.append('gate:' + name)
    weighted = 0
    for name, weight in rubric['criteria'].items():
        record = evidence.get('criteria', {}).get(name, {})
        score = record.get('score')
        if record.get('status') == 'FAIL':
            score = 0
            failures.append('criterion:' + name)
        if (isinstance(score, bool) or not isinstance(score, (int, float))
                or not math.isfinite(score) or not 0 <= score <= 100
                or not artifacts_valid(record) or not record.get('rationale')):
            missing.append('criterion:' + name)
            continue
        weighted += weight * score / 100
        if score < rubric['minimum_criterion_score']:
            failures.append('minimum:' + name)
    score = None if missing or source_mismatch else round(weighted, 2)
    if score is not None and score < rubric['release_target']:
        failures.append('release threshold')
    status = 'FAIL' if failures else ('INCOMPLETE' if missing else 'PASS')
    return {'status': status, 'score': score, 'missing': missing, 'failures': failures}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--source-sha256', required=True,
                        help='Expected SHA256 of current source snapshot; binds uncommitted changes')
    args = parser.parse_args()
    rubric = json.loads(Path(__file__).with_name('SCORECARD.json').read_text())
    result = evaluate(json.loads(args.evidence.read_text()), rubric, args.commit, args.evidence.parent, args.source_sha256)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)
