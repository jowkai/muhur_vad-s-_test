"""Bind evidence to current source, including uncommitted application changes."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from engine.task_engine import snapshot, atomic_json
from qa.score import evaluate

def fingerprint():
    return hashlib.sha256(json.dumps(snapshot(ROOT),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def main():
    source=fingerprint()
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    if '--identity' in sys.argv:
        print(json.dumps({'commit':commit,'source_sha256':source}))
        return 0
    path=ROOT/'.loop/evidence/evidence.json'
    if not path.is_file():
        result={'status':'INCOMPLETE','score':None,'missing':['evidence.json'],'failures':[]}
    else:
        result=evaluate(json.loads(path.read_text()),json.loads((ROOT/'qa/SCORECARD.json').read_text()),
                        commit,path.parent,source_sha256=source)
    atomic_json(ROOT/'.loop/game-score.json',result)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':
    raise SystemExit(main())
