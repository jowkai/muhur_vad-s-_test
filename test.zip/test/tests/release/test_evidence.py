import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import sys
from evidence import ROOT
sys.path.insert(0, str(ROOT))
from qa.score import evaluate
from evidence import valid_check, suite_passed, performance_valid, collect

IDENTITY = {'commit': 'a' * 40, 'source_sha256': 'b' * 64}


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.path = self.root / 'results.json'
        self.path.write_text(json.dumps({'testResults': [{'name': '/tests/property/v3.test.ts', 'assertionResults': [{'status': 'passed'}]}]}))
        self.check = {**IDENTITY, 'after': IDENTITY.copy(), 'exitCode': 0, 'command': ['npm', 'test'],
                      'artifacts': [{'path': 'results.json', 'sha256': hashlib.sha256(self.path.read_bytes()).hexdigest()}]}

    def test_current_success_with_real_assertions(self):
        self.assertTrue(valid_check(self.root, self.check, IDENTITY))
        self.assertTrue(suite_passed(self.root, self.check, 'property/v3.test.ts'))
        self.assertFalse(suite_passed(self.root, self.check, 'world/missing.test.ts'))

    def test_rejects_stale_legacy_failed_and_changed_source(self):
        for patch in [{'commit': 'c' * 40}, {'source_sha256': 'c' * 64}, {'exitCode': 1}, {'after': {}}, {'artifacts': []}]:
            self.assertFalse(valid_check(self.root, {**self.check, **patch}, IDENTITY), patch)
        self.assertFalse(valid_check(self.root, {'exitCode': 0, 'command': 'npm test'}, IDENTITY))

    def test_artifact_tampering_and_missing_files(self):
        self.path.write_text('tampered')
        self.assertFalse(valid_check(self.root, self.check, IDENTITY))
        self.path.unlink()
        self.assertFalse(valid_check(self.root, self.check, IDENTITY))

    def test_empty_skipped_and_failed_assertions_are_not_success(self):
        for assertions in [[], [{'status': 'pending'}], [{'status': 'failed'}]]:
            self.path.write_text(json.dumps({'testResults': [{'name': 'property/v3.test.ts', 'assertionResults': assertions}]}))
            self.assertFalse(suite_passed(self.root, self.check, 'property/v3.test.ts'))

    def test_browser_requires_v3_result(self):
        spec = {'file': 'e2e/v3-gauntlet.spec.ts', 'ok': True, 'tests': [{'results': [{'status': 'passed'}]}]}
        self.path.write_text(json.dumps({'suites': [{'specs': [spec]}]}))
        self.assertTrue(suite_passed(self.root, self.check, 'v3-gauntlet.spec.ts', True))
        self.assertFalse(suite_passed(self.root, self.check, 'v2-gauntlet.spec.ts', True))
        spec['tests'][0]['results'][0]['status'] = 'skipped'
        self.path.write_text(json.dumps({'suites': [{'specs': [spec]}]}))
        self.assertFalse(suite_passed(self.root, self.check, 'v3-gauntlet.spec.ts', True))

    def test_missing_reports_never_pass(self):
        evidence = collect(self.root, IDENTITY)
        self.assertTrue(all(g['status'] != 'PASS' for g in evidence['gates'].values()))
        self.assertTrue(all(c['score'] is None for c in evidence['criteria'].values()))


    def test_existing_scorer_rejects_missing_gate_stale_identity_and_failed_criterion(self):
        rubric = json.loads((ROOT / 'qa/SCORECARD.json').read_text())
        artifacts = ['results.json']
        proof = {**IDENTITY,
                 'gates': {name: {'status': 'PASS', 'artifacts': artifacts} for name in rubric['hard_gates']},
                 'criteria': {name: {'status': 'PASS', 'score': 100, 'artifacts': artifacts, 'rationale': 'fixture'} for name in rubric['criteria']}}
        def score(value, fingerprint=IDENTITY['source_sha256']):
            return evaluate(value, rubric, IDENTITY['commit'], self.root, fingerprint)
        self.assertEqual(score(proof)['status'], 'PASS')
        self.assertEqual(score(proof, 'c' * 64)['status'], 'FAIL')
        self.assertIsNone(score(proof, 'c' * 64)['score'])
        missing = copy.deepcopy(proof)
        del missing['gates']['browser_smoke']
        self.assertIsNone(score(missing)['score'])
        failed = copy.deepcopy(proof)
        failed['criteria']['battle_depth']['status'] = 'FAIL'
        self.assertIn('criterion:battle_depth', score(failed)['failures'])
        failed = copy.deepcopy(proof)
        failed['criteria']['battle_depth']['score'] = 40
        self.assertIn('minimum:battle_depth', score(failed)['failures'])

    def test_reference_contract_and_budget_cannot_be_weakened_by_report(self):
        run = {'sampleSeconds': 120, 'biomes': ['meadow', 'forest', 'desert', 'ice', 'volcanic'],
               'battleObserved': True, 'panelObserved': True, 'frames': 7200, 'p95Ms': 16.7, 'p99Ms': 18,
               'drawCalls': 100, 'triangles': 100000, 'queryMs': 1, 'simPerTickMs': 1,
               'activeChunks': 25, 'residentChunks': 49, 'maxSubsteps': 5}
        report = {**IDENTITY, 'after': IDENTITY.copy(), 'status': 'MEASURED_ON_REFERENCE',
                  'device': {'chip': 'Apple M1', 'memoryBytes': 8 * 1024**3, 'acPower': True},
                  'software': False, 'headless': False, 'production': True, 'foreground': True,
                  'viewport': {'width': 1440, 'height': 900}, 'dpr': 1.5, 'warmupSeconds': 10,
                  'errors': [], 'recovery': {'restoredLost': False}, 'disposalVerified': True,
                  'resourceCyclesVerified': True, 'runs': [copy.deepcopy(run) for _ in range(3)]}
        self.assertTrue(performance_valid(report, IDENTITY))
        for key, value in [('headless', True), ('production', False), ('foreground', False), ('software', True), ('dpr', 2)]:
            self.assertFalse(performance_valid({**report, key: value}, IDENTITY), key)
        for key, value in [('chip', 'Apple M1 Pro'), ('memoryBytes', 16 * 1024**3), ('acPower', False)]:
            self.assertFalse(performance_valid({**report, 'device': {**report['device'], key: value}}, IDENTITY), key)
        bad = copy.deepcopy(report)
        bad['runs'][0]['p95Ms'] = 21
        bad['budget'] = {'p95Ms': 1000}
        self.assertFalse(performance_valid(bad, IDENTITY))
        bad = copy.deepcopy(report)
        bad['runs'][0]['battleObserved'] = False
        self.assertFalse(performance_valid(bad, IDENTITY))
        self.assertFalse(performance_valid(report, {**IDENTITY, 'source_sha256': 'd' * 64}))


if __name__ == '__main__':
    unittest.main()
