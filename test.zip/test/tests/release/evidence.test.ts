import { execFileSync } from 'node:child_process';
import { describe, expect, it } from 'vitest';

// Unit tests never rebind old reports or overwrite release evidence. Collection is explicit:
// python3 tests/qa/run_gates.py && python3 tests/release/evidence.py
 describe('release evidence provenance', () => {
  it('rejects stale reports, tampered artifacts, empty suites and invalid reference measurements', () => {
    const output = execFileSync('python3', ['-m', 'unittest', 'discover', '-s', 'tests/release', '-p', 'test_*.py', '-v'],
      { encoding: 'utf8', stdio: 'pipe' });
    expect(output).toBe('');
  });
});
