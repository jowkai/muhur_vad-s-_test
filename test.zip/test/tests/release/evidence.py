"""Collect current, source-bound gate results. Never trust legacy success summaries."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]


def same_identity(record, identity):
    return all(record.get(key) == identity.get(key) for key in ('commit', 'source_sha256'))


def valid_artifact(root, artifact):
    path = (root / artifact.get('path', '')).resolve()
    return (path.is_relative_to(root.resolve()) and path.is_file() and path.stat().st_size > 0
            and hashlib.sha256(path.read_bytes()).hexdigest() == artifact.get('sha256'))


def valid_check(root, check, identity):
    return (same_identity(check, identity) and same_identity(check.get('after', {}), identity)
            and check.get('exitCode') == 0 and isinstance(check.get('command'), list)
            and bool(check.get('artifacts')) and all(valid_artifact(root, a) for a in check['artifacts']))


def suite_passed(root, check, suffix, browser=False):
    """Require actual successful assertions, not just an exit code or an empty suite."""
    for artifact in check.get('artifacts', []):
        if not artifact['path'].endswith('.json'):
            continue
        data = json.loads((root / artifact['path']).read_text())
        if browser:
            def specs(suites):
                for suite in suites:
                    yield from suite.get('specs', [])
                    yield from specs(suite.get('suites', []))
            found = [s for s in specs(data.get('suites', [])) if s.get('file', '').endswith(suffix)]
            if found and all(s.get('ok') and s.get('tests') and all(
                    t.get('results') and all(r.get('status') == 'passed' for r in t['results'])
                    for t in s['tests']) for s in found):
                return True
        else:
            found = [s for s in data.get('testResults', []) if s.get('name', '').endswith(suffix)]
            if found and all(s.get('assertionResults') and all(
                    a.get('status') == 'passed' for a in s['assertionResults']) for s in found):
                return True
    return False


def performance_valid(report, identity):
    """Fixed contract constants, not budgets chosen by the measured report itself."""
    if not same_identity(report, identity) or not same_identity(report.get('after', {}), identity):
        return False
    if not (report.get('status') == 'MEASURED_ON_REFERENCE' and report.get('device', {}).get('chip') == 'Apple M1'
            and report.get('device', {}).get('memoryBytes') == 8 * 1024**3
            and report.get('software') is False and report.get('headless') is False
            and report.get('production') is True and report.get('foreground') is True
            and report.get('device', {}).get('acPower') is True
            and report.get('viewport') == {'width': 1440, 'height': 900}
            and 0 < report.get('dpr', 0) <= 1.5 and report.get('warmupSeconds', 0) >= 10
            and report.get('errors') == [] and report.get('recovery', {}).get('restoredLost') is False
            and report.get('disposalVerified') is True and report.get('resourceCyclesVerified') is True):
        return False
    runs = report.get('runs', [])
    return len(runs) == 3 and all(
        r.get('sampleSeconds', 0) >= 120 and r.get('biomes') == ['meadow', 'forest', 'desert', 'ice', 'volcanic']
        and r.get('battleObserved') is True and r.get('panelObserved') is True
        and r.get('frames', 0) >= 2400 and r.get('p95Ms', float('inf')) <= 20
        and r.get('p99Ms', float('inf')) <= 33.4 and r.get('drawCalls', float('inf')) <= 150
        and r.get('triangles', float('inf')) <= 300000 and r.get('queryMs', float('inf')) <= 2
        and r.get('simPerTickMs', float('inf')) <= 4 and r.get('activeChunks', float('inf')) <= 25
        and r.get('residentChunks', float('inf')) <= 49 and r.get('maxSubsteps', float('inf')) <= 5
        for r in runs)


def collect(root, identity):
    index_path = root / '.reports/current-checks.json'
    index = json.loads(index_path.read_text()) if index_path.exists() else {}
    groups = {}
    for group, name in index.items():
        path = (root / name).resolve()
        if path.is_relative_to(root.resolve()) and path.is_file():
            groups[group] = json.loads(path.read_text()).get('checks', [])
    def group_ok(group):
        checks = groups.get(group, [])
        expected = {'static': [['npm', 'run', 'typecheck'], ['npm', 'run', 'lint']],
                    'build': [['npm', 'run', 'build']]}
        return bool(checks) and all(valid_check(root, c, identity) for c in checks) and (
            group not in expected or [c['command'] for c in checks] == expected[group])
    def suite(path, browser=False, group='unit'):
        if browser:
            group = 'browser'
        return group_ok(group) and any(suite_passed(root, c, path, browser) for c in groups[group])
    unit_dirs = ['contracts', 'save', 'content', 'world', 'combat', 'render', 'ui', 'integration', 'qa']
    def directory(name):
        paths = list((root / 'tests' / name).glob('*.test.ts'))
        return bool(paths) and all(suite(str(p.relative_to(root)).replace('tests/', '')) for p in paths)
    property_ok = bool(list((root / 'tests/property').glob('*.test.ts'))) and group_ok('property') and all(suite('property/' + p.name, group='property')
                    for p in (root / 'tests/property').glob('*.test.ts'))
    browser_paths = list((root / 'tests/e2e').glob('*.spec.ts')) + list((root / 'tests/qa').glob('*.spec.ts'))
    browser_ok = bool(browser_paths) and all(suite(p.name, browser=True) for p in browser_paths)
    performance_path = root / '.reports/reference-performance.json'
    performance = json.loads(performance_path.read_text()) if performance_path.exists() else {}
    perf_ok = performance_valid(performance, identity)
    checks = {name: directory(name) for name in unit_dirs}
    gate_values = {
        'build': group_ok('static') and group_ok('build') and checks['qa'],
        'world_safety': checks['world'] and checks['content'] and property_ok,
        'battle_integrity': checks['combat'] and checks['contracts'] and property_ok,
        'save_integrity': checks['save'] and checks['integration'] and suite('save-adapter.spec.ts', True) and suite('battle-reload.spec.ts', True),
        'browser_smoke': browser_ok and suite('v3-gauntlet.spec.ts', True),
        'performance': perf_ok,
    }
    output = root / '.loop/evidence'
    artifacts = output / 'current-artifacts'
    artifacts.mkdir(parents=True, exist_ok=True)
    copied = []
    for group, entries in groups.items():
        for check in entries:
            if not valid_check(root, check, identity):
                continue
            for artifact in check['artifacts']:
                source = root / artifact['path']
                target = artifacts / (artifact['sha256'] + source.suffix)
                shutil.copyfile(source, target)
                copied.append(str(target.relative_to(output)))
    # The manifest is evidence of missing gates too; it does not turn them into passes.
    manifest = artifacts / 'manifest.json'
    manifest.write_text(json.dumps({'identity': identity, 'groups': groups}, indent=2))
    copied = sorted(set(copied + [str(manifest.relative_to(output))]))
    if performance:
        target = artifacts / 'reference-performance.json'
        shutil.copyfile(performance_path, target)
        copied.append(str(target.relative_to(output)))
    dependencies = {
        'build': ['static', 'build', 'unit'], 'world_safety': ['unit', 'property'],
        'battle_integrity': ['unit', 'property'], 'save_integrity': ['unit', 'browser'],
        'browser_smoke': ['browser'], 'performance': [],
    }
    def failure(name):
        return any(same_identity(c, identity) and c.get('exitCode') != 0
                   for group in dependencies[name] for c in groups.get(group, []))
    gates = {name: {'status': 'PASS' if ok else 'FAIL' if failure(name) else 'NOT_MEASURED', 'artifacts': copied,
                   'rationale': 'Current identity, successful nonempty suites and artifact hashes required.'}
             for name, ok in gate_values.items()}
    # Missing/stale proof cannot earn points. Automated checks do not claim a visual review.
    criteria_checks = {
        'world_biomes_connectivity': [checks['world'], property_ok, suite('biomes.spec.ts', True)],
        'threejs_camera_render_performance': [checks['render'], perf_ok],
        'minimap_encounters': [suite('ui/minimap.test.ts'), checks['world'], browser_ok],
        'battle_capture_progression': [checks['combat'], browser_ok],
        'inventory_alchemy': [checks['content'], suite('ui/alchemy.test.ts'), browser_ok],
        'save_recovery': [checks['save'], checks['integration'], gate_values['save_integrity']],
        'usability_visual_identity': [checks['ui'], checks['qa'], browser_ok],
        'battle_depth': [checks['combat'], property_ok, suite('v2-gauntlet.spec.ts', True)],
        'world_purpose': [checks['world'], checks['content'], checks['integration'], suite('v3-gauntlet.spec.ts', True)],
        'presentation': [checks['ui'], checks['render'], suite('sprites.spec.ts', True)],
    }
    review_path = root / '.reports/visual-review.json'
    review = json.loads(review_path.read_text()) if review_path.exists() else {}
    reviewed = (same_identity(review, identity) and review.get('approved') is True
                and review.get('reviewer') == 'independent-read-only' and review.get('findings') == []
                and bool(review.get('artifacts')) and all(valid_artifact(root, a) for a in review['artifacts']))
    if reviewed:
        target = artifacts / 'visual-review.json'
        shutil.copyfile(review_path, target)
        copied.append(str(target.relative_to(output)))
    criteria_checks['usability_visual_identity'].append(reviewed)
    criteria_checks['presentation'].append(reviewed)
    criteria = {}
    for name, values in criteria_checks.items():
        ok = all(values)
        criteria[name] = {'status': 'PASS' if ok else 'NOT_MEASURED', 'score': 100 if ok else None,
                          'artifacts': copied, 'rationale': f'{sum(values)}/{len(values)} current automated checks; visual quality requires separate read-only review.'}
    evidence = {**identity, 'version': 1, 'gates': gates, 'criteria': criteria}
    (output / 'evidence.json').write_text(json.dumps(evidence, indent=2))
    return evidence


if __name__ == '__main__':
    identity = json.loads(subprocess.check_output(['python3', 'qa/score_current.py', '--identity'], cwd=ROOT, text=True))
    collect(ROOT, identity)
    raise SystemExit(subprocess.call(['python3', 'qa/score_current.py'], cwd=ROOT))
