import { describe, expect, it } from 'vitest';
import { IndexedDbSave, type FaultPoint } from '../../src/game/save/indexeddb';

type State = { seals: number; xp: number };
function validate(value: unknown): asserts value is State {
  if (!value || typeof value !== 'object' || !('seals' in value) || !('xp' in value) ||
    !Number.isSafeInteger(value.seals) || (value.seals as number) < 0 || !Number.isSafeInteger(value.xp)) throw new Error('invalid');
}
const options = () => ({ name: crypto.randomUUID(), initial: () => ({ seals: 3, xp: 0 }), validate });
async function putRaw(name: string, value: unknown) {
  const request = indexedDB.open(name, 1);
  await new Promise<void>((resolve, reject) => {
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const db = request.result;
      const tx = db.transaction('records', 'readwrite');
      tx.objectStore('records').put(value, 'current');
      tx.oncomplete = () => { db.close(); resolve(); };
      tx.onabort = () => { db.close(); reject(tx.error); };
    };
  });
}

describe('IndexedDB save adapter', () => {
  it('loads empty storage, then persists a result and its prior backup', async () => {
    const opts = options();
    let save = await IndexedDbSave.open(opts);
    expect(await save.load()).toBeNull();
    await save.transact('init', () => undefined);
    await save.transact('reward', (draft) => { draft.xp += 16; });
    save.close(); save = await IndexedDbSave.open(opts);
    expect(await save.load()).toEqual({ seals: 3, xp: 16 });
    const raw = await save.exportRaw();
    expect(raw.records.find(([key]) => key === 'backup')?.[1]).toEqual({ version: 2, state: { seals: 3, xp: 0 } });
    expect(raw.commands).toHaveLength(2);
    save.close();
  });
  it('deduplicates concurrently across connections and returns the original result after later commands', async () => {
    const opts = options();
    const a = await IndexedDbSave.open(opts), b = await IndexedDbSave.open(opts);
    let calls = 0;
    const results = await Promise.all(Array.from({ length: 50 }, (_, i) => (i % 2 ? a : b).transact('capture', (draft) => { calls++; draft.seals--; })));
    expect(calls).toBe(1);
    expect(results.every((state) => state.seals === 2)).toBe(true);
    await b.transact('reward', (draft) => { draft.xp += 16; });
    a.close();
    const reopened = await IndexedDbSave.open(opts);
    expect(await reopened.transact('capture', () => { throw new Error('must not execute'); })).toEqual({ seals: 2, xp: 0 });
    expect(await reopened.load()).toEqual({ seals: 2, xp: 16 });
    b.close(); reopened.close();
  });
  it.each<FaultPoint>(['after-backup', 'after-state', 'after-ledger'])('rolls every store back after fault at %s and retries once', async (point) => {
    const opts = options();
    let save = await IndexedDbSave.open(opts);
    await save.transact('init', () => undefined);
    const before = await save.exportRaw();
    save.close();
    save = await IndexedDbSave.open({ ...opts, fault: (at) => { if (at === point) throw new DOMException('full', 'QuotaExceededError'); } });
    await expect(save.transact('reward', (draft) => { draft.xp += 50; })).rejects.toMatchObject({ code: 'quota' });
    expect(await save.exportRaw()).toEqual(before);
    save.close(); save = await IndexedDbSave.open(opts);
    await save.transact('reward', (draft) => { draft.xp += 50; });
    expect(await save.load()).toEqual({ seals: 3, xp: 50 });
    save.close();
  });
  it('rejects invalid and async mutations without writing data or ledger', async () => {
    const save = await IndexedDbSave.open(options());
    await expect(save.transact('bad', (draft) => { draft.seals = -1; })).rejects.toBeDefined();
    await expect(save.transact('async', async (draft) => { await Promise.resolve(); draft.seals--; })).rejects.toMatchObject({ code: 'mutation' });
    expect(await save.load()).toBeNull();
    expect((await save.exportRaw()).commands).toHaveLength(0);
    save.close();
  });
  it('migrates v1 atomically and preserves the original backup', async () => {
    const opts = options();
    const save = await IndexedDbSave.open(opts);
    const legacy = { version: 1, data: { seals: 8, xp: 12 } };
    await putRaw(opts.name, legacy);
    expect(await save.load()).toEqual(legacy.data);
    const raw = await save.exportRaw();
    expect(raw.records.find(([key]) => key === 'backup')?.[1]).toEqual(legacy);
    expect(raw.records.find(([key]) => key === 'current')?.[1]).toEqual({ version: 2, state: legacy.data });
    save.close();
  });
  it.each([null, { version: 2, state: { seals: -1 } }, { version: 99, state: { seals: 3, xp: 0 } }])('preserves unsupported or corrupt data for export', async (raw) => {
    const opts = options(); const save = await IndexedDbSave.open(opts);
    await putRaw(opts.name, raw);
    await expect(save.load()).rejects.toMatchObject({ code: raw?.version === 99 ? 'version' : 'corrupt' });
    await expect(save.transact('overwrite', () => undefined)).rejects.toBeDefined();
    expect((await save.exportRaw()).records).toEqual([['current', raw]]);
    save.close();
  });
});
