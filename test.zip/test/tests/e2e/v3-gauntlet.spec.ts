import { expect, test, type Page } from '@playwright/test';

interface Snapshot {
  position: { x: number; z: number }; mode: string; panel: string | null;
  inventory: (string | null)[]; consumed: number;
  nearby: { entityId: string; name: string; kind: string; enabled: boolean } | null;
  party: string[]; playerName: string; mount: string | null;
  grafts: { creatureId: string; moveId: string }[]; speedEffects: string[];
  battle: { turn: number; outcome: string | null; ambushed: boolean } | null;
}
interface Node {
  entityId: string; method: string; itemId: string;
  position: { x: number; z: number }; nightOnly: boolean; hidden: boolean;
  treeKind: string | null; autoPick: boolean;
}
interface Host {
  __muhurTestBridge: {
    snapshot(): Snapshot; nodes(): Node[];
    walkTo(x: number, z: number, maxTicks?: number): boolean;
    aggressors(): { entityId: string; level: number; position: { x: number; z: number } }[];
    checkpoint(): Promise<void>;
  };
}
const bridge = (page: Page) => ({
  snapshot: () => page.evaluate(() => (globalThis as unknown as Host).__muhurTestBridge.snapshot()),
  nodes: () => page.evaluate(() => (globalThis as unknown as Host).__muhurTestBridge.nodes()),
  walkTo: (x: number, z: number, maxTicks?: number) =>
    page.evaluate(([x, z, ticks]) => (globalThis as unknown as Host).__muhurTestBridge.walkTo(x!, z!, ticks ?? undefined), [x, z, maxTicks ?? null]),
  aggressors: () => page.evaluate(() => (globalThis as unknown as Host).__muhurTestBridge.aggressors()),
  checkpoint: () => page.evaluate(() => (globalThis as unknown as Host).__muhurTestBridge.checkpoint()),
});
const count = (snapshot: Snapshot, itemId: string) => snapshot.inventory
  .filter((stack): stack is string => !!stack && stack.startsWith(`${itemId}:`))
  .reduce((sum, stack) => sum + Number(stack.split(':')[1]), 0);
const reach = (a: { x: number; z: number }, b: { x: number; z: number }) => Math.hypot(a.x - b.x, a.z - b.z);
async function boot(page: Page): Promise<void> {
  await page.waitForFunction(() => '__muhurTestBridge' in globalThis, null, { timeout: 30_000 });
  await page.locator('.mv-stage canvas').first().click({ position: { x: 400, y: 300 } });
}

test.describe('the v3 loop in a real browser', () => {
  test('renames the player, grafts a move, rides out, fells a tree and picks material up in passing', async ({ page }) => {
    test.setTimeout(240_000);
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    await page.goto('/tests/e2e/v3-seed.html');
    await expect(page.locator('#state')).toContainText('hazır:6');
    await page.goto('/');
    await boot(page);
    const api = bridge(page);

    // The top left carries the profile card; the dock carries the six bigger slots with role badges.
    await expect(page.locator('.mv-profile')).toBeVisible();
    await expect(page.locator('.mv-party .mv-party-slot')).toHaveCount(6);
    await expect(page.locator('.mv-party .mv-party-role').first()).toBeVisible();
    const slot = await page.locator('.mv-party .mv-party-slot').first().boundingBox();
    expect(slot!.width).toBeGreaterThanOrEqual(100);

    // The name is typed into the card itself and lands in the record.
    await page.locator('.mv-profile-name').click();
    await page.locator('.mv-profile-input').fill('Vadi Bekçisi');
    await page.locator('.mv-profile-input').press('Enter');
    await expect.poll(() => api.snapshot().then((s) => s.playerName), { timeout: 10_000 }).toBe('Vadi Bekçisi');
    await expect(page.locator('.mv-profile-name')).toContainText('Vadi Bekçisi');

    // A graft is a camp job: pick the creature, then the graft in the bag.
    await page.locator('nav.mv-tabbar button', { hasText: 'Kamp' }).click();
    const camp = page.locator('.mv-panel');
    await camp.locator('button', { hasText: 'Kabukcan' }).first().click();
    // The bag row selects on the first press and acts on the second.
    const graftRow = camp.locator('button', { hasText: 'Yıldız Aşısı' }).first();
    await graftRow.click();
    await graftRow.click();
    await expect.poll(() => api.snapshot().then((s) => s.grafts.length), { timeout: 10_000 }).toBe(1);
    expect((await api.snapshot()).grafts[0]!.moveId).toBe('starfall');
    expect(count(await api.snapshot(), 'graft_starfall')).toBe(0);
    await page.keyboard.press('Escape');
    await expect.poll(() => api.snapshot().then((s) => s.panel)).toBeNull();

    // R climbs on the grown mount, and the same key gets the player off again.
    await page.keyboard.press('r');
    await expect.poll(() => api.snapshot().then((s) => s.mount), { timeout: 10_000 }).toBe('p0');
    const home = (await api.snapshot()).position;
    const far = { x: home.x + 400, z: home.z };
    await page.evaluate(([x, z]) => (globalThis as unknown as Host).__muhurTestBridge.walkTo(x!, z!, 240), [far.x, far.z]);
    const ridden = reach(home, (await api.snapshot()).position);
    await page.keyboard.press('r');
    await expect.poll(() => api.snapshot().then((s) => s.mount), { timeout: 10_000 }).toBeNull();
    const before = (await api.snapshot()).position;
    await page.evaluate(([x, z]) => (globalThis as unknown as Host).__muhurTestBridge.walkTo(x!, z!, 240), [far.x, far.z]);
    const walked = reach(before, (await api.snapshot()).position);
    expect(ridden, 'binek yürümekten hızlıdır').toBeGreaterThan(walked);

    // Loose material is taken in passing: no card, no key press.
    const loose = (await api.nodes()).filter((node) => node.autoPick && !node.nightOnly && !node.hidden)
      .sort((a, b) => reach(before, a.position) - reach(before, b.position))[0];
    expect(loose, 'yakında otomatik alınacak malzeme yok').toBeTruthy();
    const heldBefore = count(await api.snapshot(), loose!.itemId);
    await api.walkTo(loose!.position.x, loose!.position.z);
    await expect.poll(() => api.snapshot().then((s) => count(s, loose!.itemId)), { timeout: 20_000 })
      .toBeGreaterThan(heldBefore);
    expect((await api.snapshot()).nearby?.entityId, 'malzeme kart açmaz').not.toBe(loose!.entityId);

    // A standing tree does ask for a key, and the clawed team in the party may answer.
    const at = (await api.snapshot()).position;
    const tree = (await api.nodes()).filter((node) => node.treeKind && !node.nightOnly)
      .sort((a, b) => reach(at, a.position) - reach(at, b.position))[0];
    expect(tree, 'yakında ağaç yok').toBeTruthy();
    await api.walkTo(tree!.position.x, tree!.position.z);
    await expect.poll(() => api.snapshot().then((s) => s.nearby?.entityId), { timeout: 20_000 }).toBe(tree!.entityId);
    const logsBefore = count(await api.snapshot(), tree!.itemId);
    for (let attempt = 0; attempt < 10; attempt++) {
      await page.keyboard.press('Enter');
      await page.waitForTimeout(300);
      if (count(await api.snapshot(), tree!.itemId) > logsBefore) break;
    }
    expect(count(await api.snapshot(), tree!.itemId), 'ağaç kesildi').toBeGreaterThan(logsBefore);

    // The record survives the reload with the name, the graft and the felled tree intact.
    await api.checkpoint();
    await page.reload();
    await boot(page);
    const reloaded = await bridge(page).snapshot();
    expect(reloaded.playerName).toBe('Vadi Bekçisi');
    expect(reloaded.grafts).toHaveLength(1);
    expect(count(reloaded, tree!.itemId)).toBeGreaterThan(logsBefore);
    expect(errors, errors.join('\n')).toEqual([]);
  });

  test('warns before a patrol strikes, and only then opens the battle', async ({ page }) => {
    test.setTimeout(240_000);
    // The recorder is installed before the page runs, so a warning that fires during the first
    // second of play is still caught; a frame recorder never misses a third-of-a-second alert.
    await page.addInitScript(() => {
      const log: { warned: boolean; battle: boolean }[] = [];
      (globalThis as unknown as { __log: typeof log }).__log = log;
      const bridge = () => (globalThis as unknown as { __muhurTestBridge?: { snapshot(): { battle: unknown } } }).__muhurTestBridge;
      const tick = () => {
        const alert = document.querySelector('.mv-warning') as HTMLElement | null;
        log.push({ warned: !!alert && !alert.hidden && !!alert.textContent, battle: !!bridge()?.snapshot().battle });
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
    await page.goto('/tests/e2e/v3-danger-seed.html');
    await expect(page.locator('#state')).toContainText('hazır:');
    await page.goto('/');
    await boot(page);
    const api = bridge(page);
    // Walk straight at creatures that hunt on their own; the world must warn before it strikes.
    let caught = false;
    for (let sweep = 0; sweep < 10 && !caught; sweep++) {
      const here = (await api.snapshot()).position;
      const hunters = (await api.aggressors()).sort((a, b) => reach(here, a.position) - reach(here, b.position));
      const hunter = hunters[0];
      if (!hunter) { await api.walkTo(here.x + 40, here.z + 30, 4_000); continue; }
      await api.walkTo(hunter.position.x, hunter.position.z, 8_000);
      await page.waitForTimeout(1_500);
      caught = !!(await api.snapshot()).battle;
    }
    const log = await page.evaluate(() => (globalThis as unknown as { __log: { warned: boolean; battle: boolean }[] }).__log);
    expect(log.length, 'kare kaydı boş').toBeGreaterThan(30);
    expect(log.some((frame) => frame.warned), 'hiç uyarı görülmedi').toBe(true);
    // The patrol did catch the player, and the warning always came first.
    expect(caught, 'devriye oyuncuyu yakalamadı').toBe(true);
    const opened = log.findIndex((frame) => frame.battle);
    expect(opened, 'savaş kaydı yok').toBeGreaterThan(0);
    expect(log.slice(0, opened).some((frame) => frame.warned), 'savaş uyarısız açıldı').toBe(true);
    // And the fight is a real one the player can answer, not a frozen world.
    await expect(page.locator('.mv-battle, [aria-label="Savaş"]').first()).toBeVisible();
  });
});


test('a deterministic night ambush warns and opens without pressing Enter', async ({ page }) => {
  await page.addInitScript(() => {
    const frames: { warning: boolean; battle: boolean }[] = [];
    (globalThis as unknown as { __ambushFrames: typeof frames }).__ambushFrames = frames;
    const record = () => {
      const warning = document.querySelector('.mv-warning') as HTMLElement | null;
      const battle = document.querySelector('.mv-battle') as HTMLElement | null;
      frames.push({ warning: !!warning && !warning.hidden && !!warning.textContent, battle: !!battle && !battle.hidden });
      requestAnimationFrame(record);
    };
    requestAnimationFrame(record);
  });
  await page.goto('/tests/e2e/v3-danger-seed.html?ambush=1');
  await expect(page.locator('#state')).toContainText('hazır:');
  await page.goto('/');
  await page.waitForFunction(() => '__muhurTestBridge' in globalThis);
  await expect.poll(() => bridge(page).snapshot().then((s) => s.battle?.ambushed), { timeout: 15000 }).toBe(true);
  await expect(page.locator('.mv-battle:not([hidden])')).toBeVisible();
  const frames = await page.evaluate(() => (globalThis as unknown as { __ambushFrames: { warning: boolean; battle: boolean }[] }).__ambushFrames);
  const opened = frames.findIndex((f) => f.battle);
  expect(opened).toBeGreaterThan(0);
  expect(frames.slice(0, opened).some((f) => f.warning)).toBe(true);
});
