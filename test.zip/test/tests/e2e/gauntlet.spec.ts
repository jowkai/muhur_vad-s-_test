import { expect, test, type Page } from '@playwright/test';

const SAVE = 'muhur-vadisi';
interface BridgeSnapshot {
  position: { x: number; z: number }; mode: string; panel: string | null; biome: string;
  movementAllowed: boolean; nearby: { entityId: string; name: string; kind: string; enabled: boolean } | null;
  team: { id: string; speciesId: string; level: number; xp: number; hp: number }[];
  inventory: (string | null)[]; eggs: number; consumed: number; recipes: number; discovered: number;
  battle: { turn: number; playerHp: number; enemyHp: number; outcome: string | null } | null;
}
interface BridgeHost {
  __muhurTestBridge: {
    snapshot(): BridgeSnapshot;
    walkTo(x: number, z: number, maxTicks?: number): boolean;
    checkpoint(): Promise<void>;
  };
}
const bridge = (page: Page) => ({
  snapshot: () => page.evaluate(() => (globalThis as unknown as BridgeHost).__muhurTestBridge.snapshot() as BridgeSnapshot),
  walkTo: (x: number, z: number) => page.evaluate(([x, z]) => (globalThis as unknown as BridgeHost).__muhurTestBridge.walkTo(x, z) as boolean, [x, z]),
  checkpoint: () => page.evaluate(() => (globalThis as unknown as BridgeHost).__muhurTestBridge.checkpoint()),
});
async function boot(page: Page): Promise<void> {
  await page.waitForFunction(() => '__muhurTestBridge' in globalThis, null, { timeout: 30_000 });
  await page.locator('.mv-stage canvas').first().click({ position: { x: 400, y: 300 } });
}
/** Counts pixels the minimap actually painted, so a blank dial cannot pass as a drawn one. */
const minimapInk = (page: Page) => page.evaluate(() => {
  const canvas = document.querySelector('.mv-minimap canvas') as HTMLCanvasElement;
  const context = canvas.getContext('2d')!;
  const { data } = context.getImageData(0, 0, canvas.width, canvas.height);
  let painted = 0;
  for (let index = 0; index < data.length; index += 4) if (data[index + 3] > 0) painted++;
  return { painted, total: data.length / 4 };
});

test.describe('real browser gauntlet', () => {
  test.beforeEach(async ({ page }) => {
    await page.addInitScript((name) => {
      if (sessionStorage.getItem('mv-gauntlet')) return;
      sessionStorage.setItem('mv-gauntlet', '1');
      indexedDB.deleteDatabase(name);
    }, SAVE);
  });

  test('walks, reads the minimap, collects, fights, captures and survives a reload', async ({ page }) => {
    test.setTimeout(180_000);
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    await page.goto('/');
    await boot(page);
    const api = bridge(page);

    const start = await api.snapshot();
    expect(start.mode).toBe('exploring');
    expect(start.team[0]).toMatchObject({ level: 2, xp: 0 });
    expect(start.biome).toBe('Şafak Çayırı');
    const blank = await minimapInk(page);
    expect(blank.painted).toBeGreaterThan(blank.total / 3);

    await page.keyboard.down('KeyD');
    await expect.poll(async () => (await api.snapshot()).position.x, { timeout: 15_000 }).toBeGreaterThan(start.position.x + 3);
    await page.keyboard.up('KeyD');
    // Discovery is reported from the committed record, so flush the pending checkpoint first.
    await api.checkpoint();
    const walked = await api.snapshot();
    expect(walked.discovered).toBeGreaterThan(start.discovered);
    expect(walked.position.z).toBeCloseTo(start.position.z, 1);

    const egg = await page.evaluate(async () => {
      const api = (globalThis as unknown as BridgeHost).__muhurTestBridge;
      for (const point of [{ x: 9, z: 15 }, { x: -15, z: 9 }]) {
        api.walkTo(point.x, point.z);
        const near = api.snapshot().nearby;
        if (near?.kind === 'egg' && near.enabled) return near;
      }
      return null;
    });
    expect(egg, 'an egg must be reachable from camp').not.toBeNull();
    await expect(page.locator('.mv-card h3')).toContainText('Yumurtası');
    await expect(page.locator('.mv-hint')).toHaveText('Enter: Topla');
    const inked = await minimapInk(page);
    expect(inked.painted).toBeGreaterThan(0);
    await page.keyboard.press('Enter');
    await expect.poll(async () => (await api.snapshot()).eggs).toBe(1);
    expect((await api.snapshot()).consumed).toBe(1);
    await page.screenshot({ path: '.reports/qa/gauntlet-collect.png' });

    await api.walkTo(23, -9);
    await expect.poll(async () => (await api.snapshot()).nearby?.kind).toBe('creature');
    await expect(page.locator('.mv-hint')).toHaveText('Enter: Savaş');
    await page.keyboard.press('Enter');
    await expect(page.locator('.mv-battle')).toBeVisible();
    const actions = page.locator('.mv-actions button');
    await expect(actions).toHaveCount(4);
    expect(await actions.nth(1).isDisabled()).toBe(true);
    expect(await actions.nth(3).isDisabled()).toBe(true);
    await expect(page.locator('.mv-side button').first()).toBeDisabled();
    const opened = await api.snapshot();
    expect(opened.mode).toBe('battle');
    expect(opened.battle).toMatchObject({ turn: 1, outcome: null });

    let captured = false;
    for (let turn = 0; turn < 24 && await page.locator('.mv-battle').isVisible(); turn++) {
      if (await page.locator('.mv-side button').first().isEnabled()) { await page.keyboard.press('KeyC'); captured = true; }
      else await page.keyboard.press('1');
      await page.waitForTimeout(220);
    }
    await expect(page.locator('.mv-battle')).toBeHidden();
    expect(captured).toBe(true);
    await page.screenshot({ path: '.reports/qa/gauntlet-battle.png' });
    const settled = await api.snapshot();
    expect(settled.mode).toBe('exploring');
    expect(settled.consumed).toBe(2);
    expect(settled.team.length + settled.team[0].xp).toBeGreaterThan(1);
    expect(settled.movementAllowed).toBe(true);

    await page.keyboard.press('KeyI');
    await expect(page.locator('[role="dialog"][aria-label="Çanta"]')).toBeVisible();
    await expect(page.locator('.mv-panel:not([hidden]) .mv-grid-cell')).toHaveCount(24);
    await expect.poll(async () => (await api.snapshot()).mode).toBe('panel');
    await page.keyboard.press('Escape');
    await expect.poll(async () => (await api.snapshot()).mode).toBe('exploring');

    await page.keyboard.press('KeyB');
    await expect(page.locator('[role="dialog"][aria-label="Yaratık defteri"]')).toBeVisible();
    const journal = page.locator('.mv-panel:not([hidden]) .mv-list').first().locator('button');
    await expect(journal.first()).toBeDisabled();
    if (settled.team.length > 1) {
      await journal.nth(1).click();
      await expect.poll(async () => (await api.snapshot()).team.length).toBe(settled.team.length);
    }
    await page.screenshot({ path: '.reports/qa/gauntlet-journal.png' });
    await page.keyboard.press('Escape');
    await expect.poll(async () => (await api.snapshot()).mode).toBe('exploring');

    const before = (await api.snapshot()).position.x;
    await page.keyboard.press('KeyP');
    await page.keyboard.down('KeyD');
    await page.waitForTimeout(600);
    await page.keyboard.up('KeyD');
    expect((await api.snapshot()).position.x).toBeCloseTo(before, 1);
    await expect(page.locator('.mv-hud .mv-sub')).toContainText('Duraklatıldı');
    await page.keyboard.press('KeyP');
    await page.keyboard.down('KeyD');
    await expect.poll(async () => (await api.snapshot()).position.x, { timeout: 10_000 }).toBeGreaterThan(before + 1);
    await page.keyboard.up('KeyD');

    // Snapshot right before the reload: the journal and pause steps moved the player since.
    const beforeReload = await api.snapshot();
    await api.checkpoint();
    await page.reload();
    await boot(page);
    const resumed = await bridge(page).snapshot();
    expect(resumed.eggs).toBe(beforeReload.eggs);
    expect(resumed.consumed).toBe(beforeReload.consumed);
    expect(resumed.team).toEqual(beforeReload.team);
    expect(resumed.position.x).toBeCloseTo(beforeReload.position.x, 0);
    expect(resumed.discovered).toBeGreaterThanOrEqual(beforeReload.discovered);
    expect(errors).toEqual([]);
  });

  test('crafts all forty recipes through the panel and keeps them after a reload', async ({ page }) => {
    test.setTimeout(180_000);
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    await page.goto('/tests/e2e/craft-seed.html');
    await expect(page.locator('#state')).toContainText('hazır:40');
    const recipeIds = await page.evaluate(() => (globalThis as unknown as { seeded: { recipes: string[] } }).seeded.recipes as string[]);
    await page.goto('/');
    await boot(page);
    const api = bridge(page);
    expect((await api.snapshot()).recipes).toBe(40);

    await page.keyboard.press('KeyC');
    await expect(page.locator('[role="dialog"][aria-label="Simya"]')).toBeVisible();
    const rows = page.locator('.mv-panel:not([hidden]) .mv-list button');
    await expect(rows).toHaveCount(40);
    const produced: string[] = [];
    for (let index = 0; index < recipeIds.length; index++) {
      await rows.nth(index).click();
      const button = page.locator('.mv-panel:not([hidden]) .mv-detail button');
      await expect(button).toBeEnabled();
      const before = await api.snapshot();
      await button.click();
      await expect.poll(async () => JSON.stringify((await api.snapshot()).inventory)).not.toBe(JSON.stringify(before.inventory));
      produced.push(recipeIds[index]);
    }
    expect(produced).toHaveLength(40);
    await page.screenshot({ path: '.reports/qa/gauntlet-alchemy.png' });
    const crafted = await api.snapshot();
    for (const id of ['salve', 'seal', 'egg_feed', 'forest_balm', 'tide_balm', 'waking_salt', 'ember_incense', 'resonant_balm',
      'stone_pick', 'lantern', 'trowel', 'lens', 'training_tonic', 'master_tonic', 'waking_draught', 'field_tonic',
      'swift_tonic', 'gale_tonic', 'graft_starfall', 'graft_cyclone', 'sea_mask', 'moon_oil']) {
      expect(crafted.inventory.some((stack) => stack?.startsWith(`${id}:`)), id).toBe(true);
    }
    await page.keyboard.press('Escape');
    await expect.poll(async () => (await api.snapshot()).mode).toBe('exploring');
    await api.checkpoint();
    await page.reload();
    await boot(page);
    expect((await bridge(page).snapshot()).inventory).toEqual(crafted.inventory);
    expect(errors).toEqual([]);
  });
});
