import { expect, test } from '@playwright/test';

for (const faultPoint of ['after-backup', 'after-state', 'after-ledger'] as const) {
test(`real IndexedDB rolls back ${faultPoint}, deduplicates and survives reload`, async ({ page }) => {
  // Storage throughput test, not a speed test: booting the full game plus 50 transactions and a
  // reload runs well past the 30 s default when the suite is running in parallel.
  test.setTimeout(120_000);
  await page.goto('/');
  const result = await page.evaluate(async (faultPoint) => {
    const modulePath = '/src/game/save/indexeddb.ts';
    const { IndexedDbSave } = await import(/* @vite-ignore */ modulePath) as typeof import('../../src/game/save/indexeddb');
    function validate(value: unknown): asserts value is { seals: number } {
      if (!value || typeof value !== 'object' || !('seals' in value) || !Number.isSafeInteger(value.seals)) throw new Error('invalid');
    }
    const opts = { name: 'save-browser', initial: () => ({ seals: 4 }), validate };
    const a = await IndexedDbSave.open(opts), b = await IndexedDbSave.open(opts);
    let calls = 0;
    await Promise.all(Array.from({ length: 50 }, (_, i) => (i % 2 ? a : b).transact('capture', (draft) => { calls++; draft.seals--; })));
    const before = await a.exportRaw();
    a.close(); b.close();
    const faulty = await IndexedDbSave.open({ ...opts, fault: (point) => { if (point === faultPoint) throw new DOMException('full', 'QuotaExceededError'); } });
    let errorCode = '';
    try { await faulty.transact('another', (draft) => { draft.seals--; }); }
    catch (error) { errorCode = (error as { code: string }).code; }
    const after = await faulty.exportRaw();
    faulty.close();
    return { calls, errorCode, unchanged: JSON.stringify(before) === JSON.stringify(after) };
  }, faultPoint);
  expect(result).toEqual({ calls: 1, errorCode: 'quota', unchanged: true });
  await page.reload();
  const state = await page.evaluate(async () => {
    const modulePath = '/src/game/save/indexeddb.ts';
    const { IndexedDbSave } = await import(/* @vite-ignore */ modulePath) as typeof import('../../src/game/save/indexeddb');
    function validate(value: unknown): asserts value is { seals: number } {
      if (!value || typeof value !== 'object' || !('seals' in value) || !Number.isSafeInteger(value.seals)) throw new Error('invalid');
    }
    const save = await IndexedDbSave.open({ name: 'save-browser', initial: () => ({ seals: 4 }), validate });
    const value = await save.transact('capture', () => { throw new Error('duplicate'); });
    const loaded = await save.load(); save.close(); return { value, loaded };
  });
  expect(state).toEqual({ value: { seals: 3 }, loaded: { seals: 3 } });
});

}

test('real IndexedDB migrates old data and preserves unknown versions for export', async ({ page }) => {
  await page.goto('/');
  const result = await page.evaluate(async () => {
    const modulePath = '/src/game/save/indexeddb.ts';
    const { IndexedDbSave } = await import(/* @vite-ignore */ modulePath) as typeof import('../../src/game/save/indexeddb');
    function validate(value: unknown): asserts value is { seals: number } {
      if (!value || typeof value !== 'object' || !('seals' in value) || !Number.isSafeInteger(value.seals)) throw new Error('invalid');
    }
    const opts = { name: 'migration-browser', initial: () => ({ seals: 4 }), validate };
    const save = await IndexedDbSave.open(opts);
    async function put(raw: unknown) {
      await new Promise<void>((resolve, reject) => {
        const request = indexedDB.open(opts.name, 1);
        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
          const db = request.result, tx = db.transaction('records', 'readwrite');
          tx.objectStore('records').put(raw, 'current');
          tx.oncomplete = () => { db.close(); resolve(); };
          tx.onabort = () => { db.close(); reject(tx.error); };
        };
      });
    }
    await put({ version: 1, data: { seals: 7 } });
    const migrated = await save.load();
    const backup = (await save.exportRaw()).records.find(([key]) => key === 'backup')?.[1];
    await put({ version: 99, state: { seals: 9 } });
    let code = '';
    try { await save.load(); } catch (error) { code = (error as { code: string }).code; }
    const preserved = (await save.exportRaw()).records.find(([key]) => key === 'current')?.[1];
    save.close(); return { migrated, backup, code, preserved };
  });
  expect(result).toEqual({ migrated: { seals: 7 }, backup: { version: 1, data: { seals: 7 } }, code: 'version', preserved: { version: 99, state: { seals: 9 } } });
});
