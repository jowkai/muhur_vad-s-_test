import { expect, test, type Page } from '@playwright/test';

interface Snapshot {
  position: { x: number; z: number }; mode: string; panel: string | null;
  recipes: number; consumed: number; inventory: (string | null)[];
  nearby: { entityId: string; name: string; kind: string; enabled: boolean } | null;
  party: string[]; activeCreatureId: string | null; shrines: string[]; anchors: string[];
  objectives: { done: number; total: number };
  day: { phase: string; secondsLeft: number };
  battle: {
    turn: number; phase: string; activeIndex: number; outcome: string | null;
    party: { id: string; hp: number }[]; playerEffects: string[]; enemyEffects: string[];
  } | null;
}
interface Node { entityId: string; method: string; itemId: string; position: { x: number; z: number }; nightOnly: boolean; hidden: boolean; treeKind: string | null; autoPick: boolean }
interface Host {
  __muhurTestBridge: {
    snapshot(): Snapshot; nodes(): Node[];
    shrines(): { id: string; biomeId: string; position: { x: number; z: number } }[];
    walkTo(x: number, z: number, maxTicks?: number): boolean;
    checkpoint(): Promise<void>;
  };
}
const bridge = (page: Page) => ({
  snapshot: () => page.evaluate(() => (globalThis as unknown as Host).__muhurTestBridge.snapshot()),
  nodes: () => page.evaluate(() => (globalThis as unknown as Host).__muhurTestBridge.nodes()),
  shrines: () => page.evaluate(() => (globalThis as unknown as Host).__muhurTestBridge.shrines()),
  walkTo: (x: number, z: number) => page.evaluate(([x, z]) => (globalThis as unknown as Host).__muhurTestBridge.walkTo(x, z), [x, z]),
  checkpoint: () => page.evaluate(() => (globalThis as unknown as Host).__muhurTestBridge.checkpoint()),
});
async function ready(page: Page): Promise<void> {
  await page.waitForFunction(() => '__muhurTestBridge' in globalThis, null, { timeout: 30_000 });
}
/** The world click unlocks audio; a battle covers the canvas, so only the world route clicks. */
async function boot(page: Page): Promise<void> {
  await ready(page);
  await page.locator('.mv-stage canvas').first().click({ position: { x: 400, y: 300 } });
}

test.describe('the v2 loop in a real browser', () => {
  test('reads a shrine, learns its recipes, travels home and gathers after dark', async ({ page }) => {
    test.setTimeout(180_000);
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    await page.goto('/tests/e2e/v2-seed.html');
    await expect(page.locator('#state')).toContainText('hazır:shrine:forest');
    await page.goto('/');
    await boot(page);
    const api = bridge(page);

    // The dock carries the six slot strip and the five tabs.
    await expect(page.locator('.mv-party .mv-party-slot')).toHaveCount(6);
    await expect(page.locator('nav.mv-tabbar button')).toHaveCount(5);
    await expect(page.locator('.mv-hud .mv-sub')).toContainText('Gece');
    const opening = await api.snapshot();
    expect(opening.party).toHaveLength(6);
    expect(opening.day.phase).toBe('night');
    expect(opening.shrines).toEqual([]);
    expect(opening.anchors).toEqual(['camp']);

    // Standing at the shrine, Enter reads the marks: two recipes and an anchor. Under a loaded
    // machine the first key can arrive before the world finished booting, so it is retried.
    for (let attempt = 0; attempt < 10; attempt++) {
      await page.keyboard.press('Enter');
      await page.waitForTimeout(300);
      if ((await api.snapshot()).shrines.length) break;
    }
    await expect.poll(() => api.snapshot().then((snapshot) => snapshot.recipes), { timeout: 15_000 }).toBe(opening.recipes + 2);
    const read = await api.snapshot();
    expect(read.shrines).toEqual(['forest']);
    expect(read.anchors).toEqual(['camp', 'shrine:forest']);
    expect(read.objectives.done).toBeGreaterThan(0);
    await expect(page.locator('.mv-message')).toContainText('Tapınak');
    await page.screenshot({ path: '.reports/qa/v2-shrine.png' });

    // The objectives tab now opens on a real panel.
    await page.keyboard.press('KeyO');
    await expect.poll(() => api.snapshot().then((snapshot) => snapshot.panel)).toBe('objectives');
    await expect(page.locator('[role="dialog"][aria-label="Hedefler"]')).toBeVisible();
    await expect(page.locator('.mv-panel:not([hidden]) .mv-objective').first()).toBeVisible();
    await page.keyboard.press('Escape');
    // Closing a panel is a transaction of its own; the next panel waits for it.
    await expect.poll(() => api.snapshot().then((snapshot) => snapshot.panel)).toBeNull();

    // Fast travel from the camp panel moves the real player to the camp.
    await page.keyboard.press('KeyK');
    await expect(page.locator('[role="dialog"][aria-label="Kamp"]')).toBeVisible();
    const travelRow = page.locator('.mv-panel:not([hidden]) .mv-list[aria-label="Hızlı seyahat"] button').first();
    await expect(travelRow).toContainText('Kamp');
    await travelRow.click();
    // The trip is one transaction behind the panel closing, so wait for the player, not the mode.
    await expect.poll(() => api.snapshot().then((snapshot) => Math.hypot(snapshot.position.x, snapshot.position.z)), { timeout: 15_000 })
      .toBeLessThan(4);
    const home = await api.snapshot();
    expect(home.mode).toBe('exploring');
    expect(home.panel).toBeNull();

    // A vein opens at once with the pick in the bag; a plain node is picked by hand. Loose
    // material is taken in passing and never asks for a key, so the route skips it, and a
    // standing tree needs claws this team does not have.
    const here = (await api.snapshot()).position;
    const reachable = (await api.nodes())
      .filter((node) => !node.hidden && !node.autoPick && !node.treeKind)
      .sort((a, b) => Math.hypot(a.position.x - here.x, a.position.z - here.z) - Math.hypot(b.position.x - here.x, b.position.z - here.z));
    expect(reachable.length).toBeGreaterThan(0);
    let target: Node | null = null;
    for (const node of reachable.slice(0, 6)) {
      if (await api.walkTo(node.position.x, node.position.z)) { target = node; break; }
    }
    expect(target, 'yürünebilir bir kaynak bulunamadı').not.toBeNull();
    expect((await api.snapshot()).consumed).toBe(0);
    await expect.poll(() => api.snapshot().then((snapshot) => snapshot.nearby?.entityId)).toBe(target!.entityId);
    await page.keyboard.press('Enter');
    await expect.poll(() => api.snapshot().then((snapshot) => snapshot.consumed), { timeout: 15_000 }).toBeGreaterThan(0);
    const gathered = await api.snapshot();
    expect(gathered.inventory.some((stack) => stack?.startsWith(`${target!.itemId}:`))).toBe(true);
    await page.screenshot({ path: '.reports/qa/v2-gather.png' });
    expect(errors).toEqual([]);
  });

  test('switches creatures mid battle, lands a status effect and keeps both across a reload', async ({ page }) => {
    test.setTimeout(180_000);
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    await page.goto('/tests/e2e/v2-battle-seed.html');
    await expect(page.locator('#state')).toContainText('hazır:battle:');
    await page.goto('/');
    await ready(page);
    const api = bridge(page);
    await expect(page.locator('.mv-battle')).toBeVisible();
    await expect(page.locator('.mv-party .mv-party-slot')).toHaveCount(6);

    const opening = await api.snapshot();
    expect(opening.battle?.party).toHaveLength(6);
    expect(opening.battle?.activeIndex).toBe(0);

    // Shift+2 sends the second creature out; the digits stay with the attack buttons.
    await page.keyboard.press('Shift+2');
    await expect.poll(() => api.snapshot().then((snapshot) => snapshot.battle?.activeIndex)).toBe(1);
    const switched = await api.snapshot();
    expect(switched.battle!.turn).toBeGreaterThan(opening.battle!.turn);
    await expect(page.locator('.mv-log')).toContainText('sahaya çıktı');
    await page.screenshot({ path: '.reports/qa/v2-switch.png' });

    // Back to the poisoner and swing its sixth level move until the poison lands.
    await page.keyboard.press('Shift+1');
    await expect.poll(() => api.snapshot().then((snapshot) => snapshot.battle?.activeIndex)).toBe(0);
    for (let turn = 0; turn < 24; turn++) {
      const snapshot = await api.snapshot();
      if (snapshot.battle?.enemyEffects.includes('poison') || snapshot.battle?.outcome) break;
      if (snapshot.battle?.phase === 'FORCED_SWITCH') { await page.keyboard.press('Shift+3'); continue; }
      await page.keyboard.press('4');
      await page.waitForTimeout(220);
    }
    const poisoned = await api.snapshot();
    expect(poisoned.battle?.enemyEffects.concat(poisoned.battle.playerEffects).length ?? 0).toBeGreaterThan(0);
    await expect(page.locator('.mv-log')).toContainText(/zehirlendi|etkilenmedi/);

    const before = await api.snapshot();
    await page.reload();
    await page.waitForFunction(() => '__muhurTestBridge' in globalThis, null, { timeout: 30_000 });
    const after = await bridge(page).snapshot();
    expect(after.battle?.activeIndex).toBe(before.battle?.activeIndex);
    expect(after.battle?.party).toEqual(before.battle?.party);
    expect(after.battle?.enemyEffects).toEqual(before.battle?.enemyEffects);
    expect(after.battle?.playerEffects).toEqual(before.battle?.playerEffects);
    expect(errors).toEqual([]);
  });
});
