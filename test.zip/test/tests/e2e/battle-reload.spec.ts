import { expect, test, type Page } from '@playwright/test';

const SAVE = 'muhur-vadisi';
const tags = (page: Page) => page.locator('.mv-battle .mv-fighter .mv-tags');
const hud = (page: Page) => page.locator('.mv-hud h2');
/** v2 moved the team out of the left panel: the strip under the tabs is the team now. */
const party = (page: Page) => page.locator('.mv-party');
const eggCount = (page: Page) => page.evaluate(() =>
  (globalThis as unknown as { __muhurTestBridge: { snapshot(): { eggs: number } } }).__muhurTestBridge.snapshot().eggs);

async function walkTo(page: Page, keys: string[], done: () => Promise<boolean>, limit = 24_000): Promise<void> {
  const started = Date.now();
  for (const key of keys) await page.keyboard.down(key);
  try {
    while (Date.now() - started < limit) {
      if (await done()) return;
      await page.waitForTimeout(150);
    }
    throw new Error('Hedefe yürünemedi');
  } finally {
    for (const key of keys) await page.keyboard.up(key);
  }
}

test.describe('battle survives a browser reload', () => {
  test.beforeEach(async ({ page }) => {
    // Clear the record once per tab: a reload inside the test must reopen the same save.
    await page.addInitScript((name) => {
      if (sessionStorage.getItem('mv-e2e-cleared')) return;
      sessionStorage.setItem('mv-e2e-cleared', '1');
      indexedDB.deleteDatabase(name);
    }, SAVE);
  });

  test('resumes the same battle after a reload and never pays the reward twice', async ({ page }) => {
    test.setTimeout(120_000);
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    await page.goto('/tests/e2e/battle-seed.html');
    await expect(page.locator('#state')).toContainText('hazır:battle:');
    const seeded = await page.evaluate(() => (window as unknown as { seeded: { enemy: string; maxHp: number } }).seeded);

    await page.goto('/');
    await expect(page.locator('.mv-battle')).toBeVisible();
    await expect(page.locator('.mv-actions button')).toHaveCount(4);
    await expect(page.locator('.mv-battle .mv-fighter').first()).toContainText(seeded.enemy);
    expect(await page.locator('.mv-actions button').nth(1).isDisabled()).toBe(true);
    await page.screenshot({ path: '.reports/c04-battle-boot.png' });

    await page.keyboard.press('1');
    await expect.poll(() => page.locator('.mv-log li').count()).toBeGreaterThan(1);
    const mid = await tags(page).allInnerTexts();
    const log = await page.locator('.mv-log li').allInnerTexts();
    expect(mid.join('|')).toMatch(new RegExp(`\\d+/${seeded.maxHp}`));

    await page.reload();
    await expect(page.locator('.mv-battle')).toBeVisible();
    expect(await tags(page).allInnerTexts()).toEqual(mid);
    expect(await page.locator('.mv-log li').allInnerTexts()).toEqual(log);
    await page.keyboard.press('1');
    await page.keyboard.press('1');
    await expect.poll(() => page.locator('.mv-log li').count()).toBeGreaterThan(log.length);
    await page.screenshot({ path: '.reports/c04-battle-resumed.png' });

    for (let turn = 0; turn < 30 && await page.locator('.mv-battle').isVisible(); turn++) {
      const capture = page.locator('.mv-side button').first();
      if (await capture.isEnabled()) await page.keyboard.press('KeyC');
      else await page.keyboard.press('1');
      await page.waitForTimeout(200);
    }
    await expect(page.locator('.mv-battle')).toBeHidden();
    await expect(page.locator('.mv-message')).not.toBeEmpty();
    const settled = { team: await party(page).innerText(), friend: await hud(page).innerText() };
    await page.screenshot({ path: '.reports/c04-after-battle.png' });

    await page.reload();
    await expect(page.locator('.mv-hud')).toBeVisible();
    await expect(page.locator('.mv-battle')).toBeHidden();
    await expect.poll(() => party(page).innerText()).toBe(settled.team);
    expect(await hud(page).innerText()).toBe(settled.friend);
    await page.reload();
    await expect.poll(() => party(page).innerText()).toBe(settled.team);
    expect(errors).toEqual([]);
  });

  test('keeps a collected egg and its incubation across a reload', async ({ page }) => {
    test.setTimeout(120_000);
    await page.goto('/');
    await expect(page.locator('.mv-stage canvas').first()).toBeVisible();
    await page.locator('.mv-stage canvas').first().click({ position: { x: 400, y: 300 } });
    await walkTo(page, ['KeyS', 'KeyD'], async () =>
      (await page.locator('.mv-hint').count()) > 0 && (await page.locator('.mv-hint').innerText()).trim() === 'Enter: Topla');
    await expect(page.locator('.mv-card h3')).toContainText('Yumurtası');
    await page.keyboard.press('Enter');
    await expect.poll(() => eggCount(page)).toBe(1);
    await page.keyboard.press('Enter');
    await page.keyboard.press('Enter');
    // Pressing it again never collects a second egg from the same nest.
    expect(await eggCount(page)).toBe(1);
    await page.reload();
    await page.waitForFunction(() => '__muhurTestBridge' in globalThis, null, { timeout: 30_000 });
    await expect.poll(() => eggCount(page)).toBe(1);
    await page.keyboard.press('KeyK');
    await expect(page.locator('[role="dialog"][aria-label="Kamp"]')).toBeVisible();
    await expect(page.locator('.mv-panel:not([hidden]) .mv-list').nth(2)).toContainText('sn aktif kamp oyunu kaldı');
    await page.screenshot({ path: '.reports/c04-egg-reload.png' });
  });
});
