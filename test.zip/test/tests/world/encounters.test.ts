import { describe, expect, it } from 'vitest';
import type { GameCommand } from '../../src/contracts';
import { createWorld } from '../../src/world/generation/world';
import { sampleTerrain } from '../../src/world/terrain/terrain';
import { TargetIndex, selectNearby, hasLineOfSight, type WorldTarget } from '../../src/world/encounters/targets';
import { EncounterDirector } from '../../src/world/encounters/director';
import { Discovery } from '../../src/world/discovery/discovery';
import { worldToMinimap, minimapToWorld, minimapMarkers } from '../../src/world/minimap-data';
const world = createWorld();
const player = world.camp;
const target = (id: string, x: number, z: number, overrides: Partial<WorldTarget> = {}): WorldTarget => ({ entityId: id, kind: 'creature', name: 'Çiytomur', spriteId: 'dewbud', level: 1, aggressive: false, position: { x, z }, ...overrides });
const interact = (id: string): GameCommand => ({ type: 'interact', entityId: id, commandId: `interact-${id}`, tick: 0 });

describe('nearby selection and spatial index', () => {
  it('rejects out-of-world values before bucket arithmetic', () => {
    const index = new TargetIndex();
    expect(() => index.query({ x: 1e308, z: 1e308 })).toThrow(RangeError);
    expect(() => index.upsert(target('outside', 1024, 0))).toThrow(RangeError);
    expect(hasLineOfSight(world, { x: 1e308, z: 0 }, { x: 1e308, z: 0 })).toBe(false);
  });
  it('enters at 6m, retains through 8m and releases beyond 8m', () => {
    const index = new TargetIndex(); index.upsert(target('a', player.x + 6.01, player.z));
    expect(selectNearby(world, index, player, null)?.interactionAllowed).toBe(false);
    index.upsert(target('a', player.x + 6, player.z));
    const acquired = selectNearby(world, index, player, null)!; expect(acquired.interactionAllowed).toBe(true);
    index.upsert(target('a', player.x + 8, player.z)); expect(selectNearby(world, index, player, acquired)?.interactionAllowed).toBe(true);
    index.upsert(target('a', player.x + 8.01, player.z)); expect(selectNearby(world, index, player, acquired)?.interactionAllowed).toBe(false);
    index.upsert(target('a', player.x + 24.01, player.z)); expect(selectNearby(world, index, player, null)).toBeNull();
  });
  it('breaks equal distance ties by ID and retains an engaged target during small proximity changes', () => {
    const index = new TargetIndex(); index.upsert(target('b', player.x - 5, player.z)); index.upsert(target('a', player.x + 5, player.z));
    const first = selectNearby(world, index, player, null)!; expect(first.entityId).toBe('a');
    index.upsert(target('b', player.x - 4.99, player.z)); expect(selectNearby(world, index, player, first)?.entityId).toBe('a');
  });
  it('moves and removes entities across hash buckets without stale duplicates', () => {
    const index = new TargetIndex(); const entry = target('a', -1, -1); index.upsert(entry);
    expect(index.query({ x: 0, z: 0 })).toHaveLength(1);
    index.upsert({ ...entry, position: { x: 1000, z: 1000 } }); expect(index.query({ x: 0, z: 0 })).toHaveLength(0);
    expect(index.query({ x: 1000, z: 1000 })).toHaveLength(1); index.remove('a'); expect(index.query({ x: 1000, z: 1000 })).toHaveLength(0);
  });
  it('blocks line of sight and manual battle through a real solid terrain cell', () => {
    let wall: { x: number; z: number } | undefined;
    for (let z = -901; z < 900 && !wall; z += 2) for (let x = -901; x < 900; x += 2) {
      if (!sampleTerrain(world, { x, z }).traversable && sampleTerrain(world, { x: x - 2, z }).traversable && sampleTerrain(world, { x: x + 2, z }).traversable) { wall = { x, z }; break; }
    }
    expect(wall).toBeDefined();
    const from = { x: wall!.x - 2, z: wall!.z }, to = { x: wall!.x + 2, z: wall!.z };
    expect(hasLineOfSight(world, from, to)).toBe(false);
    const index = new TargetIndex(); index.upsert(target('blocked', to.x, to.z));
    const director = new EncounterDirector(world, index, 'wall');
    expect(director.interact(from, interact('blocked'), 'exploring')).toBeNull();
  });
});

describe('encounter ownership and warnings', () => {
  it('collects eggs without battle and keeps one lock until the matching committed result', () => {
    const index = new TargetIndex(); index.upsert(target('egg', player.x + 3, player.z, { kind: 'egg' }));
    const director = new EncounterDirector(world, index, 'eggs');
    const started = director.interact(player, interact('egg'), 'exploring')!; expect(started.kind).toBe('collect');
    expect(director.interact(player, interact('egg'), 'exploring')).toBeNull();
    expect(director.finishCommitted('stale', 'collected')).toBe(false);
    expect(director.snapshot().lock).toEqual(started);
    expect(director.finishCommitted(started.lockId, 'collected')).toBe(true); expect(index.query(player)).toHaveLength(0);
    expect(director.interact(player, interact('egg'), 'exploring')).toBeNull();
  });
  it('requires a current target and blocks modal/paused interactions', () => {
    const index = new TargetIndex(); index.upsert(target('a', player.x + 3, player.z));
    const director = new EncounterDirector(world, index, 'gates');
    expect(director.interact(player, interact('other'), 'exploring')).toBeNull();
    expect(director.interact(player, interact('a'), 'panel')).toBeNull();
    expect(director.interact(player, interact('a'), 'exploring', true)).toBeNull();
    director.update(player, 'exploring'); index.upsert(target('a', player.x + 50, player.z));
    expect(director.interact(player, interact('a'), 'exploring')).toBeNull();
  });
  it('suppresses hostile challenges in the safe camp', () => {
    const index = new TargetIndex(); index.upsert(target('hostile', player.x + 4, player.z, { aggressive: true }));
    const director = new EncounterDirector(world, index, 'camp');
    for (let i = 0; i < 200; i++) expect(director.update(player, 'exploring')).toBeNull();
    expect(director.snapshot().warning).toBeNull();
  });
  it('warns for 1.2 simulation seconds, pauses countdown, locks once and applies flee cooldown', () => {
    const p = world.regions.find((region) => region.biomeId === 'forest')!.entrance;
    const index = new TargetIndex(); index.upsert(target('hostile', p.x + 4, p.z, { aggressive: true }));
    const director = new EncounterDirector(world, index, 'hostile');
    for (let i = 0; i < 30; i++) expect(director.update(p, 'exploring')).toBeNull();
    const before = director.snapshot();
    for (let i = 0; i < 300; i++) { director.update(p, 'panel'); director.update(p, 'exploring', true); }
    expect(director.snapshot()).toEqual(before);
    for (let i = 30; i < 71; i++) expect(director.update(p, 'exploring')).toBeNull();
    const started = director.update(p, 'exploring')!; expect(started).toMatchObject({ kind: 'battle', trigger: 'hostile' });
    for (let i = 0; i < 50; i++) expect(director.update(p, 'exploring')).toBeNull();
    director.finishCommitted(started.lockId, 'fled');
    for (let i = 0; i < 479; i++) { expect(director.update(p, 'exploring')).toBeNull(); expect(director.interact(p, interact('hostile'), 'exploring')).toBeNull(); }
    director.update(p, 'exploring'); expect(director.interact(p, interact('hostile'), 'exploring')?.kind).toBe('battle');
  });

  it('keeps defeat cooldown for 30 seconds and general aggro immunity for 3 seconds', () => {
    const p = world.regions.find((region) => region.biomeId === 'forest')!.entrance;
    const index = new TargetIndex(); index.upsert(target('a', p.x + 4, p.z, { aggressive: true }));
    const director = new EncounterDirector(world, index, 'timers');
    const lock = director.interact(p, interact('a'), 'exploring')!;
    director.finishCommitted(lock.lockId, 'lost');
    for (let tick = 0; tick < 1799; tick++) {
      expect(director.update(p, 'exploring')).toBeNull();
      expect(director.interact(p, interact('a'), 'exploring')).toBeNull();
    }
    director.update(p, 'exploring');
    const next = director.interact(p, interact('a'), 'exploring')!; expect(next).not.toBeNull();
    director.finishCommitted(next.lockId, 'cancelled');
    for (let tick = 0; tick < 179; tick++) { director.update(p, 'exploring'); expect(director.snapshot().warning).toBeNull(); }
    director.update(p, 'exploring'); expect(director.snapshot().warning?.entityId).toBe('a');
  });
  it('cancels warning when the hostile goes out of range', () => {
    const p = world.regions.find((region) => region.biomeId === 'forest')!.entrance;
    const index = new TargetIndex(); index.upsert(target('hostile', p.x + 4, p.z, { aggressive: true }));
    const director = new EncounterDirector(world, index, 'cancel'); director.update(p, 'exploring');
    expect(director.snapshot().warning).not.toBeNull();
    index.upsert(target('hostile', p.x + 11, p.z, { aggressive: true })); director.update(p, 'exploring'); expect(director.snapshot().warning).toBeNull();
  });
});

describe('discovery and north-up minimap data', () => {
  it('projects center and four directions with roundtrip and circular clipping', () => {
    const p = { x: 40, z: -20 };
    expect(worldToMinimap(p, p)).toEqual({ x: 96, y: 96, visible: true });
    for (const [dx, dz, x, y] of [[0, -96, 96, 0], [96, 0, 192, 96], [0, 96, 96, 192], [-96, 0, 0, 96]]) {
      const point = { x: p.x + dx, z: p.z + dz }; const mapped = worldToMinimap(point, p);
      expect(mapped).toEqual({ x, y, visible: true }); expect(minimapToWorld(mapped, p)).toEqual(point);
      expect(minimapToWorld(worldToMinimap(point, p, 144), p, 144)).toEqual(point);
    }
    expect(worldToMinimap({ x: p.x + 80, z: p.z + 80 }, p).visible).toBe(false);
    expect(() => worldToMinimap(p, p, 0)).toThrow();
  });
  it('never shows undiscovered or out-of-perception entities, and serializes discovery', () => {
    const index = new TargetIndex(); index.upsert(target('near', player.x + 4, player.z)); index.upsert(target('far', player.x + 60, player.z));
    const discovery = new Discovery(); expect(minimapMarkers(index, discovery, player)).toEqual([]);
    discovery.reveal(player, 'panel'); expect(discovery.serialize()).toEqual([]);
    discovery.reveal(player, 'exploring', true); expect(discovery.serialize()).toEqual([]);
    discovery.reveal(player, 'exploring'); discovery.reveal({ x: player.x + 60, z: player.z }, 'exploring');
    const restored = new Discovery(discovery.serialize());
    expect(minimapMarkers(index, restored, player, 'near')).toEqual([{ entityId: 'near', kind: 'creature', aggressive: false, selected: true, x: 100, y: 96, visible: true }]);
    expect(restored.serialize()).toEqual(discovery.serialize());
    index.remove('near'); expect(minimapMarkers(index, restored, player)).toEqual([]);
    expect(() => new Discovery([-1])).toThrow(); expect(restored.has({ x: NaN, z: 0 })).toBe(false);
  });
});
