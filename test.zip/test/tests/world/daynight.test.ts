import { describe, expect, it } from 'vitest';
import { GAME_CONFIG } from '../../src/config';
import { creatures } from '../../src/content/catalog';
import { STARTING_RECIPE_ID } from '../../src/content/secrets';
import { createWorld } from '../../src/world/generation/world';
import {
  DAY_CYCLE_TICKS, DAY_TICKS, NIGHT_AGGRO_BONUS, NIGHT_DETECTION_RADIUS, NIGHT_TICKS,
  activityOf, advanceDayTick, aggressiveBonus, dayView, detectionRadius, normalizeDayTick, phaseAt, skyLight,
} from '../../src/world/daynight';
import { CHUNK_GRID, chunkKey, spawnsForChunk } from '../../src/world/chunks/chunks';
import { ChunkManager } from '../../src/world/chunks/manager';
import { TargetIndex } from '../../src/world/encounters/targets';
import { chunkGate, createWorldState, tickWorld, validateWorldState, type WorldState } from '../../src/world/persistence/world-save';

const world = createWorld();
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: true, inventory: [{ itemId: 'seal', quantity: 1 }, null],
    unlockedRecipeIds: [STARTING_RECIPE_ID], creatures: [], creatureCapacity: 6, eggCapacity: 2, eggs: [],
    battle: null, loot: null, rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, ...overrides };
}
const everyChunk = () => {
  const coords = [];
  for (let z = 0; z < CHUNK_GRID; z += 4) for (let x = 0; x < CHUNK_GRID; x += 4) coords.push({ id: chunkKey(x, z), chunkX: x, chunkZ: z });
  return coords;
};

describe('the ten minute clock', () => {
  it('splits six minutes of day from four of night', () => {
    expect(DAY_CYCLE_TICKS).toBe(Math.round(600 / GAME_CONFIG.fixedStep));
    expect(DAY_TICKS + NIGHT_TICKS).toBe(DAY_CYCLE_TICKS);
    expect(DAY_TICKS).toBe(Math.round(360 / GAME_CONFIG.fixedStep));
    expect(phaseAt(0)).toBe('day');
    expect(phaseAt(DAY_TICKS - 1)).toBe('day');
    expect(phaseAt(DAY_TICKS)).toBe('night');
    expect(phaseAt(DAY_CYCLE_TICKS - 1)).toBe('night');
    expect(phaseAt(DAY_CYCLE_TICKS)).toBe('day');
  });
  it('wraps inside the cycle however far it is advanced', () => {
    expect(advanceDayTick(0, DAY_CYCLE_TICKS)).toBe(0);
    expect(advanceDayTick(DAY_CYCLE_TICKS - 5, 10)).toBe(5);
    expect(advanceDayTick(10, 0)).toBe(10);
    expect(normalizeDayTick(-1)).toBe(DAY_CYCLE_TICKS - 1);
    expect(() => advanceDayTick(0, -1)).toThrow();
    expect(() => advanceDayTick(0, 1.5)).toThrow();
    let tick = 0;
    for (let step = 0; step < DAY_CYCLE_TICKS; step++) tick = advanceDayTick(tick, 1);
    expect(tick).toBe(0);
  });
  it('runs from the save and reads the same hour after a reload', () => {
    let current = state({ dayTick: DAY_TICKS - 2 });
    for (let step = 0; step < 4; step++) current = tickWorld(current);
    expect(current.dayTick).toBe(DAY_TICKS + 2);
    expect(phaseAt(current.dayTick)).toBe('night');
    const reloaded = JSON.parse(JSON.stringify(current)) as WorldState;
    expect(() => validateWorldState(world, reloaded)).not.toThrow();
    expect(dayView(reloaded.dayTick)).toEqual(dayView(current.dayTick));
    // A paused or locked world holds the clock exactly where it was.
    expect(tickWorld(current, true).dayTick).toBe(current.dayTick);
    expect(tickWorld({ ...current, mode: 'panel' }).dayTick).toBe(current.dayTick);
  });
  it('projects a label, a remaining time and the night detection radius', () => {
    const noon = dayView(0);
    expect(noon).toMatchObject({ phase: 'day', label: 'Gündüz', ratio: 0, detectionRadius: GAME_CONFIG.proximityRadius });
    expect(noon.secondsLeft).toBe(360);
    const dusk = dayView(DAY_TICKS);
    expect(dusk).toMatchObject({ phase: 'night', label: 'Gece', ratio: 0, detectionRadius: NIGHT_DETECTION_RADIUS });
    expect(dusk.secondsLeft).toBe(240);
    expect(detectionRadius('day')).toBe(24);
    expect(detectionRadius('night')).toBe(16);
    expect(aggressiveBonus('day')).toBe(0);
    expect(aggressiveBonus('night')).toBe(NIGHT_AGGRO_BONUS);
  });
  it('blends the light instead of flipping it, and stays pure', () => {
    expect(skyLight(0)).toEqual(skyLight(0));
    expect(skyLight(0).sun).toBeGreaterThan(skyLight(DAY_TICKS + 100).sun);
    expect(skyLight(0).ambient).toBeGreaterThan(skyLight(DAY_TICKS + 100).ambient);
    const dusk = skyLight(DAY_TICKS - Math.round(DAY_CYCLE_TICKS / 40));
    expect(dusk.sun).toBeLessThan(skyLight(0).sun);
    expect(dusk.sun).toBeGreaterThan(skyLight(DAY_TICKS).sun);
    for (const tick of [0, DAY_TICKS, DAY_CYCLE_TICKS - 1]) {
      const light = skyLight(tick);
      expect(light.sky).toBeGreaterThanOrEqual(0);
      expect(light.sky).toBeLessThanOrEqual(0xffffff);
      expect(light.ambient).toBeGreaterThan(0);
    }
  });
});

describe('what the night changes', () => {
  it('reads a species preference from one table', () => {
    for (const species of creatures) {
      const activity = activityOf(species);
      expect(['day', 'night', 'any'], species.id).toContain(activity);
    }
    expect(activityOf({ element: 'gölge' })).toBe('night');
    expect(activityOf({ element: 'ışık' })).toBe('day');
    expect(activityOf({ element: 'su' })).toBe('any');
    // An explicit content field wins over the element rule.
    expect(activityOf({ element: 'gölge', activity: 'day' })).toBe('day');
  });
  it('spawns night creatures without taking the day ones away', () => {
    let swapped = 0, shared = 0, nocturnalSeen = 0;
    for (const chunk of everyChunk()) {
      const day = spawnsForChunk(world, chunk, 'day');
      const night = spawnsForChunk(world, chunk, 'night');
      expect(night).toHaveLength(day.length);
      for (let index = 0; index < day.length; index++) {
        const [a, b] = [day[index], night[index]];
        expect(a.target.kind).toBe(b.target.kind);
        expect(a.target.position).toEqual(b.target.position);
        if (a.target.kind !== 'creature') {
          // A resource slot may grow a night-only tree; then it is a separate entity as well.
          if (a.target.entityId === b.target.entityId) expect(a).toEqual(b);
          else expect(b.target.entityId.endsWith(':n')).toBe(true);
          continue;
        }
        if (a.speciesId === b.speciesId) { shared++; continue; }
        // A slot that changes hands becomes a different entity, with its own grave.
        expect(a.target.entityId).not.toBe(b.target.entityId);
        expect(b.target.entityId.endsWith(':n')).toBe(true);
        swapped++;
        if (activityOf(creatures.find((entry) => entry.id === b.speciesId)!) === 'night') nocturnalSeen++;
      }
    }
    // Day species keep most of their slots; some hand over to a creature that prefers the dark.
    expect(shared).toBeGreaterThan(0);
    expect(swapped).toBeGreaterThan(0);
    expect(nocturnalSeen).toBeGreaterThan(0);
  });
  it('makes more of the wild hostile after dark', () => {
    let day = 0, night = 0, creaturesSeen = 0;
    for (const chunk of everyChunk()) {
      for (const spawn of spawnsForChunk(world, chunk, 'day')) if (spawn.target.kind === 'creature') { creaturesSeen++; if (spawn.target.aggressive) day++; }
      for (const spawn of spawnsForChunk(world, chunk, 'night')) if (spawn.target.kind === 'creature' && spawn.target.aggressive) night++;
    }
    expect(creaturesSeen).toBeGreaterThan(50);
    expect(night).toBeGreaterThan(day);
  });
  it('stays deterministic: the same seed, chunk and phase give the same world', () => {
    for (const chunk of everyChunk().slice(0, 12)) {
      for (const phase of ['day', 'night'] as const) {
        expect(spawnsForChunk(world, chunk, phase)).toEqual(spawnsForChunk(world, chunk, phase));
        expect(spawnsForChunk(createWorld(), chunk, phase)).toEqual(spawnsForChunk(world, chunk, phase));
      }
    }
  });
  it('rebuilds residency once when the phase turns', () => {
    const current = state({ playerPosition: { ...world.camp } });
    const index = new TargetIndex();
    const chunks = new ChunkManager(world, index, chunkGate(() => current));
    chunks.update(current.playerPosition);
    expect(chunks.dayPhase).toBe('day');
    const before = [...chunks.loadedEntityIds];
    const unchanged = chunks.setPhase('day');
    expect(unchanged).toMatchObject({ added: [], removed: [] });
    const delta = chunks.setPhase('night');
    expect(chunks.dayPhase).toBe('night');
    const after = [...chunks.loadedEntityIds];
    expect(delta.added.length + delta.removed.length).toBeGreaterThan(0);
    expect(after).not.toEqual(before);
    // Turning back gives exactly the daytime world again.
    chunks.setPhase('day');
    expect([...chunks.loadedEntityIds]).toEqual(before);
  });
});
