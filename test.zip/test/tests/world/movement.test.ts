import { describe, expect, it } from 'vitest';
import { Object3D, Vector3 } from 'three';
import { applyPlayerPose } from '../../src/render/camera/follow-camera';
import type { GameCommand, GameState } from '../../src/contracts';
import { createWorld } from '../../src/world/generation/world';
import { sampleTerrain } from '../../src/world/terrain/terrain';
import { canOccupy, PLAYER_RADIUS } from '../../src/world/collision/collision';
import { spawnPlayer, stepMovement, type MovementState } from '../../src/world/movement/movement';
import { FixedStepClock } from '../../src/render/core/fixed-step';
import { KeyboardInput } from '../../src/render/input/keyboard';

const world = createWorld('movement');
const exploring: GameState = { mode: 'exploring' };
const move = (x: number, z: number): GameCommand => ({ type: 'move', commandId: 'test', tick: 0, direction: { x, z } });
const at = (x: number, z: number): MovementState => ({ position: { x, z }, lastSafePosition: { x, z }, yaw: 0 });

describe('fixed-step movement and circle collision', () => {
  it('normalizes diagonal distance and faces four directions without rotating a camera', () => {
    const start = spawnPlayer(world);
    const distance = (state: MovementState) => Math.hypot(state.position.x - start.position.x, state.position.z - start.position.z);
    expect(distance(stepMovement(world, start, move(1, 1), exploring))).toBeCloseTo(distance(stepMovement(world, start, move(1, 0), exploring)), 10);
    for (const [x, z] of [[0, -1], [1, 0], [0, 1], [-1, 0], [1, 1]]) {
      const moved = stepMovement(world, start, move(x, z), exploring);
      const proxy = new Object3D();
      applyPlayerPose(proxy, moved.position, 0, moved.yaw);
      const forward = new Vector3(0, 0, -1).applyQuaternion(proxy.quaternion);
      expect(forward.dot(new Vector3(x, 0, z).normalize())).toBeGreaterThan(0.999);
    }
  });
  it('does not move with a panel, battle, hidden/paused state or invalid direction', () => {
    const start = spawnPlayer(world);
    for (const state of [{ mode: 'panel', panel: 'inventory' }, { mode: 'battle', battleId: 'b', encounterId: 'e' }, { mode: 'boot' }] as GameState[]) expect(stepMovement(world, start, move(1, 0), state)).toBe(start);
    expect(stepMovement(world, start, move(1, 0), exploring, true)).toBe(start);
    expect(stepMovement(world, start, move(NaN, 0), exploring)).toBe(start);
    expect(stepMovement(world, start, move(0, 0), exploring)).toBe(start);
    expect(stepMovement(world, start, null, exploring)).toBe(start);
    expect(() => stepMovement(world, at(NaN, 0), move(1, 0), exploring)).toThrow();
  });
  it('produces the same 10-second keyboard replay at 30, 60 and 120 FPS', () => {
    const outcomes = [30, 60, 120].map((fps) => {
      const clock = new FixedStepClock(), win = new EventTarget(), doc = new EventTarget();
      const keyboard = new KeyboardInput(win, doc, () => false, `replay-${fps}`); keyboard.setOwner('world');
      let state = spawnPlayer(world), tick = 0, travelled = 0;
      // Four cardinal legs remain in the safe camp; each leg lasts exactly 2.5s.
      const keys = ['KeyD', 'ArrowDown', 'KeyA', 'ArrowUp'];
      for (const code of keys) {
        win.dispatchEvent(Object.assign(new Event('keydown'), { code }));
        for (let frame = 0; frame < fps * 2.5; frame++) clock.advance(1 / fps, () => {
          const before = state.position;
          state = stepMovement(world, state, keyboard.movement(tick++), exploring);
          travelled += Math.hypot(state.position.x - before.x, state.position.z - before.z);
        });
        win.dispatchEvent(Object.assign(new Event('keyup'), { code }));
      }
      expect(tick).toBe(600); expect(travelled).toBeCloseTo(60, 8); keyboard.dispose(); return state.position;
    });
    for (const p of outcomes) { expect(p.x).toBeCloseTo(world.camp.x, 8); expect(p.z).toBeCloseTo(world.camp.z, 8); }
    expect(outcomes[0]).toEqual(outcomes[1]); expect(outcomes[1]).toEqual(outcomes[2]);
  });
  it('clears held movement on blur and never catches up paused time', () => {
    const win = new EventTarget(), doc = new EventTarget();
    const keyboard = new KeyboardInput(win, doc, () => false, 'blur'); keyboard.setOwner('world');
    win.dispatchEvent(Object.assign(new Event('keydown'), { code: 'KeyD' }));
    let state = spawnPlayer(world); state = stepMovement(world, state, keyboard.movement(0), exploring);
    const before = state; win.dispatchEvent(new Event('blur'));
    state = stepMovement(world, state, keyboard.movement(1), exploring); expect(state).toBe(before);
    const clock = new FixedStepClock(); expect(clock.advance(60, () => { throw new Error('paused tick'); }, true).steps).toBe(0);
    win.dispatchEvent(new Event('focus')); expect(keyboard.movement(2)).toBeNull(); keyboard.dispose();
  });
  it('rejects deep water, lava, trees and rocks as full-body destinations', () => {
    const found = new Set<string>();
    for (let z = -1023; z < 1024; z += 8) for (let x = -1023; x < 1024; x += 8) {
      const cell = sampleTerrain(world, { x, z });
      const kind = cell.hazard !== 'none' ? cell.hazard : cell.obstacle;
      if (kind !== 'none' && !found.has(kind)) { expect(canOccupy(world, cell.position)).toBe(false); found.add(kind); }
    }
    expect(found.has('deep-water')).toBe(true); expect(found.has('lava')).toBe(true);
    expect(found.has('tree')).toBe(true); expect(found.has('rock')).toBe(true);
    expect(canOccupy(world, { x: 1024 - PLAYER_RADIUS / 2, z: 0 })).toBe(false);
    expect(canOccupy(world, { x: -1024, z: 0 })).toBe(false);
    expect(canOccupy(world, { x: NaN, z: 0 })).toBe(false);
  });
  it('slides along a real terrain wall without tunneling or clipping its corner', () => {
    // Find a vertical wall face with passable cells immediately to its left.
    let start: MovementState | undefined;
    for (let z = -901; z < 900 && !start; z += 2) for (let x = -901; x < 900; x += 2) {
      const solid = sampleTerrain(world, { x, z });
      if (solid.traversable) continue;
      const candidate = at(x - 1 - PLAYER_RADIUS - 0.01, z - 0.3);
      if (canOccupy(world, candidate.position) && canOccupy(world, { x: candidate.position.x, z: z + 0.3 })) { start = candidate; break; }
    }
    expect(start).toBeDefined();
    let state = start!;
    for (let i = 0; i < 5; i++) { state = stepMovement(world, state, move(1, 1), exploring); expect(canOccupy(world, state.position)).toBe(true); }
    expect(state.position.x).toBeCloseTo(start!.position.x, 10);
    expect(state.position.z).toBeGreaterThan(start!.position.z);
    expect(state.lastSafePosition).toEqual(state.position);
  });
});
