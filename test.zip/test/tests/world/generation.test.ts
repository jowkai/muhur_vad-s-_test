import { describe, expect, it } from 'vitest';
import { BIOME_IDS } from '../../src/contracts';
import { GAME_CONFIG } from '../../src/config';
import { createWorld } from '../../src/world/generation/world';
import { generateChunk, sampleTerrain } from '../../src/world/terrain/terrain';
import { creatureById } from '../../src/content/catalog';

const seeds = [1, 7, 42, 137, 2026, 2, 3, 11, 19, 31, 59, 83, 101, 233, 377, 610, 987, 1597, 2584, 4181].map(String);

describe('deterministic regional world', () => {
  it('uses a 2048m world with 64m chunks and 2m cells', () => {
    const world = createWorld();
    expect(GAME_CONFIG.worldSize).toBe(2048);
    expect(GAME_CONFIG.chunkSize).toBe(64);
    const chunk = generateChunk(world, 0, 0);
    expect(chunk.cells).toHaveLength(1024);
    expect(chunk.cells[0].position).toEqual({ x: -1023, z: -1023 });
    expect(chunk.cells[1023].position).toEqual({ x: -961, z: -961 });
    expect(generateChunk(world, 31, 31).cells[1023].position).toEqual({ x: 1023, z: 1023 });
  });
  it.each(seeds)('keeps camp and starter encounters safe and reaches every region for seed %s', (seed) => {
    const world = createWorld(seed);
    for (let z = -40; z <= 40; z += 2) for (let x = -40; x <= 40; x += 2) {
      if (x * x + z * z > 40 * 40) continue;
      expect(sampleTerrain(world, { x: world.camp.x + x, z: world.camp.z + z })).toMatchObject({ biomeId: 'meadow', traversable: true, hazard: 'none', obstacle: 'none', height: 0 });
    }
    for (const starter of world.starters) {
      expect(sampleTerrain(world, starter.position).traversable).toBe(true);
      expect(starter.aggressive).toBe(false);
      expect(starter.level).toBeLessThanOrEqual(2);
      expect(creatureById(starter.speciesId)).toMatchObject({ biomeId: 'meadow', rarity: 'common' });
    }
    expect(new Set(world.starters.map((entry) => entry.entityId)).size).toBe(world.starters.length);
    for (const region of world.regions) {
      expect(sampleTerrain(world, region.entrance)).toMatchObject({ biomeId: region.biomeId, traversable: true });
    }
    // Independent flood-fill on the actual 2m cells covering designed road corridors.
    // Restrict search space to corridors; inspect every traversed cell's generated passability.
    const side = GAME_CONFIG.worldSize / GAME_CONFIG.cellSize;
    const encode = (x: number, z: number) => z * side + x;
    const cellOf = (p: { x: number; z: number }) => ({ x: Math.floor((p.x + 1024) / 2), z: Math.floor((p.z + 1024) / 2) });
    const targets = new Set(world.regions.map((region) => { const p = cellOf(region.entrance); return encode(p.x, p.z); }));
    const start = cellOf(world.camp);
    const queue = [encode(start.x, start.z)];
    const seen = new Uint8Array(side * side); seen[queue[0]] = 1;
    for (let head = 0; head < queue.length && targets.size; head++) {
      const current = queue[head]; targets.delete(current);
      const x = current % side, z = Math.floor(current / side);
      for (const [nx, nz] of [[x + 1, z], [x - 1, z], [x, z + 1], [x, z - 1]]) {
        if (nx < 0 || nz < 0 || nx >= side || nz >= side) continue;
        const id = encode(nx, nz); if (seen[id]) continue; seen[id] = 1;
        const cell = sampleTerrain(world, { x: nx * 2 - 1023, z: nz * 2 - 1023 });
        if (cell.traversable && cell.road) queue.push(id);
      }
    }
    expect([...targets], `unreachable entrances for ${seed}`).toEqual([]);
  }, 15_000);
  it('generates chunks independently of request order, with matching boundary cells', () => {
    const a = createWorld('order');
    const left = generateChunk(a, 15, 16), right = generateChunk(a, 16, 16);
    const b = createWorld('order');
    expect(generateChunk(b, 16, 16)).toEqual(right);
    expect(generateChunk(b, 15, 16)).toEqual(left);
    for (let z = 0; z < 32; z++) {
      const l = left.cells[z * 32 + 31], r = right.cells[z * 32];
      expect(r.position.x - l.position.x).toBe(2);
      expect(sampleTerrain(a, l.position)).toEqual(l);
      expect(sampleTerrain(a, r.position)).toEqual(r);
      expect(Math.abs(l.height - r.height)).toBeLessThan(0.5);
    }
  });
  it('forms large biome regions and impassable hazards outside safe routes', () => {
    const world = createWorld();
    const totals = new Map<string, number>();
    let deep = 0, lava = 0, transitions = 0;
    for (let z = -1015; z < 1024; z += 16) for (let x = -1015; x < 1024; x += 16) {
      const cell = sampleTerrain(world, { x, z });
      totals.set(cell.biomeId, (totals.get(cell.biomeId) ?? 0) + 1);
      expect(Number.isFinite(cell.height)).toBe(true);
      if (cell.hazard !== 'none') expect(cell.traversable).toBe(false);
      if (cell.hazard === 'deep-water') deep++;
      if (cell.hazard === 'lava') lava++;
      if (cell.secondaryBiome) { transitions++; expect(cell.blend).toBeGreaterThan(0); expect(cell.blend).toBeLessThanOrEqual(0.5); }
    }
    expect([...totals.keys()].sort()).toEqual([...BIOME_IDS].sort());
    for (const count of totals.values()) expect(count).toBeGreaterThan(80);
    expect(deep).toBeGreaterThan(0); expect(lava).toBeGreaterThan(0); expect(transitions).toBeGreaterThan(0);
  });
  it('is seed-sensitive but stable when recreated', () => {
    expect(createWorld('a')).toEqual(createWorld('a'));
    expect(createWorld('a').regions).not.toEqual(createWorld('b').regions);
    expect(createWorld('a').starters[0].entityId).not.toBe(createWorld('b').starters[0].entityId);
  });
  it('rejects nonfinite coordinates and invalid chunk indices, blocks world boundaries', () => {
    const world = createWorld();
    expect(() => sampleTerrain(world, { x: NaN, z: 0 })).toThrow(RangeError);
    expect(() => generateChunk(world, 32, 0)).toThrow(RangeError);
    expect(() => generateChunk(world, 0.5, 0)).toThrow(RangeError);
    expect(() => createWorld('')).toThrow(RangeError);
    for (const position of [{ x: 1024, z: 0 }, { x: -1025, z: 0 }, { x: 0, z: 1024 }]) expect(sampleTerrain(world, position)).toMatchObject({ traversable: false, hazard: 'boundary' });
  });
});
