import { afterEach, describe, expect, it } from 'vitest';
import { GAME_CONFIG } from '../../src/config';
import { creatureById, creatures, itemById } from '../../src/content/catalog';
import { stats } from '../../src/game/combat/core';
import { createWorld } from '../../src/world/generation/world';
import { canOccupy } from '../../src/world/collision/collision';
import { CHUNK_GRID, chunkKey, spawnsForChunk } from '../../src/world/chunks/chunks';
import { AMBUSH_WARNING_TICKS, PATROL_RADIUS, WARNING_TICKS, ambushChance, ambushes, patrolPosition, GRAZE_PERIOD, GRAZE_RADIUS } from '../../src/world/encounters/patrol';
import { EncounterDirector } from '../../src/world/encounters/director';
import { TargetIndex } from '../../src/world/encounters/targets';
import {
  DEFEAT_MATERIAL_LOSS, commitEncounterOutcome, createWorldState, dropOnDefeat, validateWorldState, type WorldState,
} from '../../src/world/persistence/world-save';
import { beginBattle, createBattle } from '../../src/game/combat/core';
import { createLootPlan } from '../../src/game/combat/rewards';
import { IndexedDbSave } from '../../src/game/save/indexeddb';

const world = createWorld();
const species = creatures[0];
const maxHp = stats({ id: 'friend', species, level: 3 }).maxHp;
const hostiles = (() => {
  const found = [];
  for (let z = 0; z < CHUNK_GRID; z += 5) for (let x = 0; x < CHUNK_GRID; x += 5) {
    for (const spawn of spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z })) {
      if (spawn.target.aggressive) found.push(spawn);
    }
  }
  return found;
})();

describe('creatures that will not stand still', () => {
  it('walks every aggressive creature around its own patch, deterministically', () => {
    expect(hostiles.length).toBeGreaterThan(10);
    for (const spawn of hostiles.slice(0, 40)) {
      const home = spawn.target.position;
      const seen = new Set<string>();
      for (let tick = 0; tick < 240; tick += 15) {
        const at = patrolPosition(world, spawn.target.entityId, home, tick, true);
        expect(patrolPosition(world, spawn.target.entityId, home, tick, true)).toEqual(at);
        expect(Math.hypot(at.x - home.x, at.z - home.z)).toBeLessThanOrEqual(PATROL_RADIUS + 1e-6);
        expect(canOccupy(world, at) || at === home).toBe(true);
        seen.add(`${at.x.toFixed(2)},${at.z.toFixed(2)}`);
      }
      // A patrol that never moves would be one position for the whole lap.
      if (canOccupy(world, { x: home.x + 4, z: home.z })) expect(seen.size).toBeGreaterThan(1);
    }
  });
  it('moves the patrol in the shared index, so the map sees what the danger sees', () => {
    const hostile = hostiles[0]!.target;
    const calm = spawnsForChunk(world, { id: chunkKey(16, 16), chunkX: 16, chunkZ: 16 }).find((spawn) => !spawn.target.aggressive)!.target;
    const index = new TargetIndex();
    index.upsert(hostile); index.upsert(calm);
    const director = new EncounterDirector(world, index, 'patrol-sync');
    const home = { ...hostile.position };
    const seen = new Set<string>();
    for (let tick = 0; tick <= 720; tick += 30) {
      director.setClock(tick, 'day');
      director.movePatrols(home);
      const at = index.get(hostile.entityId)!.position;
      expect(Math.hypot(at.x - home.x, at.z - home.z), 'kendi bölgesinde kalır').toBeLessThanOrEqual(PATROL_RADIUS + 1e-6);
      seen.add(`${at.x.toFixed(2)},${at.z.toFixed(2)}`);
    }
    // The route is drawn around the home, not around the last step, so it never drifts away.
    expect(seen.size, 'devriye yerinde saymaz').toBeGreaterThan(1);
    director.setClock(0, 'day');
    director.movePatrols(home);
    expect(index.get(hostile.entityId)!.position).toEqual(patrolPosition(world, hostile.entityId, home, 0, true));
    expect(index.get(calm.entityId)!.position, 'sakin yaratık kıpırdamaz').toEqual(calm.position);
  });
  it('lets calm creatures graze close to home instead of standing frozen', () => {
    const calm = spawnsForChunk(world, { id: chunkKey(16, 16), chunkX: 16, chunkZ: 16 }).find((spawn) => !spawn.target.aggressive)!;
    const home = calm.target.position;
    const seen = new Set<string>();
    for (let tick = 0; tick < GRAZE_PERIOD; tick += GRAZE_PERIOD / 8) {
      const at = patrolPosition(world, calm.target.entityId, home, tick, false);
      // A grazing creature never leaves its own patch, and never leaves walkable ground.
      expect(Math.hypot(at.x - home.x, at.z - home.z)).toBeLessThanOrEqual(GRAZE_RADIUS);
      expect(canOccupy(world, at)).toBe(true);
      seen.add(`${at.x.toFixed(3)},${at.z.toFixed(3)}`);
    }
    expect(seen.size, 'a calm creature should drift, not stand still').toBeGreaterThan(1);
    // Still deterministic: the same tick always puts it in the same place after a reload.
    expect(patrolPosition(world, calm.target.entityId, home, 900, false))
      .toEqual(patrolPosition(world, calm.target.entityId, home, 900, false));
  });
});

describe('ambush', () => {
  it('rises with the region level and with the night, and never fires in the meadow', () => {
    expect(ambushChance(2, 'day')).toBe(0);
    expect(ambushChance(2, 'night')).toBe(0);
    expect(ambushChance(20, 'night')).toBeGreaterThan(ambushChance(20, 'day'));
    expect(ambushChance(40, 'day')).toBeGreaterThan(ambushChance(10, 'day'));
    expect(ambushChance(50, 'night')).toBeLessThanOrEqual(.3);
    expect(ambushChance(Number.NaN, 'day')).toBe(0);
  });
  it('draws the same answer for the same creature and window', () => {
    const id = hostiles[0].target.entityId;
    for (const window of [0, 3, 11]) {
      expect(ambushes(world, id, 30, 'night', window)).toBe(ambushes(world, id, 30, 'night', window));
    }
    let sprung = 0;
    for (let index = 0; index < 400; index++) sprung += ambushes(world, `probe-${index}`, 30, 'night', 1) ? 1 : 0;
    const share = sprung / 400;
    expect(share).toBeGreaterThan(0.05);
    expect(share).toBeLessThan(ambushChance(30, 'night') * 2);
    // A low level region never ambushes at all.
    for (let index = 0; index < 200; index++) expect(ambushes(world, `calm-${index}`, 3, 'night', 1)).toBe(false);
  });
  it('still warns, but leaves far less time', () => {
    expect(AMBUSH_WARNING_TICKS).toBeGreaterThan(0);
    expect(AMBUSH_WARNING_TICKS).toBeLessThan(WARNING_TICKS);
    expect(WARNING_TICKS).toBe(Math.round(1.2 / GAME_CONFIG.fixedStep));
    const index = new TargetIndex();
    const director = new EncounterDirector(world, index, 'test');
    director.setClock(120, 'night');
    const target = hostiles[0].target;
    index.upsert(target);
    expect(director.livePosition(target)).toEqual(patrolPosition(world, target.entityId, target.position, 120, true));
  });
});

let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
describe('losing a fight', () => {
  const player = { id: 'friend', species, level: 3 };
  const enemy = { id: 'wild', species: creatureById('snowspool')!, level: 4 };
  function lost(inventory: WorldState['inventory']): WorldState {
    const battle = beginBattle(createBattle({
      battleId: 'b', encounterId: 'wild-1', seed: 5, player, enemy, playerHp: 1,
    }));
    const finished = {
      ...battle, phase: 'LOST' as const, outcome: 'LOST' as const, playerHp: 0,
      party: battle.party.map((member) => ({ ...member, hp: 0 })),
    };
    const base = createWorldState(world, {
      mode: 'exploring', atCamp: false, inventory, unlockedRecipeIds: ['salve'],
      creatures: [{ id: 'friend', speciesId: species.id, level: 3, xp: 0, hp: maxHp, maxHp }],
      creatureCapacity: 6, eggCapacity: 2, eggs: [], battle: null, loot: null,
      rewardLedger: ['b'], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
    });
    return {
      ...base, mode: 'committing', battle: finished, loot: createLootPlan('b', enemy, false, 7),
      activeCreatureId: 'friend', party: ['friend'],
      playerPosition: { x: world.camp.x + 60, z: world.camp.z }, lastSafePosition: { x: world.camp.x + 60, z: world.camp.z },
      mount: null,
    };
  }
  async function storage(initial: WorldState) {
    const save = await IndexedDbSave.open<WorldState>({
      name: `danger-${counter++}`, initial: () => structuredClone(initial),
      validate: (value) => validateWorldState(world, value),
    });
    opened.push(save); return save;
  }
  afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });

  it('scatters a tenth of every material and nothing that was crafted', () => {
    const inventory: WorldState['inventory'] = [
      { itemId: 'dew_leaf', quantity: 40 }, { itemId: 'seal', quantity: 5 },
      { itemId: 'oak_log', quantity: 3 }, { itemId: 'stone_pick', quantity: 1 },
      { itemId: 'moss_thread', quantity: 1 }, null,
    ];
    const after = dropOnDefeat(inventory);
    expect(after[0]).toEqual({ itemId: 'dew_leaf', quantity: 36 });
    // Products keep their count whatever happens.
    expect(after[1]).toEqual({ itemId: 'seal', quantity: 5 });
    expect(after[3]).toEqual({ itemId: 'stone_pick', quantity: 1 });
    // Small stacks lose one, and a single unit is never taken.
    expect(after[2]).toEqual({ itemId: 'oak_log', quantity: 2 });
    expect(after[4]).toEqual({ itemId: 'moss_thread', quantity: 1 });
    expect(after[5]).toBeNull();
    expect(DEFEAT_MATERIAL_LOSS).toBe(.1);
    expect(itemById('dew_leaf')).toBeDefined();
  });
  it('walks the player home, drops the mount and costs materials in one transaction', async () => {
    const before = lost([{ itemId: 'dew_leaf', quantity: 20 }, { itemId: 'seal', quantity: 2 }, null, null]);
    const save = await storage(before);
    const after = await commitEncounterOutcome(world, save, 'settle:b', 'b');
    expect(after.playerPosition).toEqual({ ...world.camp });
    expect(after.lastSafePosition).toEqual({ ...world.camp });
    expect(after.mount).toBeNull();
    expect(after.inventory[0]).toEqual({ itemId: 'dew_leaf', quantity: 18 });
    expect(after.inventory[1]).toEqual({ itemId: 'seal', quantity: 2 });
    expect(after.mode).toBe('exploring');
    expect(after.battle).toBeNull();
    // The same settlement twice takes nothing more.
    expect(await commitEncounterOutcome(world, save, 'settle:b', 'b')).toEqual(after);
  });
});
