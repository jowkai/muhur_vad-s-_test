import { afterEach, describe, expect, it } from 'vitest';
import { GAME_CONFIG } from '../../src/config';
import { STARTING_RECIPE_ID } from '../../src/content/secrets';
import { creatureById, creatures, itemById, items } from '../../src/content/catalog';
import { createWorld } from '../../src/world/generation/world';
import { CHUNK_GRID, chunkKey, spawnsForChunk, type ChunkSpawn } from '../../src/world/chunks/chunks';
import { DAY_TICKS, detectionRadiusWith, phaseAt } from '../../src/world/daynight';
import {
  CACHE_HELP_RADIUS, DIG_HOLD_TICKS, GARDEN_PLOTS, GARDEN_TICKS, GARDEN_YIELD, TOOL, carries, digYield, gardenPlots, gardenReady,
  gardenYield, gather, harvestGarden, hasDigTool, hasStoneAlly, isSeed, nodeFor, partySpecies, plantSeed,
  sensedCaches,
} from '../../src/world/gathering/gathering';
import { RESPAWN_TICKS, createWorldState, validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { LOOT_BONUS_CHANCE, createLootPlan } from '../../src/game/combat/rewards';
import { stats } from '../../src/game/combat/core';
import { IndexedDbSave } from '../../src/game/save/indexeddb';

const world = createWorld();
const allSpawns = (): ChunkSpawn[] => {
  const out: ChunkSpawn[] = [];
  for (let z = 0; z < CHUNK_GRID; z += 3) for (let x = 0; x < CHUNK_GRID; x += 3) {
    out.push(...spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z }, 'day'));
  }
  return out;
};
const resources = allSpawns().filter((spawn) => spawn.target.kind === 'resource');
const owned = (id: string, speciesId: string, level = 2) => {
  const species = creatureById(speciesId)!;
  const maxHp = stats({ id, species, level }).maxHp;
  return { id, speciesId, level, xp: 0, hp: maxHp, maxHp };
};
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [null, null, null, null], unlockedRecipeIds: [STARTING_RECIPE_ID],
    creatures: [], creatureCapacity: 6, eggCapacity: 2, eggs: [], battle: null, loot: null,
    rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, ...overrides };
}
/** Puts the player on top of a node with the team it needs. */
function at(node: { position: { x: number; z: number } }, overrides: Partial<WorldState> = {}): WorldState {
  return state({ playerPosition: { ...node.position }, lastSafePosition: { ...node.position }, ...overrides });
}
const withTeam = (speciesIds: string[]) => ({
  creatures: speciesIds.map((speciesId, index) => owned(`c${index}`, speciesId)),
  party: speciesIds.map((_, index) => `c${index}`),
  activeCreatureId: 'c0',
});
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
async function storage(initial: WorldState) {
  const save = await IndexedDbSave.open<WorldState>({
    name: `gather-${counter++}`, initial: () => structuredClone(initial),
    validate: (value) => validateWorldState(world, value),
  });
  opened.push(save); return save;
}
afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });
const firstNode = (method: string, nightOnly = false) =>
  resources.map((spawn) => ({ spawn, node: nodeFor(world, spawn, [], 'night')! }))
    .find((entry) => entry.node.method === method && entry.node.nightOnly === nightOnly)!;

describe('how a material can reach the bag', () => {
  it('gives every resource exactly one method, deterministically', () => {
    expect(resources.length).toBeGreaterThan(100);
    const counts = { pick: 0, dig: 0, cache: 0, garden: 0, chest: 0, fell: 0 };
    for (const spawn of resources) {
      const node = nodeFor(world, spawn, [], 'day')!;
      expect(node.entityId).toBe(spawn.target.entityId);
      expect(nodeFor(world, spawn, [], 'day')).toEqual(node);
      counts[node.method]++;
    }
    // Hand picking stays the common case; veins and caches are the new ways.
    expect(counts.pick).toBeGreaterThan(counts.dig);
    // v3: a quarter of the slots stand as trees instead of loose material.
    expect(counts.fell).toBeGreaterThan(0);
    expect(counts.dig).toBeGreaterThan(0);
    expect(counts.cache).toBeGreaterThan(0);
    expect(nodeFor(world, allSpawns().find((spawn) => spawn.target.kind === 'creature')!, [], 'day')).toBeNull();
  });
  it('hides a night resource by day and a cache without the right creature', () => {
    const night = firstNode('pick', true);
    expect(nodeFor(world, night.spawn, [], 'day')!.hidden).toBe(true);
    expect(nodeFor(world, night.spawn, [], 'night')!.hidden).toBe(false);
    const cache = firstNode('cache');
    const helper = creatures.find((species) => species.element === cache.node.element)!;
    expect(nodeFor(world, cache.spawn, [], 'night')!.hidden).toBe(true);
    expect(nodeFor(world, cache.spawn, [helper.id], 'night')!.hidden).toBe(cache.node.nightOnly ? false : false);
  });
  it('lets the party sense nearby caches and nothing further away', () => {
    const cache = firstNode('cache');
    const helper = creatures.find((species) => species.element === cache.node.element)!;
    const close = at(cache.node, { ...withTeam([helper.id]), dayTick: DAY_TICKS });
    expect(partySpecies(close)).toEqual([helper.id]);
    const sensed = sensedCaches(world, [cache.spawn], close);
    expect(sensed.map((node) => node.entityId)).toEqual([cache.node.entityId]);
    const blind = at(cache.node, { ...withTeam([creatures.find((species) => species.element !== cache.node.element)!.id]), dayTick: DAY_TICKS });
    expect(sensedCaches(world, [cache.spawn], blind)).toEqual([]);
    const far = state({
      ...withTeam([helper.id]), dayTick: DAY_TICKS,
      playerPosition: { ...world.camp }, lastSafePosition: { ...world.camp },
    });
    const distance = Math.hypot(cache.node.position.x - world.camp.x, cache.node.position.z - world.camp.z);
    if (distance > CACHE_HELP_RADIUS) expect(sensedCaches(world, [cache.spawn], far)).toEqual([]);
  });
});

describe('gathering as one transaction', () => {
  it('picks a plain resource, tombstones it and schedules its return', async () => {
    const entry = resources.map((spawn) => ({ spawn, node: nodeFor(world, spawn, [], 'day')! })).find((row) => row.node.method === 'pick' && !row.node.nightOnly)!;
    const save = await storage(at(entry.node, { worldTick: 200 }));
    const after = await gather(world, save, 'pick-1', { spawn: entry.spawn, method: 'pick' });
    expect(after.inventory.some((stack) => stack?.itemId === entry.node.itemId)).toBe(true);
    expect(after.consumedEntityIds).toEqual([entry.node.entityId]);
    expect(after.respawns).toEqual([{ entityId: entry.node.entityId, tick: 200 + RESPAWN_TICKS }]);
    // The same command twice takes one material.
    const again = await gather(world, save, 'pick-1', { spawn: entry.spawn, method: 'pick' });
    expect(again).toEqual(after);
    await expect(gather(world, save, 'pick-2', { spawn: entry.spawn, method: 'pick' })).rejects.toThrow();
  });
  it('opens a vein with a stone ally, with a tool, or with three held seconds — and never for free', async () => {
    const vein = firstNode('dig');
    const empty = at(vein.node, { dayTick: vein.node.nightOnly ? DAY_TICKS : 0 });
    const bare = await storage(empty);
    await bare.transact('init', () => {});
    await expect(gather(world, bare, 'no-way', { spawn: vein.spawn, method: 'dig' })).rejects.toThrow();
    await expect(gather(world, bare, 'too-short', { spawn: vein.spawn, method: 'dig', holdTicks: DIG_HOLD_TICKS - 1 })).rejects.toThrow();
    // A refused dig leaves the vein exactly where it was.
    expect((await bare.load())!.consumedEntityIds).toEqual([]);
    expect((await bare.load())!.inventory.every((stack) => stack === null)).toBe(true);
    const held = await gather(world, bare, 'held', { spawn: vein.spawn, method: 'dig', holdTicks: DIG_HOLD_TICKS });
    expect(held.consumedEntityIds).toEqual([vein.node.entityId]);

    const stone = creatures.find((species) => species.element === 'taş')!;
    const ally = at(vein.node, { ...withTeam([stone.id]), dayTick: vein.node.nightOnly ? DAY_TICKS : 0 });
    expect(hasStoneAlly(ally)).toBe(true);
    const instant = await gather(world, await storage(ally), 'ally', { spawn: vein.spawn, method: 'dig' });
    expect(instant.consumedEntityIds).toEqual([vein.node.entityId]);
    const withTool = at(vein.node, { tools: [TOOL.pick], dayTick: vein.node.nightOnly ? DAY_TICKS : 0 });
    expect(hasDigTool(withTool)).toBe(true);
    expect(carries(withTool, TOOL.pick)).toBe(true);
    // A pick in the bag counts exactly like one on the belt; another tool does not open a vein.
    expect(hasDigTool(at(vein.node, { inventory: [{ itemId: TOOL.pick, quantity: 1 }, null, null, null] }))).toBe(true);
    expect(hasDigTool(at(vein.node, { tools: [TOOL.trowel] }))).toBe(false);
    const tooled = await gather(world, await storage(withTool), 'tool', { spawn: vein.spawn, method: 'dig' });
    expect(tooled.consumedEntityIds).toEqual([vein.node.entityId]);
    // A vein pays its own material and sometimes the region's rare one.
    const yields = digYield(world, vein.node);
    expect(yields[0]).toEqual({ itemId: vein.node.itemId, quantity: 1 });
    expect(yields.every((part) => itemById(part.itemId))).toBe(true);
  });
  it('refuses the wrong method, the wrong hour, the wrong distance and a locked world', async () => {
    const vein = firstNode('dig');
    const night = firstNode('pick', true);
    const cases: [string, WorldState, { spawn: ChunkSpawn; method: 'pick' | 'dig' | 'cache' }][] = [
      ['wrong method', at(vein.node, { ...withTeam([creatures.find((s) => s.element === 'taş')!.id]) }), { spawn: vein.spawn, method: 'pick' }],
      ['by day', at(night.node, { dayTick: 0 }), { spawn: night.spawn, method: 'pick' }],
      ['too far', state({ playerPosition: { ...world.camp }, lastSafePosition: { ...world.camp }, dayTick: DAY_TICKS }), { spawn: night.spawn, method: 'pick' }],
      ['in a panel', at(night.node, { dayTick: DAY_TICKS, mode: 'panel' }), { spawn: night.spawn, method: 'pick' }],
    ];
    for (const [label, world_state, request] of cases) {
      const save = await storage(world_state);
      await save.transact('init', () => {});
      await expect(gather(world, save, `deny-${label}`, request), label).rejects.toThrow();
      expect((await save.load())!.consumedEntityIds, label).toEqual([]);
    }
    expect(phaseAt(0)).toBe('day');
  });
  it('sends a full bag to the delivery box instead of losing the material', async () => {
    const entry = resources.map((spawn) => ({ spawn, node: nodeFor(world, spawn, [], 'day')! })).find((row) => row.node.method === 'pick' && !row.node.nightOnly)!;
    const packed = at(entry.node, {
      inventory: Array.from({ length: 12 }, () => ({ itemId: 'seal', quantity: 20 })),
    });
    const after = await gather(world, await storage(packed), 'overflow', { spawn: entry.spawn, method: 'pick' });
    expect(after.deliveryBox).toEqual([{ kind: 'item', itemId: entry.node.itemId, quantity: 1 }]);
    expect(after.consumedEntityIds).toEqual([entry.node.entityId]);
  });
});

describe('the camp garden', () => {
  const seeds = items.filter((item) => isSeed(item.id));
  it('knows which materials are seeds and what they grow into', () => {
    expect(seeds.length).toBeGreaterThan(0);
    for (const seed of seeds) {
      const harvest = gardenYield(seed.id);
      expect(harvest.quantity).toBe(GARDEN_YIELD);
      expect(itemById(harvest.itemId)?.biomeId).toBe(seed.biomeId);
    }
    expect(isSeed('seal')).toBe(false);
  });
  it('plants, waits three minutes of world time and harvests once', async () => {
    const seed = seeds[0];
    const camp = state({ atCamp: true, playerPosition: { ...world.camp }, lastSafePosition: { ...world.camp }, inventory: [{ itemId: seed.id, quantity: 2 }, null, null, null], worldTick: 10 });
    const save = await storage(camp);
    const planted = await plantSeed(world, save, 'plant', seed.id);
    expect(planted.garden).toEqual([{ itemId: seed.id, plantedTick: 10 }]);
    expect(planted.inventory[0]).toEqual({ itemId: seed.id, quantity: 1 });
    expect(gardenReady(planted.garden![0], planted.worldTick)).toBe(false);
    await expect(harvestGarden(world, save, 'early')).rejects.toThrow();
    const grown = await storage({ ...planted, worldTick: 10 + GARDEN_TICKS });
    const harvested = await harvestGarden(world, grown, 'harvest');
    expect(harvested.garden).toEqual([]);
    const yielded = gardenYield(seed.id);
    expect(harvested.inventory.filter((stack) => stack?.itemId === yielded.itemId).reduce((sum, stack) => sum + (stack?.quantity ?? 0), 0)).toBe(GARDEN_YIELD);
    await expect(harvestGarden(world, grown, 'twice')).rejects.toThrow();
  });
  it('refuses a non-seed, a full garden and planting away from the camp', async () => {
    const seed = seeds[0];
    const camp = state({ atCamp: true, playerPosition: { ...world.camp }, lastSafePosition: { ...world.camp }, inventory: [{ itemId: seed.id, quantity: 9 }, { itemId: 'seal', quantity: 1 }, null, null] });
    const save = await storage(camp);
    await save.transact('init', () => {});
    await expect(plantSeed(world, save, 'not-a-seed', 'seal')).rejects.toThrow();
    let current = camp;
    for (let plot = 0; plot < GARDEN_PLOTS; plot++) current = await plantSeed(world, save, `plot-${plot}`, seed.id);
    expect(current.garden).toHaveLength(GARDEN_PLOTS);
    await expect(plantSeed(world, save, 'one-too-many', seed.id)).rejects.toThrow();
    const away = await storage({ ...camp, atCamp: false });
    await away.transact('init', () => {});
    await expect(plantSeed(world, away, 'in-the-wild', seed.id)).rejects.toThrow();
    expect((await away.load())!.garden ?? []).toEqual([]);
  });
});

describe('the four gardener tools', () => {
  it('each opens one way of working the valley', () => {
    const cache = firstNode('cache');
    const blind = at(cache.node, { dayTick: DAY_TICKS });
    expect(nodeFor(world, cache.spawn, [], 'night', false)!.hidden).toBe(true);
    // The lens reads a mark no creature in the team can smell.
    expect(nodeFor(world, cache.spawn, [], 'night', true)!.hidden).toBe(false);
    expect(sensedCaches(world, [cache.spawn], blind)).toEqual([]);
    expect(sensedCaches(world, [cache.spawn], { ...blind, tools: [TOOL.lens] }).map((node) => node.entityId)).toEqual([cache.node.entityId]);
    expect(gardenPlots(blind)).toBe(GARDEN_PLOTS);
    expect(gardenPlots({ ...blind, tools: [TOOL.trowel] })).toBe(GARDEN_PLOTS + 2);
    expect(detectionRadiusWith('night', false)).toBe(16);
    expect(detectionRadiusWith('night', true)).toBe(24);
    expect(Object.values(TOOL).every((id) => itemById(id)?.effect?.kind === 'tool')).toBe(true);
  });
  it('plants two more beds with a trowel in the bag', async () => {
    const seed = items.filter((item) => isSeed(item.id))[0];
    const camp = state({
      atCamp: true, playerPosition: { ...world.camp }, lastSafePosition: { ...world.camp },
      inventory: [{ itemId: seed.id, quantity: 9 }, { itemId: TOOL.trowel, quantity: 1 }, null, null],
    });
    const save = await storage(camp);
    let current = camp;
    for (let plot = 0; plot < GARDEN_PLOTS + 2; plot++) current = await plantSeed(world, save, `bed-${plot}`, seed.id);
    expect(current.garden).toHaveLength(GARDEN_PLOTS + 2);
    await expect(plantSeed(world, save, 'one-too-many', seed.id)).rejects.toThrow();
  });
});

describe('battle loot as a seventh way', () => {
  it('drops the region material and sometimes a rare second one, fixed at encounter time', () => {
    const enemy = { id: 'wild', species: creatures[0], level: 3 };
    let bonuses = 0;
    for (let seed = 1; seed <= 400; seed++) {
      const plan = createLootPlan(`b${seed}`, enemy, false, seed);
      expect(plan.habitat).toEqual({ itemId: 'dew_leaf', quantity: 1 });
      expect(createLootPlan(`b${seed}`, enemy, false, seed)).toEqual(plan);
      if (plan.bonus) {
        bonuses++;
        expect(itemById(plan.bonus.itemId)?.rarity).toBe('rare');
        expect(itemById(plan.bonus.itemId)?.biomeId).toBe(creatures[0].biomeId);
      }
    }
    const share = bonuses / 400;
    expect(share).toBeGreaterThan(LOOT_BONUS_CHANCE / 2);
    expect(share).toBeLessThan(LOOT_BONUS_CHANCE * 2);
    expect(GAME_CONFIG.interactionRadius).toBeGreaterThan(0);
  });
});
