import { afterEach, describe, expect, it } from 'vitest';
import { BIOME_IDS } from '../../src/contracts';
import { GAME_CONFIG } from '../../src/config';
import { BIOME_EXTRA_RECIPE, BIOME_RECIPE, STARTING_RECIPE_ID, recipesForBiome, secretIdFor } from '../../src/content/secrets';
import { creatures, itemById } from '../../src/content/catalog';
import { createWorld } from '../../src/world/generation/world';
import { canOccupy } from '../../src/world/collision/collision';
import { sampleTerrain } from '../../src/world/terrain/terrain';
import { chunkAt, shrineInChunk, spawnsForChunk } from '../../src/world/chunks/chunks';
import {
  SHRINE_MAX_DISTANCE, SHRINE_MIN_DISTANCE, SHRINE_VISIT_RADIUS, biomeOfShrine, shrineAt, shrineById,
  shrineChest, shrineIdFor, shrinesFor, travelAnchors,
} from '../../src/world/shrines/shrines';
import { visitShrine } from '../../src/world/shrines/visit';
import { createWorldState, validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { createLootPlan } from '../../src/game/combat/rewards';
import { IndexedDbSave } from '../../src/game/save/indexeddb';

const world = createWorld();
const shrines = shrinesFor(world);
const distanceTo = (id: string) => {
  const shrine = shrineById(world, id)!;
  const region = world.regions.find((entry) => entry.biomeId === shrine.biomeId)!;
  return Math.hypot(shrine.position.x - region.entrance.x, shrine.position.z - region.entrance.z);
};
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [{ itemId: 'seal', quantity: 1 }, null, null, null],
    unlockedRecipeIds: [STARTING_RECIPE_ID], creatures: [], creatureCapacity: 3, eggCapacity: 2, eggs: [],
    battle: null, loot: null, rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, ...overrides };
}
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
async function storage(initial: WorldState) {
  const save = await IndexedDbSave.open<WorldState>({
    name: `shrine-${counter++}`, initial: () => structuredClone(initial),
    validate: (value) => validateWorldState(world, value),
  });
  opened.push(save); return save;
}
const atShrine = (biomeId: typeof BIOME_IDS[number], overrides: Partial<WorldState> = {}) =>
  state({ playerPosition: { ...shrineById(world, shrineIdFor(biomeId))!.position }, ...overrides });
afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });

describe('gardener shrines', () => {
  it('stands one walkable shrine in every region, 30–60 m from its entrance', () => {
    expect(shrines).toHaveLength(8);
    expect(shrines.map((shrine) => shrine.biomeId).sort()).toEqual([...BIOME_IDS].sort());
    for (const shrine of shrines) {
      const terrain = sampleTerrain(world, shrine.position);
      expect(terrain.traversable, shrine.id).toBe(true);
      expect(terrain.hazard, shrine.id).toBe('none');
      expect(terrain.road, shrine.id).toBe(false);
      expect(terrain.biomeId, shrine.id).toBe(shrine.biomeId);
      expect(canOccupy(world, shrine.position), shrine.id).toBe(true);
      const distance = distanceTo(shrine.id);
      expect(distance, shrine.id).toBeGreaterThanOrEqual(SHRINE_MIN_DISTANCE - GAME_CONFIG.cellSize);
      expect(distance, shrine.id).toBeLessThanOrEqual(SHRINE_MAX_DISTANCE + GAME_CONFIG.cellSize);
      expect(shrine.story.length).toBeGreaterThan(20);
      expect(biomeOfShrine(shrine.id)).toBe(shrine.biomeId);
    }
    expect(biomeOfShrine('shrine:nowhere')).toBeNull();
    expect(shrineById(world, 'shrine:nowhere')).toBeNull();
  });
  it('places them deterministically and never twice in the same spot', () => {
    const again = shrinesFor(createWorld());
    expect(again.map((shrine) => shrine.position)).toEqual(shrines.map((shrine) => shrine.position));
    const other = shrinesFor(createWorld('başka-tohum'));
    expect(other).toHaveLength(8);
    expect(other.map((shrine) => shrine.position)).not.toEqual(shrines.map((shrine) => shrine.position));
    expect(new Set(shrines.map((shrine) => `${shrine.position.x},${shrine.position.z}`)).size).toBe(8);
  });
  it('keeps the shrine ground clear of spawns and reports it chunk by chunk', () => {
    for (const shrine of shrines) {
      const chunk = chunkAt(shrine.position);
      expect(shrineInChunk(world, chunk)?.id).toBe(shrine.id);
      for (const spawn of spawnsForChunk(world, chunk)) {
        expect(Math.hypot(spawn.target.position.x - shrine.position.x, spawn.target.position.z - shrine.position.z), spawn.target.entityId)
          .toBeGreaterThanOrEqual(6);
      }
    }
    const empty = chunkAt({ x: world.camp.x, z: world.camp.z });
    expect(shrineInChunk(world, empty)).toBeNull();
  });
  it('answers proximity only inside the visit radius', () => {
    const shrine = shrines[0];
    expect(shrineAt(world, shrine.position)?.id).toBe(shrine.id);
    expect(shrineAt(world, { x: shrine.position.x + SHRINE_VISIT_RADIUS - 1, z: shrine.position.z })?.id).toBe(shrine.id);
    expect(shrineAt(world, { x: shrine.position.x + SHRINE_VISIT_RADIUS + 1, z: shrine.position.z })).toBeNull();
  });
  it('packs a chest of two region materials and one seal', () => {
    for (const biomeId of BIOME_IDS) {
      const chest = shrineChest(biomeId);
      expect(chest).toHaveLength(3);
      expect(chest.at(-1)).toEqual({ itemId: 'seal', quantity: 1 });
      for (const part of chest) expect(itemById(part.itemId), part.itemId).toBeDefined();
      expect(chest.slice(0, 2).every((part) => itemById(part.itemId)?.biomeId === biomeId)).toBe(true);
    }
  });
});

describe('visiting a shrine', () => {
  it('teaches the region recipe with no dice, hands the chest over and opens the anchor', async () => {
    const save = await storage(atShrine('forest'));
    const visited = await visitShrine(world, save, 'visit-forest', shrineIdFor('forest'));
    // Each shrine teaches two: the region product and the gardener's own tool or tonic.
    expect(recipesForBiome('forest')).toEqual([BIOME_RECIPE.forest, BIOME_EXTRA_RECIPE.forest]);
    expect(visited.unlockedRecipeIds).toEqual([STARTING_RECIPE_ID, BIOME_RECIPE.forest, BIOME_EXTRA_RECIPE.forest]);
    expect(visited.secretFlags).toEqual([secretIdFor('forest')]);
    expect(visited.shrines).toEqual([{ biomeId: 'forest', visitedTick: visited.worldTick, chestTaken: true }]);
    const chest = shrineChest('forest');
    for (const part of chest) {
      const held = visited.inventory.filter((stack) => stack?.itemId === part.itemId).reduce((sum, stack) => sum + (stack?.quantity ?? 0), 0);
      expect(held, part.itemId).toBeGreaterThanOrEqual(part.quantity);
    }
    expect(travelAnchors(world, visited.shrines).map((anchor) => anchor.id)).toEqual(['camp', shrineIdFor('forest')]);
  });
  it('gives the chest once: later visits only keep the anchor', async () => {
    const save = await storage(atShrine('ice'));
    const first = await visitShrine(world, save, 'visit-1', shrineIdFor('ice'));
    const seals = (s: WorldState) => s.inventory.reduce((sum, stack) => sum + (stack?.itemId === 'seal' ? stack.quantity : 0), 0);
    for (let repeat = 0; repeat < 10; repeat++) {
      const again = await visitShrine(world, save, `visit-${repeat + 2}`, shrineIdFor('ice'));
      expect(again.shrines).toEqual(first.shrines);
      expect(seals(again)).toBe(seals(first));
      expect(again.unlockedRecipeIds).toEqual(first.unlockedRecipeIds);
      expect(again.deliveryBox).toEqual(first.deliveryBox);
    }
    // The same commandId is a repeat, not a second chest either.
    expect(await visitShrine(world, save, 'visit-1', shrineIdFor('ice'))).toEqual(first);
  });
  it('refuses a shrine the player is not standing at, an unknown one and a locked world', async () => {
    const far = await storage(state());
    await expect(visitShrine(world, far, 'too-far', shrineIdFor('desert'))).rejects.toThrow();
    expect((await far.load())).toBeNull();
    const unknown = await storage(atShrine('sea'));
    await expect(visitShrine(world, unknown, 'ghost', 'shrine:nowhere')).rejects.toThrow();
    const busy = await storage(atShrine('sea', { mode: 'committing' }));
    await expect(visitShrine(world, busy, 'busy', shrineIdFor('sea'))).rejects.toThrow();
    const after = await storage(atShrine('sea'));
    const ok = await visitShrine(world, after, 'fine', shrineIdFor('sea'));
    expect(ok.shrines).toHaveLength(1);
  });
  it('sends an overflowing chest to the delivery box instead of dropping it', async () => {
    const full = atShrine('volcanic', {
      inventory: Array.from({ length: 12 }, () => ({ itemId: 'seal', quantity: 20 })),
    });
    const save = await storage(full);
    const visited = await visitShrine(world, save, 'overflow', shrineIdFor('volcanic'));
    expect(visited.deliveryBox.length).toBeGreaterThan(0);
    expect(visited.deliveryBox.every((entry) => entry.kind === 'item')).toBe(true);
    expect(visited.unlockedRecipeIds).toContain(BIOME_RECIPE.volcanic);
  });
  it('opens an anchor for every region once all eight are read', async () => {
    let current = state();
    for (const biomeId of BIOME_IDS) {
      const save = await storage({ ...current, playerPosition: { ...shrineById(world, shrineIdFor(biomeId))!.position } });
      current = await visitShrine(world, save, `tour-${biomeId}`, shrineIdFor(biomeId));
    }
    expect(current.shrines).toHaveLength(8);
    expect(new Set(current.unlockedRecipeIds)).toEqual(new Set([...Object.values(BIOME_RECIPE), ...Object.values(BIOME_EXTRA_RECIPE)]));
    expect(current.unlockedRecipeIds).toHaveLength(16);
    expect(travelAnchors(world, current.shrines)).toHaveLength(9);
  });
  it('no longer leaves a random gardener mark in battle loot', () => {
    const enemy = { id: 'wild', species: creatures[0], level: 3 };
    for (let seed = 1; seed < 50; seed++) expect(createLootPlan(`b${seed}`, enemy, seed % 2 === 0).secretId).toBeNull();
  });
});
