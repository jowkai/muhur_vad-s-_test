import { afterEach, describe, expect, it } from 'vitest';
import { GAME_CONFIG } from '../../src/config';
import { STARTING_RECIPE_ID } from '../../src/content/secrets';
import { creatures } from '../../src/content/catalog';
import { createWorld } from '../../src/world/generation/world';
import { chunkAt } from '../../src/world/chunks/chunks';
import { ChunkManager } from '../../src/world/chunks/manager';
import { TargetIndex } from '../../src/world/encounters/targets';
import { shrineIdFor, shrineById } from '../../src/world/shrines/shrines';
import { visitShrine } from '../../src/world/shrines/visit';
import { TRAVEL_TICKS, travelOptions, travelTo } from '../../src/world/travel';
import { DEFEAT_COOLDOWN_TICKS, chunkGate, createWorldState, validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { MAX_INCUBATION_TICKS } from '../../src/game/combat/rewards';
import { beginBattle, createBattle, stats } from '../../src/game/combat/core';
import { createLootPlan } from '../../src/game/combat/rewards';
import { IndexedDbSave, type FaultPoint } from '../../src/game/save/indexeddb';

const world = createWorld();
const forest = shrineById(world, shrineIdFor('forest'))!;
const player = { id: 'friend', species: creatures[0], level: 2 };
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: true, inventory: [{ itemId: 'seal', quantity: 1 }, null, null, null],
    unlockedRecipeIds: [STARTING_RECIPE_ID],
    creatures: [{ id: player.id, speciesId: player.species.id, level: 2, xp: 0, hp: stats(player).maxHp, maxHp: stats(player).maxHp }],
    creatureCapacity: 6, eggCapacity: 2, eggs: [], battle: null, loot: null,
    rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, activeCreatureId: player.id, party: [player.id], ...overrides };
}
const visited = (overrides: Partial<WorldState> = {}) =>
  state({ shrines: [{ biomeId: 'forest', visitedTick: 10, chestTaken: true }], ...overrides });
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
async function storage(initial: WorldState, fault?: (point: FaultPoint) => void) {
  const save = await IndexedDbSave.open<WorldState>({
    name: `travel-${counter++}`, initial: () => structuredClone(initial),
    validate: (value) => validateWorldState(world, value), fault,
  });
  opened.push(save); return save;
}
afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });

describe('fast travel anchors', () => {
  it('offers the camp always and a shrine only once it was read', () => {
    const fresh = travelOptions(world, state());
    expect(fresh.map((anchor) => anchor.id)).toEqual(['camp']);
    const open = travelOptions(world, visited({ playerPosition: { ...world.camp } }));
    expect(open.map((anchor) => anchor.id)).toEqual(['camp', shrineIdFor('forest')]);
    expect(open[0]).toMatchObject({ here: true, enabled: false, note: 'Zaten buradasın' });
    expect(open[1].enabled).toBe(true);
    expect(open[1].note).toContain('60 sn');
  });
  it('closes while a battle, a panel or a commit holds the world', () => {
    const battle = beginBattle(createBattle({
      battleId: 'b', encounterId: 'e', seed: 1, player, enemy: { id: 'wild', species: creatures[1], level: 1 },
    }));
    for (const overrides of [
      { mode: 'panel' as const }, { mode: 'committing' as const }, { mode: 'recovery' as const }, { mode: 'encounter' as const },
      { mode: 'battle' as const, battle, loot: createLootPlan('b', battle.enemy, false) },
    ]) {
      const closed = travelOptions(world, visited(overrides));
      expect(closed.every((anchor) => !anchor.enabled), overrides.mode).toBe(true);
    }
  });
});

describe('travelling', () => {
  it('moves the player, advances sixty seconds and keeps the record valid', async () => {
    const before = visited({ playerPosition: { ...world.camp }, worldTick: 500 });
    const save = await storage(before);
    const after = await travelTo(world, save, 'go-forest', shrineIdFor('forest'));
    expect(after.playerPosition).toEqual(forest.position);
    expect(after.lastSafePosition).toEqual(forest.position);
    expect(after.worldTick).toBe(500 + TRAVEL_TICKS);
    expect(after.atCamp).toBe(false);
    expect(() => validateWorldState(world, after)).not.toThrow();
    // The same command twice is one trip.
    expect(await travelTo(world, save, 'go-forest', shrineIdFor('forest'))).toEqual(after);
  });
  it('runs cooldowns down, brings due respawns back and matures eggs only at the camp', async () => {
    const eggs = [{ id: 'e1', encounterId: 'egg-1', speciesId: creatures[0].id, seed: 3, activeTicks: 100 }];
    const outbound = visited({
      playerPosition: { ...world.camp }, worldTick: 1000, eggs, consumedEntityIds: ['egg-1', 'gone'],
      // Sixty seconds outlast every cooldown the world can hand out, so both are gone on arrival.
      entityCooldowns: [{ entityId: 'cooling', ticks: 900 }, { entityId: 'slow', ticks: DEFEAT_COOLDOWN_TICKS }],
      respawns: [{ entityId: 'gone', tick: 1000 + TRAVEL_TICKS }],
    });
    const away = await travelTo(world, await storage(outbound), 'out', shrineIdFor('forest'));
    expect(away.entityCooldowns).toEqual([]);
    expect(TRAVEL_TICKS).toBeGreaterThan(DEFEAT_COOLDOWN_TICKS);
    expect(away.respawns).toEqual([]);
    expect(away.consumedEntityIds).toEqual(['egg-1']);
    // Away from the fire the egg waits exactly where it was.
    expect(away.eggs[0].activeTicks).toBe(100);
    const home = await travelTo(world, await storage({ ...away, shrines: outbound.shrines }), 'home', 'camp');
    expect(home.atCamp).toBe(true);
    expect(home.playerPosition).toEqual({ ...world.camp });
    expect(home.eggs[0].activeTicks).toBe(100 + TRAVEL_TICKS);
    const ripe = await travelTo(world, await storage({ ...home, eggs: [{ ...eggs[0], activeTicks: MAX_INCUBATION_TICKS - 10 }] }), 'wait', 'camp');
    expect(ripe.eggs[0].activeTicks).toBe(MAX_INCUBATION_TICKS);
  });
  it('refuses an unvisited anchor, an unknown one and a locked world without moving', async () => {
    const fresh = state({ playerPosition: { ...world.camp } });
    const save = await storage(fresh);
    await save.transact('init', () => {});
    for (const anchorId of [shrineIdFor('forest'), 'shrine:nowhere', 'nowhere']) {
      await expect(travelTo(world, save, `deny-${anchorId}`, anchorId), anchorId).rejects.toThrow();
    }
    expect((await save.load())!.playerPosition).toEqual(fresh.playerPosition);
    expect((await save.load())!.worldTick).toBe(fresh.worldTick);
    for (const mode of ['panel', 'committing', 'recovery'] as const) {
      const locked = await storage(visited({ mode, playerPosition: { ...world.camp } }));
      await locked.transact('init', () => {});
      await expect(travelTo(world, locked, 'locked', shrineIdFor('forest')), mode).rejects.toThrow();
      expect((await locked.load())!.playerPosition).toEqual(world.camp);
    }
  });
  it('leaves the player in place when the write faults, then travels on a retry', async () => {
    let enabled = false;
    const before = visited({ playerPosition: { ...world.camp }, worldTick: 42 });
    const save = await storage(before, (point) => { if (enabled && point === 'after-state') throw new Error('fault'); });
    await save.transact('init', () => {});
    enabled = true;
    await expect(travelTo(world, save, 'faulty', shrineIdFor('forest'))).rejects.toThrow();
    const stored = (await save.load())!;
    expect(stored.playerPosition).toEqual(before.playerPosition);
    expect(stored.worldTick).toBe(42);
    enabled = false;
    const after = await travelTo(world, save, 'retry', shrineIdFor('forest'));
    expect(after.playerPosition).toEqual(forest.position);
    expect(after.worldTick).toBe(42 + TRAVEL_TICKS);
  });
  it('re-centres chunk residency on the destination', async () => {
    const save = await storage(visited({ playerPosition: { ...world.camp } }));
    const after = await travelTo(world, save, 'ride', shrineIdFor('forest'));
    const index = new TargetIndex();
    const chunks = new ChunkManager(world, index, chunkGate(() => after));
    chunks.update(after.playerPosition);
    const middle = chunkAt(after.playerPosition);
    expect(chunks.residency.visual.some((chunk) => chunk.id === middle.id)).toBe(true);
    expect(chunks.residency.visual).toHaveLength((2 * GAME_CONFIG.visualChunkRadius + 1) ** 2);
    expect(chunks.shrines.some((shrine) => shrine.id === shrineIdFor('forest'))).toBe(true);
  });
  it('opens a new anchor as soon as its shrine is read', async () => {
    const save = await storage(state({ playerPosition: { ...shrineById(world, shrineIdFor('sea'))!.position } }));
    expect(travelOptions(world, state()).map((anchor) => anchor.id)).toEqual(['camp']);
    const read = await visitShrine(world, save, 'read-sea', shrineIdFor('sea'));
    expect(travelOptions(world, read).map((anchor) => anchor.id)).toEqual(['camp', shrineIdFor('sea')]);
    const home = await travelTo(world, save, 'sea-home', 'camp');
    expect(home.playerPosition).toEqual({ ...world.camp });
    expect(home.atCamp).toBe(true);
  });
});
