import { afterEach, describe, expect, it } from 'vitest';
import { MAX_LEVEL, type GameCommand } from '../../src/contracts';
import { GAME_CONFIG } from '../../src/config';
import { creatures } from '../../src/content/catalog';
import { createWorld } from '../../src/world/generation/world';
import { sampleTerrain } from '../../src/world/terrain/terrain';
import { canOccupy } from '../../src/world/collision/collision';
import { TargetIndex } from '../../src/world/encounters/targets';
import { CHUNK_GRID, chunkAt, residency, spawnsForChunk } from '../../src/world/chunks/chunks';
import { ChunkManager } from '../../src/world/chunks/manager';
import {
  DEFEAT_COOLDOWN_TICKS, FLEE_COOLDOWN_TICKS, RESPAWN_TICKS, checkpointExploration, chunkGate, commitEncounterOutcome,
  cooldownRemaining, createWorldState, explorationAllowed, restoreWorld, settlementOf, tickWorld,
  validateWorldState, type WorldState,
} from '../../src/world/persistence/world-save';
import { beginBattle, createBattle, stats, type BattleState } from '../../src/game/combat/core';
import { applyBattleCommand, createLootPlan } from '../../src/game/combat/rewards';
import { IndexedDbSave, type FaultPoint } from '../../src/game/save/indexeddb';

const world = createWorld();
const attack: GameCommand = { type: 'attack', slot: 0, commandId: 'attack', tick: 1 };
const player = { id: 'friend', species: creatures[0], level: 2 };
const enemy = { id: 'wild', species: creatures[0], level: 1 };
const safeAway = { x: world.camp.x + 30, z: world.camp.z };
const safeBack = { x: world.camp.x + 10, z: world.camp.z };

function state(overrides: Partial<WorldState> = {}): WorldState {
  const battle = beginBattle(createBattle({ battleId: 'b', encounterId: 'wild-1', seed: 1, player, enemy, inventorySnapshot: { seal: 1 }, captureCapacity: 1 }));
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [{ itemId: 'seal', quantity: 1 }, null], unlockedRecipeIds: [],
    creatures: [{ id: player.id, speciesId: player.species.id, level: 2, xp: 0, hp: stats(player).maxHp, maxHp: stats(player).maxHp }],
    creatureCapacity: 3, eggCapacity: 2, eggs: [], battle: null, loot: null,
    rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  const creatures = base.creatures.map(c => c.id === player.id ? { ...c, hp: overrides.battle?.playerHp ?? battle.playerHp } : c);
  const built: WorldState = { ...base, creatures, playerPosition: { ...safeAway }, lastSafePosition: { ...safeBack }, activeCreatureId: player.id,
    mode: 'battle', battle, loot: createLootPlan('b', enemy, false), ...overrides };
  return built.battle ? { ...built, battle: syncParty(built.battle) } : built;
}
/** Keeps the team record in step when a fixture overrides the fighter's HP directly. */
function syncParty(battle: BattleState): BattleState {
  return { ...battle, party: battle.party.map((member, index) => index === battle.activeIndex ? { ...member, hp: battle.playerHp } : member) };
}
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
async function storage(initial: WorldState, fault?: (point: FaultPoint) => void, name = `lifecycle-${counter++}`) {
  const save = await IndexedDbSave.open<WorldState>({
    name, initial: () => structuredClone(initial), validate: (value) => validateWorldState(world, value), fault,
  });
  opened.push(save); return save;
}
afterEach(() => { for (const save of opened) save.close(); opened.length = 0; });

describe('chunk residency and deterministic spawns', () => {
  it('keeps 25 visual and 9 simulation chunks inland and clips them at the world edge', () => {
    expect(residency(world.camp, GAME_CONFIG.visualChunkRadius)).toHaveLength(25);
    expect(residency(world.camp, GAME_CONFIG.simulationChunkRadius)).toHaveLength(9);
    const corner = { x: -GAME_CONFIG.worldSize / 2 + 1, z: -GAME_CONFIG.worldSize / 2 + 1 };
    expect(residency(corner, GAME_CONFIG.visualChunkRadius)).toHaveLength(9);
    expect(residency(corner, GAME_CONFIG.simulationChunkRadius)).toHaveLength(4);
    expect(chunkAt(corner)).toMatchObject({ chunkX: 0, chunkZ: 0 });
    expect(chunkAt({ x: GAME_CONFIG.worldSize / 2 - 1, z: 0 }).chunkX).toBe(CHUNK_GRID - 1);
    expect(() => chunkAt({ x: GAME_CONFIG.worldSize / 2, z: 0 })).toThrow(RangeError);
    expect(() => residency(world.camp, 1.5)).toThrow(RangeError);
  });
  it('places every entity inside its own chunk on walkable ground with stable unique ids', () => {
    const seen = new Set<string>();
    for (const chunk of residency({ x: 300, z: -420 }, 2)) {
      const spawns = spawnsForChunk(world, chunk);
      expect(spawnsForChunk(world, { ...chunk })).toEqual(spawns);
      for (const { target, speciesId, itemId, seed } of spawns) {
        expect(Number.isSafeInteger(seed) && seed >= 0 && seed <= 0xffffffff).toBe(true);
        if (target.kind === 'egg') expect(creatures.some((entry) => entry.id === speciesId)).toBe(true);
        if (target.kind === 'resource') expect(itemId).toBe(target.spriteId);
        expect(seen.has(target.entityId)).toBe(false); seen.add(target.entityId);
        expect(chunkAt(target.position).id).toBe(chunk.id);
        const cell = sampleTerrain(world, target.position);
        expect(cell.traversable).toBe(true); expect(cell.hazard).toBe('none');
        expect(target.level).toBeGreaterThanOrEqual(target.kind === 'resource' ? 0 : 1);
        expect(target.level).toBeLessThanOrEqual(MAX_LEVEL);
        if (target.aggressive) expect(target.kind).toBe('creature');
      }
    }
    expect(seen.size).toBeGreaterThan(20);
    const other = createWorld('другой-seed');
    expect(spawnsForChunk(other, chunkAt({ x: 300, z: -420 }))).not.toEqual(spawnsForChunk(world, chunkAt({ x: 300, z: -420 })));
  });
  it('loads the same entities however the player reached the chunk and unloads what it leaves', () => {
    const open = { consumed: () => false };
    const direct = new ChunkManager(world, new TargetIndex(), open);
    direct.update({ x: 100, z: 100 });
    const wandered = new ChunkManager(world, new TargetIndex(), open);
    for (const step of [{ x: -400, z: 380 }, { x: 600, z: -240 }, { x: 100, z: 100 }]) wandered.update(step);
    expect(wandered.loadedEntityIds).toEqual(direct.loadedEntityIds);
    expect(wandered.residency.visual).toHaveLength(25);
    expect(wandered.residency.simulation).toHaveLength(9);
    const camp = new ChunkManager(world, new TargetIndex(), open);
    camp.update(world.camp);
    const eggId = camp.loadedEntityIds.find((id) => camp.spawn(id)?.target.kind === 'egg')!;
    const record = camp.spawn(eggId)!;
    expect(creatures.some((entry) => entry.id === record.speciesId)).toBe(true);
    expect(camp.spawn(eggId)).toEqual(record);
    expect(camp.spawn('olmayan-varlık')).toBeNull();
    const departed = wandered.update({ x: 100, z: 700 });
    expect(departed.unloaded.length).toBeGreaterThan(0);
    for (const entityId of departed.removed) expect(wandered.loadedEntityIds).not.toContain(entityId);
  });
});

describe('durable tombstones and cooldown gates', () => {
  function gated(consumed: string[], cooling: Map<string, number>) {
    const index = new TargetIndex();
    const manager = new ChunkManager(world, index, {
      consumed: (id) => consumed.includes(id), suppressed: (id) => (cooling.get(id) ?? 0) > 0,
    });
    return { index, manager };
  }
  it('never respawns a consumed entity across unload, reload and a fresh session', () => {
    const consumed: string[] = []; const cooling = new Map<string, number>();
    const { index, manager } = gated(consumed, cooling);
    manager.update(world.camp);
    expect(manager.loadedEntityIds.length).toBeGreaterThan(10);
    const victim = manager.loadedEntityIds.find((id) => index.query(world.camp, 24).some((target) => target.entityId === id))!;
    expect(victim).toBeTypeOf('string');
    consumed.push(victim);
    expect(manager.refresh().removed).toContain(victim);
    manager.update({ x: 700, z: 700 });
    manager.update(world.camp);
    expect(manager.loadedEntityIds).not.toContain(victim);
    const fresh = gated(consumed, cooling);
    fresh.manager.update(world.camp);
    expect(fresh.manager.loadedEntityIds).not.toContain(victim);
    expect(fresh.index.query(world.camp, 24).map((target) => target.entityId)).not.toContain(victim);
  });
  it('hides a cooling entity and brings it back when the cooldown expires', () => {
    const consumed: string[] = []; const cooling = new Map<string, number>();
    const { manager } = gated(consumed, cooling);
    manager.update(world.camp);
    expect(manager.loadedEntityIds.length).toBeGreaterThan(10);
    const target = manager.loadedEntityIds[0];
    cooling.set(target, FLEE_COOLDOWN_TICKS);
    expect(manager.refresh().removed).toContain(target);
    cooling.set(target, 0);
    expect(manager.refresh().added).toContain(target);
    expect(manager.loadedEntityIds).toContain(target);
  });
});

describe('persisted world record', () => {
  it('rejects foreign seeds, impossible positions and malformed discovery or cooldown data', () => {
    expect(() => validateWorldState(world, state({ mode: 'exploring', battle: null, loot: null }))).not.toThrow();
    const invalid: Partial<WorldState>[] = [
      { seed: 'başka-tohum' }, { saveVersion: 5 as unknown as WorldState['saveVersion'] },
      // v3 fields are part of the record now, so their broken shapes must be refused too.
      { playerName: '' }, { playerName: ' boşluklu ' }, { playerName: 'x'.repeat(40) },
      { grafts: [{ creatureId: 'yok', moveId: 'touch', tick: 1 }] },
      { grafts: [{ creatureId: 'friend', moveId: 'yok', tick: 1 }] },
      { mount: { creatureId: 'yok', role: 'ride' } },
      { speedEffects: [{ itemId: 'yok', multiplier: 1.5, untilTick: 10 }] },
      { speedEffects: [{ itemId: 'seal', multiplier: 9, untilTick: 10 }] },
      { playerPosition: { x: 1e6, z: 0 } }, { lastSafePosition: { x: Number.NaN, z: 0 } },
      { discoveredCells: [5, 5] }, { discoveredCells: [7, 3] }, { discoveredCells: [-1] },
      { entityCooldowns: [{ entityId: 'a', ticks: 0 }] },
      { entityCooldowns: [{ entityId: 'a', ticks: DEFEAT_COOLDOWN_TICKS + 1 }] },
      { entityCooldowns: [{ entityId: 'a', ticks: 5 }, { entityId: 'a', ticks: 6 }] },
      { worldTick: -1 }, { activeCreatureId: 'yok' }, { activeCreatureId: null },
      // v4 fields join the record, so their broken shapes are refused on the same footing.
      { seenSpeciesIds: ['yok'] }, { discoveredItemIds: ['yok'] },
      { loadouts: [{ creatureId: 'yok', moveIds: ['touch', 'guard', 'strike', 'mend'] }] },
      { loadouts: [{ creatureId: 'friend', moveIds: ['touch'] }] },
    ];
    for (const patch of invalid) expect(() => validateWorldState(world, state(patch))).toThrow();
    const walkable = spawnsForChunk(world, chunkAt(world.camp)).every(({ target }) => canOccupy(world, target.position));
    expect(walkable).toBe(true);
  });
  it('advances world time only while exploring and expires cooldowns tick by tick', () => {
    const exploring = state({ mode: 'exploring', battle: null, loot: null, entityCooldowns: [{ entityId: 'a', ticks: 2 }] });
    expect(tickWorld(exploring, true)).toBe(exploring);
    expect(tickWorld(state({ mode: 'panel', battle: null, loot: null }))).toMatchObject({ worldTick: 0 });
    expect(tickWorld(state())).toMatchObject({ worldTick: 0 });
    const once = tickWorld(exploring);
    expect(once).toMatchObject({ worldTick: 1, entityCooldowns: [{ entityId: 'a', ticks: 1 }] });
    expect(tickWorld(once).entityCooldowns).toEqual([]);
    expect(explorationAllowed(exploring)).toBe(true);
    expect(explorationAllowed(exploring, true)).toBe(false);
    expect(explorationAllowed(state())).toBe(false);
  });
  it('merges discovery forward, refuses rewound time and refuses solid or battle-mode checkpoints', async () => {
    const save = await storage(state({ mode: 'exploring', battle: null, loot: null, discoveredCells: [4, 9] }));
    const checkpoint = { position: safeAway, yaw: 1, lastSafePosition: safeBack, worldTick: 10, discoveredCells: [9, 2], entityCooldowns: [{ entityId: 'a', ticks: 3 }] };
    const saved = await checkpointExploration(world, save, 'c1', checkpoint);
    expect(saved.discoveredCells).toEqual([2, 4, 9]);
    expect(saved).toMatchObject({ worldTick: 10, playerYaw: 1 });
    await expect(checkpointExploration(world, save, 'c2', { ...checkpoint, worldTick: 9 })).rejects.toThrow();
    await expect(checkpointExploration(world, save, 'c3', { ...checkpoint, position: { x: 1e6, z: 0 } })).rejects.toThrow();
    expect((await save.load())!.discoveredCells).toEqual([2, 4, 9]);
    const battling = await storage(state());
    await expect(checkpointExploration(world, battling, 'c4', checkpoint)).rejects.toThrow();
  });
});

describe('encounter settlement and blocked movement', () => {
  async function fought(patch: Partial<WorldState>, command: GameCommand) {
    const save = await storage(state(patch));
    const resolved = await applyBattleCommand(save, 'b', command);
    return { save, resolved };
  }
  it('keeps the win position, consumes the target and leaves no cooldown', async () => {
    const battle = state().battle!; battle.enemyHp = 1;
    const { save, resolved } = await fought({ battle }, attack);
    expect(resolved.battle!.outcome).toBe('WON');
    expect(explorationAllowed(resolved)).toBe(false);
    expect(settlementOf(resolved)).toEqual({ entityId: 'wild-1', outcome: 'won' });
    const settled = await commitEncounterOutcome(world, save, 'commit-win', 'b');
    expect(settled).toMatchObject({ mode: 'exploring', battle: null, loot: null, playerPosition: safeAway });
    expect(settled.consumedEntityIds).toEqual(['wild-1']);
    expect(settled.entityCooldowns).toEqual([]);
    expect(explorationAllowed(settled)).toBe(true);
    for (let i = 0; i < 50; i++) await commitEncounterOutcome(world, save, `again-${i}`, 'b');
    expect(await save.load()).toEqual(settled);
  });
  it('returns a defeated player to camp with a 30s cooldown and no tombstone', async () => {
    const battle = state().battle!; battle.playerHp = 1; battle.enemyHp = stats(enemy).maxHp;
    const { save, resolved } = await fought({ battle }, attack);
    expect(resolved.battle!.outcome).toBe('LOST');
    const settled = await commitEncounterOutcome(world, save, 'commit-loss', 'b');
    expect(settled.playerPosition).toEqual(world.camp);
    expect(settled.lastSafePosition).toEqual(world.camp);
    expect(settled.consumedEntityIds).toEqual([]);
    expect(cooldownRemaining(settled, 'wild-1')).toBe(DEFEAT_COOLDOWN_TICKS);
  });
  it('returns a fleeing player to the last safe position with an 8s cooldown', async () => {
    const { save, resolved } = await fought({}, { type: 'flee', commandId: 'flee', tick: 1 });
    expect(resolved.battle!.outcome).toBe('FLED');
    const settled = await commitEncounterOutcome(world, save, 'commit-flee', 'b');
    expect(settled.playerPosition).toEqual(safeBack);
    expect(cooldownRemaining(settled, 'wild-1')).toBe(FLEE_COOLDOWN_TICKS);
    const restored = restoreWorld(world, () => settled);
    expect(restored.movement.position).toEqual(safeBack);
    expect(restored.chunks.loadedEntityIds).not.toContain('wild-1');
  });
  it('refuses to unlock the world before the reward ledger or while the battle is unresolved', async () => {
    const unresolved = await storage(state());
    await expect(commitEncounterOutcome(world, unresolved, 'x', 'b')).rejects.toThrow();
    const battle = state().battle!; battle.enemyHp = 1;
    const { save, resolved } = await fought({ battle }, attack);
    await expect(save.transact('strip-ledger', (draft) => { draft.rewardLedger = []; })).rejects.toThrow();
    expect((await save.load())!.rewardLedger).toEqual(resolved.rewardLedger);
    await expect(commitEncounterOutcome(world, save, 'z', 'other-battle')).rejects.toThrow();
    expect((await save.load())!.mode).toBe(resolved.mode);
  });
  it.each(['after-backup', 'after-state', 'after-ledger'] as const)('a %s save error keeps the world locked until a retry succeeds', async (point) => {
    let enabled = false;
    const battle = state().battle!; battle.playerHp = 1; battle.enemyHp = stats(enemy).maxHp;
    const save = await storage(state({ battle }), (p) => { if (enabled && p === point) throw new Error('fault'); });
    const resolved = await applyBattleCommand(save, 'b', attack);
    enabled = true;
    await expect(commitEncounterOutcome(world, save, 'commit', 'b')).rejects.toThrow();
    const blocked = (await save.load())!;
    expect(blocked).toEqual(resolved);
    expect(blocked.mode).toBe('committing');
    expect(explorationAllowed(blocked)).toBe(false);
    expect(blocked.playerPosition).toEqual(safeAway);
    expect(blocked.entityCooldowns).toEqual([]);
    enabled = false;
    const retried = await commitEncounterOutcome(world, save, 'commit', 'b');
    expect(explorationAllowed(retried)).toBe(true);
    expect(retried.playerPosition).toEqual(world.camp);
  });
  it('rebuilds a session where consumed targets stay gone and cooling targets stay hidden', () => {
    const settled = state({ mode: 'exploring', battle: null, loot: null });
    const manager = new ChunkManager(world, new TargetIndex(), chunkGate(() => settled));
    manager.update(settled.playerPosition, true);
    const [consumedId, coolingId] = manager.loadedEntityIds;
    expect(consumedId).not.toBe(coolingId);
    const record = { ...settled, consumedEntityIds: [consumedId], entityCooldowns: [{ entityId: coolingId, ticks: 10 }] };
    const restored = restoreWorld(world, () => record);
    expect(restored.chunks.loadedEntityIds).not.toContain(consumedId);
    expect(restored.chunks.loadedEntityIds).not.toContain(coolingId);
    expect(restored.chunks.residency.visual).toHaveLength(25);
    expect(restored.discovery.serialize()).toEqual([]);
  });
});

describe('timed respawn', () => {
  it('schedules a defeated wild creature back and never returns a collected or sealed one', async () => {
    const battle = state().battle!; battle.enemyHp = 1;
    const save = await storage(state({ battle, inventory: [{ itemId: 'seal', quantity: 1 }, null, null, null] }), undefined, 'respawn-win');
    const won = await applyBattleCommand(save, 'b', attack);
    expect(won.battle!.outcome).toBe('WON');
    const settled = await commitEncounterOutcome(world, save, 'settle', 'b');
    expect(settled.consumedEntityIds).toEqual(['wild-1']);
    expect(settled.respawns).toEqual([{ entityId: 'wild-1', tick: RESPAWN_TICKS }]);

    const early = await checkpointExploration(world, save, 'early', {
      position: safeAway, yaw: 0, lastSafePosition: safeBack,
      worldTick: RESPAWN_TICKS - 1, discoveredCells: [], entityCooldowns: [],
    });
    expect(early.respawns).toHaveLength(1);
    expect(early.consumedEntityIds).toEqual(['wild-1']);
    const due = await checkpointExploration(world, save, 'due', {
      position: safeAway, yaw: 0, lastSafePosition: safeBack,
      worldTick: RESPAWN_TICKS, discoveredCells: [], entityCooldowns: [],
    });
    expect(due.respawns).toEqual([]);
    expect(due.consumedEntityIds).toEqual([]);
    const manager = new ChunkManager(world, new TargetIndex(), chunkGate(() => due));
    manager.update(due.playerPosition, true);
    expect(chunkGate(() => due).consumed('wild-1')).toBe(false);
  });
  it('rejects a record that would respawn a sealed creature or a collected egg', () => {
    const sealed = state({
      mode: 'exploring', battle: null, loot: null,
      creatures: [state().creatures[0], { id: 'capture:wild-1', speciesId: creatures[0].id, level: 1, xp: 0, hp: 5, maxHp: stats({ id: 'x', species: creatures[0], level: 1 }).maxHp }],
      consumedEntityIds: ['wild-1'], respawns: [{ entityId: 'wild-1', tick: 10 }],
    });
    expect(() => validateWorldState(world, sealed)).toThrow();
    const hatched = state({
      mode: 'exploring', battle: null, loot: null,
      eggs: [{ id: 'e1', encounterId: 'egg-1', speciesId: creatures[0].id, seed: 2, activeTicks: 0 }],
      consumedEntityIds: ['egg-1'], respawns: [{ entityId: 'egg-1', tick: 10 }],
    });
    expect(() => validateWorldState(world, hatched)).toThrow();
    const orphan = state({ mode: 'exploring', battle: null, loot: null, respawns: [{ entityId: 'nobody', tick: 10 }] });
    expect(() => validateWorldState(world, orphan)).toThrow();
    const ok = state({ mode: 'exploring', battle: null, loot: null, consumedEntityIds: ['wild-9'], respawns: [{ entityId: 'wild-9', tick: 10 }] });
    expect(() => validateWorldState(world, ok)).not.toThrow();
  });
});
