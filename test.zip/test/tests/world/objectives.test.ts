import { describe, expect, it } from 'vitest';
import { BIOME_IDS, PARTY_LIMIT } from '../../src/contracts';
import { GAME_CONFIG } from '../../src/config';
import { BIOME_RECIPE, STARTING_RECIPE_ID } from '../../src/content/secrets';
import { creatures } from '../../src/content/catalog';
import { createWorld } from '../../src/world/generation/world';
import { createWorldState, validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { stats } from '../../src/game/combat/core';
import {
  MAPPED_SHARE, OBJECTIVES, objectiveById, objectiveList, objectiveProgress, type ObjectiveId,
} from '../../src/world/objectives';

const world = createWorld();
const CELLS = (GAME_CONFIG.worldSize / GAME_CONFIG.cellSize) ** 2;
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [{ itemId: 'seal', quantity: 1 }, null],
    unlockedRecipeIds: [STARTING_RECIPE_ID], creatures: [], creatureCapacity: 60, eggCapacity: 4, eggs: [],
    battle: null, loot: null, rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, ...overrides };
}
const owned = (id: string, speciesIndex: number, level = 1) => {
  const species = creatures[speciesIndex % creatures.length];
  const maxHp = stats({ id, species, level }).maxHp;
  return { id, speciesId: species.id, level, xp: 0, hp: maxHp, maxHp };
};
const cells = (count: number) => Array.from({ length: count }, (_, index) => index);

describe('objectives derived from the save', () => {
  it('defines exactly eight rows as data, each with a title, hint, target and unit', () => {
    expect(OBJECTIVES).toHaveLength(8);
    expect(new Set(OBJECTIVES.map((objective) => objective.id)).size).toBe(8);
    for (const objective of OBJECTIVES) {
      expect(objective.title.length, objective.id).toBeGreaterThan(3);
      expect(objective.hint.length, objective.id).toBeGreaterThan(10);
      expect(objective.unit.length, objective.id).toBeGreaterThan(1);
      expect(Number.isSafeInteger(objective.target) && objective.target > 0, objective.id).toBe(true);
      expect(Object.isFrozen(objective)).toBe(true);
    }
    expect(Object.isFrozen(OBJECTIVES)).toBe(true);
  });
  it('reads a fresh save as eight untouched objectives', () => {
    const list = objectiveList(state());
    expect(list).toHaveLength(8);
    expect(list.every((objective) => !objective.done)).toBe(true);
    expect(list.find((objective) => objective.id === 'all-recipes')!.value).toBe(1);
    expect(objectiveProgress(state())).toBe(0);
  });
  it('counts shrines, recipes, slots, seals, eggs, levels and mapped ground', () => {
    const shrines = BIOME_IDS.map((biomeId) => ({ biomeId, visitedTick: 1, chestTaken: true }));
    const party = Array.from({ length: PARTY_LIMIT }, (_, index) => `p${index}`);
    const full = state({
      shrines,
      unlockedRecipeIds: Object.values(BIOME_RECIPE),
      creatures: [
        ...party.map((id, index) => owned(id, index)),
        ...Array.from({ length: 8 }, (_, index) => owned(`capture:e${index}`, index)),
        owned('egg:first', 1),
        owned('veteran', 2, 12),
      ],
      party,
      discoveredCells: cells(Math.round(CELLS * MAPPED_SHARE)),
    });
    const done = (id: ObjectiveId) => objectiveById(full, id).done;
    for (const id of OBJECTIVES.map((objective) => objective.id)) expect(done(id), id).toBe(true);
    expect(objectiveProgress(full)).toBe(1);
    expect(objectiveById(full, 'veteran-level').value).toBe(10);
  });
  it('counts distinct species, not captured creatures', () => {
    const sameSpecies = state({
      creatures: Array.from({ length: 8 }, (_, index) => owned(`capture:e${index}`, 0)),
    });
    expect(objectiveById(sameSpecies, 'sealed-species').value).toBe(1);
    const mixed = state({ creatures: Array.from({ length: 8 }, (_, index) => owned(`capture:e${index}`, index)) });
    expect(objectiveById(mixed, 'sealed-species').value).toBe(8);
    // An egg or a starter is not a seal.
    const hatched = state({ creatures: [owned('egg:one', 3), owned('starter', 4)] });
    expect(objectiveById(hatched, 'sealed-species').value).toBe(0);
    expect(objectiveById(hatched, 'hatched-egg').done).toBe(true);
  });
  it('clamps a value at its target and never reports more than done', () => {
    const many = state({
      creatures: [owned('veteran', 0, 30), ...Array.from({ length: 12 }, (_, index) => owned(`capture:e${index}`, index))],
      discoveredCells: cells(CELLS),
    });
    expect(objectiveById(many, 'veteran-level')).toMatchObject({ value: 10, target: 10, ratio: 1, done: true });
    expect(objectiveById(many, 'sealed-species').value).toBe(8);
    expect(objectiveById(many, 'mapped-valley').ratio).toBe(1);
  });
  it('keeps every finished objective finished as the save grows', () => {
    const steps: Partial<WorldState>[] = [
      {},
      { shrines: [{ biomeId: 'meadow', visitedTick: 5, chestTaken: true }] },
      { creatures: [owned('capture:a', 0)] },
      { unlockedRecipeIds: Object.values(BIOME_RECIPE) },
      { discoveredCells: cells(Math.round(CELLS * MAPPED_SHARE)) },
      { party: ['p0', 'p1', 'p2', 'p3', 'p4', 'p5'], creatures: Array.from({ length: 6 }, (_, index) => owned(`p${index}`, index)) },
    ];
    let current: Partial<WorldState> = {};
    const seen = new Set<ObjectiveId>();
    let lastRatio = 0;
    for (const step of steps) {
      current = { ...current, ...step };
      const snapshot = state(current);
      validateWorldState(world, { ...snapshot, activeCreatureId: snapshot.party[0] ?? null });
      for (const objective of objectiveList(snapshot)) {
        if (objective.done) seen.add(objective.id);
        // Nothing the save can do turns a finished objective back off.
        expect(seen.has(objective.id) ? objective.done : true, objective.id).toBe(true);
      }
      const ratio = objectiveProgress(snapshot);
      expect(ratio).toBeGreaterThanOrEqual(lastRatio);
      lastRatio = ratio;
    }
    expect(lastRatio).toBe(0.5);
  });
  it('stores no quest state of its own: the same save always reads the same', () => {
    const snapshot = state({ shrines: [{ biomeId: 'sea', visitedTick: 3, chestTaken: true }] });
    const copy = JSON.parse(JSON.stringify(snapshot)) as WorldState;
    expect(objectiveList(copy)).toEqual(objectiveList(snapshot));
    expect(Object.keys(snapshot)).toEqual(Object.keys(copy));
    // Reading objectives is pure: it touches nothing in the save.
    const before = JSON.stringify(snapshot);
    objectiveList(snapshot); objectiveProgress(snapshot);
    expect(JSON.stringify(snapshot)).toBe(before);
  });
});
