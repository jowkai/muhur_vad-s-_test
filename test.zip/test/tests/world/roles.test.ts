import { describe, expect, it } from 'vitest';
import { CREATURE_ROLES, type MountRecord, type SpeedEffect } from '../../src/contracts';
import { creatureById, creatures, itemById } from '../../src/content/catalog';
import { cosmeticStage, type OwnedCreature } from '../../src/game/progression';
import { stats } from '../../src/game/combat/core';
import {
  FLY_STAGE, ROLE_RULES, activeSpeedEffects, bestMountRole, mountRefusal, mountRoles, partyRoles,
  permissions, roleUnlocked, roleViews, rolesOf, speedEffectFor, tonicMultiplier, travelSpeed, unlockedRoles,
} from '../../src/game/roles';
import { createWorld } from '../../src/world/generation/world';
import { canOccupy } from '../../src/world/collision/collision';
import { sampleTerrain } from '../../src/world/terrain/terrain';
import { stepMovement } from '../../src/world/movement/movement';

const world = createWorld();
const owned = (speciesId: string, level: number, id = speciesId): OwnedCreature => {
  const species = creatureById(speciesId)!;
  const maxHp = stats({ id, species, level }).maxHp;
  return { id, speciesId, level, xp: 0, hp: maxHp, maxHp };
};
const speciesWith = (role: string) => creatures.filter((entry) => entry.roles.includes(role as never));

describe('the six roles', () => {
  it('opens each role at its own level and never without the species', () => {
    expect(Object.keys(ROLE_RULES).sort()).toEqual([...CREATURE_ROLES].sort());
    expect(ROLE_RULES.claw.unlockLevel).toBe(10);
    expect(ROLE_RULES.ride.unlockLevel).toBe(20);
    expect(ROLE_RULES.fly.unlockLevel).toBe(28);
    for (const role of CREATURE_ROLES) {
      const species = speciesWith(role);
      expect(species.length, role).toBeGreaterThan(0);
      const creature = owned(species[0].id, ROLE_RULES[role].unlockLevel);
      expect(roleUnlocked(creature, role), role).toBe(true);
      expect(roleUnlocked(owned(species[0].id, ROLE_RULES[role].unlockLevel - 1), role), role).toBe(false);
      // A species without the role never gets it, however high its level.
      const other = creatures.find((entry) => !entry.roles.includes(role as never))!;
      expect(roleUnlocked(owned(other.id, 50), role), `${role}/${other.id}`).toBe(false);
    }
  });
  it('asks a flier for a grown body as well as a level', () => {
    const flier = speciesWith('fly')[0];
    expect(cosmeticStage(ROLE_RULES.fly.unlockLevel)).toBeGreaterThanOrEqual(FLY_STAGE);
    expect(roleUnlocked(owned(flier.id, 28), 'fly')).toBe(true);
    expect(roleUnlocked(owned(flier.id, 9), 'fly')).toBe(false);
    const views = roleViews(owned(flier.id, 12));
    const view = views.find((entry) => entry.role === 'fly')!;
    expect(view.unlocked).toBe(false);
    expect(view.note).toContain('28');
    expect(roleViews(owned(flier.id, 30)).find((entry) => entry.role === 'fly')!.unlocked).toBe(true);
  });
  it('lists what a creature and a whole team can do', () => {
    const rider = speciesWith('ride')[0];
    expect(rolesOf(rider.id)).toContain('ride');
    expect(unlockedRoles(owned(rider.id, 1))).toEqual([]);
    expect(unlockedRoles(owned(rider.id, 50))).toEqual(rolesOf(rider.id).filter((role) => ROLE_RULES[role].unlockLevel <= 50));
    const digger = speciesWith('dig')[0];
    const team = [owned(rider.id, 24, 'a'), owned(digger.id, 20, 'b')];
    const open = partyRoles(['a', 'b'], team);
    expect(open.has('ride')).toBe(true);
    expect(open.has('dig')).toBe(true);
    expect(partyRoles([], team).size).toBe(0);
  });
});

describe('mounting and speed', () => {
  const rider = speciesWith('ride')[0];
  it('refuses a mount that is not ready and accepts one that is', () => {
    const grown = owned(rider.id, 24, 'mount');
    expect(mountRefusal({ creature: grown, party: ['mount'] })).toBeNull();
    expect(mountRefusal({ creature: grown, party: [] })).toBe('Yalnız takımdaki bir yaratığa binilir');
    expect(mountRefusal({ creature: undefined, party: ['mount'] })).toBe('Bu yaratık koleksiyonda yok');
    expect(mountRefusal({ creature: { ...grown, hp: 0 }, party: ['mount'] })).toBe('Baygın yaratığa binilemez');
    const young = owned(rider.id, 4, 'mount');
    expect(mountRefusal({ creature: young, party: ['mount'] })).toContain('Sv');
    const carrierless = creatures.find((entry) => !entry.roles.some((role) => ROLE_RULES[role].carries))!;
    expect(mountRefusal({ creature: owned(carrierless.id, 50, 'mount'), party: ['mount'] })).toBe('Bu yaratık taşıyamaz');
    expect(bestMountRole(grown)).toBe(mountRoles(grown)[0]);
  });
  it('makes a rarer mount faster and a tonic faster still', () => {
    const plain = owned(rider.id, 24, 'mount');
    const onFoot = travelSpeed({ mount: null, creatures: [plain] });
    expect(onFoot).toBe(1);
    const mount: MountRecord = { creatureId: 'mount', role: 'ride' };
    const mounted = travelSpeed({ mount, creatures: [plain] });
    expect(mounted).toBeGreaterThan(onFoot);
    const rare = creatures.filter((entry) => entry.roles.includes('ride') && entry.rarity === 'rare')[0];
    const common = creatures.filter((entry) => entry.roles.includes('ride') && entry.rarity !== 'rare')[0];
    const rareSpeed = travelSpeed({ mount: { creatureId: 'r', role: 'ride' }, creatures: [owned(rare.id, 30, 'r')] });
    const commonSpeed = travelSpeed({ mount: { creatureId: 'c', role: 'ride' }, creatures: [owned(common.id, 30, 'c')] });
    expect(rareSpeed).toBeGreaterThan(commonSpeed);
    // A tonic multiplies whatever the mount already gives, and only while it lasts.
    const tonic: SpeedEffect = { itemId: 'swift_tonic', multiplier: 1.35, untilTick: 1000 };
    expect(travelSpeed({ mount, creatures: [plain], effects: [tonic], worldTick: 10 })).toBeCloseTo(mounted * 1.35, 6);
    expect(travelSpeed({ mount, creatures: [plain], effects: [tonic], worldTick: 1001 })).toBeCloseTo(mounted, 6);
    expect(travelSpeed({ mount: null, creatures: [], effects: [tonic], worldTick: 0 })).toBe(1.35);
  });
  it('keeps only the running tonics and never stacks them', () => {
    const effects: SpeedEffect[] = [
      { itemId: 'swift_tonic', multiplier: 1.35, untilTick: 500 },
      { itemId: 'gale_tonic', multiplier: 1.6, untilTick: 200 },
    ];
    expect(activeSpeedEffects(effects, 100)).toHaveLength(2);
    expect(tonicMultiplier(effects, 100)).toBe(1.6);
    expect(activeSpeedEffects(effects, 300)).toHaveLength(1);
    expect(tonicMultiplier(effects, 300)).toBe(1.35);
    expect(tonicMultiplier(effects, 900)).toBe(1);
    const brewed = speedEffectFor('gale_tonic', 600)!;
    expect(brewed.multiplier).toBe(itemById('gale_tonic')!.effect!.value);
    expect(brewed.untilTick).toBe(600 + 180 * 60);
    expect(speedEffectFor('seal', 0)).toBeNull();
  });
});

describe('where a mount may go', () => {
  const deepWater = (() => {
    const sea = world.regions.find((region) => region.biomeId === 'sea')!;
    for (let offset = 0; offset < 400; offset += 2) {
      const point = { x: sea.center.x + offset, z: sea.center.z };
      if (sampleTerrain(world, point).hazard === 'deep-water') return point;
    }
    throw new Error('derin su bulunamadı');
  })();
  it('lets swimming and flight cross deep water, and nothing cross the edge', () => {
    expect(canOccupy(world, deepWater)).toBe(false);
    expect(canOccupy(world, deepWater, undefined, { swim: true })).toBe(true);
    expect(canOccupy(world, deepWater, undefined, { fly: true })).toBe(true);
    const outside = { x: 5000, z: 0 };
    expect(canOccupy(world, outside, undefined, { fly: true, swim: true })).toBe(false);
    expect(permissions({ creatureId: 'a', role: 'fly' })).toEqual({ fly: true, swim: true, dig: false });
    expect(permissions({ creatureId: 'a', role: 'swim' })).toEqual({ fly: false, swim: true, dig: false });
    expect(permissions(null)).toEqual({ fly: false, swim: false, dig: false });
  });
  it('walks faster on a mount and keeps the last dry spot to return to', () => {
    const start = { position: { ...world.camp }, yaw: 0, lastSafePosition: { ...world.camp } };
    const command = { type: 'move' as const, direction: { x: 1, z: 0 }, commandId: 'm', tick: 1 };
    const walked = stepMovement(world, start, command, { mode: 'exploring' });
    const ridden = stepMovement(world, start, command, { mode: 'exploring' }, false, { speed: 2 });
    expect(ridden.position.x - start.position.x).toBeCloseTo((walked.position.x - start.position.x) * 2, 6);
    // An absurd multiplier is clamped instead of teleporting the player.
    const capped = stepMovement(world, start, command, { mode: 'exploring' }, false, { speed: 99 });
    expect(capped.position.x - start.position.x).toBeLessThanOrEqual((walked.position.x - start.position.x) * 3 + 1e-6);
    const swimming = stepMovement(world, { position: { ...deepWater }, yaw: 0, lastSafePosition: { ...world.camp } },
      command, { mode: 'exploring' }, false, { passes: { swim: true } });
    expect(swimming.position).not.toEqual(deepWater);
    expect(canOccupy(world, swimming.lastSafePosition)).toBe(true);
  });
});
