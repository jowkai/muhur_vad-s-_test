import { afterEach, describe, expect, it } from 'vitest';
import { TREE_KINDS, type TreeKind } from '../../src/contracts';
import { creatureById, creatures, itemById } from '../../src/content/catalog';
import { stats } from '../../src/game/combat/core';
import { ROLE_RULES } from '../../src/game/roles';
import { createWorld } from '../../src/world/generation/world';
import { CHUNK_GRID, TREE_TABLE, chunkKey, spawnsForChunk, treeFor, type ChunkSpawn } from '../../src/world/chunks/chunks';
import { DAY_TICKS } from '../../src/world/daynight';
import {
  AUTO_PICK_RADIUS, FELL_RESPAWN_TICKS, autoPickTargets, clawBearer, drinkTonic, fellYield, gather, nodeFor,
} from '../../src/world/gathering/gathering';
import { tonicMultiplier } from '../../src/game/roles';
import { createWorldState, validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import type { ItemClass } from '../../src/content/schema';

/** The catalogue narrows a product away from `itemClass`, so material lookups go through this. */
const classOf = (itemId: string): ItemClass | null => {
  const item = itemById(itemId);
  return item && 'itemClass' in item ? item.itemClass : null;
};
import { IndexedDbSave } from '../../src/game/save/indexeddb';

const world = createWorld();
const clawSpecies = creatures.find((row) => row.roles.includes('claw'))!;
const plainSpecies = creatures.find((row) => !row.roles.includes('claw'))!;
const owned = (speciesId: string, level: number, id = speciesId) => {
  const species = creatureById(speciesId)!;
  const maxHp = stats({ id, species, level }).maxHp;
  return { id, speciesId, level, xp: 0, hp: maxHp, maxHp };
};
const allSpawns = (phase: 'day' | 'night' = 'day'): ChunkSpawn[] => {
  const out: ChunkSpawn[] = [];
  for (let z = 0; z < CHUNK_GRID; z += 3) for (let x = 0; x < CHUNK_GRID; x += 3) {
    out.push(...spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z }, phase));
  }
  return out;
};
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [null, null, null, null, null, null],
    unlockedRecipeIds: ['salve'], creatures: [], creatureCapacity: 60, eggCapacity: 4, eggs: [],
    battle: null, loot: null, rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, ...overrides };
}
const withClaw = (level = ROLE_RULES.claw.unlockLevel) => ({
  creatures: [owned(clawSpecies.id, level, 'claw')], party: ['claw'], activeCreatureId: 'claw',
});
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
async function storage(initial: WorldState) {
  const save = await IndexedDbSave.open<WorldState>({
    name: `harvest-${counter++}`, initial: () => structuredClone(initial),
    validate: (value) => validateWorldState(world, value),
  });
  opened.push(save); return save;
}
afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });
const trees = (phase: 'day' | 'night' = 'day') => allSpawns(phase).filter((spawn) => spawn.treeKind);

describe('trees as resources', () => {
  it('grows nine kinds, each only where and when it belongs', () => {
    expect(Object.keys(TREE_TABLE).sort()).toEqual([...TREE_KINDS].sort());
    const standing = trees('night');
    expect(standing.length).toBeGreaterThan(20);
    const kinds = new Set(standing.map((spawn) => spawn.treeKind));
    expect(kinds.size).toBeGreaterThan(2);
    for (const spawn of standing) {
      const entry = TREE_TABLE[spawn.treeKind as TreeKind];
      expect(classOf(spawn.itemId!), spawn.itemId!).toBe('wood');
      expect(entry.itemId).toBe(spawn.itemId);
    }
    // The ghost tree only stands after dark, and the day slot is a different entity.
    const ghostByDay = trees('day').filter((spawn) => spawn.treeKind === 'ghostwood');
    expect(ghostByDay).toEqual([]);
    expect(trees('night').some((spawn) => spawn.treeKind === 'ghostwood')).toBe(true);
    // The sea grows two woods now; both are legal, and both are wood.
    expect(['frostpine', 'coralwood']).toContain(treeFor('sea', .5, 'day')?.kind);
    expect(['oak', 'ironroot']).toContain(treeFor('earth', .9, 'day')?.kind);
    expect(treeFor('meadow', 0, 'night')).not.toBeNull();
  });
  it('places the same trees for the same seed and chunk', () => {
    const chunk = { id: chunkKey(9, 9), chunkX: 9, chunkZ: 9 };
    expect(spawnsForChunk(world, chunk, 'night')).toEqual(spawnsForChunk(world, chunk, 'night'));
    expect(spawnsForChunk(createWorld(), chunk, 'day')).toEqual(spawnsForChunk(world, chunk, 'day'));
  });
  it('asks for a clawed creature and gives wood, essence and sometimes a gem', () => {
    const tree = trees('night')[0];
    const node = nodeFor(world, tree, [], 'night')!;
    expect(node.method).toBe('fell');
    expect(node.autoPick).toBe(false);
    expect(node.hidden).toBe(false);
    expect(clawBearer(state())).toBeNull();
    expect(clawBearer(state(withClaw(ROLE_RULES.claw.unlockLevel - 1)))).toBeNull();
    expect(clawBearer(state(withClaw()))).toBe('claw');
    const rare = trees('night').map((spawn) => nodeFor(world, spawn, [], 'night')!).find((entry) => entry.treeKind === 'ghostwood')!;
    const yields = fellYield(world, rare);
    expect(yields[0].itemId).toBe(rare.itemId);
    expect(yields.some((part) => classOf(part.itemId) === 'essence')).toBe(true);
    expect(yields.every((part) => itemById(part.itemId))).toBe(true);
  });
  it('fells a tree once, pays out and lets it grow back after five minutes', async () => {
    const tree = trees('night')[0];
    const node = nodeFor(world, tree, [], 'night')!;
    const at = state({
      ...withClaw(), dayTick: DAY_TICKS + 10, worldTick: 100,
      playerPosition: { ...node.position }, lastSafePosition: { ...node.position },
    });
    const save = await storage(at);
    const after = await gather(world, save, 'fell-1', { spawn: tree, method: 'fell' });
    expect(after.consumedEntityIds).toEqual([node.entityId]);
    expect(after.respawns).toEqual([{ entityId: node.entityId, tick: 100 + FELL_RESPAWN_TICKS }]);
    expect(after.inventory.some((stack) => stack?.itemId === node.itemId)).toBe(true);
    expect(FELL_RESPAWN_TICKS).toBe(300 * 60);
    // The same command again changes nothing, and a second attempt is refused.
    expect(await gather(world, save, 'fell-1', { spawn: tree, method: 'fell' })).toEqual(after);
    await expect(gather(world, save, 'fell-2', { spawn: tree, method: 'fell' })).rejects.toThrow();
  });
  it('refuses a tree when nobody in the team has claws, and takes nothing', async () => {
    const tree = trees('night')[0];
    const node = nodeFor(world, tree, [], 'night')!;
    const bare = state({
      creatures: [owned(plainSpecies.id, 30, 'soft')], party: ['soft'], activeCreatureId: 'soft',
      dayTick: DAY_TICKS + 10, playerPosition: { ...node.position }, lastSafePosition: { ...node.position },
    });
    const save = await storage(bare);
    await save.transact('init', () => {});
    await expect(gather(world, save, 'no-claw', { spawn: tree, method: 'fell' })).rejects.toThrow();
    const stored = (await save.load())!;
    expect(stored.consumedEntityIds).toEqual([]);
    expect(stored.inventory.every((stack) => stack === null)).toBe(true);
  });
});

describe('speed tonics', () => {
  it('drinks one bottle, runs for three minutes and never stacks with itself', async () => {
    const start = state({ worldTick: 500, inventory: [{ itemId: 'swift_tonic', quantity: 2 }, null, null, null, null, null] });
    const save = await storage(start);
    const after = await drinkTonic(world, save, 'drink-1', 'swift_tonic');
    expect(after.speedEffects).toHaveLength(1);
    expect(after.speedEffects[0]).toMatchObject({ itemId: 'swift_tonic', multiplier: itemById('swift_tonic')!.effect!.value });
    expect(after.speedEffects[0].untilTick).toBe(500 + 180 * 60);
    expect(after.inventory[0]).toEqual({ itemId: 'swift_tonic', quantity: 1 });
    expect(tonicMultiplier(after.speedEffects, 600)).toBeGreaterThan(1);
    expect(tonicMultiplier(after.speedEffects, 500 + 180 * 60 + 1)).toBe(1);
    // A second bottle of the same tonic refreshes the clock instead of adding a second effect.
    const again = await drinkTonic(world, save, 'drink-2', 'swift_tonic');
    expect(again.speedEffects).toHaveLength(1);
    await expect(drinkTonic(world, save, 'drink-3', 'swift_tonic')).rejects.toThrow();
    await expect(drinkTonic(world, save, 'drink-4', 'seal')).rejects.toThrow();
  });
});

describe('material picked up in passing', () => {
  const loose = () => allSpawns('day')
    .map((spawn) => ({ spawn, node: nodeFor(world, spawn, [], 'day')! }))
    .filter((entry) => entry.node && entry.node.autoPick)[0];
  it('marks loose material for auto pick and leaves decisions to the player', () => {
    const entry = loose();
    expect(entry.node.method).toBe('pick');
    expect(entry.node.autoPick).toBe(true);
    for (const spawn of allSpawns('day')) {
      const node = nodeFor(world, spawn, [], 'day');
      if (!node) continue;
      // Only a plain, visible pick is taken in passing.
      if (node.autoPick) expect(node.method).toBe('pick');
      if (node.method !== 'pick' || node.hidden) expect(node.autoPick).toBe(false);
    }
  });
  it('only reaches what the player is standing next to', () => {
    const entry = loose();
    const here = state({
      playerPosition: { ...entry.node.position }, lastSafePosition: { ...entry.node.position },
    });
    expect(autoPickTargets(world, [entry.spawn], here).map((node) => node.entityId)).toEqual([entry.node.entityId]);
    const away = state({
      playerPosition: { x: entry.node.position.x + AUTO_PICK_RADIUS + 2, z: entry.node.position.z },
      lastSafePosition: { ...entry.node.position },
    });
    expect(autoPickTargets(world, [entry.spawn], away)).toEqual([]);
    // Something already taken is never offered again.
    const taken = state({ ...here, consumedEntityIds: [entry.node.entityId] });
    expect(autoPickTargets(world, [entry.spawn], taken)).toEqual([]);
  });
  it('takes it through the same transaction the deliberate pick uses', async () => {
    const entry = loose();
    const save = await storage(state({
      playerPosition: { ...entry.node.position }, lastSafePosition: { ...entry.node.position },
    }));
    const after = await gather(world, save, `pick:${entry.node.entityId}`, { spawn: entry.spawn, method: 'pick' });
    expect(after.inventory.some((stack) => stack?.itemId === entry.node.itemId)).toBe(true);
    expect(after.consumedEntityIds).toEqual([entry.node.entityId]);
    expect(autoPickTargets(world, [entry.spawn], after)).toEqual([]);
  });
});

describe('v3 source and role restrictions', () => {
  it('never puts a gem in an automatic pick or cache node', () => {
    let gems = 0;
    for (const spawn of allSpawns('night')) {
      if (classOf(spawn.itemId ?? '') !== 'gem') continue;
      const node = nodeFor(world, spawn, [], 'night')!;
      expect(node.method).toBe('dig'); expect(node.autoPick).toBe(false);
      gems++;
    }
    expect(gems).toBeGreaterThan(0);
  });
  it('lets a healthy level 16 non-stone digger open a vein without a tool or hold', async () => {
    const digger = creatures.find((row) => row.roles.includes('dig') && row.element !== 'taş')!;
    expect(digger).toBeDefined();
    const spawn = allSpawns('night').find((s) => nodeFor(world, s, [], 'night')?.method === 'dig')!;
    const member = owned(digger.id, 16, 'dig');
    const base = state({ creatures: [member], party: ['dig'], activeCreatureId: 'dig',
      dayTick: DAY_TICKS + 10, playerPosition: spawn.target.position, lastSafePosition: spawn.target.position });
    const save = await storage(base);
    const after = await gather(world, save, 'role-dig', { spawn, method: 'dig', holdTicks: 0 });
    expect(after.consumedEntityIds).toContain(spawn.target.entityId);
    expect(await gather(world, save, 'role-dig', { spawn, method: 'dig', holdTicks: 0 })).toEqual(after);
    for (const denied of [{ ...member, level: 15 }, { ...member, hp: 0 }]) {
      const db = await storage({ ...base, creatures: [denied] });
      await expect(gather(world, db, 'refuse-dig', { spawn, method: 'dig', holdTicks: 0 })).rejects.toThrow();
    }
  });
});
