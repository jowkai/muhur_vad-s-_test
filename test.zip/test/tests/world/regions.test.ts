import { describe, expect, it } from 'vitest';
import { BIOME_IDS, MAX_LEVEL, type BiomeId } from '../../src/contracts';
import { creatures } from '../../src/content/catalog';
import { xpRequired } from '../../src/game/progression';
import { ROLE_RULES } from '../../src/game/roles';
import { createWorld } from '../../src/world/generation/world';
import { BANDS, CHUNK_GRID, REGION_GATE, chunkKey, spawnsForChunk } from '../../src/world/chunks/chunks';
import { sampleTerrain } from '../../src/world/terrain/terrain';
import { canOccupy } from '../../src/world/collision/collision';

const world = createWorld();
const sweep = (phase: 'day' | 'night' = 'day') => {
  const found: { biomeId: BiomeId; level: number; kind: string; entityId: string }[] = [];
  for (let z = 0; z < CHUNK_GRID; z += 2) for (let x = 0; x < CHUNK_GRID; x += 2) {
    for (const spawn of spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z }, phase)) {
      found.push({
        biomeId: sampleTerrain(world, spawn.target.position).biomeId,
        level: spawn.target.level, kind: spawn.target.kind, entityId: spawn.target.entityId,
      });
    }
  }
  return found;
};

describe('deeper regions', () => {
  it('raises every band and stops at the new ceiling', () => {
    expect(BANDS.meadow).toEqual([1, 5]);
    expect(BANDS.flame).toEqual([36, 50]);
    expect(MAX_LEVEL).toBe(50);
    const order: BiomeId[] = ['meadow', 'forest', 'sea', 'desert', 'earth', 'ice', 'volcanic', 'flame'];
    for (let index = 1; index < order.length; index++) {
      // Each region on the road is deeper than the one before it.
      expect(BANDS[order[index]][0], order[index]).toBeGreaterThanOrEqual(BANDS[order[index - 1]][0]);
      expect(BANDS[order[index]][1], order[index]).toBeGreaterThan(BANDS[order[index - 1]][1]);
    }
    for (const biome of BIOME_IDS) {
      const [low, high] = BANDS[biome];
      expect(low, biome).toBeGreaterThanOrEqual(1);
      expect(high, biome).toBeLessThanOrEqual(MAX_LEVEL);
      expect(high, biome).toBeGreaterThan(low);
    }
  });
  it('spawns creatures inside their own band and never above the ceiling', () => {
    const seen = sweep();
    expect(seen.length).toBeGreaterThan(200);
    let deep = 0;
    for (const entry of seen) {
      if (entry.kind !== 'creature') { expect(entry.level).toBeLessThanOrEqual(1); continue; }
      const [low, high] = BANDS[entry.biomeId];
      expect(entry.level, `${entry.biomeId}/${entry.entityId}`).toBeGreaterThanOrEqual(low);
      expect(entry.level, `${entry.biomeId}/${entry.entityId}`).toBeLessThanOrEqual(high);
      expect(entry.level).toBeLessThanOrEqual(MAX_LEVEL);
      if (entry.level > 30) deep++;
    }
    // The old ceiling is no longer the end of the world.
    expect(deep).toBeGreaterThan(0);
  });
  it('names the role each region leans on, and every gate is a real role', () => {
    expect(REGION_GATE.meadow).toBeNull();
    for (const biome of BIOME_IDS) {
      const gate = REGION_GATE[biome];
      if (!gate) continue;
      expect(Object.keys(ROLE_RULES)).toContain(gate);
      // A region never asks for a role no species can offer.
      expect(creatures.some((row) => row.roles.includes(gate)), gate).toBe(true);
      // And the creature that opens it can be raised inside the regions before it.
      expect(ROLE_RULES[gate].unlockLevel).toBeLessThanOrEqual(MAX_LEVEL);
    }
    expect(REGION_GATE.sea).toBe('swim');
    expect(REGION_GATE.flame).toBe('fly');
  });
  it('keeps deep water impassable on foot and open to a swimmer', () => {
    const sea = world.regions.find((region) => region.biomeId === 'sea')!;
    let water = null as { x: number; z: number } | null;
    for (let offset = 0; offset < 400 && !water; offset += 2) {
      const point = { x: sea.center.x + offset, z: sea.center.z };
      if (sampleTerrain(world, point).hazard === 'deep-water') water = point;
    }
    expect(water).not.toBeNull();
    expect(canOccupy(world, water!)).toBe(false);
    expect(canOccupy(world, water!, undefined, { swim: true })).toBe(true);
  });
  it('keeps generation deterministic after the band change', () => {
    const chunk = { id: chunkKey(12, 20), chunkX: 12, chunkZ: 20 };
    expect(spawnsForChunk(world, chunk)).toEqual(spawnsForChunk(world, chunk));
    expect(spawnsForChunk(createWorld(), chunk)).toEqual(spawnsForChunk(world, chunk));
    // The experience ladder still grows with the level, so the ceiling is reachable but slow.
    expect(xpRequired(50)).toBeGreaterThan(xpRequired(30));
    expect(xpRequired(1)).toBeGreaterThan(0);
  });
});
