import { afterEach, describe, expect, it } from 'vitest';
import { PARTY_LIMIT } from '../../src/contracts';
import { creatures } from '../../src/content/catalog';
import { secretIdFor, STARTING_RECIPE_ID } from '../../src/content/secrets';
import { stats } from '../../src/game/combat/core';
import { IndexedDbSave, SaveError } from '../../src/game/save/indexeddb';
import { createWorld } from '../../src/world/generation/world';
import {
  DAY_CYCLE_TICKS, WORLD_SAVE_VERSION, createWorldState, migrateWorldState, validateWorldState, type WorldState,
} from '../../src/world/persistence/world-save';

const world = createWorld();
const species = creatures[0];
const maxHp = stats({ id: 'friend', species, level: 2 }).maxHp;
const owned = (id: string, level = 2) => ({ id, speciesId: species.id, level, xp: 0, hp: maxHp, maxHp: stats({ id, species, level }).maxHp });
/** A record exactly as v1 wrote it: one active creature, region marks as secret flags. */
function legacy(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  const modern = createWorldState(world, {
    mode: 'exploring', atCamp: true, inventory: [{ itemId: 'seal', quantity: 2 }, null], unlockedRecipeIds: [STARTING_RECIPE_ID],
    creatures: [owned('friend'), owned('capture:wild-1', 4)],
    creatureCapacity: 60, eggCapacity: 2, eggs: [], battle: null, loot: null,
    rewardLedger: [], consumedEntityIds: [], secretFlags: [secretIdFor('meadow'), secretIdFor('forest')], deliveryBox: [],
  });
  const { party: _party, shrines: _shrines, dayTick: _dayTick, tools: _tools, ...rest } = modern;
  void _party; void _shrines; void _dayTick; void _tools;
  return { ...rest, saveVersion: 1, activeCreatureId: 'friend', ...overrides };
}
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
async function storage(raw: unknown, name = `migration-${counter++}`) {
  await putRaw(name, { version: 2, state: raw });
  const save = await IndexedDbSave.open<WorldState>({
    name, initial: () => createWorldState(world, {
      mode: 'exploring', atCamp: true, inventory: [null], unlockedRecipeIds: [STARTING_RECIPE_ID],
      creatures: [owned('friend')], creatureCapacity: 60, eggCapacity: 2, eggs: [], battle: null, loot: null,
      rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
    }),
    migrate: migrateWorldState, validate: (value) => validateWorldState(world, value),
  });
  opened.push(save);
  return save;
}
async function putRaw(name: string, value: unknown): Promise<void> {
  const request = indexedDB.open(name, 1);
  await new Promise<void>((resolve, reject) => {
    request.onupgradeneeded = () => { request.result.createObjectStore('records'); request.result.createObjectStore('commands'); };
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const db = request.result;
      const tx = db.transaction('records', 'readwrite');
      tx.objectStore('records').put(value, 'current');
      tx.oncomplete = () => { db.close(); resolve(); };
      tx.onabort = () => { db.close(); reject(tx.error); };
    };
  });
}
afterEach(() => { for (const save of opened) save.close(); opened.length = 0; });

describe('v1 to v2 record migration', () => {
  it('moves the single active creature into the first party slot', () => {
    const upgraded = migrateWorldState(legacy()) as WorldState;
    expect(upgraded.saveVersion).toBe(WORLD_SAVE_VERSION);
    expect(upgraded.party).toEqual(['friend']);
    expect(upgraded.activeCreatureId).toBe('friend');
    expect(upgraded.party.length).toBeLessThanOrEqual(PARTY_LIMIT);
    expect(upgraded.creatures).toHaveLength(2);
    expect(upgraded.creatureCapacity).toBe(60);
    expect(() => validateWorldState(world, upgraded)).not.toThrow();
  });
  it('turns known region marks into visited shrines without replaying their chests', () => {
    const upgraded = migrateWorldState(legacy()) as WorldState;
    expect(upgraded.shrines).toEqual([
      { biomeId: 'meadow', visitedTick: 0, chestTaken: true },
      { biomeId: 'forest', visitedTick: 0, chestTaken: true },
    ]);
    expect(upgraded.dayTick).toBe(0);
    expect(upgraded.tools).toEqual([]);
    expect(upgraded.secretFlags).toEqual([secretIdFor('meadow'), secretIdFor('forest')]);
  });
  it('leaves an already upgraded record untouched and survives a headless creature', () => {
    const modern = createWorldState(world, {
      mode: 'exploring', atCamp: true, inventory: [null], unlockedRecipeIds: [STARTING_RECIPE_ID],
      creatures: [owned('friend')], creatureCapacity: 60, eggCapacity: 2, eggs: [], battle: null, loot: null,
      rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
    });
    expect(migrateWorldState(modern)).toBe(modern);
    const empty = migrateWorldState(legacy({ creatures: [], activeCreatureId: 'friend' })) as WorldState;
    expect(empty.party).toEqual([]);
    expect(empty.activeCreatureId).toBeNull();
    expect(migrateWorldState(null)).toBeNull();
    expect(migrateWorldState('bozuk')).toBe('bozuk');
  });
  it('upgrades the stored record once, keeps the original as a backup and repeats safely', async () => {
    const name = 'migration-store';
    const save = await storage(legacy(), name);
    const loaded = (await save.load())!;
    expect(loaded.saveVersion).toBe(WORLD_SAVE_VERSION);
    expect(loaded.party).toEqual(['friend']);
    const raw = await save.exportRaw();
    expect((raw.records.find(([key]) => key === 'current')?.[1] as { state: WorldState }).state.party).toEqual(['friend']);
    expect((raw.records.find(([key]) => key === 'backup')?.[1] as { state: { saveVersion: number } }).state.saveVersion).toBe(1);
    for (let i = 0; i < 50; i++) await save.load();
    const after = await save.exportRaw();
    expect((after.records.find(([key]) => key === 'backup')?.[1] as { state: { saveVersion: number } }).state.saveVersion).toBe(1);
    const resumed = await save.transact('after-migration', (draft) => { draft.dayTick = 120; });
    expect(resumed.dayTick).toBe(120);
    expect(resumed.party).toEqual(['friend']);
  });
  it('explains an unupgradable record instead of deleting it', async () => {
    for (const [name, broken] of [
      ['party-overflow', legacy({ party: ['a', 'b', 'c', 'd', 'e', 'f', 'g'], saveVersion: WORLD_SAVE_VERSION })],
      ['active-outside-party', legacy({ party: ['capture:wild-1'], saveVersion: WORLD_SAVE_VERSION })],
      ['bad-day', legacy({ saveVersion: WORLD_SAVE_VERSION, party: ['friend'], shrines: [], tools: [], dayTick: DAY_CYCLE_TICKS })],
      ['bad-shrine', legacy({ saveVersion: WORLD_SAVE_VERSION, party: ['friend'], tools: [], dayTick: 0, shrines: [{ biomeId: 'yok', visitedTick: 0, chestTaken: true }] })],
    ] as const) {
      const save = await storage(broken, `migration-${name}`);
      const failure = await save.load().catch((error: unknown) => error);
      expect(failure, name).toBeInstanceOf(SaveError);
      expect((failure as SaveError).code, name).toBe('corrupt');
      expect((failure as SaveError).message, name).toMatch(/dışa aktar/);
      const stored = await save.exportRaw();
      expect(stored.records.find(([key]) => key === 'current'), name).toBeTruthy();
    }
  });
});
