import { describe, expect, it } from 'vitest';
import { Object3D, Vector3 } from 'three';
import { FollowCamera, applyPlayerPose } from '../../src/render/camera/follow-camera';
import { FixedStepClock } from '../../src/render/core/fixed-step';
import { KeyboardInput } from '../../src/render/input/keyboard';

function key(code: string, type = 'keydown', extras = {}) {
  return Object.assign(new Event(type, { cancelable: true }), { code, ...extras });
}
describe('north-oriented follow camera', () => {
  it('keeps north up, projects player at center and updates aspect on resize', () => {
    const follow = new FollowCamera(); follow.resize(1440, 900);
    follow.follow({ x: 10, z: 20 }, 3, 0, true);
    const player = new Vector3(10, 3, 20).project(follow.camera);
    expect(player.x).toBeCloseTo(0); expect(player.y).toBeCloseTo(0);
    expect(new Vector3(10, 3, 19).project(follow.camera).y).toBeGreaterThan(0);
    expect(new Vector3(11, 3, 20).project(follow.camera).x).toBeGreaterThan(0);
    const viewDirection = follow.camera.getWorldDirection(new Vector3());
    expect(Math.asin(-viewDirection.y)).toBeCloseTo(Math.PI / 3);
    expect((follow.camera.right - follow.camera.left) / 32).toBeCloseTo(1.6);
    follow.resize(390, 844); expect((follow.camera.right - follow.camera.left) / 32).toBeCloseTo(390 / 844);
    follow.resize(0, 0); expect(follow.camera.projectionMatrix.elements.every(Number.isFinite)).toBe(true);
  });
  it('damps consistently at 30/60/120 FPS and snaps on teleport', () => {
    const outcomes = [30, 60, 120].map((fps) => {
      const follow = new FollowCamera();
      for (let frame = 0; frame < fps / 2; frame++) follow.follow({ x: 10, z: 0 }, 0, 1 / fps);
      expect(Math.abs(follow.camera.position.x - 10)).toBeLessThan(0.1);
      return follow.camera.position.x;
    });
    expect(outcomes[0]).toBeCloseTo(outcomes[1], 10); expect(outcomes[1]).toBeCloseTo(outcomes[2], 10);
    const follow = new FollowCamera(); follow.follow({ x: 100, z: 400 }, 0, 0, true);
    expect(follow.camera.position.x).toBe(100);
  });
  it('rotates the player without changing the camera orientation', () => {
    const follow = new FollowCamera(), proxy = new Object3D();
    const rotation = follow.camera.quaternion.clone();
    for (const yaw of [0, Math.PI / 2, Math.PI, -Math.PI / 2]) {
      applyPlayerPose(proxy, { x: 4, z: 7 }, 2, yaw);
      expect(proxy.rotation.y).toBe(yaw); expect(follow.camera.quaternion.equals(rotation)).toBe(true);
    }
    expect(() => applyPlayerPose(proxy, { x: NaN, z: 0 }, 0, 0)).toThrow();
  });
});
describe('fixed timestep', () => {
  it('produces identical simulation time at three display rates', () => {
    for (const fps of [30, 60, 120]) {
      const clock = new FixedStepClock(); let ticks = 0, seconds = 0;
      for (let frame = 0; frame < fps * 10; frame++) clock.advance(1 / fps, (dt) => { ticks++; seconds += dt; });
      expect(ticks).toBe(600); expect(seconds).toBeCloseTo(10);
    }
  });
  it('limits catchup to five steps, tracks dropped time and clears paused accumulation', () => {
    const clock = new FixedStepClock(); let ticks = 0;
    expect(clock.advance(1, () => ticks++).steps).toBe(5);
    expect(clock.droppedSeconds).toBeCloseTo(1 - 5 / 60);
    clock.advance(1 / 120, () => ticks++);
    expect(clock.advance(30, () => ticks++, true)).toEqual({ steps: 0, alpha: 0 });
    expect(clock.advance(1 / 120, () => ticks++).steps).toBe(0);
    expect(ticks).toBe(5);
    expect(() => clock.advance(NaN, () => undefined)).toThrow();
  });
});
describe('keyboard command adapter', () => {
  it('maps WASD/arrows without multiplying repeats and releases opposing keys', () => {
    const win = new EventTarget(), doc = new EventTarget();
    const input = new KeyboardInput(win, doc, () => false, 'test'); input.setOwner('world');
    win.dispatchEvent(key('KeyW')); win.dispatchEvent(key('ArrowUp')); win.dispatchEvent(key('KeyD'));
    for (let i = 0; i < 10; i++) win.dispatchEvent(key('KeyW', 'keydown', { repeat: true }));
    expect(input.movement(0)).toMatchObject({ type: 'move', direction: { x: 1, z: -1 } });
    win.dispatchEvent(key('KeyS')); expect(input.movement(1)).toMatchObject({ direction: { x: 1, z: 0 } });
    win.dispatchEvent(key('KeyD', 'keyup')); expect(input.movement(2)).toBeNull(); input.dispose();
  });
  it('clears keys on blur, focus, modal ownership, text focus and visibility changes', () => {
    const win = new EventTarget(), doc = new EventTarget(); let hidden = false;
    const input = new KeyboardInput(win, doc, () => hidden, 'test'); input.setOwner('world');
    win.dispatchEvent(key('KeyW')); win.dispatchEvent(new Event('blur')); expect(input.movement(0)).toBeNull();
    win.dispatchEvent(key('KeyW')); win.dispatchEvent(new Event('focus')); expect(input.movement(1)).toBeNull();
    win.dispatchEvent(key('KeyW')); input.setOwner('panel'); input.setOwner('world'); expect(input.movement(2)).toBeNull();
    win.dispatchEvent(key('KeyW')); doc.dispatchEvent(new Event('focusin')); expect(input.movement(3)).toBeNull();
    win.dispatchEvent(key('KeyW')); hidden = true; doc.dispatchEvent(new Event('visibilitychange')); hidden = false;
    expect(input.movement(4)).toBeNull();
    const editable = key('KeyW'); Object.defineProperty(editable, 'target', { value: { tagName: 'INPUT' } });
    win.dispatchEvent(editable); expect(input.movement(5)).toBeNull();
    input.dispose(); win.dispatchEvent(key('KeyW')); expect(input.movement(6)).toBeNull();
  });
});
