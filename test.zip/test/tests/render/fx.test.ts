import { describe, expect, it } from 'vitest';
import { Color, DirectionalLight, Fog, HemisphereLight, Points, Scene } from 'three';
import { DAY_CYCLE_TICKS, DAY_TICKS } from '../../src/world/daynight';
import { PARTICLE_POOL, ParticleField, SPARKS, type SparkKind } from '../../src/render/fx/particles';
import { DAMAGE_DURATION_MS, STILL_DURATION_MS, damageNumber, DAMAGE_CSS } from '../../src/render/fx/damage-numbers';
import { applySky, skySetting } from '../../src/render/fx/sky';

const KINDS: SparkKind[] = ['gather', 'seal', 'levelup', 'hit'];

describe('pooled particles', () => {
  it('keeps every burst in one Points cloud, so one draw call covers them all', () => {
    const scene = new Scene();
    const field = new ParticleField(scene);
    for (const kind of KINDS) field.emit(kind, { x: 1, y: 2, z: 3 }, 20);
    const clouds = scene.children.filter((child) => child instanceof Points);
    expect(clouds).toHaveLength(1);
    expect(field.drawCalls).toBe(1);
    expect(field.alive).toBe(80);
    const geometry = (clouds[0] as Points).geometry;
    expect(geometry.getAttribute('position').count).toBe(PARTICLE_POOL);
    expect(geometry.getAttribute('color').count).toBe(PARTICLE_POOL);
    field.dispose();
    expect(scene.children.filter((child) => child instanceof Points)).toHaveLength(0);
  });
  it('recycles the pool instead of growing it', () => {
    const field = new ParticleField(new Scene(), 32);
    expect(field.emit('gather', { x: 0, y: 0, z: 0 }, 100)).toBe(32);
    expect(field.alive).toBe(32);
    field.emit('seal', { x: 0, y: 0, z: 0 }, 10);
    expect(field.alive).toBe(32);
    field.dispose();
  });
  it('lets a burst die out and freezes movement under reduced motion', () => {
    const field = new ParticleField(new Scene(), 16);
    field.emit('hit', { x: 0, y: 0, z: 0 }, 4);
    const before = field.positionOf(0);
    field.update(0.1);
    const moved = field.positionOf(0);
    expect(moved.y).not.toBe(before.y);
    field.update(SPARKS.hit.life, false);
    expect(field.alive).toBe(0);

    const still = new ParticleField(new Scene(), 16);
    still.emit('gather', { x: 0, y: 0, z: 0 }, 4);
    const start = still.positionOf(0);
    still.update(0.2, true);
    expect(still.positionOf(0)).toEqual(start);
    // The burst still fades, so a reduced-motion player is not left with frozen dots.
    still.update(SPARKS.gather.life, true);
    expect(still.alive).toBe(0);
    field.dispose(); still.dispose();
  });
  it('describes all four bursts in one table', () => {
    expect(Object.keys(SPARKS).sort()).toEqual([...KINDS].sort());
    for (const kind of KINDS) {
      expect(SPARKS[kind].life).toBeGreaterThan(0);
      expect(SPARKS[kind].size).toBeGreaterThan(0);
    }
  });
});

describe('damage numbers', () => {
  it('formats damage, healing, status and a miss', () => {
    expect(damageNumber({ amount: 12 })).toMatchObject({ text: '−12', tone: 'damage', animated: true, durationMs: DAMAGE_DURATION_MS });
    expect(damageNumber({ amount: 7, tone: 'heal' }).text).toBe('+7');
    expect(damageNumber({ tone: 'miss' }).text).toBe('ıska');
    expect(damageNumber({ tone: 'status', text: 'zehirlendi' })).toMatchObject({ text: 'zehirlendi', tone: 'status' });
    expect(damageNumber({ amount: 3.6 }).text).toBe('−4');
  });
  it('stands still and stays longer when motion is reduced', () => {
    const still = damageNumber({ amount: 9, reducedMotion: true });
    expect(still.animated).toBe(false);
    expect(still.durationMs).toBe(STILL_DURATION_MS);
    expect(still.durationMs).toBeGreaterThan(DAMAGE_DURATION_MS);
    // The stylesheet also answers the system setting on its own.
    expect(DAMAGE_CSS).toContain('@media (prefers-reduced-motion:reduce)');
    expect(DAMAGE_CSS).toContain('animation:none');
  });
  it('places the number inside the screen even with nonsense input', () => {
    expect(damageNumber({ amount: 1, x: Number.NaN, y: Number.POSITIVE_INFINITY })).toMatchObject({ x: 50, y: 40 });
    expect(damageNumber({ amount: 1, x: 12, y: 80 })).toMatchObject({ x: 12, y: 80 });
  });
});

describe('the hour drives the light', () => {
  it('turns the sky, the fog and the shadows over with the clock', () => {
    const noon = skySetting(0);
    const midnight = skySetting(DAY_TICKS + 3000);
    expect(noon.shadows).toBe(true);
    expect(midnight.shadows).toBe(false);
    expect(noon.sun).toBeGreaterThan(midnight.sun);
    expect(noon.ambient).toBeGreaterThan(midnight.ambient);
    expect(noon.sky).not.toBe(midnight.sky);
    expect(midnight.far).toBeLessThan(noon.far);
    // Same tick, same look: nothing here is random.
    expect(skySetting(1234)).toEqual(skySetting(1234));
    expect(skySetting(DAY_CYCLE_TICKS)).toEqual(skySetting(0));
  });
  it('applies a setting to a real scene and switches the shadow map', () => {
    const scene = new Scene();
    scene.background = new Color('#000000');
    scene.fog = new Fog('#000000', 10, 20);
    const hemisphere = new HemisphereLight();
    const sun = new DirectionalLight();
    let shadows = true;
    const targets = { scene, hemisphere, sun, setShadows: (enabled: boolean) => { shadows = enabled; } };
    applySky(targets, skySetting(0));
    const day = { background: (scene.background as Color).getHex(), fog: (scene.fog as Fog).color.getHex(), sun: sun.intensity };
    expect(shadows).toBe(true);
    expect(sun.castShadow).toBe(true);
    applySky(targets, skySetting(DAY_TICKS + 3000));
    expect((scene.background as Color).getHex()).not.toBe(day.background);
    expect((scene.fog as Fog).color.getHex()).not.toBe(day.fog);
    expect(sun.intensity).toBeLessThan(day.sun);
    expect(shadows).toBe(false);
    expect(sun.castShadow).toBe(false);
    expect((scene.fog as Fog).near).toBeLessThan(75);
  });
});
