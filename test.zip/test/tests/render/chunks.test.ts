import { afterEach, describe, expect, it } from 'vitest';
import { BufferGeometry, Group, InstancedMesh, Mesh, Scene } from 'three';
import { GAME_CONFIG } from '../../src/config';
import { BIOME_IDS } from '../../src/contracts';
import { createWorld } from '../../src/world/generation/world';
import { sampleTerrain } from '../../src/world/terrain/terrain';
import { chunkAt, residency, type ChunkCoord } from '../../src/world/chunks/chunks';
import { BIOME_STYLE, decorKey } from '../../src/render/terrain/biome-style';
import { buildChunkTerrain, collectDecor, type ChunkTerrainBuild } from '../../src/render/terrain/chunk-terrain';
import { ResourceRegistry } from '../../src/render/resources/registry';
import { ChunkRenderer } from '../../src/render/chunks/chunk-renderer';
import { EntityLayer } from '../../src/render/entities/entity-layer';
import { interpolateEntity, type RenderEntity, type WorldFrame } from '../../src/render/entities/frame';

const world = createWorld();
const side = GAME_CONFIG.chunkSize / GAME_CONFIG.cellSize;
const forest = chunkAt({ x: -530, z: -280 });
const meadow = chunkAt(world.camp);
const closing: { dispose(): void }[] = [];
function scene() {
  const registry = new ResourceRegistry();
  const root = new Scene();
  const renderer = new ChunkRenderer(world, root, registry, { build: stub });
  closing.push(renderer, { dispose: () => registry.disposeAll() });
  return { registry, root, renderer };
}
/** Cheap stand-in for the real builder where a test is about residency, not geometry. */
const stubCache = new Map<string, ChunkTerrainBuild>();
function stub(_world: typeof world, chunkX: number, chunkZ: number): Promise<ChunkTerrainBuild> {
  void _world;
  const key = `${chunkX},${chunkZ}`;
  const cached = stubCache.get(key);
  if (cached) return Promise.resolve({ ...cached, geometry: cached.geometry.clone() });
  const built = buildChunkTerrain(world, chunkX, chunkZ);
  stubCache.set(key, built);
  return Promise.resolve({ ...built, geometry: built.geometry.clone() });
}
afterEach(() => { for (const item of closing.reverse()) item.dispose(); closing.length = 0; });

describe('chunk terrain and biome identity', () => {
  it('builds a seamless low-poly chunk with deterministic vertex colours', () => {
    const built = buildChunkTerrain(world, forest.chunkX, forest.chunkZ);
    const position = built.geometry.getAttribute('position');
    const color = built.geometry.getAttribute('color');
    expect(position.count).toBe((side + 1) ** 2);
    expect(color.count).toBe(position.count);
    expect(built.triangles).toBe(side * side * 2);
    expect(built.geometry.getIndex()!.count).toBe(built.triangles * 3);
    const again = buildChunkTerrain(world, forest.chunkX, forest.chunkZ);
    expect([...position.array]).toEqual([...again.geometry.getAttribute('position').array]);
    expect([...color.array]).toEqual([...again.geometry.getAttribute('color').array]);
    const east = buildChunkTerrain(world, forest.chunkX + 1, forest.chunkZ);
    for (let z = 0; z <= side; z++) {
      const mine = (z * (side + 1) + side) * 3, theirs = (z * (side + 1)) * 3;
      expect(position.array[mine]).toBe(east.geometry.getAttribute('position').array[theirs]);
      expect(position.array[mine + 1]).toBeCloseTo(east.geometry.getAttribute('position').array[theirs + 1], 6);
    }
    for (const geometry of [built.geometry, again.geometry, east.geometry]) geometry.dispose();
  });
  it('gives all eight biomes their own pattern, palette and silhouette', () => {
    const styles = BIOME_IDS.map((id) => BIOME_STYLE[id]);
    expect(styles).toHaveLength(8);
    expect(new Set(styles.map((style) => style.pattern)).size).toBe(8);
    expect(new Set(styles.map((style) => style.ground)).size).toBe(8);
    expect(new Set(styles.map((style) => `${style.tree.shape}|${style.rock.shape}|${style.shrub.shape}`)).size).toBeGreaterThanOrEqual(6);
    const meadowColors = [...buildChunkTerrain(world, meadow.chunkX, meadow.chunkZ).geometry.getAttribute('color').array];
    const forestColors = [...buildChunkTerrain(world, forest.chunkX, forest.chunkZ).geometry.getAttribute('color').array];
    expect(meadowColors).not.toEqual(forestColors);
  });
  it('places trees and rocks exactly on the collision obstacles and shrubs only on walkable ground', () => {
    const decor = collectDecor(world, forest.chunkX, forest.chunkZ);
    expect(decor.length).toBeGreaterThan(20);
    let trees = 0;
    for (const placement of decor) {
      const cell = sampleTerrain(world, placement.position);
      expect(cell.biomeId).toBe(placement.biomeId);
      if (placement.kind === 'shrub') { expect(cell.traversable).toBe(true); expect(cell.road).toBe(false); continue; }
      expect(cell.obstacle).toBe(placement.kind);
      expect(cell.traversable).toBe(false);
      if (placement.kind === 'tree') trees++;
      expect(placement.scale).toBeGreaterThan(0.7);
    }
    expect(trees).toBeGreaterThan(0);
    const obstacles = new Set(decor.filter((p) => p.kind !== 'shrub').map((p) => `${p.position.x},${p.position.z}`));
    expect(obstacles.size).toBe(decor.filter((p) => p.kind !== 'shrub').length);
  });
});

describe('instanced chunk residency', () => {
  it('draws one instanced mesh per decor group and shares geometry and material across chunks', async () => {
    const { registry, root, renderer } = scene();
    const neighbours = residency({ x: -530, z: -280 }, 1).slice(0, 2);
    await renderer.setVisible(neighbours);
    expect(renderer.chunkIds()).toHaveLength(2);
    const groups = root.children.filter((child): child is Group => child instanceof Group);
    expect(groups).toHaveLength(2);
    const instanced = groups.flatMap((group) => group.children.filter((child): child is InstancedMesh => child instanceof InstancedMesh));
    expect(instanced.length).toBeGreaterThan(1);
    for (const mesh of instanced) expect(mesh.count).toBeGreaterThan(0);
    const first = groups[0].children.find((child): child is InstancedMesh => child instanceof InstancedMesh)!;
    const expected = collectDecor(world, neighbours[0].chunkX, neighbours[0].chunkZ);
    const treeCount = expected.filter((placement) => placement.kind === 'tree' && placement.biomeId === 'forest').length;
    expect(instanced.filter((mesh) => mesh.name.startsWith('tree|forest')).map((mesh) => mesh.count)).toContain(treeCount);
    expect(registry.references(decorKey('tree', 'forest', 'geometry'))).toBeGreaterThan(1);
    const shared = new Set(instanced.filter((mesh) => mesh.name.startsWith('tree|forest')).map((mesh) => mesh.geometry));
    expect(shared.size).toBe(1);
    expect(first.instanceMatrix.needsUpdate || first.count > 0).toBe(true);
    expect(groups.every((group) => group.children.some((child) => child instanceof Mesh && !(child instanceof InstancedMesh)))).toBe(true);
    expect(renderer.stats.drawCalls).toBeLessThanOrEqual(150);
  });
  it('frees a shared decor resource only when its last chunk is gone', async () => {
    const registry = new ResourceRegistry();
    const root = new Scene();
    const renderer = new ChunkRenderer(world, root, registry, { build: stub, cacheLimit: 0 });
    closing.push(renderer, { dispose: () => registry.disposeAll() });
    const pair = residency({ x: -530, z: -280 }, 1).filter((chunk) =>
      collectDecor(world, chunk.chunkX, chunk.chunkZ).some((placement) => placement.kind === 'tree' && placement.biomeId === 'forest')).slice(0, 2);
    expect(pair).toHaveLength(2);
    await renderer.setVisible(pair);
    const key = decorKey('tree', 'forest', 'geometry');
    const geometry = registry.geometry<BufferGeometry>(key, () => { throw new Error('paylaşılan kaynak yeniden üretilmemeli'); });
    registry.release(key);
    let freed = 0;
    geometry.addEventListener('dispose', () => { freed++; });
    expect(registry.references(key)).toBe(2);
    await renderer.setVisible([pair[0]]);
    expect(registry.references(key)).toBe(1);
    expect(freed).toBe(0);
    await renderer.setVisible([]);
    expect(registry.references(key)).toBe(0);
    expect(freed).toBe(1);
  });
  it('keeps at most 25 visible and 24 cached chunks while walking', async () => {
    const { renderer } = scene();
    await renderer.setVisible(residency(world.camp, GAME_CONFIG.visualChunkRadius));
    expect(renderer.stats).toMatchObject({ visible: 25, cached: 0, resident: 25 });
    for (let step = 1; step <= 6; step++) {
      await renderer.setVisible(residency({ x: world.camp.x + step * GAME_CONFIG.chunkSize, z: world.camp.z }, GAME_CONFIG.visualChunkRadius));
      const stats = renderer.stats;
      expect(stats.visible).toBe(25);
      expect(stats.cached).toBeLessThanOrEqual(24);
      expect(stats.resident).toBeLessThanOrEqual(GAME_CONFIG.maxResidentChunks);
    }
    const back = await renderer.setVisible(residency(world.camp, GAME_CONFIG.visualChunkRadius));
    expect(back.visible).toBe(25);
    expect(back.resident).toBeLessThanOrEqual(GAME_CONFIG.maxResidentChunks);
  });
  it('drops a stale async result with the generation token instead of adding it to the scene', async () => {
    const registry = new ResourceRegistry();
    const root = new Scene();
    const gates = new Map<string, (build: ChunkTerrainBuild) => void>();
    const renderer = new ChunkRenderer(world, root, registry, {
      build: (_world, chunkX, chunkZ) => new Promise<ChunkTerrainBuild>((resolve) => gates.set(`${chunkX},${chunkZ}`, resolve)),
    });
    closing.push(renderer, { dispose: () => registry.disposeAll() });
    const far: ChunkCoord[] = [chunkAt({ x: 600, z: 600 })];
    const pending = renderer.setVisible(far);
    const other = chunkAt({ x: -600, z: -600 });
    const second = renderer.setVisible([other]);
    const staleBuild = buildChunkTerrain(world, far[0].chunkX, far[0].chunkZ);
    let freed = 0;
    staleBuild.geometry.addEventListener('dispose', () => { freed++; });
    gates.get(far[0].id)!(staleBuild);
    gates.get(other.id)!(buildChunkTerrain(world, other.chunkX, other.chunkZ));
    await Promise.all([pending, second]);
    expect(renderer.has(far[0].id)).toBe(false);
    expect(renderer.cached(far[0].id)).toBe(false);
    expect(renderer.stats.discarded).toBe(1);
    expect(renderer.chunkIds()).toEqual([other.id]);
    expect(root.children.filter((child) => child.name.startsWith('chunk-'))).toHaveLength(1);
    expect(freed).toBe(1);
    expect(registry.references('terrain:vertex-colors')).toBe(1);
  });
  it('releases every shared resource on eviction and never grows across repeated mounts', async () => {
    const { registry, root, renderer } = scene();
    const route = [world.camp, { x: -530, z: -280 }, { x: 450, z: 540 }, { x: -30, z: -700 }];
    const samples: number[] = [];
    for (let lap = 0; lap < 5; lap++) {
      for (const stop of route) await renderer.setVisible(residency(stop, GAME_CONFIG.visualChunkRadius));
      samples.push(registry.counts().geometry + registry.counts().material);
    }
    expect(renderer.stats.resident).toBeLessThanOrEqual(GAME_CONFIG.maxResidentChunks);
    expect(Math.max(...samples.slice(1))).toBeLessThanOrEqual(samples[0]);
    const before = registry.size;
    renderer.dispose();
    expect(registry.size).toBe(0);
    expect(before).toBeGreaterThan(0);
    expect(root.children.filter((child) => child.name.startsWith('chunk-'))).toHaveLength(0);
    renderer.dispose();
    expect(registry.size).toBe(0);
  });
});

describe('entity proxies', () => {
  const entity = (id: string, x: number, overrides: Partial<RenderEntity> = {}): RenderEntity =>
    ({ id, position: { x, z: 0 }, height: 0, yaw: 0, visualId: 'dewbud', kind: 'creature', ...overrides });
  const frame = (entities: readonly RenderEntity[], tick = 1): WorldFrame => ({ tick, playerId: 'player', entities, visibleChunkIds: [] });
  it('keeps an id-keyed proxy per entity and shares one material per visual', () => {
    const registry = new ResourceRegistry();
    const root = new Scene();
    const layer = new EntityLayer(root, registry);
    closing.push(layer, { dispose: () => registry.disposeAll() });
    expect(layer.sync(frame([entity('a', 0), entity('b', 4), entity('c', 8, { visualId: 'puffkip' })])).added).toEqual(['a', 'b', 'c']);
    expect(registry.references('entity:dewbud')).toBe(2);
    expect(registry.references('entity:plane')).toBe(3);
    const kept = layer.group.children.find((child) => child.name === 'entity-c')!;
    expect(layer.sync(frame([entity('a', 0), entity('c', 8, { visualId: 'puffkip' })])).removed).toEqual(['b']);
    expect(layer.ids()).toEqual(['a', 'c']);
    expect(layer.group.children.find((child) => child.name === 'entity-c')).toBe(kept);
    expect(registry.references('entity:dewbud')).toBe(1);
    layer.dispose();
    expect(registry.size).toBe(0);
    expect(root.children.some((child) => child.name === 'entities')).toBe(false);
  });
  it('interpolates between snapshots without extrapolating past them', () => {
    const registry = new ResourceRegistry();
    const layer = new EntityLayer(new Scene(), registry);
    closing.push(layer, { dispose: () => registry.disposeAll() });
    layer.sync(frame([entity('a', 0)]));
    layer.draw(frame([entity('a', 0)]), 0);
    layer.draw(frame([entity('a', 10)], 2), 0.5);
    const mesh = layer.group.children[0] as Mesh;
    expect(mesh.position.x).toBeCloseTo(5, 6);
    layer.draw(frame([entity('a', 20)], 3), 3);
    expect(mesh.position.x).toBeCloseTo(20, 6);
    const wrapped = interpolateEntity(entity('a', 0, { yaw: Math.PI - 0.1 }), entity('a', 0, { yaw: -Math.PI + 0.1 }), 0.5);
    expect(Math.abs(wrapped.yaw)).toBeCloseTo(Math.PI, 6);
    expect(interpolateEntity(undefined, entity('a', 3), 0.5).position.x).toBe(3);
    expect(() => interpolateEntity(entity('a', 0), entity('a', 1), Number.NaN)).toThrow(RangeError);
  });
});
