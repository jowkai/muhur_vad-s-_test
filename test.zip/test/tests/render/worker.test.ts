import { describe, expect, it, vi } from 'vitest';
import { Group } from 'three';
import { GAME_CONFIG } from '../../src/config';
import { createWorld } from '../../src/world/generation/world';
import { chunkKey, residency, type ChunkCoord } from '../../src/world/chunks/chunks';
import {
  LOD_FAR_STEP, LOD_NEAR_STEP, buildChunkArrays, buildChunkTerrain, geometryFromArrays,
} from '../../src/render/terrain/chunk-terrain';
import { ChunkRenderer, DEFAULT_LOD_RING, lodStepFor } from '../../src/render/chunks/chunk-renderer';
import { ResourceRegistry } from '../../src/render/resources/registry';
import { createTerrainWorker, synchronousBuild } from '../../src/render/worker/terrain-client';
import { isFailure, transferables, type ChunkRequest, type ChunkResponse } from '../../src/render/worker/protocol';

const world = createWorld();
const coord = (x: number, z: number): ChunkCoord => ({ id: chunkKey(x, z), chunkX: x, chunkZ: z });
/** A worker that answers on the microtask queue, exactly like a real message port would. */
class FakeWorker implements Partial<Worker> {
  readonly posted: ChunkRequest[] = [];
  private readonly listeners = new Map<string, ((event: unknown) => void)[]>();
  terminated = false;
  constructor(private readonly behaviour: 'answer' | 'error' | 'silent' = 'answer') {}
  addEventListener(type: string, listener: (event: unknown) => void): void {
    this.listeners.set(type, [...(this.listeners.get(type) ?? []), listener]);
  }
  removeEventListener(): void { /* not needed by the client */ }
  postMessage(request: ChunkRequest): void {
    this.posted.push(request);
    if (this.behaviour === 'silent') return;
    queueMicrotask(() => {
      if (this.behaviour === 'error') { this.emit('message', { data: { id: request.id, error: 'patladı' } }); return; }
      const arrays = buildChunkArrays(world, request.chunkX, request.chunkZ, request.step);
      const response: ChunkResponse = {
        id: request.id, chunkX: request.chunkX, chunkZ: request.chunkZ, step: arrays.step,
        positions: arrays.positions, colors: arrays.colors, indices: arrays.indices,
        decor: arrays.decor, triangles: arrays.triangles,
      };
      expect(transferables(response)).toHaveLength(3);
      this.emit('message', { data: response });
    });
  }
  terminate(): void { this.terminated = true; }
  private emit(type: string, event: unknown): void { for (const listener of this.listeners.get(type) ?? []) listener(event); }
}

describe('terrain arrays and level of detail', () => {
  it('builds the same ground at two resolutions, sharing every border vertex', () => {
    const fine = buildChunkArrays(world, 16, 16, LOD_NEAR_STEP);
    const coarse = buildChunkArrays(world, 16, 16, LOD_FAR_STEP);
    expect(fine.step).toBe(2);
    expect(coarse.step).toBe(8);
    expect(coarse.positions.length).toBeLessThan(fine.positions.length);
    expect(coarse.triangles).toBe((GAME_CONFIG.chunkSize / LOD_FAR_STEP) ** 2 * 2);
    // Every coarse vertex exists in the fine mesh at the same height: the seam cannot crack.
    const finePoints = new Map<string, number>();
    for (let index = 0; index < fine.positions.length; index += 3) {
      finePoints.set(`${fine.positions[index]},${fine.positions[index + 2]}`, fine.positions[index + 1]);
    }
    let matched = 0;
    for (let index = 0; index < coarse.positions.length; index += 3) {
      const height = finePoints.get(`${coarse.positions[index]},${coarse.positions[index + 2]}`);
      expect(height, `${coarse.positions[index]},${coarse.positions[index + 2]}`).toBeDefined();
      expect(height).toBeCloseTo(coarse.positions[index + 1], 5);
      matched++;
    }
    expect(matched).toBe((GAME_CONFIG.chunkSize / LOD_FAR_STEP + 1) ** 2);
    // Decor does not thin out with distance; only the ground grid does.
    expect(coarse.decor).toEqual(fine.decor);
    expect(() => buildChunkArrays(world, 16, 16, 3)).toThrow(RangeError);
    expect(() => buildChunkArrays(world, -1, 0)).toThrow(RangeError);
  });
  it('wraps raw buffers into the same geometry the synchronous path builds', () => {
    const arrays = buildChunkArrays(world, 8, 9);
    const wrapped = geometryFromArrays(arrays);
    const direct = buildChunkTerrain(world, 8, 9);
    expect(wrapped.triangles).toBe(direct.triangles);
    expect([...(wrapped.geometry.getAttribute('position').array as Float32Array)])
      .toEqual([...(direct.geometry.getAttribute('position').array as Float32Array)]);
    wrapped.geometry.dispose(); direct.geometry.dispose();
  });
  it('keeps the fine grid in the near ring and coarsens the rest', () => {
    expect(lodStepFor(0)).toBe(LOD_NEAR_STEP);
    expect(lodStepFor(DEFAULT_LOD_RING)).toBe(LOD_NEAR_STEP);
    expect(lodStepFor(DEFAULT_LOD_RING + 1)).toBe(LOD_FAR_STEP);
    expect(lodStepFor(5, 4)).toBe(LOD_FAR_STEP);
  });
});

describe('the chunk worker client', () => {
  it('answers through the worker and hands back a mounted geometry', async () => {
    const fake = new FakeWorker();
    const client = createTerrainWorker({ factory: () => fake as unknown as Worker });
    expect(client.usingWorker).toBe(true);
    const built = await client.build(world, 12, 12, LOD_FAR_STEP);
    expect(fake.posted[0]).toMatchObject({ chunkX: 12, chunkZ: 12, step: LOD_FAR_STEP, seed: world.seed });
    expect(built.triangles).toBe((GAME_CONFIG.chunkSize / LOD_FAR_STEP) ** 2 * 2);
    expect(built.geometry.getAttribute('position').count).toBeGreaterThan(0);
    client.dispose();
    expect(fake.terminated).toBe(true);
  });
  it('falls back to synchronous building when there is no worker or it fails', async () => {
    const none = createTerrainWorker({ factory: () => { throw new Error('no workers here'); } });
    expect(none.usingWorker).toBe(false);
    const built = await none.build(world, 4, 4);
    expect(built.triangles).toBeGreaterThan(0);
    none.dispose();

    const broken = createTerrainWorker({ factory: () => new FakeWorker('error') as unknown as Worker });
    const recovered = await broken.build(world, 5, 5);
    expect(recovered.geometry.getAttribute('position').count).toBeGreaterThan(0);
    broken.dispose();
    const direct = await synchronousBuild(world, 5, 5);
    expect(direct.triangles).toBe(recovered.triangles);
  });
  it('marks a failure message for what it is', () => {
    expect(isFailure({ id: 1, error: 'x' })).toBe(true);
    expect(isFailure({ id: 1, chunkX: 0, chunkZ: 0, step: 2, positions: new Float32Array(), colors: new Float32Array(), indices: new Uint32Array(), decor: [], triangles: 0 })).toBe(false);
  });
});

describe('the renderer with a worker behind it', () => {
  const ring = residency({ x: 0, z: 0 }, GAME_CONFIG.visualChunkRadius);
  it('keeps 25 visible and the same cache limit, whoever builds the chunks', async () => {
    const registry = new ResourceRegistry();
    const fake = new FakeWorker();
    const client = createTerrainWorker({ factory: () => fake as unknown as Worker });
    const renderer = new ChunkRenderer(world, new Group(), registry, { build: client.build });
    const stats = await renderer.setVisible(ring, ring[Math.floor(ring.length / 2)]);
    expect(ring).toHaveLength(25);
    expect(stats.visible).toBe(25);
    expect(stats.cached).toBe(0);
    expect(fake.posted).toHaveLength(25);
    // The centre keeps the fine ground, the outer ring is coarse.
    const middle = ring[Math.floor(ring.length / 2)];
    expect(renderer.stepOf(middle.id)).toBe(LOD_NEAR_STEP);
    expect(renderer.stepOf(ring[0].id)).toBe(LOD_FAR_STEP);
    const moved = await renderer.setVisible(residency({ x: 64 * 3, z: 0 }, GAME_CONFIG.visualChunkRadius), coord(19, 16));
    expect(moved.visible).toBe(25);
    expect(moved.cached).toBeLessThanOrEqual(GAME_CONFIG.maxResidentChunks - 25);
    renderer.dispose(); client.dispose();
    expect(registry.size).toBe(0);
  });
  it('never mounts a chunk the player already walked away from', async () => {
    const registry = new ResourceRegistry();
    const slow = new Map<string, () => void>();
    const renderer = new ChunkRenderer(world, new Group(), registry, {
      build: (target, chunkX, chunkZ, step) => new Promise((resolve) => {
        slow.set(chunkKey(chunkX, chunkZ), () => resolve(buildChunkTerrain(target, chunkX, chunkZ, step)));
      }),
    });
    const first = renderer.setVisible([coord(4, 4)], coord(4, 4));
    const second = renderer.setVisible([coord(20, 20)], coord(20, 20));
    slow.get(chunkKey(4, 4))!();
    slow.get(chunkKey(20, 20))!();
    await Promise.all([first, second]);
    expect(renderer.chunkIds()).toEqual([chunkKey(20, 20)]);
    expect(renderer.stats.discarded).toBeGreaterThan(0);
    renderer.dispose();
    expect(registry.size).toBe(0);
  });
  it('rebuilds a chunk that changed resolution instead of showing the wrong detail', async () => {
    const registry = new ResourceRegistry();
    const builds = vi.fn((target: typeof world, chunkX: number, chunkZ: number, step?: number) =>
      Promise.resolve(buildChunkTerrain(target, chunkX, chunkZ, step)));
    const renderer = new ChunkRenderer(world, new Group(), registry, { build: builds });
    await renderer.setVisible([coord(10, 10), coord(11, 10)], coord(10, 10));
    expect(renderer.stepOf(chunkKey(11, 10))).toBe(LOD_NEAR_STEP);
    await renderer.setVisible([coord(10, 10), coord(11, 10)], coord(13, 10));
    expect(renderer.stepOf(chunkKey(11, 10))).toBe(LOD_FAR_STEP);
    expect(builds.mock.calls.length).toBeGreaterThan(2);
    renderer.dispose();
    expect(registry.size).toBe(0);
  });
});
