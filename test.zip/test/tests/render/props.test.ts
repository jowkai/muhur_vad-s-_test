import { afterEach, describe, expect, it } from 'vitest';
import { Mesh, PointLight, Scene } from 'three';
import { createWorld } from '../../src/world/generation/world';
import { sampleTerrain } from '../../src/world/terrain/terrain';
import { ResourceRegistry } from '../../src/render/resources/registry';
import { createCampProps } from '../../src/render/props/camp';
import { atlasPixel, FOG_COLOUR } from '../../src/render/minimap/atlas';

const world = createWorld();
const closing: { dispose(): void }[] = [];
afterEach(() => { for (const item of closing.reverse()) item.dispose(); closing.length = 0; });

describe('camp landmarks', () => {
  it('stands at the camp, shares its resources and frees them on dispose', () => {
    const registry = new ResourceRegistry();
    const scene = new Scene();
    const props = createCampProps(registry, world.camp);
    closing.push({ dispose: () => registry.disposeAll() });
    scene.add(props.group);
    expect(props.group.position.x).toBe(world.camp.x);
    expect(props.group.position.z).toBe(world.camp.z);
    const meshes = props.group.children.filter((child): child is Mesh => child instanceof Mesh);
    expect(meshes.length).toBeGreaterThan(8);
    expect(props.group.children.some((child) => child instanceof PointLight)).toBe(true);
    // The seven fire stones reuse two shared geometries rather than making one each.
    expect(registry.references('camp:fire-stone-0:geometry')).toBeGreaterThan(1);
    expect(registry.size).toBeLessThan(meshes.length * 2);
    const before = registry.size;
    props.dispose();
    expect(before).toBeGreaterThan(0);
    expect(registry.size).toBe(0);
    expect(scene.children.some((child) => child.name === 'camp-props')).toBe(false);
    props.dispose();
  });
  it('animates the seal stone but holds still when motion is reduced', () => {
    const registry = new ResourceRegistry();
    const props = createCampProps(registry, world.camp);
    closing.push({ dispose: () => { props.dispose(); registry.disposeAll(); } });
    const seal = props.group.children.find((child) => child instanceof Mesh && child.geometry.type === 'OctahedronGeometry')!;
    props.update(2, false);
    const moved = { y: seal.position.y, rotation: seal.rotation.y };
    expect(moved.rotation).toBeCloseTo(0.8, 6);
    props.update(9, true);
    expect(seal.position.y).toBe(2.6);
    expect(seal.rotation.y).toBeCloseTo(moved.rotation, 6);
  });
  it('keeps every prop clear of the walkable camp centre', () => {
    const registry = new ResourceRegistry();
    const props = createCampProps(registry, world.camp);
    closing.push({ dispose: () => { props.dispose(); registry.disposeAll(); } });
    for (const child of props.group.children) {
      const point = { x: world.camp.x + child.position.x, z: world.camp.z + child.position.z };
      expect(sampleTerrain(world, point).traversable, `${child.name} at ${point.x},${point.z}`).toBe(true);
    }
  });
});

describe('minimap atlas colours', () => {
  it('paints fog until a cell is discovered and mirrors biome, road and hazard tones', () => {
    const point = { x: world.camp.x + 12, z: world.camp.z + 12 };
    expect(atlasPixel(world, point, false)).toEqual(FOG_COLOUR);
    const discovered = atlasPixel(world, point, true);
    expect(discovered).not.toEqual(FOG_COLOUR);
    expect(discovered.every((channel) => channel >= 0 && channel <= 255)).toBe(true);
    // Region centres sit on the carved roads, so sample the interior a little off the corridor.
    const interior = (biomeId: 'forest' | 'desert') => {
      const centre = world.regions.find((region) => region.biomeId === biomeId)!.center;
      for (const offset of [40, -40, 60, -60]) {
        const point = { x: centre.x + offset, z: centre.z + offset };
        const cell = sampleTerrain(world, point);
        if (cell.biomeId === biomeId && !cell.road) return point;
      }
      throw new Error(`${biomeId} interior not found`);
    };
    const forest = atlasPixel(world, interior('forest'), true);
    const desert = atlasPixel(world, interior('desert'), true);
    expect(forest).not.toEqual(desert);
    const road = world.roads[0];
    const onRoad = { x: (road.from.x + road.to.x) / 2, z: (road.from.z + road.to.z) / 2 };
    expect(sampleTerrain(world, onRoad).road).toBe(true);
    expect(atlasPixel(world, onRoad, true)).toEqual([214, 180, 116]);
  });
});
