import { describe, expect, it } from 'vitest';
import { Group, Mesh, MeshBasicMaterial, Texture } from 'three';
import { creatureAssets, eggAssets, itemAssets } from '../../src/content/asset-manifest';
import { catalog } from '../../src/content/catalog';
import { cosmeticStage } from '../../src/game/progression';
import {
  ATLAS_FRAMES, IDLE_FRAME_TICKS, frameFor, framePixels, frameRect, planAtlas, stageScale,
} from '../../src/render/atlas/layout';
import { EntityLayer, ATLAS_MATERIAL } from '../../src/render/entities/entity-layer';
import type { RenderEntity, WorldFrame } from '../../src/render/entities/frame';
import { ResourceRegistry } from '../../src/render/resources/registry';

const ids = [
  ...catalog.creatures.map((row) => row.id),
  ...Object.keys(eggAssets).map((biomeId) => `egg_${biomeId}`),
  ...catalog.items.map((row) => row.id),
];
const layout = planAtlas(ids);
const entity = (id: string, visualId: string, overrides: Partial<RenderEntity> = {}): RenderEntity => ({
  id, visualId, kind: 'creature', position: { x: 0, z: 0 }, height: 0, yaw: 0, ...overrides,
});
const frame = (entities: RenderEntity[], tick = 0): WorldFrame =>
  ({ tick, playerId: 'p', entities, visibleChunkIds: [] });

describe('the sprite atlas layout', () => {
  it('packs every catalogue drawing into one grid of three-frame strips', () => {
    expect(layout.ids).toHaveLength(ids.length);
    expect(layout.ids.length).toBe(catalog.creatures.length + 8 + catalog.items.length);
    expect(Object.keys(creatureAssets)).toHaveLength(catalog.creatures.length);
    expect(Object.keys(itemAssets)).toHaveLength(catalog.items.length);
    // Power-of-two texture, every strip inside it.
    expect(Math.log2(layout.width) % 1).toBe(0);
    expect(Math.log2(layout.height) % 1).toBe(0);
    for (const id of layout.ids) {
      const cell = layout.cells.get(id)!;
      expect(cell.frames).toHaveLength(ATLAS_FRAMES);
      for (const rect of cell.frames) {
        expect(rect.u0).toBeGreaterThanOrEqual(0);
        expect(rect.u1).toBeLessThanOrEqual(1);
        expect(rect.v0).toBeGreaterThanOrEqual(0);
        expect(rect.v1).toBeLessThanOrEqual(1);
        expect(rect.u1).toBeGreaterThan(rect.u0);
        expect(rect.v1).toBeGreaterThan(rect.v0);
      }
      const box = framePixels(layout, id, 2)!;
      expect(box.x + box.size).toBeLessThanOrEqual(layout.width);
      expect(box.y + box.size).toBeLessThanOrEqual(layout.height);
    }
  });
  it('gives every frame its own box and never overlaps two sprites', () => {
    const boxes = layout.ids.flatMap((id) => Array.from({ length: ATLAS_FRAMES }, (_, index) => {
      const box = framePixels(layout, id, index)!;
      return `${box.x},${box.y}`;
    }));
    expect(new Set(boxes).size).toBe(boxes.length);
    expect(frameRect(layout, 'yok', 0)).toBeNull();
    expect(frameRect(layout, layout.ids[0], 9)).toEqual(frameRect(layout, layout.ids[0], 2));
    expect(() => planAtlas(ids, 4)).toThrow(RangeError);
  });
  it('steps three idle frames and pins them under reduced motion', () => {
    expect(frameFor(0)).toBe(0);
    expect(frameFor(IDLE_FRAME_TICKS)).toBe(1);
    expect(frameFor(IDLE_FRAME_TICKS * 2)).toBe(2);
    expect(frameFor(IDLE_FRAME_TICKS * 3)).toBe(1);
    expect(frameFor(IDLE_FRAME_TICKS * 4)).toBe(0);
    expect(frameFor(IDLE_FRAME_TICKS * 2, { reducedMotion: true })).toBe(0);
    expect(frameFor(0, { hit: true })).toBe(2);
    expect(frameFor(0, { hit: true, reducedMotion: true })).toBe(0);
  });
  it('turns a cosmetic stage into a bigger silhouette', () => {
    expect(cosmeticStage(1)).toBe(0);
    expect(cosmeticStage(5)).toBe(1);
    expect(cosmeticStage(10)).toBe(2);
    expect(stageScale(0)).toBe(1);
    expect(stageScale(1)).toBeGreaterThan(stageScale(0));
    expect(stageScale(2)).toBeGreaterThan(stageScale(1));
    expect(stageScale(99)).toBe(stageScale(2));
  });
});

describe('the entity layer on one atlas', () => {
  const build = () => {
    const registry = new ResourceRegistry();
    const scene = new Group();
    const texture = new Texture();
    const layer = new EntityLayer(scene, registry, { atlas: { texture, layout } });
    return { registry, scene, texture, layer };
  };
  it('keeps exactly one material for every sprite it draws', () => {
    const { registry, layer } = build();
    layer.sync(frame([
      entity('a', 'dewbud'), entity('b', 'emberpod'), entity('c', 'egg_meadow', { kind: 'egg' }),
      entity('d', 'dew_leaf', { kind: 'resource' }),
    ]));
    expect(layer.size).toBe(4);
    expect(layer.materialKeys).toEqual([ATLAS_MATERIAL]);
    expect(registry.counts().material).toBe(1);
    expect(registry.references(ATLAS_MATERIAL)).toBe(4);
    layer.dispose();
  });
  it('animates by swapping the prepared frame geometry, not by touching the material', () => {
    const { registry, layer } = build();
    const one = entity('a', 'dewbud');
    layer.sync(frame([one]));
    const mesh = () => layer.group.children[0] as Mesh;
    const uvAt = () => [...(mesh().geometry.attributes.uv.array as Float32Array)];
    const rest = uvAt();
    const material = mesh().material as MeshBasicMaterial;
    layer.draw(frame([one], IDLE_FRAME_TICKS), 1);
    const lifted = uvAt();
    expect(lifted).not.toEqual(rest);
    expect(mesh().material).toBe(material);
    expect(registry.counts().material).toBe(1);
    layer.draw(frame([one], IDLE_FRAME_TICKS * 2), 1);
    expect(uvAt()).not.toEqual(lifted);
    layer.draw(frame([one], IDLE_FRAME_TICKS * 4), 1);
    expect(uvAt()).toEqual(rest);
    layer.dispose();
  });
  it('holds a single frame while motion is reduced', () => {
    const registry = new ResourceRegistry();
    const layer = new EntityLayer(new Group(), registry, { atlas: { texture: new Texture(), layout }, reducedMotion: () => true });
    const one = entity('a', 'dewbud');
    layer.sync(frame([one]));
    const uv = () => [...((layer.group.children[0] as Mesh).geometry.attributes.uv.array as Float32Array)];
    const rest = uv();
    for (const tick of [IDLE_FRAME_TICKS, IDLE_FRAME_TICKS * 2, IDLE_FRAME_TICKS * 3]) {
      layer.draw(frame([one], tick), 1);
      expect(uv()).toEqual(rest);
    }
    layer.dispose();
  });
  it('draws the cosmetic stage and gives every resource back on dispose', () => {
    const { registry, layer } = build();
    layer.sync(frame([
      entity('young', 'dewbud', { stage: 0 }),
      entity('grown', 'emberpod', { stage: 2 }),
      entity('rock', 'dew_leaf', { kind: 'resource', stage: 2 }),
    ]));
    const [young, grown, rock] = layer.group.children as Mesh[];
    expect(grown.scale.x).toBeGreaterThan(young.scale.x);
    expect(grown.scale.x).toBeCloseTo(young.scale.x * stageScale(2), 6);
    // A pebble does not grow up.
    expect(rock.scale.x).toBeCloseTo(0.9, 6);
    layer.dispose();
    expect(registry.size).toBe(0);
    expect(registry.counts()).toMatchObject({ geometry: 0, material: 0, references: 0 });
  });
  it('still works without an atlas, one material per sprite', () => {
    const registry = new ResourceRegistry();
    const layer = new EntityLayer(new Group(), registry, {});
    layer.sync(frame([entity('a', 'dewbud'), entity('b', 'emberpod')]));
    expect(layer.materialKeys).toEqual(['entity:dewbud', 'entity:emberpod']);
    expect(registry.counts().material).toBe(2);
    layer.dispose();
    expect(registry.size).toBe(0);
  });
});
