import { describe, expect, it, vi } from 'vitest';
import { CommandBus } from '../../src/contracts/command-bus';
import type { GameCommand, InputOwner } from '../../src/contracts';

const capture: GameCommand = { commandId: 'capture-1', tick: 10, type: 'capture' };
describe('command bus', () => {
  it('recognizes equivalent nested payloads regardless of property order', async () => {
    const handle = vi.fn(async () => true);
    const bus = new CommandBus(() => 'world', handle);
    await bus.dispatch({ commandId: 'm', tick: 0, type: 'move', direction: { x: 1, z: 0 } });
    expect(await bus.dispatch({ type: 'move', tick: 0, commandId: 'm', direction: { z: 0, x: 1 } })).toEqual({ accepted: true, value: true });
    expect(handle).toHaveBeenCalledTimes(1);
  });
  it('serializes fifty duplicate submissions into one mutation', async () => {
    const handle = vi.fn(async () => ({ sealsUsed: 1 }));
    const bus = new CommandBus(() => 'battle', handle);
    const results = await Promise.all(Array.from({ length: 50 }, () => bus.dispatch(capture)));
    expect(handle).toHaveBeenCalledTimes(1);
    expect(results.every((result) => result.accepted)).toBe(true);
    if (results[0].accepted) results[0].value.sealsUsed = 99;
    expect(await bus.dispatch(capture)).toEqual({ accepted: true, value: { sealsUsed: 1 } });
    expect(await bus.dispatch({ ...capture, type: 'flee' })).toEqual({ accepted: false, reason: 'id-conflict' });
  });
  it('rejects wrong owners and invalid values without executing', async () => {
    const handle = vi.fn(async () => true);
    const bus = new CommandBus(() => 'world', handle);
    expect(await bus.dispatch(capture)).toEqual({ accepted: false, reason: 'owner' });
    expect(await bus.dispatch({ commandId: 'm', tick: 0, type: 'move', direction: { x: NaN, z: 0 } })).toEqual({ accepted: false, reason: 'invalid' });
    expect(await bus.dispatch({ ...capture, commandId: ' ' })).toEqual({ accepted: false, reason: 'invalid' });
    expect(await bus.dispatch({ ...capture, tick: -1 })).toEqual({ accepted: false, reason: 'invalid' });
    expect(handle).not.toHaveBeenCalled();
  });
  it('allows retry after a failed write and keeps the queue usable', async () => {
    const handle = vi.fn().mockRejectedValueOnce(new Error('quota')).mockResolvedValueOnce('committed');
    const bus = new CommandBus(() => 'battle', handle);
    await expect(bus.dispatch(capture)).rejects.toThrow('quota');
    expect(await bus.dispatch(capture)).toEqual({ accepted: true, value: 'committed' });
    expect(handle).toHaveBeenCalledTimes(2);
  });
  it('evaluates ownership at execution and snapshots mutable input at submission', async () => {
    let owner: InputOwner = 'world';
    const handle = vi.fn(async () => { owner = 'panel'; return true; });
    const bus = new CommandBus(() => owner, handle);
    const open: GameCommand = { commandId: 'open', tick: 1, type: 'open-panel', panel: 'inventory' };
    const first = bus.dispatch(open);
    const second = bus.dispatch({ commandId: 'move', tick: 1, type: 'move', direction: { x: 1, z: 0 } });
    open.panel = 'alchemy';
    await first;
    expect(handle.mock.calls[0]).toEqual([{ commandId: 'open', tick: 1, type: 'open-panel', panel: 'inventory' }]);
    expect(await second).toEqual({ accepted: false, reason: 'owner' });
  });
});
