import { describe, expect, it } from 'vitest';
import {
  CREATURE_ROLES, DEFAULT_PLAYER_NAME, graftCapacity, MAX_GRAFTS_PER_CREATURE, MAX_LEVEL, PLAYER_NAME_LIMIT, TREE_KINDS,
  type CommandIntent, type CreatureRole, type GraftRecord, type MountRecord, type SpeedEffect, type TreeKind,
} from '../../src/contracts';
import { commandOwner } from '../../src/contracts/command-bus';
import { creatureById, creatures } from '../../src/content/catalog';
import { stats } from '../../src/game/combat/core';
import { createWorld } from '../../src/world/generation/world';
import {
  WORLD_SAVE_VERSION, createWorldState, migrateWorldState, validPlayerName, validateWorldState, type WorldState,
} from '../../src/world/persistence/world-save';

const world = createWorld();
const owned = (id: string, speciesId = 'dewbud', level = 4) => {
  const species = creatureById(speciesId)!;
  const maxHp = stats({ id, species, level }).maxHp;
  return { id, speciesId, level, xp: 0, hp: maxHp, maxHp };
};
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: true, inventory: [{ itemId: 'seal', quantity: 1 }, null],
    unlockedRecipeIds: ['salve'], creatures: [owned('friend')], creatureCapacity: 60, eggCapacity: 4, eggs: [],
    battle: null, loot: null, rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, activeCreatureId: 'friend', party: ['friend'], ...overrides };
}

describe('v3 contracts', () => {
  it('names the six roles, the nine tree kinds and the new ceilings', () => {
    expect(CREATURE_ROLES).toEqual(['ride', 'fly', 'swim', 'dig', 'tank', 'claw']);
    expect(TREE_KINDS).toEqual(['oak', 'amber', 'ghostwood', 'emberbark', 'frostpine',
      'ironroot', 'dunepalm', 'coralwood', 'ashwillow']);
    expect(new Set(CREATURE_ROLES).size).toBe(CREATURE_ROLES.length);
    expect(MAX_LEVEL).toBe(50);
    expect(PLAYER_NAME_LIMIT).toBe(24);
    expect(MAX_GRAFTS_PER_CREATURE).toBe(4);
    expect(graftCapacity(1)).toBe(2);
    expect(graftCapacity(MAX_LEVEL)).toBe(MAX_GRAFTS_PER_CREATURE);
    expect(DEFAULT_PLAYER_NAME.length).toBeGreaterThan(2);
    // The types are structural, so a wrong literal cannot be assigned.
    const role: CreatureRole = 'claw';
    const tree: TreeKind = 'ghostwood';
    expect(CREATURE_ROLES).toContain(role);
    expect(TREE_KINDS).toContain(tree);
  });
  it('routes every new intent to exactly one owner', () => {
    const owners: [CommandIntent, string][] = [
      [{ type: 'ride', creatureId: 'friend' }, 'world'],
      [{ type: 'dismount' }, 'world'],
      [{ type: 'fell', entityId: 'tree' }, 'world'],
      [{ type: 'graft', creatureId: 'friend', moveId: 'touch' }, 'panel'],
      [{ type: 'rename', name: 'Murat' }, 'panel'],
    ];
    for (const [intent, owner] of owners) {
      expect(commandOwner({ ...intent, commandId: 'c', tick: 1 }), intent.type).toBe(owner);
    }
  });
  it('accepts a printable name and refuses everything else', () => {
    expect(validPlayerName('Murat')).toBe(true);
    expect(validPlayerName('Ay Bahçıvanı')).toBe(true);
    expect(validPlayerName('')).toBe(false);
    expect(validPlayerName('  ')).toBe(false);
    expect(validPlayerName(' kenar ')).toBe(false);
    expect(validPlayerName('x'.repeat(PLAYER_NAME_LIMIT + 1))).toBe(false);
    expect(validPlayerName('kötü\u0007ad')).toBe(false);
    expect(validPlayerName(42)).toBe(false);
  });
});

describe('the v3 record', () => {
  it('writes a fresh save at version three with the new fields', () => {
    const fresh = state();
    expect(fresh.saveVersion).toBe(WORLD_SAVE_VERSION);
    expect(WORLD_SAVE_VERSION).toBe(4);
    expect(fresh.playerName).toBe(DEFAULT_PLAYER_NAME);
    expect(fresh.grafts).toEqual([]);
    expect(fresh.mount).toBeNull();
    expect(fresh.speedEffects).toEqual([]);
    expect(() => validateWorldState(world, fresh)).not.toThrow();
  });
  it('lifts a v2 record without losing anything', () => {
    const v2 = { ...state(), saveVersion: 2, worldTick: 4242, secretFlags: ['secret:forest'] } as unknown as Record<string, unknown>;
    delete v2.loadouts; delete v2.seenSpeciesIds; delete v2.discoveredItemIds;
    delete v2.playerName; delete v2.grafts; delete v2.mount; delete v2.speedEffects;
    const upgraded = migrateWorldState(v2) as WorldState;
    expect(upgraded.saveVersion).toBe(4);
    expect(upgraded.playerName).toBe(DEFAULT_PLAYER_NAME);
    expect(upgraded.grafts).toEqual([]);
    expect(upgraded.mount).toBeNull();
    expect(upgraded.speedEffects).toEqual([]);
    // Everything the older record already held survives the lift.
    expect(upgraded.worldTick).toBe(4242);
    expect(upgraded.secretFlags).toEqual(['secret:forest']);
    expect(() => validateWorldState(world, upgraded)).not.toThrow();
    // A record that is already current is returned untouched.
    const current = state();
    expect(migrateWorldState(current)).toBe(current);
  });
  it('keeps a name the player already chose when lifting', () => {
    const v2 = { ...state({ playerName: 'Murat' }), saveVersion: 2 } as unknown as Record<string, unknown>;
    delete v2.loadouts; delete v2.seenSpeciesIds; delete v2.discoveredItemIds;
    expect((migrateWorldState(v2) as WorldState).playerName).toBe('Murat');
  });
  it('refuses a duplicate graft, a third graft and an unknown move', () => {
    const graft = (moveId: string, creatureId = 'friend'): GraftRecord => ({ creatureId, moveId, tick: 12 });
    expect(() => validateWorldState(world, state({ grafts: [graft('starfall')] }))).not.toThrow();
    expect(() => validateWorldState(world, state({ grafts: [graft('starfall'), graft('starfall')] }))).toThrow();
    // A third graft is refused until the creature is old enough to hold one.
    expect(() => validateWorldState(world, state({
      grafts: [graft('starfall'), graft('cyclone'), graft('sunburst')],
    }))).toThrow();
    expect(() => validateWorldState(world, state({ grafts: [graft('yok')] }))).toThrow();
    expect(() => validateWorldState(world, state({ grafts: [graft('starfall', 'başkası')] }))).toThrow();
    // Two different moves on one creature are the allowed maximum.
    expect(() => validateWorldState(world, state({ grafts: [graft('starfall'), graft('cyclone')] }))).not.toThrow();
  });
  it('refuses a mount that is not travelling with the player and a runaway tonic', () => {
    const mount = (creatureId: string, role: MountRecord['role'] = 'ride'): MountRecord => ({ creatureId, role });
    expect(() => validateWorldState(world, state({ mount: mount('friend') }))).not.toThrow();
    expect(() => validateWorldState(world, state({ mount: mount('yok') }))).toThrow();
    expect(() => validateWorldState(world, state({ mount: { creatureId: 'friend', role: 'tank' } as unknown as MountRecord }))).toThrow();
    const effect = (overrides: Partial<SpeedEffect> = {}): SpeedEffect => ({ itemId: 'seal', multiplier: 1.5, untilTick: 900, ...overrides });
    expect(() => validateWorldState(world, state({ speedEffects: [effect()] }))).not.toThrow();
    expect(() => validateWorldState(world, state({ speedEffects: [effect({ multiplier: 1 })] }))).toThrow();
    expect(() => validateWorldState(world, state({ speedEffects: [effect({ multiplier: 4 })] }))).toThrow();
    expect(() => validateWorldState(world, state({ speedEffects: [effect({ untilTick: -1 })] }))).toThrow();
    expect(() => validateWorldState(world, state({ speedEffects: [effect({ itemId: 'yok' })] }))).toThrow();
    expect(creatures.length).toBeGreaterThan(0);
  });
});
