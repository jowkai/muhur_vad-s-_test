import { describe, expect, it } from 'vitest';
import { inputOwner, transition } from '../../src/app/state';
import { BIOME_IDS, type GameState } from '../../src/contracts';
import { GAME_CONFIG } from '../../src/config';

describe('shared contracts', () => {
  it('rejects delayed battle and commit events from a different encounter', () => {
    const encounter: GameState = { mode: 'encounter', encounterId: 'new' };
    expect(transition(encounter, { type: 'start-battle', encounterId: 'old', battleId: 'old-battle' })).toBe(encounter);
    const battle = transition(encounter, { type: 'start-battle', encounterId: 'new', battleId: 'new-battle' });
    expect(transition(battle, { type: 'commit', battleId: 'old-battle', transactionId: 'old-tx' })).toBe(battle);
  });
  it('defines eight unique biomes and bounded fixed simulation steps', () => {
    expect(new Set(BIOME_IDS).size).toBe(8);
    expect(GAME_CONFIG.worldSize / GAME_CONFIG.chunkSize).toBe(32);
    expect(GAME_CONFIG.maxFrameDelta / GAME_CONFIG.fixedStep).toBe(5);
  });
  it('routes input exclusively and blocks it when hidden', () => {
    const states: GameState[] = [{ mode: 'exploring' }, { mode: 'panel', panel: 'inventory' }, { mode: 'battle', battleId: 'b', encounterId: 'e' }];
    expect(states.map((state) => inputOwner(state))).toEqual(['world', 'panel', 'battle']);
    expect(states.map((state) => inputOwner(state, true))).toEqual(['none', 'none', 'none']);
  });
  it('retains the world lock and transaction identity after a failed commit', () => {
    let state: GameState = { mode: 'boot' };
    state = transition(state, { type: 'loaded' });
    state = transition(state, { type: 'encounter', encounterId: 'e' });
    expect(transition(state, { type: 'encounter', encounterId: 'other' })).toBe(state);
    state = transition(state, { type: 'start-battle', battleId: 'b', encounterId: 'e' });
    state = transition(state, { type: 'commit', transactionId: 'tx', battleId: 'b' });
    expect(transition(state, { type: 'committed', transactionId: 'old' })).toBe(state);
    state = transition(state, { type: 'commit-failed', transactionId: 'tx', error: 'quota' });
    expect(inputOwner(state)).toBe('none');
    expect(transition(state, { type: 'close-panel' })).toBe(state);
    state = transition(state, { type: 'retry' });
    expect(state).toEqual({ mode: 'committing', battleId: 'b', encounterId: 'e', transactionId: 'tx' });
    state = transition(state, { type: 'committed', transactionId: 'tx' });
    expect(inputOwner(state)).toBe('world');
  });
  it('permits panels only during exploration', () => {
    const battle: GameState = { mode: 'battle', battleId: 'b', encounterId: 'e' };
    expect(transition(battle, { type: 'open-panel', panel: 'alchemy' })).toBe(battle);
    const panel = transition({ mode: 'exploring' }, { type: 'open-panel', panel: 'alchemy' });
    expect(inputOwner(panel)).toBe('panel');
    expect(transition(panel, { type: 'close-panel' })).toEqual({ mode: 'exploring' });
  });
});
