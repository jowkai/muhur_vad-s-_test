import { describe, expect, it } from 'vitest';
import { BIOME_IDS, PARTY_LIMIT, type CommandIntent, type GameCommand, type ShrineRecord, type StatusEffect } from '../../src/contracts';
import { commandOwner } from '../../src/contracts/command-bus';
import { inputOwner } from '../../src/app/state';

const command = (intent: CommandIntent): GameCommand => ({ ...intent, commandId: 'c1', tick: 1 });

describe('v2 command surface', () => {
  it('routes every new intent to exactly one owner', () => {
    const owners: [CommandIntent, string][] = [
      [{ type: 'gather', entityId: 'e1', method: 'dig' }, 'world'],
      [{ type: 'visit-shrine', shrineId: 'forest' }, 'world'],
      [{ type: 'travel', anchorId: 'forest' }, 'panel'],
      [{ type: 'set-active', creatureId: 'friend' }, 'panel'],
      [{ type: 'switch-party', index: 2 }, 'battle'],
      [{ type: 'use-battle-item', itemId: 'salve' }, 'battle'],
    ];
    for (const [intent, owner] of owners) expect(commandOwner(command(intent)), intent.type).toBe(owner);
    // World intents stay out of the battle owner and battle intents out of the world owner.
    expect(commandOwner(command({ type: 'attack', slot: 0 }))).toBe('battle');
    expect(commandOwner(command({ type: 'interact', entityId: 'e' }))).toBe('world');
  });
  it('keeps panel ownership consistent with the app state machine', () => {
    expect(inputOwner({ mode: 'panel', panel: 'objectives' })).toBe('panel');
    expect(inputOwner({ mode: 'panel', panel: 'settings' })).toBe('panel');
    expect(inputOwner({ mode: 'battle', battleId: 'b', encounterId: 'e' })).toBe('battle');
    expect(inputOwner({ mode: 'exploring' }, true)).toBe('none');
  });
  it('fixes the party limit and the shapes the later waves build on', () => {
    expect(PARTY_LIMIT).toBe(6);
    const status: StatusEffect = { kind: 'poison', turns: 3 };
    expect(['poison', 'burn', 'slow']).toContain(status.kind);
    const shrine: ShrineRecord = { biomeId: 'forest', visitedTick: 12, chestTaken: false };
    expect(BIOME_IDS).toContain(shrine.biomeId);
    expect(shrine.chestTaken).toBe(false);
  });
});
