import { describe, expect, it } from 'vitest';
import { creatures, items, recipes } from '../../src/content/catalog';
import { itemAssets } from '../../src/content/asset-manifest';
import { craft, planInventory, type ContentState } from '../../src/content/alchemy';
import { useCampItem } from '../../src/content/camp-use';
import { stats } from '../../src/game/combat/core';
import { createWorld } from '../../src/world/generation/world';
import { createWorldState, validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { IndexedDbSave } from '../../src/game/save/indexeddb';
import { INVENTORY_COLUMNS, inventoryView, moveSelection } from '../../src/ui/inventory/model';
import { alchemyView, craftPreview } from '../../src/ui/alchemy/model';
import { campView, INCUBATION_TICKS } from '../../src/ui/camp/model';
import { claimDelivery } from '../../src/game/combat/rewards';
import { panelIntentForKey } from '../../src/ui/inventory/panel-dialog';

const world = createWorld();
const species = creatures[0];
const maxHp = stats({ id: 'friend', species, level: 2 }).maxHp;
const slots = (...stacks: ({ itemId: string; quantity: number } | null)[]): ContentState['inventory'] =>
  [...stacks, ...Array.from({ length: Math.max(0, 12 - stacks.length) }, () => null)];
function state(overrides: Partial<WorldState> = {}): WorldState {
  return {
    ...createWorldState(world, {
      mode: 'panel', atCamp: true, inventory: slots({ itemId: 'dew_leaf', quantity: 5 }, { itemId: 'soft_seed', quantity: 2 }, { itemId: 'salve', quantity: 1 }),
      unlockedRecipeIds: ['salve'],
      creatures: [{ id: 'friend', speciesId: species.id, level: 2, xp: 0, hp: maxHp - 12, maxHp }],
      creatureCapacity: 3, eggCapacity: 2, eggs: [], battle: null, loot: null,
      rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
    }), ...overrides,
  };
}
let counter = 0;
async function storage(initial: WorldState) {
  const save = await IndexedDbSave.open<WorldState>({
    name: `alchemy-${counter++}`, initial: () => structuredClone(initial), validate: (value) => validateWorldState(world, value),
  });
  await save.transact('boot', () => {});
  return save;
}

describe('inventory grid', () => {
  it('lays six columns out with stacks, icons and a tooltip that reads the catalogue', () => {
    const view = inventoryView(state(), { selectedIndex: 0 });
    expect(view.columns).toBe(INVENTORY_COLUMNS);
    expect(view.cells).toHaveLength(12);
    expect(view.cells[0]).toMatchObject({ row: 0, column: 0, itemId: 'dew_leaf', quantity: 5, stackLimit: 99, full: false });
    expect(view.cells[6]).toMatchObject({ row: 1, column: 0 });
    expect(view.cells[0].iconUrl).toBe(itemAssets.dew_leaf);
    // v3 tooltips name the material class next to its region.
    expect(view.selected).toMatchObject({ name: 'Çiy Yaprağı', quantity: 5, rarity: 'Sık', origin: 'Şafak Çayırı · Bitki', effect: null });
    expect(inventoryView(state(), { selectedIndex: 2 }).selected!.effect).toContain('20 can yeniler');
    expect(view.used).toBe(3);
    expect(view.summary).toBe('3/12 yuva dolu');
    expect(inventoryView({ inventory: slots({ itemId: 'dew_leaf', quantity: 99 }) }).cells[0].full).toBe(true);
  });
  it('filters without rewriting the record and walks the grid with the arrow keys', () => {
    const record = state();
    const filtered = inventoryView(record, { filter: 'effect' });
    expect(filtered.cells.filter((cell) => cell.itemId && cell.matches).map((cell) => cell.itemId)).toEqual(['salve']);
    expect(filtered.cells.filter((cell) => cell.itemId).length).toBe(3);
    expect(inventoryView(record, { filter: 'material' }).cells.filter((cell) => cell.itemId && cell.matches).map((cell) => cell.itemId)).toEqual(['dew_leaf', 'soft_seed']);
    expect(record).toEqual(state());
    expect(moveSelection(0, 'ArrowRight', 12)).toBe(1);
    expect(moveSelection(5, 'ArrowRight', 12)).toBe(5);
    expect(moveSelection(0, 'ArrowLeft', 12)).toBe(0);
    expect(moveSelection(0, 'ArrowDown', 12)).toBe(6);
    expect(moveSelection(6, 'ArrowUp', 12)).toBe(0);
    expect(moveSelection(11, 'ArrowDown', 12)).toBe(11);
    expect(moveSelection(8, 'Home', 12)).toBe(6);
    expect(moveSelection(8, 'End', 12)).toBe(11);
    expect(moveSelection(3, 'Enter', 12)).toBe(3);
    expect(() => moveSelection(12, 'ArrowUp', 12)).toThrow(RangeError);
  });
});

describe('alchemy preview and the eighty-eight recipe book', () => {
  it('lists every recipe, hides undiscovered names and counts missing ingredients', () => {
    const view = alchemyView(state(), 'salve');
    expect(view.rows).toHaveLength(88);
    expect(view.totalCount).toBe(recipes.length);
    expect(view.unlockedCount).toBe(1);
    expect(view.note).toBe('1/88 tarif keşfedildi');
    const locked = view.rows.find((row) => row.recipeId === 'seal')!;
    expect(locked).toMatchObject({ unlocked: false, name: 'Keşfedilmemiş tarif', outputId: null, craftable: false });
    expect(view.preview).toMatchObject({ outputName: 'Çiy Merhemi', outputQuantity: 1, craftable: true });
    expect(view.preview!.slots.map((slot) => slot.text)).toEqual(['Çiy Yaprağı 5/2', 'Yumuşak Tohum 2/1']);
    expect(alchemyView(state(), 'seal').preview).toBeNull();
    const short = craftPreview({ inventory: slots({ itemId: 'dew_leaf', quantity: 1 }), unlockedRecipeIds: ['salve'] }, 'salve')!;
    expect(short).toMatchObject({ craftable: false });
    expect(short.reason).toBe('Çiy Yaprağı 1 eksik · Yumuşak Tohum 1 eksik');
    expect(short.slots[0]).toMatchObject({ have: 1, need: 2, enough: false, missing: 1 });
  });
  it('previews with the same planner the atomic command uses and consumes nothing', () => {
    const record = state();
    const preview = craftPreview(record, 'salve')!;
    expect(preview.resultingFreeSlots).toBe(inventoryView(record).cells.filter((cell) => !cell.itemId).length);
    expect(record.inventory[0]).toEqual({ itemId: 'dew_leaf', quantity: 5 });
    const planned = planInventory(record.inventory, recipes.find((recipe) => recipe.id === 'salve')!.inputs, [{ itemId: 'salve', quantity: 1 }]);
    expect(planned.filter((stack) => stack === null).length).toBe(preview.resultingFreeSlots);
    expect(craftPreview(record, 'yok')).toBeNull();
    const fullBag: ContentState['inventory'] = [{ itemId: 'clay_shard', quantity: 2 }, { itemId: 'dew_leaf', quantity: 1 }];
    const tight = craftPreview({ inventory: fullBag, unlockedRecipeIds: ['seal'] }, 'seal')!;
    expect(tight.craftable).toBe(true);
    expect(tight.outputQuantity).toBe(2);
  });
  it('rejects a locked or short craft without spending anything', async () => {
    const save = await storage(state());
    await expect(craft(save, 'c1', 'seal')).rejects.toThrow();
    expect((await save.load())!.inventory).toEqual(state().inventory);
    const crafted = await craft(save, 'c2', 'salve');
    expect(crafted.inventory[0]).toEqual({ itemId: 'dew_leaf', quantity: 3 });
    expect(crafted.inventory[2]).toEqual({ itemId: 'salve', quantity: 2 });
    for (let i = 0; i < 20; i++) await craft(save, 'c2', 'salve');
    expect(await save.load()).toEqual(crafted);
    expect(alchemyView(crafted, 'salve').preview!.craftable).toBe(true);
    const drained = await craft(save, 'c3', 'salve');
    expect(craftPreview(drained, 'salve')!.craftable).toBe(false);
    await expect(craft(save, 'c4', 'salve')).rejects.toThrow();
    expect((await save.load())!.inventory).toEqual(drained.inventory);
    save.close();
  });
  it('covers all forty recipes with a preview once their ingredients are in the bag', () => {
    const everything = items.map((item) => ({ itemId: item.id, quantity: 4 }));
    const stocked = { inventory: [...everything, null, null], unlockedRecipeIds: recipes.map((recipe) => recipe.id) };
    const view = alchemyView(stocked);
    expect(view.rows.every((row) => row.unlocked && row.craftable)).toBe(true);
    for (const recipe of recipes) {
      const preview = craftPreview(stocked, recipe.id)!;
      expect(preview.slots).toHaveLength(recipe.inputs.length);
      expect(preview.slots.every((slot) => slot.enough)).toBe(true);
      expect(preview.outputQuantity).toBe(recipe.output.quantity);
    }
  });
});

describe('camp use, incubation and panel focus rules', () => {
  it('previews healing per creature and refuses the wrong target without consuming an item', async () => {
    const record = state();
    const view = campView(record, { selectedItemId: 'salve', selectedCreatureId: 'friend' });
    expect(view.creatures[0]).toMatchObject({ hp: maxHp - 12, maxHp, preview: `${maxHp - 12} → ${maxHp}` });
    expect(view.items.find((row) => row.itemId === 'salve')).toMatchObject({ usable: true, quantity: 1, needsTarget: true });
    const healthy = campView({ ...record, creatures: [{ ...record.creatures[0], hp: maxHp }] }, { selectedItemId: 'salve', selectedCreatureId: 'friend' });
    expect(healthy.items.find((row) => row.itemId === 'salve')).toMatchObject({ usable: false, reason: 'Canı zaten tam' });
    const fainted = { ...record, creatures: [{ ...record.creatures[0], hp: 0 }] };
    expect(campView(fainted, { selectedItemId: 'salve', selectedCreatureId: 'friend' }).items[0].reason).toBe('Baygın yaratık için Uyanış Tuzu gerekir');
    const away = campView({ ...record, atCamp: false });
    expect(away.locked).toBe('Eşyalar yalnız güvenli kampta kullanılabilir');
    expect(away.items.every((row) => !row.usable)).toBe(true);
    const save = await storage(fainted);
    await expect(useCampItem(save, 'u1', 'salve', 'friend')).rejects.toThrow();
    expect((await save.load())!.inventory).toEqual(fainted.inventory);
    const healed = await useCampItem(await storage(record), 'u2', 'salve', 'friend');
    expect(healed.creatures[0].hp).toBe(maxHp);
    expect(healed.inventory[2]).toBeNull();
    save.close();
  });
  it('tracks incubation as active camp time and explains every blocked hatch', () => {
    const egg = { id: 'e1', encounterId: 'enc', speciesId: species.id, seed: 3, activeTicks: INCUBATION_TICKS - 600 };
    const record = state({ eggs: [egg], consumedEntityIds: ['enc'], inventory: slots({ itemId: 'heat_herb', quantity: 1 }) });
    const waiting = campView(record).eggs[0];
    expect(waiting).toMatchObject({ ready: false, reason: 'Kuluçka sürüyor', remainingSeconds: 10 });
    expect(waiting.ratio).toBeCloseTo((INCUBATION_TICKS - 600) / INCUBATION_TICKS, 6);
    expect(waiting.text).toBe('10 sn aktif kamp oyunu kaldı');
    const ready = campView({ ...record, eggs: [{ ...egg, activeTicks: INCUBATION_TICKS }] }).eggs[0];
    expect(ready).toMatchObject({ ready: true, reason: null, text: 'Çatlamaya hazır', remainingSeconds: 0 });
    const noHerb = campView({ ...record, eggs: [{ ...egg, activeTicks: INCUBATION_TICKS }], inventory: slots() }).eggs[0];
    expect(noHerb).toMatchObject({ ready: false, reason: 'Isı Otu gerekir' });
    const fullTeam = campView({ ...record, eggs: [{ ...egg, activeTicks: INCUBATION_TICKS }], creatureCapacity: 1 }).eggs[0];
    expect(fullTeam.reason).toBe('Koleksiyon dolu');
    const away = campView({ ...record, atCamp: false, eggs: [{ ...egg, activeTicks: INCUBATION_TICKS }] }).eggs[0];
    expect(away.reason).toBe('Kuluçka yalnız güvenli kampta ilerler');
    expect(campView(state()).eggs).toEqual([]);
  });
  it('routes panel keys only when the world owns input and closes the open panel with Escape', () => {
    expect(panelIntentForKey('i', 'world', null)).toEqual({ type: 'open-panel', panel: 'inventory' });
    expect(panelIntentForKey('C', 'world', null)).toEqual({ type: 'open-panel', panel: 'alchemy' });
    expect(panelIntentForKey('k', 'world', null)).toEqual({ type: 'open-panel', panel: 'camp' });
    expect(panelIntentForKey('Escape', 'panel', 'inventory')).toEqual({ type: 'close-panel' });
    expect(panelIntentForKey('i', 'panel', 'inventory')).toBeNull();
    expect(panelIntentForKey('Escape', 'world', null)).toBeNull();
    expect(panelIntentForKey('c', 'battle', null)).toBeNull();
    expect(panelIntentForKey('i', 'none', null)).toBeNull();
    expect(panelIntentForKey('q', 'world', null)).toBeNull();
  });
});

describe('delivery box', () => {
  it('lists overflowed rewards, explains why they wait and claims what fits', async () => {
    const full = state({
      inventory: [{ itemId: 'dew_leaf', quantity: 99 }, { itemId: 'soft_seed', quantity: 4 }, { itemId: 'salve', quantity: 1 }],
      deliveryBox: [{ kind: 'item', itemId: 'clay_shard', quantity: 3 }, { kind: 'essence', element: 'çim', quantity: 1 }],
    });
    const blocked = campView(full).delivery;
    expect(blocked.rows).toHaveLength(2);
    expect(blocked.rows[0]).toMatchObject({ label: 'Kil Parçası ×3', claimable: false, detail: 'Çantada yer açınca alınabilir' });
    expect(blocked.rows[1]).toMatchObject({ label: 'çim esansı ×1', claimable: false });
    expect(blocked).toMatchObject({ items: 1, essences: 1, canClaim: false, reason: 'Çantada boş yuva yok' });
    const save = await storage(full);
    await expect(claimDelivery(save, 'claim-blocked')).rejects.toThrow();
    expect((await save.load())!.deliveryBox).toEqual(full.deliveryBox);

    const roomy = state({
      inventory: [{ itemId: 'dew_leaf', quantity: 99 }, null, null],
      deliveryBox: [{ kind: 'item', itemId: 'clay_shard', quantity: 3 }, { kind: 'essence', element: 'çim', quantity: 1 }],
    });
    expect(campView(roomy).delivery).toMatchObject({ canClaim: true, reason: null });
    const open = await storage(roomy);
    const claimed = await claimDelivery(open, 'claim');
    expect(claimed.inventory.some((stack) => stack?.itemId === 'clay_shard' && stack.quantity === 3)).toBe(true);
    expect(claimed.deliveryBox).toEqual([{ kind: 'essence', element: 'çim', quantity: 1 }]);
    for (let i = 0; i < 10; i++) await claimDelivery(open, 'claim');
    expect(await open.load()).toEqual(claimed);
    await expect(claimDelivery(open, 'claim-again')).rejects.toThrow();
    save.close(); open.close();
  });
  it('takes only what fits and leaves the remainder in the box', async () => {
    const tight = state({
      inventory: [{ itemId: 'dew_leaf', quantity: 99 }, { itemId: 'clay_shard', quantity: 98 }],
      deliveryBox: [{ kind: 'item', itemId: 'clay_shard', quantity: 4 }],
    });
    const save = await storage(tight);
    const claimed = await claimDelivery(save, 'partial');
    expect(claimed.inventory[1]).toEqual({ itemId: 'clay_shard', quantity: 99 });
    expect(claimed.deliveryBox).toEqual([{ kind: 'item', itemId: 'clay_shard', quantity: 3 }]);
    expect(campView(claimed).delivery.canClaim).toBe(false);
    save.close();
  });
});
