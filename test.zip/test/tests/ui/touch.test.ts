import { describe, expect, it } from 'vitest';
import { STICK_DEAD_ZONE, STICK_RADIUS, STICK_REST, VirtualStick, readStick } from '../../src/ui/touch/stick';
import { TOUCH_CSS } from '../../src/ui/touch/touch-controls';
import { UI_CSS } from '../../src/ui/hud/hud-view';
import { PARTY_CSS } from '../../src/ui/party/style';
import { TAB_TARGET_PX } from '../../src/ui/shell/tabs';

const origin = { x: 100, z: 100 };

describe('the virtual stick', () => {
  it('reads a normalised direction and never longer than one', () => {
    const right = readStick(origin, { x: 100 + STICK_RADIUS, z: 100 });
    expect(right.active).toBe(true);
    expect(right.direction.x).toBeCloseTo(1, 6);
    expect(right.direction.z).toBeCloseTo(0, 6);
    const far = readStick(origin, { x: 100 + STICK_RADIUS * 4, z: 100 + STICK_RADIUS * 4 });
    expect(Math.hypot(far.direction.x, far.direction.z)).toBeCloseTo(1, 6);
    expect(Math.hypot(far.knob.x, far.knob.z)).toBeCloseTo(STICK_RADIUS, 6);
    const half = readStick(origin, { x: 100, z: 100 + STICK_RADIUS / 2 });
    expect(half.direction.z).toBeCloseTo(.5, 6);
  });
  it('ignores a resting thumb inside the dead zone', () => {
    expect(readStick(origin, { x: 100 + STICK_RADIUS * STICK_DEAD_ZONE * .9, z: 100 })).toEqual(STICK_REST);
    expect(readStick(origin, origin)).toEqual(STICK_REST);
    expect(readStick(origin, { x: Number.NaN, z: 0 })).toEqual(STICK_REST);
  });
  it('takes the same command path as the keyboard', () => {
    const stick = new VirtualStick('session');
    stick.setOwner('world');
    expect(stick.movement(4)).toBeNull();
    stick.press(1, origin, { x: 100, z: 100 - STICK_RADIUS });
    const command = stick.movement(4)!;
    expect(command).toMatchObject({ type: 'move', tick: 4 });
    expect(command.type === 'move' && command.direction.z).toBeCloseTo(-1, 6);
    expect(command.commandId).toContain('session');
    // Every frame gets its own command id, exactly like the keyboard adapter.
    expect(stick.movement(5)!.commandId).not.toBe(command.commandId);
    expect(() => stick.movement(-1)).toThrow(RangeError);
  });
  it('keeps still while a panel or a battle owns the input', () => {
    const stick = new VirtualStick('session');
    stick.setOwner('panel');
    expect(stick.press(1, origin, { x: 160, z: 100 })).toBe(false);
    expect(stick.movement(1)).toBeNull();
    stick.setOwner('world');
    stick.press(1, origin, { x: 160, z: 100 });
    expect(stick.movement(1)).not.toBeNull();
    // Opening a panel mid-drag drops the grip instead of walking on.
    stick.setOwner('panel');
    expect(stick.current).toEqual(STICK_REST);
    expect(stick.movement(2)).toBeNull();
  });
  it('answers one pointer at a time, so a mouse and a finger cannot both drive', () => {
    const stick = new VirtualStick('session');
    stick.setOwner('world');
    expect(stick.press(1, origin, { x: 160, z: 100 })).toBe(true);
    // A second pointer (the mouse) is refused while the first one holds the pad.
    expect(stick.press(2, origin, { x: 40, z: 100 })).toBe(false);
    expect(stick.move(2, { x: 40, z: 100 })).toBe(false);
    const held = stick.movement(1)!;
    expect(held.type).toBe('move');
    expect(held.type === 'move' ? held.direction.x : 0).toBeGreaterThan(0);
    expect(stick.release(2)).toBe(false);
    expect(stick.release(1)).toBe(true);
    expect(stick.movement(2)).toBeNull();
    expect(stick.press(2, origin, { x: 40, z: 100 })).toBe(true);
  });
});

describe('the narrow screen', () => {
  it('keeps the pad, the tabs and the party strip out of each other', () => {
    expect(TOUCH_CSS).toMatch(/\.mv-stick\{[^}]*touch-action:none/);
    expect(TOUCH_CSS).toMatch(/\.mv-stick\{[^}]*left:18px/);
    expect(TOUCH_CSS).toContain('@media (max-width:640px)');
    // A pointer-fine device (a desktop mouse) does not get a thumb stick by accident.
    expect(TOUCH_CSS).toContain('@media (pointer:fine)');
    const narrowTabs = UI_CSS.slice(UI_CSS.indexOf('@media (max-width:640px)'));
    expect(narrowTabs).toMatch(/\.mv-tabbar\{[^}]*width:100%/);
    const narrowParty = PARTY_CSS.slice(PARTY_CSS.indexOf('@media (max-width:640px)'));
    expect(narrowParty).toMatch(/\.mv-party-slot\{[^}]*flex:1 1 0/);
    expect(narrowParty).toMatch(/\.mv-party\{[^}]*width:100%/);
  });
  it('keeps every touch target at 44 px', () => {
    expect(TAB_TARGET_PX).toBe(44);
    expect(UI_CSS).toMatch(/\.mv-tabbar button\{[^}]*min-height:44px/);
    expect(PARTY_CSS).toMatch(/\.mv-party-slot\{[^}]*min-height:112px/);
    // The stick itself is far larger than a finger target.
    const size = Number(/\.mv-stick\{[^}]*width:(\d+)px/.exec(TOUCH_CSS)![1]);
    expect(size).toBeGreaterThanOrEqual(44);
    expect(Number(/\.mv-stick-knob\{[^}]*width:(\d+)px/.exec(TOUCH_CSS)![1])).toBeGreaterThanOrEqual(44);
  });
  it('never lets a bar scroll the page sideways', () => {
    expect(UI_CSS).toMatch(/\.mv-tabbar\{[^}]*overflow-x:auto/);
    expect(PARTY_CSS).toMatch(/\.mv-party\{[^}]*overflow-x:auto/);
    expect(UI_CSS).toMatch(/\.mv-dock\{[^}]*max-width:calc\(100vw - 32px\)/);
  });
});
