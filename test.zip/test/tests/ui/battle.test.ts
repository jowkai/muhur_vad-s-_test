import { describe, expect, it, vi } from 'vitest';
import type { CommandIntent } from '../../src/contracts';
import { creatureById } from '../../src/content/catalog';
import { creatureAssets } from '../../src/content/asset-manifest';
import { beginBattle, captureChance, createBattle, movesFor, resolveBattle, stats, type BattleState } from '../../src/game/combat/core';
import { battleLog, battleView, intentForKey, CAPTURE_THRESHOLD } from '../../src/ui/battle/model';
import { BattleActionGate } from '../../src/ui/battle/gate';

// Pinned by name: the battle card's slot shape is the point of this file, and a growing
// roster must not silently re-point it at a different species.
const species = creatureById('bloomhart')!;
const player = { id: 'friend', species, level: 2 };
const enemySpecies = creatureById('breezefinch')!;
const enemy = { id: 'wild', species: enemySpecies, level: 2 };
function battle(overrides: Partial<BattleState> = {}): BattleState {
  const state = beginBattle(createBattle({ battleId: 'b', encounterId: 'e', seed: 7, player, enemy, inventorySnapshot: { seal: 2 }, captureCapacity: 1 }));
  return { ...state, ...overrides };
}
const view = (overrides: Partial<BattleState> = {}) => battleView(battle(overrides));

describe('battle slots and fighters', () => {
  it('draws the friend from behind and the wild creature from the front', () => {
    const model = view();
    expect(model.player).toMatchObject({ facing: 'back', name: species.name, level: 2, hpText: `${stats(player).maxHp}/${stats(player).maxHp}` });
    expect(model.enemy).toMatchObject({ facing: 'front', name: enemySpecies.name });
    expect(model.player.spriteUrl).toBe(creatureAssets[species.id as keyof typeof creatureAssets].back);
    expect(model.enemy.spriteUrl).toBe(creatureAssets[enemySpecies.id as keyof typeof creatureAssets].front);
    expect(model.player.spriteUrl).not.toBe(model.enemy.spriteUrl);
  });
  it('shows all four slots with their unlock level and energy cost', () => {
    const low = view();
    expect(low.slots).toHaveLength(4);
    expect(low.slots.map((slot) => slot.name)).toEqual(movesFor(player).map((move) => move.name));
    expect(low.slots[0]).toMatchObject({ unlocked: true, enabled: true, cost: 1, note: '1 enerji' });
    // The opener a fresh creature can always press, and the finisher it grows into.
    expect(low.slots[1]).toMatchObject({ unlocked: true, enabled: true, cost: 0 });
    expect(low.slots[3]).toMatchObject({ unlocked: false, enabled: false, note: "Sv 10'da açılır" });
    expect(low.slots.map((slot) => slot.unlockLevel)).toEqual([1, 1, 1, 10]);
    expect(low.slots[2]).toMatchObject({ unlocked: true, cost: 1, enabled: true });
    const veteran = battleView(battle({ player: { ...player, level: 10 }, stamina: 1 }));
    expect(veteran.slots[3]).toMatchObject({ unlocked: true, affordable: false, enabled: false, note: '4 enerji gerekir' });
    expect(veteran.slots[1].enabled).toBe(true);
    expect(low.slots.every((slot) => slot.intent.type === 'attack')).toBe(true);
  });
  it('locks every action while the turn resolves or the battle is over', () => {
    for (const state of [{ phase: 'RESOLVE_ENEMY' as const }, { phase: 'WON' as const, outcome: 'WON' as const, enemyHp: 0 }]) {
      const model = battleView(battle(state));
      expect(model.busy).toBe(true);
      expect(model.slots.every((slot) => !slot.enabled)).toBe(true);
      expect(model.capture.enabled).toBe(false);
      expect(model.flee.enabled).toBe(false);
      expect(intentForKey('1', model)).toBeNull();
      expect(intentForKey('c', model)).toBeNull();
      expect(intentForKey('Escape', model)).toBeNull();
    }
    expect(battleView(battle({ phase: 'WON', outcome: 'WON', enemyHp: 0 })).resultText).toBe(`${enemySpecies.name} bayıldı`);
  });
});

describe('capture affordances without a formula copy', () => {
  const max = stats(enemy).maxHp;
  it('marks the 35 percent threshold and refuses above it', () => {
    const high = battleView(battle({ enemyHp: Math.floor(max * CAPTURE_THRESHOLD) + 1 }));
    expect(high.capture).toMatchObject({ thresholdRatio: 0.35, belowThreshold: false, enabled: false });
    expect(high.capture.note).toContain('%35');
    const ready = battleView(battle({ enemyHp: Math.floor(max * CAPTURE_THRESHOLD) }));
    expect(ready.capture).toMatchObject({ belowThreshold: true, enabled: true, seals: 2 });
    expect(ready.enemy.ratio).toBeLessThanOrEqual(CAPTURE_THRESHOLD);
  });
  it('explains every blocked capture and never promises a percentage', () => {
    const low = { enemyHp: 1 };
    expect(battleView(battle({ ...low, inventorySnapshot: {} })).capture).toMatchObject({ enabled: false, note: 'Mühür kalmadı', seals: 0 });
    expect(battleView(battle({ ...low, captureCapacity: 0 })).capture.note).toBe('Koleksiyon dolu');
    expect(battleView(battle({ ...low, capturable: false })).capture.note).toBe('Bu hedef yakalanamaz');
    expect(battleView(battle({ enemyHp: 0, phase: 'WON', outcome: 'WON' })).capture.note).toBe('Bayılmış hedef yakalanamaz');
    const ready = battleView(battle(low));
    expect(ready.capture.note).not.toMatch(/%\d/);
    expect(['düşük', 'orta', 'yüksek']).toContain(ready.capture.odds);
    // The label is bucketed straight from the domain chance; the UI recomputes nothing.
    const chance = captureChance(battle(low));
    expect(ready.capture.odds).toBe(chance >= 0.6 ? 'yüksek' : chance >= 0.35 ? 'orta' : 'düşük');
  });
});

describe('log and command routing', () => {
  it('builds the log from committed receipts and mirrors the domain result in HP', () => {
    const start = battle({ enemyHp: 40 });
    const first = resolveBattle(start, { type: 'attack', slot: 0, commandId: 'a1', tick: 1 });
    expect(first.accepted).toBe(true);
    const model = battleView(first.state);
    expect(model.enemy.hp).toBe(first.state.enemyHp);
    expect(model.enemy.hpText).toBe(`${first.state.enemyHp}/${stats(enemy).maxHp}`);
    expect(model.log.length).toBeGreaterThanOrEqual(2);
    expect(model.log[0]).toContain(species.name);
    expect(model.log.some((entry) => entry.includes('hasar') || entry.includes('ıskaladı') || entry.includes('siper'))).toBe(true);
    expect(model.log.at(-1)).toBe('— tur sonu —');
    expect(model.turn).toBe(first.state.turn);
    const fled = resolveBattle(battle(), { type: 'flee', commandId: 'f1', tick: 1 });
    expect(battleLog(fled.state).some((entry) => entry.startsWith('Kaçış'))).toBe(true);
  });
  it('maps 1-4, C and Escape to the very intents the pointer controls publish', () => {
    const model = battleView(battle({ enemyHp: 1, player: { ...player, level: 10 } }));
    expect(intentForKey('1', model)).toEqual({ type: 'attack', slot: 0 });
    expect(intentForKey('4', model)).toEqual({ type: 'attack', slot: 3 });
    expect(intentForKey('c', model)).toEqual({ type: 'capture' });
    expect(intentForKey('C', model)).toEqual({ type: 'capture' });
    expect(intentForKey('Escape', model)).toEqual({ type: 'flee' });
    expect(intentForKey('5', model)).toBeNull();
    expect(intentForKey('q', model)).toBeNull();
    // A slot the creature has not grown into publishes no intent at all.
    expect(intentForKey('4', battleView(battle()))).toBeNull();
  });
  it('sends one command per action even when the player double-presses', async () => {
    let release: () => void = () => {};
    let hold = true;
    const sent: CommandIntent[] = [];
    const send = vi.fn(async (intent: CommandIntent) => {
      sent.push(intent);
      if (hold) await new Promise<void>((resolve) => { release = resolve; });
    });
    const gate = new BattleActionGate(send);
    const first = gate.submit({ type: 'attack', slot: 0 });
    expect(gate.busy).toBe(true);
    expect(await gate.submit({ type: 'attack', slot: 0 })).toBe('busy');
    expect(await gate.submit({ type: 'capture' })).toBe('busy');
    release();
    hold = false;
    expect(await first).toBe('sent');
    expect(send).toHaveBeenCalledTimes(1);
    expect(gate.busy).toBe(false);
    expect(await gate.submit({ type: 'flee' })).toBe('sent');
    expect(sent).toEqual([{ type: 'attack', slot: 0 }, { type: 'flee' }]);
    expect(gate.count).toBe(2);
    expect(await gate.submit(null)).toBe('rejected');
    const closed = new BattleActionGate(send, () => false);
    expect(await closed.submit({ type: 'capture' })).toBe('rejected');
    expect(send).toHaveBeenCalledTimes(2);
  });
  it('keeps the gate usable after a failed command', async () => {
    const send = vi.fn().mockRejectedValueOnce(new Error('kayıt hatası')).mockResolvedValue(undefined);
    const gate = new BattleActionGate(send);
    await expect(gate.submit({ type: 'attack', slot: 0 })).rejects.toThrow('kayıt hatası');
    expect(gate.busy).toBe(false);
    expect(await gate.submit({ type: 'attack', slot: 0 })).toBe('sent');
  });
});
