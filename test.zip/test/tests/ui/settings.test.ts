import { describe, expect, it } from 'vitest';
import { BIOME_IDS } from '../../src/contracts';
import { creatureById } from '../../src/content/catalog';
import { BIOME_EXTRA_RECIPE, BIOME_RECIPE, STARTING_RECIPE_ID } from '../../src/content/secrets';
import { stats } from '../../src/game/combat/core';
import { createWorld } from '../../src/world/generation/world';
import { createWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { objectivesPanelView } from '../../src/ui/objectives/model';
import {
  ACTIONS, DEFAULT_PREFERENCES, PREFERENCES_KEY, RESERVED_KEYS, loadPreferences, normalizePreferences,
  rebind, savePreferences, type PreferenceStore,
} from '../../src/ui/settings/preferences';
import {
  BASE_DB_NAME, SLOT_IDS, dbNameFor, recoveryView, rememberSlot, rememberedSlot, slotViews, type SlotRecord,
} from '../../src/ui/recovery/slots';

const world = createWorld();
const owned = (id: string, speciesId: string, level = 3) => {
  const species = creatureById(speciesId)!;
  const maxHp = stats({ id, species, level }).maxHp;
  return { id, speciesId, level, xp: 0, hp: maxHp, maxHp };
};
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [{ itemId: 'seal', quantity: 1 }, null],
    unlockedRecipeIds: [STARTING_RECIPE_ID], creatures: [], creatureCapacity: 12, eggCapacity: 2, eggs: [],
    battle: null, loot: null, rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, ...overrides };
}
class MemoryStore implements PreferenceStore {
  private readonly map = new Map<string, string>();
  getItem(key: string) { return this.map.get(key) ?? null; }
  setItem(key: string, value: string) { this.map.set(key, value); }
}
class BlockedStore implements PreferenceStore {
  getItem(): string { throw new Error('private mode'); }
  setItem(): void { throw new Error('private mode'); }
}

describe('the objectives panel', () => {
  it('splits the eight objectives into open and finished', () => {
    const fresh = objectivesPanelView(state());
    expect(fresh.total).toBe(8);
    expect(fresh.open).toHaveLength(8);
    expect(fresh.done).toEqual([]);
    expect(fresh.summary).toBe('0/8 hedef tamamlandı');
    expect(fresh.ratio).toBe(0);
    const started = objectivesPanelView(state({
      shrines: [{ biomeId: 'meadow', visitedTick: 4, chestTaken: true }],
      creatures: [owned('egg:one', 'dewbud')],
    }));
    expect(started.done.map((row) => row.id).sort()).toEqual(['first-shrine', 'hatched-egg']);
    expect(started.open).toHaveLength(6);
    expect(started.summary).toBe('2/8 hedef tamamlandı');
    expect(started.done.every((row) => row.status === 'done' && row.percent === 100)).toBe(true);
  });
  it('shows each row with its own numbers and a readable percentage', () => {
    const view = objectivesPanelView(state({ unlockedRecipeIds: [STARTING_RECIPE_ID, BIOME_RECIPE.forest, BIOME_EXTRA_RECIPE.forest] }));
    const recipes = view.open.find((row) => row.id === 'all-recipes')!;
    expect(recipes.progressText).toBe('3/8 tarif');
    expect(recipes.percent).toBe(38);
    expect(recipes.hint.length).toBeGreaterThan(10);
    expect(BIOME_IDS).toHaveLength(8);
  });
});

describe('preferences', () => {
  it('starts from sane defaults and clamps anything stored', () => {
    expect(DEFAULT_PREFERENCES.volume).toBeGreaterThan(0);
    expect(DEFAULT_PREFERENCES.reducedMotion).toBe(false);
    expect(Object.keys(DEFAULT_PREFERENCES.keys).sort()).toEqual(ACTIONS.map((action) => action.id).sort());
    expect(normalizePreferences({ volume: 5 }).volume).toBe(1);
    expect(normalizePreferences({ volume: -3 }).volume).toBe(0);
    expect(normalizePreferences({ volume: Number.NaN }).volume).toBe(DEFAULT_PREFERENCES.volume);
    expect(normalizePreferences({ reducedMotion: 'yes' }).reducedMotion).toBe(false);
    expect(normalizePreferences(null)).toEqual(DEFAULT_PREFERENCES);
    expect(normalizePreferences({ keys: { up: 'Escape' } }).keys.up).toBe(DEFAULT_PREFERENCES.keys.up);
    // A duplicate binding would disable an action, so the later one falls back to its default.
    expect(normalizePreferences({ keys: { up: 'KeyW', down: 'KeyW' } }).keys.down).toBe(DEFAULT_PREFERENCES.keys.down);
  });
  it('survives a reload through the store it is given', () => {
    const store = new MemoryStore();
    expect(loadPreferences(store)).toEqual(DEFAULT_PREFERENCES);
    const wanted = { ...DEFAULT_PREFERENCES, volume: .25, reducedMotion: true };
    expect(savePreferences(wanted, store)).toBe(true);
    expect(store.getItem(PREFERENCES_KEY)).toContain('0.25');
    expect(loadPreferences(store)).toEqual(wanted);
  });
  it('never throws in a private window; it only stops persisting', () => {
    const blocked = new BlockedStore();
    expect(loadPreferences(blocked)).toEqual(DEFAULT_PREFERENCES);
    expect(savePreferences({ ...DEFAULT_PREFERENCES, volume: .1 }, blocked)).toBe(false);
    expect(loadPreferences(null)).toEqual(DEFAULT_PREFERENCES);
    expect(savePreferences(DEFAULT_PREFERENCES, null)).toBe(false);
    const broken = new MemoryStore();
    broken.setItem(PREFERENCES_KEY, '{not json');
    expect(loadPreferences(broken)).toEqual(DEFAULT_PREFERENCES);
  });
  it('rebinds a key, refuses a duplicate and refuses a reserved one', () => {
    const first = rebind(DEFAULT_PREFERENCES, 'up', 'ArrowUp');
    expect(first.error).toBeNull();
    expect(first.preferences.keys.up).toBe('ArrowUp');
    expect(first.preferences.keys.down).toBe(DEFAULT_PREFERENCES.keys.down);
    const clash = rebind(first.preferences, 'down', 'ArrowUp');
    expect(clash.error).toContain('İleri');
    expect(clash.preferences).toBe(first.preferences);
    for (const reserved of RESERVED_KEYS) {
      expect(rebind(DEFAULT_PREFERENCES, 'pause', reserved).error).toBe('Bu tuş kullanılamaz');
    }
    expect(rebind(DEFAULT_PREFERENCES, 'fly' as never, 'KeyF').error).toBe('Bilinmeyen eylem');
    expect(rebind(DEFAULT_PREFERENCES, 'up', '   ').error).toBe('Bu tuş kullanılamaz');
  });
});

describe('save slots and the screen before boot', () => {
  it('keeps three slots, the first on the original database', () => {
    expect(SLOT_IDS).toEqual(['a', 'b', 'c']);
    expect(dbNameFor('a')).toBe(BASE_DB_NAME);
    expect(new Set(SLOT_IDS.map(dbNameFor)).size).toBe(3);
    const records: SlotRecord[] = [
      { slot: 'a', status: 'ready', state: state({ creatures: [owned('c0', 'dewbud', 7)], worldTick: 60 * 60 * 5, shrines: [{ biomeId: 'sea', visitedTick: 2, chestTaken: true }] }) },
      { slot: 'b', status: 'corrupt', error: 'Kayıt içeriği geçersiz.' },
    ];
    const views = slotViews(records);
    expect(views.map((view) => view.status)).toEqual(['ready', 'corrupt', 'empty']);
    expect(views[0]).toMatchObject({ canContinue: true, canStart: false, canExport: true });
    expect(views[0].summary).toContain('en yüksek Sv 7');
    expect(views[0].summary).toContain('1/8 tapınak');
    expect(views[1]).toMatchObject({ canContinue: false, canStart: true, canExport: true, summary: 'Kayıt içeriği geçersiz.' });
    expect(views[2]).toMatchObject({ canContinue: false, canStart: true, canExport: false, summary: 'Boş — yeni oyun' });
  });
  it('offers retry, raw export and a fresh start when a record cannot be read', () => {
    expect(recoveryView(null).visible).toBe(false);
    const view = recoveryView('Kayıt içeriği geçersiz.');
    expect(view.visible).toBe(true);
    expect(view.actions.map((action) => action.id)).toEqual(['retry', 'export', 'new']);
    expect(view.message).toContain('silinmez');
    expect(view.message).toContain('Kayıt içeriği geçersiz.');
  });
  it('remembers the chosen slot without ever throwing', () => {
    const store = new MemoryStore();
    expect(rememberedSlot(store)).toBe('a');
    expect(rememberSlot('c', store)).toBe(true);
    expect(rememberedSlot(store)).toBe('c');
    store.setItem('muhur-vadisi:slot', 'zz');
    expect(rememberedSlot(store)).toBe('a');
    const blocked = { getItem() { throw new Error('nope'); }, setItem() { throw new Error('nope'); } };
    expect(rememberedSlot(blocked)).toBe('a');
    expect(rememberSlot('b', blocked)).toBe(false);
  });
});
