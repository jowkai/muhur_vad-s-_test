import { describe, expect, it } from 'vitest';
import { BIOME_IDS, PARTY_LIMIT, type PanelId } from '../../src/contracts';
import { creatures } from '../../src/content/catalog';
import { UI_CSS } from '../../src/ui/hud/hud-view';
import { BATTLE_CSS } from '../../src/ui/battle/battle-view';
import { PANEL_CSS } from '../../src/ui/inventory/panel-dialog';
import { ROLE_RULES } from '../../src/game/roles';
import { hudModel, hudSections, regionGateHint } from '../../src/ui/hud/model';
import { TABS, TAB_TARGET_PX, tabForKey, tabItems } from '../../src/ui/shell/tabs';
import { panelIntentForKey } from '../../src/ui/inventory/panel-dialog';
import { createWorld } from '../../src/world/generation/world';
import { createWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { stats } from '../../src/game/combat/core';

const world = createWorld();
const species = creatures[0];
const active = { id: 'friend', speciesId: species.id, level: 4, xp: 12, hp: 20, maxHp: stats({ id: 'friend', species, level: 4 }).maxHp };
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [{ itemId: 'seal', quantity: 1 }, null],
    unlockedRecipeIds: ['salve'], creatures: [active], creatureCapacity: 6, eggCapacity: 2, eggs: [],
    battle: null, loot: null, rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, activeCreatureId: active.id, party: [active.id], ...overrides };
}
const model = (overrides: Parameters<typeof hudModel>[1] = { biomeId: 'meadow', movementAllowed: true }) =>
  hudModel(state(), overrides);

describe('the left panel keeps only health and experience', () => {
  it('lists name, biome, HP and XP — and nothing else', () => {
    const sections = hudSections(model());
    expect(sections.map((section) => section.id)).toEqual(['identity', 'biome', 'hp', 'xp']);
    expect(sections[0].text).toContain(species.name);
    expect(sections[0].text).toContain('Sv 4');
    expect(sections[1].text).toContain('Şafak Çayırı');
    expect(sections[2].text).toBe(`20/${active.maxHp}`);
    expect(sections[3].text).toContain('XP');
    // The team and the egg counters moved out of the panel; the model still carries them.
    expect(sections.some((section) => section.text.includes('Takım'))).toBe(false);
    expect(sections.some((section) => section.text.includes('Yumurta'))).toBe(false);
    expect(model().team.max).toBe(6);
  });
  it('adds the warning line only while something is approaching, and marks low health', () => {
    // The ice shelf asks for a tank, and this team has none, so the region line appears too.
    const warned = hudSections(model({ biomeId: 'ice', movementAllowed: true, warningName: 'Kar Yumağı', warningSeconds: 1.5 }));
    expect(warned.map((section) => section.id)).toEqual(['identity', 'biome', 'hp', 'xp', 'gate', 'warning']);
    expect(warned.at(-1)).toMatchObject({ tone: 'alert' });
    expect(warned.at(-1)!.text).toContain('Kar Yumağı');
    const hurt = hudModel(state({ creatures: [{ ...active, hp: 3 }] }), { biomeId: 'meadow', movementAllowed: true });
    expect(hudSections(hurt).find((section) => section.id === 'hp')).toMatchObject({ tone: 'low' });
    const empty = hudModel(state({ creatures: [], party: [], activeCreatureId: null }), { biomeId: 'meadow', movementAllowed: true });
    expect(hudSections(empty)[0].text).toBe('Takım boş');
    expect(hudSections(empty).find((section) => section.id === 'hp')!.text).toBe('—');
  });
  it('names the role a region asks for, and stays quiet once the team carries it', () => {
    // The meadow gates nothing, so it never adds the line.
    const open = hudModel(state({}), { biomeId: 'meadow', movementAllowed: true });
    expect(open.gate).toBeNull();
    // The forest wants a clawed creature; without one the HUD says which role and which level.
    const barred = regionGateHint('forest', state({}));
    expect(barred).toContain(ROLE_RULES.claw.label);
    expect(barred).toContain(String(ROLE_RULES.claw.unlockLevel));
    // With a clawed creature old enough to use the role, the warning disappears.
    const clawed = creatures.find((species) => species.roles.includes('claw'))!;
    const ready = state({ creatures: [{ ...active, speciesId: clawed.id, level: ROLE_RULES.claw.unlockLevel }] });
    expect(regionGateHint('forest', ready)).toBeNull();
    // A fainted creature cannot open a region on the team's behalf.
    const downed = state({ creatures: [{ ...active, speciesId: clawed.id, level: ROLE_RULES.claw.unlockLevel, hp: 0 }] });
    expect(regionGateHint('forest', downed)).not.toBeNull();
  });
});

describe('the bottom-centre tab bar', () => {
  it('carries the five panels with their shortcuts', () => {
    expect(TABS.map((tab) => tab.id)).toEqual(['inventory', 'alchemy', 'camp', 'bestiary', 'objectives']);
    expect(TABS.map((tab) => tab.label)).toEqual(['Çanta', 'Simya', 'Kamp', 'Defter', 'Hedefler']);
    expect(TABS.map((tab) => tab.key)).toEqual(['i', 'c', 'k', 'b', 'o']);
    expect(new Set(TABS.map((tab) => tab.key)).size).toBe(TABS.length);
    for (const tab of TABS) expect(tab.hint.length).toBeGreaterThan(5);
  });
  it('marks the open tab and publishes one intent per tab', () => {
    const closed = tabItems({ open: null });
    expect(closed.every((item) => !item.active && item.enabled)).toBe(true);
    expect(closed.map((item) => item.intent)).toEqual(TABS.map((tab) => ({ type: 'open-panel', panel: tab.id })));
    const open = tabItems({ open: 'alchemy' });
    expect(open.filter((item) => item.active).map((item) => item.id)).toEqual(['alchemy']);
    expect(open.map((item) => item.shortcut)).toEqual(['I', 'C', 'K', 'B', 'O']);
  });
  it('greys out while a battle owns the input, and while a panel is not built yet', () => {
    expect(tabItems({ open: null, locked: true }).every((item) => !item.enabled)).toBe(true);
    const partial = tabItems({ open: null, unavailable: ['objectives'] as PanelId[] });
    expect(partial.filter((item) => !item.enabled).map((item) => item.id)).toEqual(['objectives']);
  });
  it('shares one shortcut table with the keyboard', () => {
    for (const tab of TABS) {
      expect(tabForKey(tab.key)?.id).toBe(tab.id);
      expect(tabForKey(tab.key.toUpperCase())?.id).toBe(tab.id);
      expect(panelIntentForKey(tab.key, 'world', null)).toEqual({ type: 'open-panel', panel: tab.id });
    }
    expect(tabForKey('q')).toBeNull();
    // Escape still closes, a battle still swallows the keys, and an open panel blocks a second one.
    expect(panelIntentForKey('Escape', 'panel', 'camp')).toEqual({ type: 'close-panel' });
    expect(panelIntentForKey('Escape', 'world', null)).toBeNull();
    expect(panelIntentForKey('i', 'battle', null)).toBeNull();
    expect(panelIntentForKey('i', 'panel', 'camp')).toBeNull();
  });
});

describe('the dock fits both widths', () => {
  it('keeps 44 px targets and never lets the bar overflow the viewport', () => {
    expect(TAB_TARGET_PX).toBe(44);
    expect(UI_CSS).toMatch(/\.mv-tabbar button\{[^}]*min-height:44px/);
    expect(UI_CSS).toMatch(/\.mv-tabbar button\{[^}]*min-width:44px/);
    // Bottom centre, above the world, and never wider than the window.
    expect(UI_CSS).toMatch(/\.mv-dock\{[^}]*left:50%/);
    expect(UI_CSS).toMatch(/\.mv-dock\{[^}]*bottom:16px/);
    expect(UI_CSS).toMatch(/\.mv-dock\{[^}]*max-width:calc\(100vw - 32px\)/);
    expect(UI_CSS).toMatch(/\.mv-tabbar\{[^}]*max-width:100%/);
    expect(UI_CSS).toMatch(/\.mv-hud\{[^}]*max-width:calc\(100vw - 32px\)/);
    // The health panel sits under the profile card instead of on top of it.
    expect(UI_CSS).toMatch(/\.mv-hud\{[^}]*top:172px/);
  });
  it('has a narrow-screen rule that puts the bar on one row', () => {
    const narrow = UI_CSS.slice(UI_CSS.indexOf('@media (max-width:640px)'));
    expect(narrow).toContain('.mv-dock{');
    expect(narrow).toMatch(/\.mv-tabbar\{[^}]*width:100%/);
    expect(narrow).toMatch(/\.mv-tabbar button\{[^}]*padding:0 8px/);
    expect(narrow).toContain('.mv-tab-key{display:none}');
    // The minimap steps out of the dock's way; the card follows the dock's measured height on
    // every width, so the narrow rule only widens it.
    expect(narrow).toMatch(/\.mv-minimap\{[^}]*bottom:236px/);
    expect(narrow).toMatch(/\.mv-card\{[^}]*width:auto/);
    expect(narrow).not.toMatch(/\.mv-card\{[^}]*bottom:/);
    expect(UI_CSS).toMatch(/\.mv-card\{[^}]*bottom:calc\(var\(--mv-dock-height/);
    // And the dock sits above the card, so a card near the bottom never eats a tab click.
    expect(UI_CSS).toMatch(/\.mv-dock\{[^}]*z-index:2/);
    expect(UI_CSS).toMatch(/\.mv-card\{z-index:1\}/);
    // And the panels and the battle sit above the dock, so an open panel keeps every row clickable.
    expect(PANEL_CSS).toMatch(/\.mv-panel\{[^}]*z-index:5/);
    expect(BATTLE_CSS).toMatch(/\.mv-battle\{[^}]*z-index:6/);
  });
  it('leaves the panel dialogs and the biome list untouched', () => {
    expect(BIOME_IDS).toHaveLength(8);
    expect(PARTY_LIMIT).toBe(6);
    expect(UI_CSS).not.toContain('.mv-counters');
    expect(UI_CSS).not.toContain('.mv-hud-controls');
  });
});
