import { describe, expect, it } from 'vitest';
import { creatures, recipes } from '../../src/content/catalog';
import { BIOME_IDS } from '../../src/contracts';
import { BIOME_RECIPE, STARTING_RECIPE_ID, recipeForSecret, secretIdFor, recipesForBiome } from '../../src/content/secrets';
import { creatureAssets, itemAssets } from '../../src/content/asset-manifest';
import { stats } from '../../src/game/combat/core';
import { xpRequired } from '../../src/game/progression';
import { createWorld } from '../../src/world/generation/world';
import { createWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { rewardSnapshot, rewardView } from '../../src/ui/battle/reward';
import { GameAudio, MUTE_STORAGE_KEY } from '../../src/ui/audio';

const world = createWorld();
const species = creatures[0];
const maxHp = stats({ id: 'friend', species, level: 2 }).maxHp;
function state(overrides: Partial<WorldState> = {}): WorldState {
  return {
    ...createWorldState(world, {
      mode: 'exploring', atCamp: false, inventory: [{ itemId: 'seal', quantity: 2 }, null, null, null], unlockedRecipeIds: [],
      creatures: [{ id: 'friend', speciesId: species.id, level: 2, xp: 0, hp: maxHp, maxHp }],
      creatureCapacity: 6, eggCapacity: 2, eggs: [], battle: null, loot: null,
      rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
    }), activeCreatureId: 'friend', ...overrides,
  };
}

describe('reward summary', () => {
  it('reports only what changed between the two committed snapshots', () => {
    const before = rewardSnapshot(state());
    const after = state({
      creatures: [{ id: 'friend', speciesId: species.id, level: 2, xp: 16, hp: maxHp, maxHp }],
      inventory: [{ itemId: 'seal', quantity: 2 }, { itemId: 'dew_leaf', quantity: 1 }, null, null],
      secretFlags: ['secret:meadow'],
    });
    const summary = rewardView(before, rewardSnapshot(after), 'won', after);
    expect(summary.title).toBe('Zafer');
    expect(summary.empty).toBe(false);
    expect(summary.lines[0]).toMatchObject({ label: '16 XP' });
    expect(summary.lines[0].iconUrl).toBe(creatureAssets[species.id as keyof typeof creatureAssets].front);
    expect(summary.lines.some((line) => line.label === 'Çiy Yaprağı ×1')).toBe(true);
    expect(summary.lines.find((line) => line.label === 'Çiy Yaprağı ×1')!.iconUrl).toBe(itemAssets.dew_leaf);
    expect(summary.lines.some((line) => line.label === 'Bir sır keşfedildi')).toBe(true);
  });
  it('counts experience across a level up and names the captured creature', () => {
    const before = rewardSnapshot(state({ creatures: [{ id: 'friend', speciesId: species.id, level: 2, xp: xpRequired(2) - 4, hp: maxHp, maxHp }] }));
    const captured = state({
      creatures: [
        { id: 'friend', speciesId: species.id, level: 3, xp: 9, hp: maxHp, maxHp },
        { id: 'capture:wild-1', speciesId: creatures[1].id, level: 4, xp: 0, hp: 5, maxHp: 40 },
      ],
    });
    const summary = rewardView(before, rewardSnapshot(captured), 'captured', captured);
    expect(summary.title).toBe('Mühürlendi');
    expect(summary.lines[0].label).toBe('13 XP');
    expect(summary.lines[0].detail).toContain('seviye 3');
    const gained = summary.lines.find((line) => line.detail.includes('koleksiyona katıldı'))!;
    expect(gained.label).toBe(creatures[1].name);
    expect(gained.detail).toContain('Seviye 4');
  });
  it('stays empty for a flight and mentions the delivery box when the bag was full', () => {
    const before = rewardSnapshot(state());
    const fled = rewardView(before, rewardSnapshot(state()), 'fled', state());
    expect(fled).toMatchObject({ title: 'Kaçtın', empty: true });
    expect(fled.lines).toEqual([]);
    const overflow = state({ deliveryBox: [{ kind: 'item', itemId: 'dew_leaf', quantity: 1 }] });
    const summary = rewardView(before, rewardSnapshot(overflow), 'won', overflow);
    expect(summary.lines.some((line) => line.label.includes('teslim kutusunda'))).toBe(true);
  });
});

describe('procedural audio', () => {
  const storage = () => {
    const map = new Map<string, string>();
    return { getItem: (key: string) => map.get(key) ?? null, setItem: (key: string, value: string) => { map.set(key, value); },
      removeItem: (key: string) => { map.delete(key); }, clear: () => map.clear(), key: () => null, length: 0 } as Storage;
  };
  it('stays silent until unlocked and remembers the mute preference', () => {
    const store = storage();
    let created = 0;
    const audio = new GameAudio({ storage: store, context: () => { created++; throw new Error('no audio in node'); } });
    expect(audio.muted).toBe(false);
    expect(audio.started).toBe(false);
    audio.play('collect');
    expect(created).toBe(0);
    audio.unlock();
    expect(created).toBe(1);
    expect(audio.started).toBe(false);
    expect(audio.toggle()).toBe(true);
    expect(store.getItem(MUTE_STORAGE_KEY)).toBe('1');
    expect(new GameAudio({ storage: store }).muted).toBe(true);
    audio.unlock();
    expect(created).toBe(1);
    audio.setMuted(false);
    expect(store.getItem(MUTE_STORAGE_KEY)).toBe('0');
    audio.dispose();
  });
  it('survives storage that throws and never starts while muted', () => {
    const hostile = { getItem: () => { throw new Error('blocked'); }, setItem: () => { throw new Error('blocked'); } } as unknown as Storage;
    const audio = new GameAudio({ storage: hostile, context: () => { throw new Error('unused'); } });
    expect(audio.muted).toBe(false);
    expect(() => audio.setMuted(true)).not.toThrow();
    expect(audio.muted).toBe(true);
    audio.unlock();
    expect(audio.started).toBe(false);
    audio.dispose();
  });
});

describe('region secrets teach recipes', () => {
  it('maps every biome to its own recipe and recognises only region marks', () => {
    const recipeIds = BIOME_IDS.flatMap((biomeId) => [...recipesForBiome(biomeId)]);
    expect(new Set(recipeIds).size).toBe(16);
    expect(recipeIds.every((id) => recipes.some((recipe) => recipe.id === id))).toBe(true);
    // Sixteen of the forty recipes are the shrine book; the rest are found by crafting.
    expect(recipeIds.length).toBeLessThan(recipes.length);
    expect(recipes.length).toBe(88);
    expect(BIOME_IDS.map((biomeId) => BIOME_RECIPE[biomeId])).toHaveLength(8);
    expect(STARTING_RECIPE_ID).toBe(BIOME_RECIPE.meadow);
    expect(secretIdFor('flame')).toBe('secret:flame');
    expect(recipeForSecret('secret:flame')).toBe(BIOME_RECIPE.flame);
    expect(recipeForSecret('secret:yok')).toBeNull();
    expect(recipeForSecret('başka:flame')).toBeNull();
    expect(() => secretIdFor('yok' as never)).toThrow(RangeError);
  });
  it('shows a newly taught recipe in the result window exactly once', () => {
    const before = rewardSnapshot(state({ unlockedRecipeIds: [STARTING_RECIPE_ID] }));
    const after = state({ unlockedRecipeIds: [STARTING_RECIPE_ID, BIOME_RECIPE.forest], secretFlags: ['secret:forest'] });
    const summary = rewardView(before, rewardSnapshot(after), 'won', after);
    const taught = summary.lines.filter((line) => line.label.startsWith('Yeni tarif'));
    expect(taught).toHaveLength(1);
    expect(taught[0].label).toBe('Yeni tarif: Koru Balsamı');
    expect(taught[0].detail).toBe('Simya defterine işlendi');
    expect(summary.lines.some((line) => line.label === 'Bir sır keşfedildi')).toBe(true);
    const repeat = rewardView(rewardSnapshot(after), rewardSnapshot(after), 'won', after);
    expect(repeat.lines.some((line) => line.label.startsWith('Yeni tarif'))).toBe(false);
  });
});
