import { describe, expect, it } from 'vitest';
import { creatures } from '../../src/content/catalog';
import { creatureAssets } from '../../src/content/asset-manifest';
import { commandOwner } from '../../src/contracts/command-bus';
import { beginBattle, createBattle, stats } from '../../src/game/combat/core';
import { createLootPlan } from '../../src/game/combat/rewards';
import { createWorld } from '../../src/world/generation/world';
import { createWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { bestiaryView } from '../../src/ui/bestiary/model';
import { BIOME_RECIPE, secretIdFor } from '../../src/content/secrets';
import { panelIntentForKey } from '../../src/ui/inventory/panel-dialog';

const world = createWorld();
const species = creatures[0];
const other = creatures[1];
const maxHp = stats({ id: 'friend', species, level: 2 }).maxHp;
const owned = (id: string, speciesId: string, level: number, hp: number) => ({ id, speciesId, level, xp: 0, hp, maxHp: stats({ id, species: creatures.find((entry) => entry.id === speciesId)!, level }).maxHp });
function state(overrides: Partial<WorldState> = {}): WorldState {
  return {
    ...createWorldState(world, {
      mode: 'panel', atCamp: true, inventory: [null, null], unlockedRecipeIds: [],
      creatures: [owned('friend', species.id, 2, maxHp)],
      creatureCapacity: 60, eggCapacity: 2, eggs: [], battle: null, loot: null,
      rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
    }), activeCreatureId: 'friend', ...overrides,
  };
}

describe('bestiary journal', () => {
  it('lists the collection with origin, level and the active marker', () => {
    const view = bestiaryView(state({
      creatures: [owned('friend', species.id, 2, maxHp), owned('capture:wild-1', other.id, 5, 12), owned('egg:egg1', species.id, 1, 0)],
    }));
    expect(view.owned).toHaveLength(3);
    expect(view.owned[0]).toMatchObject({ name: species.name, level: 2, active: true, origin: 'başlangıç', canActivate: false, reason: 'Zaten aktif' });
    expect(view.owned[1]).toMatchObject({ name: other.name, level: 5, active: false, origin: 'mühürlendi', canActivate: true, reason: null });
    expect(view.owned[2]).toMatchObject({ origin: 'yumurtadan', fainted: true, canActivate: true });
    expect(view.owned[2].reason).toContain('Baygın');
    expect(view.owned[1].spriteUrl).toBe(creatureAssets[other.id as keyof typeof creatureAssets].front);
    expect(view.owned[1].intent).toEqual({ type: 'set-active', creatureId: 'capture:wild-1' });
    expect(view.capacity).toBe('3/60');
  });
  it('hides every species the save has no record of', () => {
    const view = bestiaryView(state());
    expect(view.totalSpecies).toBe(creatures.length);
    expect(view.knownCount).toBe(1);
    const known = view.species.find((entry) => entry.speciesId === species.id)!;
    expect(known).toMatchObject({ known: true, name: species.name, owned: 1, note: '1 kayıt' });
    expect(known.element).toBe(species.element);
    const unknown = view.species.find((entry) => entry.speciesId === other.id)!;
    expect(unknown).toMatchObject({ known: false, name: '???', owned: 0, element: null, rarity: null, spriteUrl: null });
    expect(unknown.note).toBe('Henüz mühürlenmedi');
    // The biome is a map hint, not a spoiler: it never names the creature.
    expect(unknown.biome).not.toContain(other.name);
    expect(view.summary).toContain(`1/${creatures.length}`);
  });
  it('refuses to swap the active creature while a battle is unresolved', () => {
    const player = { id: 'friend', species, level: 2 };
    const enemy = { id: 'wild', species: other, level: 2 };
    const battle = beginBattle(createBattle({ battleId: 'b', encounterId: 'wild-1', seed: 5, player, enemy, inventorySnapshot: {}, captureCapacity: 1 }));
    const fighting = state({ mode: 'battle', battle, loot: createLootPlan('b', enemy, false) });
    const view = bestiaryView(fighting);
    expect(view.locked).toBe('Savaş sürerken aktif yaratık değiştirilemez');
    expect(view.owned.every((entry) => !entry.canActivate)).toBe(true);
    expect(bestiaryView(state()).locked).toBeNull();
  });
  it('routes B to the journal and keeps the swap intent on the panel owner', () => {
    expect(panelIntentForKey('b', 'world', null)).toEqual({ type: 'open-panel', panel: 'bestiary' });
    expect(panelIntentForKey('B', 'world', null)).toEqual({ type: 'open-panel', panel: 'bestiary' });
    expect(panelIntentForKey('b', 'battle', null)).toBeNull();
    expect(panelIntentForKey('b', 'panel', 'bestiary')).toBeNull();
    expect(commandOwner({ type: 'set-active', creatureId: 'friend', commandId: 'a', tick: 1 })).toBe('panel');
  });
});

describe('journal secrets and trophies', () => {
  it('counts region secrets, recipes and essence trophies without spoiling unknown regions', () => {
    const view = bestiaryView(state({
      secretFlags: [secretIdFor('meadow'), secretIdFor('flame')],
      unlockedRecipeIds: [BIOME_RECIPE.meadow, BIOME_RECIPE.flame],
      deliveryBox: [{ kind: 'essence', element: 'kor', quantity: 2 }, { kind: 'essence', element: 'çim', quantity: 1 }, { kind: 'item', itemId: 'dew_leaf', quantity: 1 }],
    }));
    expect(view.secrets).toMatchObject({ known: 2, total: 8 });
    expect(view.secrets.regions).toEqual(['Şafak Çayırı', 'Kor Çanağı']);
    expect(view.trophies).toEqual([{ label: 'kor esansı', count: 2 }, { label: 'çim esansı', count: 1 }].sort((a, b) => a.label < b.label ? -1 : 1));
    expect(view.summary).toContain('2/8 bölge sırrı');
    expect(view.summary).toContain('2/8 tarif');
    const fresh = bestiaryView(state());
    expect(fresh.secrets).toMatchObject({ known: 0, regions: [] });
    expect(fresh.trophies).toEqual([]);
  });
});
