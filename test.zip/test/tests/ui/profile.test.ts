import { afterEach, describe, expect, it } from 'vitest';
import { DEFAULT_PLAYER_NAME, PLAYER_NAME_LIMIT } from '../../src/contracts';
import { GAME_CONFIG } from '../../src/config';
import { creatureById, creatures } from '../../src/content/catalog';
import { stats } from '../../src/game/combat/core';
import { PROFILE_CSS } from '../../src/ui/profile/profile-card';
import { TITLES, normalizeName, playtimeText, profileView, renameRefusal, titleFor } from '../../src/ui/profile/model';
import { UI_CSS } from '../../src/ui/hud/hud-view';
import { createWorld } from '../../src/world/generation/world';
import { createWorldState, validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { GameSession, newGame } from '../../src/app/session';
import { IndexedDbSave } from '../../src/game/save/indexeddb';

const world = createWorld();
const owned = (id: string, speciesId: string, level = 4) => {
  const species = creatureById(speciesId)!;
  const maxHp = stats({ id, species, level }).maxHp;
  return { id, speciesId, level, xp: 0, hp: maxHp, maxHp };
};
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: true, inventory: [{ itemId: 'seal', quantity: 1 }, null],
    unlockedRecipeIds: ['salve'], creatures: [owned('a', creatures[0].id)], creatureCapacity: 60,
    eggCapacity: 4, eggs: [], battle: null, loot: null,
    rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, activeCreatureId: 'a', party: ['a'], ...overrides };
}
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });
async function session(overrides: Partial<WorldState> = {}) {
  const save = await IndexedDbSave.open<WorldState>({
    name: `profile-${counter++}`, initial: () => ({ ...newGame(world), ...overrides }),
    validate: (value) => validateWorldState(world, value),
  });
  opened.push(save);
  return GameSession.open({ world, save, sessionId: `p${counter}` });
}

describe('the profile card', () => {
  it('shows the name, the earned title and the tally', () => {
    const view = profileView(state());
    expect(view.name).toBe(DEFAULT_PLAYER_NAME);
    expect(view.title).toBe(TITLES[0].title);
    expect(view.rank).toBe(0);
    expect(view.stats.map((stat) => stat.id)).toEqual(['species', 'creatures', 'level', 'shrines', 'time']);
    expect(view.stats.find((stat) => stat.id === 'species')!.value).toBe(`1/${creatures.length}`);
    expect(view.stats.find((stat) => stat.id === 'shrines')!.value).toBe('0/8');
    expect(view.progress).toBe(0);
    expect(view.progressText).toBe('Hedefler %0');
    expect(view.nameLimit).toBe(PLAYER_NAME_LIMIT);
  });
  it('earns a better title as the valley opens', () => {
    expect(titleFor(state()).rank).toBe(0);
    const explorer = state({
      creatures: [owned('a', creatures[0].id), owned('b', creatures[1].id), owned('c', creatures[2].id)],
      party: ['a', 'b', 'c'],
    });
    expect(titleFor(explorer).rank).toBeGreaterThan(0);
    const master = state({
      shrines: ['meadow', 'forest', 'earth', 'desert', 'sea', 'ice', 'volcanic', 'flame']
        .map((biomeId) => ({ biomeId, visitedTick: 1, chestTaken: true })) as WorldState['shrines'],
      creatures: [owned('a', creatures[0].id, 30)],
      unlockedRecipeIds: Array.from({ length: 8 }, (_, index) => ['salve', 'seal', 'egg_feed', 'forest_balm', 'tide_balm', 'waking_salt', 'ember_incense', 'resonant_balm'][index]),
    });
    expect(titleFor(master).title).toBe('Vadi Ustası');
    // Titles only ever go up as the record grows.
    expect(titleFor(master).rank).toBeGreaterThan(titleFor(explorer).rank);
  });
  it('reads the clock in minutes and hours', () => {
    expect(playtimeText(0)).toBe('0 dk');
    expect(playtimeText(Math.round(90 / GAME_CONFIG.fixedStep))).toBe('1 dk');
    expect(playtimeText(Math.round(3900 / GAME_CONFIG.fixedStep))).toBe('1 sa 5 dk');
  });
  it('refuses an empty, an overlong and a control-character name', () => {
    expect(renameRefusal('Murat')).toBeNull();
    expect(renameRefusal('  Murat  ')).toBeNull();
    expect(normalizeName('  Murat  ')).toBe('Murat');
    expect(renameRefusal('')).toBe('Bir ad yaz');
    expect(renameRefusal('   ')).toBe('Bir ad yaz');
    expect(renameRefusal('x'.repeat(PLAYER_NAME_LIMIT + 1))).toContain(String(PLAYER_NAME_LIMIT));
    expect(renameRefusal('kötü\u0000ad')).toBe('Bu ad kullanılamaz');
    expect(normalizeName('y'.repeat(60)).length).toBe(PLAYER_NAME_LIMIT);
  });
  it('falls back to the default when the record holds nonsense', () => {
    expect(profileView({ ...state(), playerName: '' } as WorldState).name).toBe(DEFAULT_PLAYER_NAME);
    expect(profileView({ ...state(), playerName: 'Murat' }).name).toBe('Murat');
  });
});

describe('renaming through the domain', () => {
  it('writes the name once and keeps it after a reload', async () => {
    const live = await session();
    expect(live.state.playerName).toBe(DEFAULT_PLAYER_NAME);
    await live.dispatch({ type: 'rename', name: '  Ay Bahçıvanı  ' });
    expect(live.state.playerName).toBe('Ay Bahçıvanı');
    expect(profileView(live.state).name).toBe('Ay Bahçıvanı');
    // A refused name never reaches the record.
    await expect(live.dispatch({ type: 'rename', name: '   ' })).rejects.toThrow();
    expect(live.state.playerName).toBe('Ay Bahçıvanı');
  });
});

describe('the card on screen', () => {
  it('sits in the corner above the health panel and stays inside the viewport', () => {
    expect(PROFILE_CSS).toMatch(/\.mv-profile\{[^}]*top:16px/);
    expect(PROFILE_CSS).toMatch(/\.mv-profile\{[^}]*left:16px/);
    expect(PROFILE_CSS).toMatch(/\.mv-profile\{[^}]*max-width:calc\(100vw - 32px\)/);
    // The health panel moved down, so the two never overlap.
    expect(UI_CSS).toMatch(/\.mv-hud\{[^}]*top:172px/);
    const narrow = PROFILE_CSS.slice(PROFILE_CSS.indexOf('@media (max-width:640px)'));
    expect(narrow).toContain('.mv-profile{');
    expect(PROFILE_CSS).toContain('.mv-profile-name:focus-visible');
  });
});
