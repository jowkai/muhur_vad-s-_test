import { describe, expect, it } from 'vitest';
import { BIOME_IDS, type NearbyTarget } from '../../src/contracts';
import { GAME_CONFIG } from '../../src/config';
import { creatures } from '../../src/content/catalog';
import { creatureAssets, eggAssets, itemAssets } from '../../src/content/asset-manifest';
import { stats } from '../../src/game/combat/core';
import { xpRequired } from '../../src/game/progression';
import { createWorld } from '../../src/world/generation/world';
import { Discovery } from '../../src/world/discovery/discovery';
import { TargetIndex, type WorldTarget } from '../../src/world/encounters/targets';
import { createWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { BIOME_LABEL, biomeLabel } from '../../src/ui/hud/labels';
import { buildMinimap, minimapViewport, project, MINIMAP_RADIUS_METRES } from '../../src/ui/minimap/model';
import { encounterCard } from '../../src/ui/encounter/card';
import { hudModel } from '../../src/ui/hud/model';

const world = createWorld();
const player = world.camp;
const species = creatures[0];
const target = (id: string, dx: number, dz: number, overrides: Partial<WorldTarget> = {}): WorldTarget => ({
  entityId: id, kind: 'creature', name: species.name, spriteId: species.id, level: 3, aggressive: false,
  position: { x: player.x + dx, z: player.z + dz }, ...overrides,
});
function populated(targets: readonly WorldTarget[]) {
  const index = new TargetIndex();
  for (const entry of targets) index.upsert(entry);
  const discovery = new Discovery();
  discovery.reveal(player, 'exploring');
  return { index, discovery };
}
const view = (targets: readonly WorldTarget[], options: Partial<Parameters<typeof buildMinimap>[0]> = {}) => {
  const { index, discovery } = populated(targets);
  return buildMinimap({ index, discovery, player, yaw: 0, biomeId: 'meadow', viewportWidth: 1280, ...options });
};

describe('minimap viewport and projection', () => {
  it('uses a 192 px dial above 1280 px and 144 px below it, with a 16 px safe margin', () => {
    expect(minimapViewport(1280)).toMatchObject({ size: 192, center: 96, radius: 96, margin: 16 });
    expect(minimapViewport(1279)).toMatchObject({ size: 144, center: 72, radius: 72, margin: 16 });
    expect(minimapViewport(1920).scale).toBeCloseTo(1, 12);
    expect(minimapViewport(1024).scale).toBeCloseTo(0.75, 12);
    expect(() => minimapViewport(0)).toThrow(RangeError);
  });
  it('keeps north up and maps the four cardinal directions within 1 px', () => {
    for (const [name, offset, expected] of [
      ['kuzey', { x: 0, z: -48 }, { x: 96, y: 48 }],
      ['güney', { x: 0, z: 48 }, { x: 96, y: 144 }],
      ['doğu', { x: 48, z: 0 }, { x: 144, y: 96 }],
      ['batı', { x: -48, z: 0 }, { x: 48, y: 96 }],
      ['kuzeydoğu', { x: 33.94, z: -33.94 }, { x: 129.94, y: 62.06 }],
    ] as const) {
      const point = project({ x: player.x + offset.x, z: player.z + offset.z }, player, minimapViewport(1280));
      expect(Math.abs(point.x - expected.x), name).toBeLessThanOrEqual(1);
      expect(Math.abs(point.y - expected.y), name).toBeLessThanOrEqual(1);
      expect(point.visible).toBe(true);
    }
    const edge = project({ x: player.x + MINIMAP_RADIUS_METRES, z: player.z }, player, minimapViewport(1280));
    expect(edge).toMatchObject({ x: 192, y: 96, visible: true });
    expect(project({ x: player.x + MINIMAP_RADIUS_METRES + 0.01, z: player.z }, player, minimapViewport(1280)).visible).toBe(false);
    expect(minimapViewport(1280).scale * MINIMAP_RADIUS_METRES).toBe(96);
  });
  it('clips beyond the dial, hides undiscovered targets and shows detected ones', () => {
    const near = view([target('a', 6, 0), target('far', 0, GAME_CONFIG.proximityRadius + 1)]);
    expect(near.markers.map((marker) => marker.entityId)).toEqual(['a']);
    for (const marker of near.markers) {
      expect(Math.hypot(marker.x - near.viewport.center, marker.y - near.viewport.center)).toBeLessThanOrEqual(near.viewport.radius);
    }
    const { index } = populated([target('a', 6, 0)]);
    const dark = buildMinimap({ index, discovery: new Discovery(), player, yaw: 0, biomeId: 'meadow', viewportWidth: 1280 });
    expect(dark.markers).toEqual([]);
    expect(dark.selectedLabel).toBeNull();
  });
  it('gives each marker kind its own shape and marks the hostile and selected ones', () => {
    const built = view([
      target('creature', 4, 0), target('egg', -4, 0, { kind: 'egg', level: 1 }),
      target('resource', 0, 4, { kind: 'resource', level: 0, spriteId: 'dew_leaf', name: 'Çiy Yaprağı' }),
      target('hostile', 0, -4, { aggressive: true }),
    ], { selectedId: 'egg', secrets: [{ x: player.x + 3, z: player.z + 3 }] });
    const shapes = Object.fromEntries(built.markers.map((marker) => [marker.entityId, marker.shape]));
    expect(shapes).toMatchObject({ creature: 'claw', egg: 'oval', resource: 'diamond', hostile: 'hostile-claw' });
    expect(built.markers.some((marker) => marker.shape === 'star')).toBe(true);
    expect(built.markers.map((marker) => marker.entityId)).toEqual([...built.markers].map((marker) => marker.entityId).sort());
    expect(built.selectedLabel).toBe(species.name);
    expect(built.player).toMatchObject({ x: 96, y: 96, yaw: 0 });
    expect(built.northAngle).toBe(0);
    expect(built.biome.label).toBe('Şafak Çayırı');
    expect(built.markers.find((marker) => marker.entityId === 'creature')!.distance).toBeCloseTo(4, 6);
  });
  it('labels all eight biomes and rejects an unknown one', () => {
    expect(BIOME_IDS.map(biomeLabel)).toHaveLength(8);
    expect(new Set(BIOME_IDS.map(biomeLabel)).size).toBe(8);
    expect(BIOME_LABEL.flame).toBe('Kor Çanağı');
    expect(() => biomeLabel('yok' as never)).toThrow(RangeError);
  });
});

describe('encounter card model', () => {
  const nearby = (overrides: Partial<NearbyTarget> = {}): NearbyTarget => ({
    entityId: 'e1', kind: 'creature', name: species.name, spriteId: species.id,
    distance: 4, level: 5, interactionAllowed: true, ...overrides,
  });
  const context = { eggSlotsLeft: 1, creatureSlotsLeft: 1, hasHealthyCreature: true, inventoryFull: false };
  it('shows the original SVG, name, level, element and the Enter affordance', () => {
    const card = encounterCard(nearby(), context)!;
    expect(card).toMatchObject({ name: species.name, level: 5, element: species.element, hint: 'Enter: Savaş', enabled: true, spriteSize: 128 });
    expect(card.spriteUrl).toBe(creatureAssets[species.id as keyof typeof creatureAssets].front);
    expect(card.intent).toEqual({ type: 'interact', entityId: 'e1' });
    expect(card.biomeLabel).toBe('Şafak Çayırı');
    expect(encounterCard(null, context)).toBeNull();
  });
  it('separates collecting from battling and explains every disabled state', () => {
    const egg = encounterCard(nearby({ kind: 'egg', spriteId: 'egg_forest', name: 'Yosunçan Yumurtası', level: 1 }), context)!;
    expect(egg).toMatchObject({ hint: 'Enter: Topla', enabled: true, element: null, biomeLabel: 'Fısıltı Ormanı' });
    expect(egg.spriteUrl).toBe(eggAssets.forest);
    const fullEgg = encounterCard(nearby({ kind: 'egg', spriteId: 'egg_meadow' }), { ...context, eggSlotsLeft: 0 })!;
    expect(fullEgg).toMatchObject({ enabled: false, disabledReason: 'Kuluçka yuvası dolu', hint: 'Enter: Topla · Kuluçka yuvası dolu' });
    const resource = encounterCard(nearby({ kind: 'resource', spriteId: 'dew_leaf', name: 'Çiy Yaprağı', level: 0 }), { ...context, inventoryFull: true })!;
    expect(resource).toMatchObject({ level: null, enabled: false, disabledReason: 'Çanta dolu' });
    expect(resource.spriteUrl).toBe(itemAssets.dew_leaf);
    expect(encounterCard(nearby(), { ...context, hasHealthyCreature: false })!.disabledReason).toBe('Ayakta yaratığın yok');
    expect(encounterCard(nearby({ interactionAllowed: false }), context)!).toMatchObject({ enabled: false, disabledReason: 'Yaklaş' });
    expect(encounterCard(nearby(), { ...context, aggressive: true })!.behaviour).toBe('Saldırgan');
  });
});

describe('hud model', () => {
  const maxHp = stats({ id: 'friend', species, level: 2 }).maxHp;
  const base = (overrides: Partial<WorldState> = {}): WorldState => ({
    ...createWorldState(world, {
      mode: 'exploring', atCamp: true, inventory: [null], unlockedRecipeIds: [],
      creatures: [{ id: 'friend', speciesId: species.id, level: 2, xp: 12, hp: 20, maxHp }],
      creatureCapacity: 3, eggCapacity: 2, eggs: [], battle: null, loot: null,
      rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
    }), ...overrides,
  });
  it('projects hp, xp, counters and the mode without touching the record', () => {
    const state = base();
    const model = hudModel(state, { biomeId: 'meadow', movementAllowed: true });
    expect(model.active).toMatchObject({ name: species.name, level: 2 });
    expect(model.active!.hp).toMatchObject({ value: 20, max: maxHp, text: `20/${maxHp}` });
    expect(model.active!.hp.ratio).toBeCloseTo(20 / maxHp, 12);
    expect(model.active!.xp).toMatchObject({ value: 12, max: xpRequired(2) });
    expect(model.team.text).toBe('1/3');
    expect(model.eggs.text).toBe('0/2');
    expect(model.modeLabel).toBe('Keşif');
    expect(model.warning).toBeNull();
    expect(state).toEqual(base());
  });
  it('reports pause, hostile warning and a locked world after a failed save', () => {
    const paused = hudModel(base(), { biomeId: 'ice', paused: true, movementAllowed: false, warningName: 'Karçile', warningSeconds: 0.8 });
    expect(paused.biome.label).toBe('Akbuz Yaylası');
    expect(paused.warning).toBe('Karçile yaklaşıyor · 0.8 sn');
    expect(paused.movementAllowed).toBe(false);
    const empty = hudModel(base({ creatures: [], activeCreatureId: null }), { biomeId: 'meadow', movementAllowed: true });
    expect(empty.active).toBeNull();
    expect(empty.team.text).toBe('0/3');
    const capped = hudModel(base({ creatures: [{ id: 'friend', speciesId: species.id, level: 30, xp: 5, hp: 1, maxHp: stats({ id: 'friend', species, level: 30 }).maxHp }] }), { biomeId: 'meadow', movementAllowed: true });
    expect(capped.active!.xp.ratio).toBeLessThanOrEqual(1);
    expect(capped.active!.hp.ratio).toBeLessThan(0.35);
  });
});
