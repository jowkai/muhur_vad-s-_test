import { describe, expect, it } from 'vitest';
import { creatureById } from '../../src/content/catalog';
import { stats } from '../../src/game/combat/core';
import { ROLE_RULES } from '../../src/game/roles';
import {
  MIN_CONTRAST, TARGET_PX, THEME, THEME_CSS, THEME_STYLE_ID, THEME_VARIABLES, contrast, luminance,
} from '../../src/ui/theme/theme';
import { PANEL_CSS } from '../../src/ui/inventory/panel-dialog';
import { PARTY_CSS } from '../../src/ui/party/style';
import { partyStrip } from '../../src/ui/party/model';
import { createWorld } from '../../src/world/generation/world';
import { createWorldState, type WorldState } from '../../src/world/persistence/world-save';

const world = createWorld();
const rider = creatureById(
  // a species that can carry the player, so the badge has something to show
  ['duneear', 'clovermink', 'meadowram'].find((id) => creatureById(id)?.roles.includes('ride')) ?? 'duneear',
)!;
const owned = (id: string, speciesId: string, level: number) => {
  const species = creatureById(speciesId)!;
  const maxHp = stats({ id, species, level }).maxHp;
  return { id, speciesId, level, xp: 0, hp: maxHp, maxHp };
};
function state(overrides: Partial<WorldState> = {}): WorldState {
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [{ itemId: 'seal', quantity: 1 }, null],
    unlockedRecipeIds: ['salve'], creatures: [owned('mount', rider.id, ROLE_RULES.ride.unlockLevel)],
    creatureCapacity: 60, eggCapacity: 2, eggs: [], battle: null, loot: null,
    rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, activeCreatureId: 'mount', party: ['mount'], ...overrides };
}

describe('one theme for every panel', () => {
  it('keeps the tokens in one place and publishes them as variables', () => {
    expect(THEME.display).toContain('serif');
    expect(THEME_VARIABLES).toContain('--mv-gold:');
    expect(THEME_VARIABLES).toContain('--mv-ink:');
    expect(THEME_CSS.startsWith(THEME_VARIABLES)).toBe(true);
    expect(THEME_STYLE_ID).toBe('muhur-theme-style');
    // Bag, alchemy and notebook all live inside .mv-panel, so one rule dresses them all.
    expect(THEME_CSS).toContain('.mv-panel-frame{');
    expect(THEME_CSS).toContain('.mv-grid-cell{');
    expect(THEME_CSS).toContain('.mv-detail{');
    // Nothing is fetched: no font import, no remote image.
    expect(THEME_CSS).not.toMatch(/@import|url\(http|\/\/fonts\./);
  });
  it('reads comfortably: body text and headings clear 4.5:1', () => {
    expect(MIN_CONTRAST).toBe(4.5);
    expect(contrast(THEME.ink, THEME.panel)).toBeGreaterThanOrEqual(MIN_CONTRAST);
    expect(contrast(THEME.inkSoft, THEME.panel)).toBeGreaterThanOrEqual(MIN_CONTRAST);
    expect(contrast(THEME.gold, THEME.panel)).toBeGreaterThanOrEqual(MIN_CONTRAST);
    expect(contrast(THEME.ink, THEME.deep)).toBeGreaterThanOrEqual(MIN_CONTRAST);
    // A pressed button flips to gold, so the dark ink on it must read as well.
    expect(contrast('#14231d', THEME.gold)).toBeGreaterThanOrEqual(MIN_CONTRAST);
    expect(luminance('#ffffff')).toBeCloseTo(1, 5);
    expect(luminance('#000000')).toBeCloseTo(0, 5);
    expect(contrast('#000000', '#ffffff')).toBeCloseTo(21, 3);
  });
  it('keeps every control at the touch target the theme promises', () => {
    expect(TARGET_PX).toBe(44);
    expect(THEME.target).toBe('44px');
    expect(PANEL_CSS).toMatch(/\.mv-panel button\{[^}]*min-height:44px/);
    expect(PANEL_CSS).toMatch(/\.mv-grid-cell\{[^}]*min-height:64px/);
  });
});

describe('the bigger party strip', () => {
  it('grows the slots and keeps them one row on a narrow screen', () => {
    expect(PARTY_CSS).toMatch(/\.mv-party-slot\{[^}]*width:104px/);
    expect(PARTY_CSS).toMatch(/\.mv-party-slot\{[^}]*min-height:112px/);
    expect(PARTY_CSS).toMatch(/\.mv-party-sprite\{[^}]*width:52px/);
    const narrow = PARTY_CSS.slice(PARTY_CSS.indexOf('@media (max-width:640px)'));
    expect(narrow).toMatch(/\.mv-party-slot\{[^}]*flex:1 1 0/);
    expect(narrow).toMatch(/\.mv-party-slot\{[^}]*min-height:88px/);
    expect(PARTY_CSS).toContain('.mv-party-role');
  });
  it('shows what each creature can do and marks the one being ridden', () => {
    const view = partyStrip(state());
    const slot = view.slots[0];
    expect(slot.roles.length).toBeGreaterThan(0);
    expect(slot.roles.some((badge) => badge.role === 'ride')).toBe(true);
    expect(slot.roles.every((badge) => badge.label.length > 2)).toBe(true);
    expect(slot.mounted).toBe(false);
    const riding = partyStrip(state({ mount: { creatureId: 'mount', role: 'ride' } }));
    expect(riding.slots[0].mounted).toBe(true);
    // A young creature carries the same badge, but it reads as locked with the level on it.
    const young = partyStrip(state({ creatures: [owned('mount', rider.id, 2)] }));
    const badge = young.slots[0].roles.find((entry) => entry.role === 'ride')!;
    expect(badge.unlocked).toBe(false);
    expect(badge.note).toContain(String(ROLE_RULES.ride.unlockLevel));
    expect(view.slots[1].roles).toEqual([]);
  });
});
