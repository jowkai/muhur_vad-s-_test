import { describe, expect, it } from 'vitest';
import { PARTY_LIMIT } from '../../src/contracts';
import { creatureAssets } from '../../src/content/asset-manifest';
import { creatureById } from '../../src/content/catalog';
import { beginBattle, createBattle, resolveBattle, stats, type BattleState } from '../../src/game/combat/core';
import { createLootPlan } from '../../src/game/combat/rewards';
import type { PartyMember } from '../../src/game/party';
import { partyIntentForKey, partyStrip } from '../../src/ui/party/model';
import { PARTY_CSS } from '../../src/ui/party/style';
import { createWorld } from '../../src/world/generation/world';
import { createWorldState, type WorldState } from '../../src/world/persistence/world-save';

const world = createWorld();
const ROSTER = ['dewbud', 'emberpod', 'shellwisp', 'pebblenib', 'mirrormoth', 'snowspool'];
const owned = (index: number, hp?: number) => {
  const species = creatureById(ROSTER[index])!;
  const id = `c${index}`;
  const maxHp = stats({ id, species, level: 3 }).maxHp;
  return { id, speciesId: species.id, level: 3, xp: 0, hp: hp ?? maxHp, maxHp };
};
function state(count = 3, overrides: Partial<WorldState> = {}, hps: Record<number, number> = {}): WorldState {
  const creatures = Array.from({ length: count }, (_, index) => owned(index, hps[index]));
  const base = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [{ itemId: 'seal', quantity: 1 }, null],
    unlockedRecipeIds: ['salve'], creatures, creatureCapacity: 12, eggCapacity: 2, eggs: [],
    battle: null, loot: null, rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...base, activeCreatureId: 'c0', party: creatures.map((creature) => creature.id), ...overrides };
}
function battling(current: WorldState, activeIndex = 0): WorldState {
  const party: PartyMember[] = current.party.map((id) => {
    const creature = current.creatures.find((entry) => entry.id === id)!;
    return { id, species: creatureById(creature.speciesId)!, level: creature.level, hp: creature.hp };
  });
  const active = party[activeIndex];
  const battle = beginBattle(createBattle({
    battleId: 'b', encounterId: 'e', seed: 5,
    player: { id: active.id, species: active.species, level: active.level },
    enemy: { id: 'wild', species: creatureById('snowspool')!, level: 2 },
    party, activeIndex, playerHp: active.hp, inventorySnapshot: { seal: 1 }, captureCapacity: 1,
  }));
  return { ...current, mode: 'battle', battle, loot: createLootPlan('b', battle.enemy, false, 7), activeCreatureId: active.id };
}

describe('the six slot party strip', () => {
  it('always draws six slots and marks the empty ones', () => {
    const view = partyStrip(state(2));
    expect(view.slots).toHaveLength(PARTY_LIMIT);
    expect(view.slots.filter((slot) => slot.filled)).toHaveLength(2);
    const empty = view.slots[2];
    expect(empty).toMatchObject({ filled: false, name: 'Boş yuva', note: 'Boş yuva', enabled: false, intent: null, hpText: '—' });
    expect(view.slots.map((slot) => slot.index)).toEqual([0, 1, 2, 3, 4, 5]);
  });
  it('shows a sprite, a level and a health bar for every travelling creature', () => {
    const view = partyStrip(state(3, {}, { 1: 4 }));
    const first = view.slots[0];
    expect(first.spriteUrl).toBe(creatureAssets.dewbud.front);
    expect(first.level).toBe(3);
    expect(first.hpText).toBe(`${first.maxHp}/${first.maxHp}`);
    expect(first.ratio).toBe(1);
    const hurt = view.slots[1];
    expect(hurt.hp).toBe(4);
    expect(hurt.ratio).toBeLessThan(.35);
    expect(hurt.hpText).toBe(`4/${hurt.maxHp}`);
  });
  it('sends set-active in the world and switch-party in a battle', () => {
    const outside = partyStrip(state(3));
    expect(outside.inBattle).toBe(false);
    expect(outside.slots[0]).toMatchObject({ active: true, enabled: false, note: 'Sahada' });
    expect(outside.slots[1]).toMatchObject({ enabled: true, note: 'Sahaya çıkar' });
    expect(outside.slots[1].intent).toEqual({ type: 'set-active', creatureId: 'c1' });
    const inside = partyStrip(battling(state(3)));
    expect(inside.inBattle).toBe(true);
    expect(inside.caption).toBe('Değiştirmek bir tur harcar');
    expect(inside.slots[1]).toMatchObject({ enabled: true, note: 'Değiştirmek bir tur harcar' });
    expect(inside.slots[1].intent).toEqual({ type: 'switch-party', index: 1 });
  });
  it('marks a fainted creature, gives the reason and refuses to send it out', () => {
    const view = partyStrip(state(3, {}, { 1: 0 }));
    expect(view.slots[1]).toMatchObject({ fainted: true, enabled: false, note: 'Baygın · kampta iyileştir', intent: null });
    expect(view.slots[1].ratio).toBe(0);
    expect(view.slots[0].fainted).toBe(false);
  });
  it('waits while the turn resolves and asks for a replacement when the fighter falls', () => {
    const fighting = battling(state(3));
    const resolving = { ...fighting, battle: { ...fighting.battle!, phase: 'RESOLVE_ENEMY' as const } };
    expect(partyStrip(resolving).slots.every((slot) => !slot.enabled)).toBe(true);
    expect(partyStrip(resolving).slots[1].note).toBe('Tur çözülüyor');
    const hurt = { ...fighting.battle!, playerHp: 1, party: fighting.battle!.party.map((member, index) => index === 0 ? { ...member, hp: 1 } : member) };
    const fallen = resolveBattle(hurt as BattleState, { type: 'attack', slot: 0, commandId: 'trade', tick: 1 });
    expect(fallen.state.phase).toBe('FORCED_SWITCH');
    const view = partyStrip({ ...fighting, battle: fallen.state, creatures: fighting.creatures.map((creature) => creature.id === 'c0' ? { ...creature, hp: 0 } : creature) });
    expect(view.forced).toBe(true);
    expect(view.caption).toBe('Ayakta bir yaratık seç');
    expect(view.slots[0]).toMatchObject({ fainted: true, enabled: false, note: 'Bayıldı' });
    expect(view.slots[1].enabled).toBe(true);
  });
  it('reads 1–6 in the world and Shift+1–6 in a battle', () => {
    const outside = partyStrip(state(3));
    expect(partyIntentForKey({ key: '2' }, outside)).toEqual({ type: 'set-active', creatureId: 'c1' });
    expect(partyIntentForKey({ key: '2', shiftKey: true }, outside)).toBeNull();
    expect(partyIntentForKey({ key: '1' }, outside)).toBeNull();
    expect(partyIntentForKey({ key: '4' }, outside)).toBeNull();
    expect(partyIntentForKey({ key: '7' }, outside)).toBeNull();
    expect(partyIntentForKey({ key: 'a' }, outside)).toBeNull();
    const inside = partyStrip(battling(state(3)));
    // The bare digits belong to the four attack buttons while a battle is open.
    expect(partyIntentForKey({ key: '2' }, inside)).toBeNull();
    expect(partyIntentForKey({ key: '2', shiftKey: true }, inside)).toEqual({ type: 'switch-party', index: 1 });
  });
  it('changes nothing in the save and stays a pure projection', () => {
    const current = state(4, {}, { 2: 0 });
    const before = JSON.stringify(current);
    const view = partyStrip(current);
    expect(JSON.stringify(current)).toBe(before);
    expect(Object.isFrozen(view)).toBe(true);
    expect(view.slots.every((slot) => Object.isFrozen(slot))).toBe(true);
    expect(partyStrip(current)).toEqual(view);
  });
  it('keeps six touch targets on a narrow screen', () => {
    expect(PARTY_CSS).toMatch(/\.mv-party-slot\{[^}]*min-height:112px/);
    expect(PARTY_CSS).toMatch(/\.mv-party\{[^}]*max-width:100%/);
    const narrow = PARTY_CSS.slice(PARTY_CSS.indexOf('@media (max-width:640px)'));
    expect(narrow).toMatch(/\.mv-party-slot\{[^}]*flex:1 1 0/);
    expect(narrow).toMatch(/\.mv-party-slot\{[^}]*min-height:88px/);
    expect(narrow).toMatch(/\.mv-party-name\{display:none\}/);
  });
});
