import { afterEach, describe, expect, it } from 'vitest';
import type { GameCommand, VecXZ } from '../../src/contracts';
import { BIOME_EXTRA_RECIPE, BIOME_RECIPE, STARTING_RECIPE_ID } from '../../src/content/secrets';
import { itemById } from '../../src/content/catalog';
import { createWorld } from '../../src/world/generation/world';
import { validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { DAY_TICKS, phaseAt } from '../../src/world/daynight';
import { shrineIdFor, shrineById } from '../../src/world/shrines/shrines';
import { TRAVEL_TICKS } from '../../src/world/travel';
import { GARDEN_TICKS, TOOL, isSeed } from '../../src/world/gathering/gathering';
import { IndexedDbSave } from '../../src/game/save/indexeddb';
import { GameSession, newGame } from '../../src/app/session';

const world = createWorld();
const forest = shrineById(world, shrineIdFor('forest'))!;
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
async function storage(seed: Partial<WorldState> = {}) {
  const save = await IndexedDbSave.open<WorldState>({
    name: `v2-${counter++}`, initial: () => ({ ...newGame(world), ...seed }),
    validate: (value) => validateWorldState(world, value),
  });
  opened.push(save);
  return save;
}
const move = (direction: VecXZ, tick: number): GameCommand => ({ type: 'move', direction, commandId: `m${tick}`, tick });
/** Teleports through the record, then lets the session rebuild its runtime from it. */
async function sessionAt(position: VecXZ, seed: Partial<WorldState> = {}) {
  const save = await storage({ playerPosition: { ...position }, lastSafePosition: { ...position }, worldTick: 5, ...seed });
  return GameSession.open({ world, save, sessionId: `s${counter}` });
}
afterEach(async () => { for (const save of opened) save.close(); opened.length = 0; });

describe('the v2 loop on real modules', () => {
  it('reads a shrine, learns both region recipes and opens the anchor', async () => {
    const session = await sessionAt(forest.position);
    expect(session.nearbyShrine()?.id).toBe(forest.id);
    expect(session.view().objectives.done).toEqual([]);
    await session.dispatch({ type: 'visit-shrine', shrineId: forest.id });
    const state = session.state;
    expect(state.shrines.map((shrine) => shrine.biomeId)).toEqual(['forest']);
    expect(state.unlockedRecipeIds).toEqual([STARTING_RECIPE_ID, BIOME_RECIPE.forest, BIOME_EXTRA_RECIPE.forest]);
    expect(session.view().objectives.done.map((row) => row.id)).toContain('first-shrine');
    // Reading it again changes nothing at all.
    const before = JSON.stringify(session.state);
    await session.dispatch({ type: 'visit-shrine', shrineId: forest.id });
    expect(JSON.stringify(session.state)).toBe(before);
    expect(session.view().travel.map((anchor) => anchor.id)).toEqual(['camp', forest.id]);
  });
  it('travels back to camp in one command, moving the runtime with the record', async () => {
    const session = await sessionAt(forest.position);
    await session.dispatch({ type: 'visit-shrine', shrineId: forest.id });
    const tickBefore = session.state.worldTick;
    await session.dispatch({ type: 'travel', anchorId: 'camp' });
    expect(session.position).toEqual(world.camp);
    expect(session.state.playerPosition).toEqual({ ...world.camp });
    expect(session.state.worldTick).toBe(tickBefore + TRAVEL_TICKS);
    expect(session.view().chunks).toHaveLength(25);
    // And back out to the shrine it opened.
    await session.dispatch({ type: 'travel', anchorId: forest.id });
    expect(session.position).toEqual(forest.position);
  });
  it('keeps saving after a journey, instead of refusing every later checkpoint', async () => {
    const session = await sessionAt(forest.position);
    await session.dispatch({ type: 'visit-shrine', shrineId: forest.id });
    await session.dispatch({ type: 'travel', anchorId: 'camp' });
    const afterTravel = session.state.worldTick;
    // A minute of world time passed in the record; the session's own clock has to follow it.
    for (let tick = 0; tick < 30; tick++) session.step({ move: move({ x: 1, z: 0 }, tick) });
    const walked = session.position;
    await session.checkpoint();
    expect(session.state.playerPosition.x, 'yolculuktan sonra konum kaydedilir').toBeCloseTo(walked.x, 5);
    expect(session.state.worldTick).toBeGreaterThanOrEqual(afterTravel);
  });
  it('refuses to travel to an anchor that was never read', async () => {
    const session = await sessionAt(world.camp);
    await session.dispatch({ type: 'travel', anchorId: shrineIdFor('ice') });
    expect(session.position).toEqual(world.camp);
    expect(session.view().hud.message).toBeTruthy();
  });
  it('runs the ten minute clock and shows it in the HUD', async () => {
    const session = await sessionAt(world.camp, { dayTick: DAY_TICKS - 2 });
    expect(session.view().day.phase).toBe('day');
    for (let tick = 0; tick < 4; tick++) session.step({ move: move({ x: 0, z: 0 }, tick) });
    expect(session.dayTick).toBe(DAY_TICKS + 2);
    await session.checkpoint();
    expect(session.state.dayTick).toBe(DAY_TICKS + 2);
    expect(session.view().day.phase).toBe('night');
    expect(phaseAt(session.dayTick)).toBe('night');
    expect(session.view().hud.day).toContain('Gece');
    expect(session.view().day.detectionRadius).toBe(16);
  });
  it('gathers a resource through the same command path and tombstones it once', async () => {
    const session = await sessionAt(world.camp);
    expect(session.state.consumedEntityIds).toEqual([]);
    const nearby = session.visibleEntities().find((entity) => entity.kind === 'resource');
    expect(nearby).toBeDefined();
    const plan = session.gatherPlan(nearby!.entityId)!;
    expect(plan.method).toMatch(/pick|dig|cache|fell/);
    if (plan.method !== 'pick' || plan.nightOnly) return;
    await sessionWalk(session, nearby!.position);
    await session.dispatch({ type: 'gather', entityId: nearby!.entityId, method: 'pick' });
    expect(session.state.consumedEntityIds).toContain(nearby!.entityId);
    const held = session.state.inventory.reduce((sum, stack) => sum + (stack?.itemId === plan.itemId ? stack.quantity : 0), 0);
    expect(held).toBeGreaterThan(0);
    await session.dispatch({ type: 'gather', entityId: nearby!.entityId, method: 'pick' });
    expect(session.state.consumedEntityIds.filter((id) => id === nearby!.entityId)).toHaveLength(1);
  });
  it('plants a seed at camp and harvests it after three minutes of world time', async () => {
    const seed = [...Array(1)].map(() => itemById('soft_seed')!)[0];
    expect(isSeed(seed.id)).toBe(true);
    const session = await sessionAt(world.camp, {
      atCamp: true, inventory: [{ itemId: seed.id, quantity: 2 }, null, null, null, null, null, null, null, null, null, null, null],
    });
    await session.plant(seed.id);
    expect(session.gardenView().plots).toHaveLength(1);
    expect(session.gardenView().canHarvest).toBe(false);
    await expect(session.harvest()).rejects.toThrow();
    // Three minutes of world time pass exactly as the world tick counts them.
    const grown = await sessionAt(world.camp, {
      atCamp: true, worldTick: GARDEN_TICKS + 10,
      garden: [{ itemId: seed.id, plantedTick: 5 }],
      inventory: [{ itemId: seed.id, quantity: 1 }, null, null, null, null, null, null, null, null, null, null, null],
    });
    expect(grown.gardenView().canHarvest).toBe(true);
    await grown.harvest();
    expect(grown.gardenView().plots).toEqual([]);
    expect(grown.state.inventory.some((stack) => stack?.itemId === 'dew_leaf')).toBe(true);
  });
  it('releases a record left in a screen-only mode so the panels open again', async () => {
    // A tab closed with the bag open used to lock every panel and all movement for good.
    for (const stuck of ['panel', 'encounter'] as const) {
      const save = await storage({ mode: stuck });
      const session = await GameSession.open({ world, save, sessionId: `release-${stuck}` });
      expect(session.state.mode, stuck).toBe('exploring');
      expect(session.view().movementAllowed, stuck).toBe(true);
      await session.dispatch({ type: 'open-panel', panel: 'inventory' });
      expect(session.openPanel, stuck).toBe('inventory');
      expect(session.state.mode, stuck).toBe('panel');
    }
    // A battle in the record is real state and is never released by the boot.
    const battling = await storage({ mode: 'committing' });
    const session = await GameSession.open({ world, save: battling, sessionId: 'keep-committing' });
    expect(session.state.mode).toBe('committing');
  });
  it('keeps the world still while a panel is open and lets the tools change the rules', async () => {
    const session = await sessionAt(world.camp, { tools: [TOOL.pick] });
    expect(session.canDigNow()).toBe(true);
    const before = session.state.worldTick;
    await session.dispatch({ type: 'open-panel', panel: 'objectives' });
    for (let tick = 0; tick < 10; tick++) session.step({ move: move({ x: 1, z: 0 }, tick) });
    expect(session.state.worldTick).toBe(before);
    expect(session.position).toEqual(world.camp);
    expect(session.view().objectives.total).toBe(8);
    await session.dispatch({ type: 'close-panel' });
    session.step({ move: move({ x: 1, z: 0 }, 11) });
    expect(session.position.x).toBeGreaterThan(world.camp.x);
  });
});
/** Walks the real movement domain toward a point. */
async function sessionWalk(session: GameSession, goal: VecXZ, limit = 900): Promise<void> {
  for (let tick = 0; tick < limit; tick++) {
    const at = session.position;
    const dx = goal.x - at.x, dz = goal.z - at.z;
    if (Math.hypot(dx, dz) <= 2.5) return;
    session.step({ move: move({ x: dx, z: dz }, tick) });
  }
  throw new Error('Hedefe yürünemedi');
}
