import { describe, expect, it } from 'vitest';
import { newGame } from '../../src/app/session';
import { reconcileRoleCapacity, withRoleCapacity } from '../../src/app/role-capacity';
import { creatures, itemById } from '../../src/content/catalog';
import { stats } from '../../src/game/combat/core';
import { createWorld } from '../../src/world/generation/world';
import { validateWorldState } from '../../src/world/persistence/world-save';
import { IndexedDbSave } from '../../src/game/save/indexeddb';

const world = createWorld();
function initial() {
  const state = newGame(world);
  const species = creatures.find((row) => row.roles.includes('tank'))!;
  const maxHp = stats({ id: 'tank', species, level: 14 }).maxHp;
  state.creatures.push({ id: 'tank', speciesId: species.id, level: 14, xp: 0, hp: maxHp, maxHp });
  state.party.push('tank'); state.activeCreatureId = 'tank';
  return state;
}
describe('transactional role capacity', () => {
  it('moves overflow to delivery on faint or switching without deleting or duplicating it', () => {
    const state = initial();
    const capacity = state.inventory.length;
    reconcileRoleCapacity(state);
    expect(state.inventory).toHaveLength(capacity + 6);
    const stackLimit = itemById('dew_leaf')!.stackLimit;
    state.inventory = state.inventory.map(() => ({ itemId: 'dew_leaf', quantity: stackLimit }));
    state.activeCreatureId = 'friend';
    reconcileRoleCapacity(state);
    expect(state.inventory).toHaveLength(capacity);
    expect(state.deliveryBox.reduce((n, stack) => n + stack.quantity, 0)).toBe(6 * stackLimit);
    reconcileRoleCapacity(state);
    expect(state.deliveryBox.reduce((n, stack) => n + stack.quantity, 0)).toBe(6 * stackLimit);
    state.activeCreatureId = 'tank';
    state.creatures.find((c) => c.id === 'tank')!.hp = 0;
    reconcileRoleCapacity(state);
    expect(state.inventory).toHaveLength(capacity);
  });
  it('persists the bonus atomically and does not grant six more on reload or duplicate command', async () => {
    const state = initial();
    const db = await IndexedDbSave.open({ name: 'role-capacity-proof', initial: () => structuredClone(state), validate: (v) => validateWorldState(world, v) });
    const save = withRoleCapacity(db);
    try {
      const first = await save.transact('grant', () => {});
      expect(first.inventory).toHaveLength(state.inventory.length + 6);
      expect(await save.transact('grant', () => {})).toEqual(first);
      const reloaded = await save.load();
      expect(reloaded!.tankBonusSlots).toBe(6);
      expect((await save.transact('reload', () => {})).inventory).toHaveLength(first.inventory.length);
      await expect(save.transact('abort', (draft) => { draft.activeCreatureId = 'friend'; throw new Error('fault'); })).rejects.toThrow();
      expect((await save.load())!.inventory).toHaveLength(first.inventory.length);
    } finally { db.close(); }
  });
});
