import { afterEach, describe, expect, it } from 'vitest';
import type { GameCommand, VecXZ } from '../../src/contracts';
import { createWorld } from '../../src/world/generation/world';
import { validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { IndexedDbSave } from '../../src/game/save/indexeddb';
import { INCUBATION_TICKS } from '../../src/ui/camp/model';
import { GameSession, newGame, CHECKPOINT_TICKS } from '../../src/app/session';
import { BIOME_RECIPE, STARTING_RECIPE_ID, secretIdFor } from '../../src/content/secrets';
import { creatureById } from '../../src/content/catalog';
import { stats } from '../../src/game/combat/core';

const world = createWorld();
const egg = world.starters.find((starter) => starter.kind === 'egg')!;
const wild = world.starters.find((starter) => starter.kind === 'creature')!;
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
async function storage(name = `loop-${counter++}`, seed?: Partial<WorldState>) {
  const save = await IndexedDbSave.open<WorldState>({
    name, initial: () => ({ ...newGame(world), ...seed }), validate: (value) => validateWorldState(world, value),
  });
  opened.push(save);
  return save;
}
const move = (direction: VecXZ, tick: number): GameCommand => ({ type: 'move', direction, commandId: `m${tick}`, tick });
/** Walks the real movement domain toward a point, one fixed step at a time. */
async function walkTo(session: GameSession, goal: VecXZ, limit = 1200): Promise<number> {
  for (let tick = 0; tick < limit; tick++) {
    const at = session.position;
    const dx = goal.x - at.x, dz = goal.z - at.z;
    if (Math.hypot(dx, dz) <= 3.5) return tick;
    session.step({ move: move({ x: dx, z: dz }, tick) });
  }
  throw new Error('Hedefe yürünemedi');
}
afterEach(async () => { for (const save of opened) save.close(); opened.length = 0; });

describe('boot and first steps', () => {
  it('starts a single player at camp with a level 2 friend and a reachable tutorial hint', async () => {
    const session = await GameSession.open({ world, save: await storage(), sessionId: 's1' });
    const view = session.view();
    expect(view.position).toEqual(world.camp);
    expect(view.hud.active).toMatchObject({ level: 2 });
    expect(view.hud.biome.label).toBe('Şafak Çayırı');
    expect(view.hud.team.text).toBe('1/60');
    expect(view.movementAllowed).toBe(true);
    expect(view.chunks).toHaveLength(25);
    expect(view.hint).toMatch(/m uzakta · WASD/);
    expect(view.hint).toContain('Yumurtası');
    expect(session.state.creatures[0]).toMatchObject({ level: 2, xp: 0 });
    expect(session.state.inventory[0]).toEqual({ itemId: 'seal', quantity: 2 });
  });
  it('moves with the world domain, reveals the map and checkpoints the walk', async () => {
    const save = await storage('walk');
    const session = await GameSession.open({ world, save, sessionId: 's2' });
    const start = session.position;
    for (let tick = 0; tick < CHECKPOINT_TICKS + 5; tick++) session.step({ move: move({ x: 1, z: 0 }, tick) });
    await session.checkpoint();
    const walked = session.position;
    expect(walked.x).toBeGreaterThan(start.x + 10);
    const stored = (await save.load())!;
    expect(stored.playerPosition.x).toBeCloseTo(walked.x, 6);
    expect(stored.discoveredCells.length).toBeGreaterThan(100);
    expect(stored.worldTick).toBeGreaterThanOrEqual(CHECKPOINT_TICKS);
    expect(session.view().minimap.markers.length).toBeGreaterThanOrEqual(0);
    const paused = session.position;
    session.step({ move: move({ x: 1, z: 0 }, 999), paused: true });
    expect(session.position).toEqual(paused);
  });
});

describe('the full loop on real modules', () => {
  it('walks to an egg, collects it, hatches it at camp and keeps it after a reload', async () => {
    const save = await storage('egg-loop');
    const session = await GameSession.open({ world, save, sessionId: 's3' });
    await walkTo(session, egg.position);
    session.step({ move: null });
    const card = session.view().card!;
    expect(card.entityId).toBe(egg.entityId);
    expect(card.hint).toBe('Enter: Topla');
    await session.dispatch(card.intent);
    expect(session.state.eggs).toHaveLength(1);
    expect(session.state.consumedEntityIds).toEqual([egg.entityId]);
    expect(session.view().camp.eggs[0].ready).toBe(false);
    await walkTo(session, world.camp);
    for (let tick = 0; tick < INCUBATION_TICKS + 10; tick++) session.step({ move: null });
    await session.checkpoint();
    const ready = session.view().camp.eggs[0];
    expect(ready).toMatchObject({ ready: true, reason: null });
    await session.hatch(session.state.eggs[0].id);
    expect(session.state.creatures).toHaveLength(2);
    expect(session.state.eggs).toEqual([]);
    expect(session.state.inventory.some((stack) => stack?.itemId === 'heat_herb')).toBe(false);
    await session.dispose();
    save.close();
    const reopened = await storage('egg-loop');
    const resumed = await GameSession.open({ world, save: reopened, sessionId: 's3b' });
    expect(resumed.state.creatures).toHaveLength(2);
    expect(resumed.state.consumedEntityIds).toContain(egg.entityId);
    expect(resumed.view().card?.entityId).not.toBe(egg.entityId);
    expect(resumed.position.x).toBeCloseTo(session.position.x, 1);
  }, 20000);
  it('runs encounter → battle → capture → XP → world return through one command path', async () => {
    const save = await storage('battle-loop');
    const session = await GameSession.open({ world, save, sessionId: 's4' });
    await walkTo(session, wild.position);
    session.step({ move: null });
    const card = session.view().card!;
    expect(card.entityId).toBe(wild.entityId);
    expect(card.hint).toBe('Enter: Savaş');
    await session.dispatch(card.intent);
    expect(session.state.mode).toBe('battle');
    const battle = session.view().battle!;
    expect(battle.player.facing).toBe('back');
    expect(battle.enemy.facing).toBe('front');
    expect(battle.slots[0].enabled).toBe(true);
    expect(session.view().movementAllowed).toBe(false);
    let guard = 0;
    while (session.state.mode === 'battle' && guard++ < 30) {
      const view = session.view().battle!;
      await session.dispatch(view.capture.enabled ? view.capture.intent : view.slots[0].intent);
      session.step({ move: null });
    }
    expect(session.state.mode).toBe('exploring');
    const outcome = session.view().adapter.lastOutcome;
    expect(['won', 'captured']).toContain(outcome);
    expect(session.state.consumedEntityIds).toContain(wild.entityId);
    expect(session.state.rewardLedger).toHaveLength(1);
    expect(session.view().movementAllowed).toBe(true);
    expect(session.view().hud.message).toBeTruthy();
    if (outcome === 'captured') expect(session.state.creatures).toHaveLength(2);
    else expect(session.state.creatures[0].xp).toBeGreaterThan(0);
    const stored = (await save.load())!;
    expect(stored.mode).toBe('exploring');
    expect(stored.battle).toBeNull();
    for (let tick = 0; tick < 30; tick++) session.step({ move: move({ x: 0, z: 1 }, tick) });
    expect(session.view().card?.entityId).not.toBe(wild.entityId);
  }, 20000);
  it('crafts through the panel path while the world stays locked, then saves and reloads', async () => {
    const save = await storage('craft-loop', {
      inventory: [{ itemId: 'dew_leaf', quantity: 4 }, { itemId: 'soft_seed', quantity: 2 }, ...Array.from({ length: 22 }, () => null)],
    });
    const session = await GameSession.open({ world, save, sessionId: 's5' });
    await session.dispatch({ type: 'open-panel', panel: 'alchemy' });
    expect(session.openPanel).toBe('alchemy');
    expect(session.state.mode).toBe('panel');
    expect(session.view().movementAllowed).toBe(false);
    const before = session.position;
    for (let tick = 0; tick < 60; tick++) session.step({ move: move({ x: 1, z: 0 }, tick) });
    expect(session.position).toEqual(before);
    expect(session.view().card).toBeNull();
    const preview = session.view().alchemy.preview ?? session.view().alchemy.rows.find((row) => row.unlocked)!;
    expect(session.view().alchemy.rows).toHaveLength(88);
    await session.dispatch({ type: 'craft', recipeId: 'salve' });
    expect(session.state.inventory.some((stack) => stack?.itemId === 'salve')).toBe(true);
    expect(preview).toBeTruthy();
    await expect(session.dispatch({ type: 'craft', recipeId: 'seal' })).rejects.toThrow();
    expect(session.state.inventory[0]).toEqual({ itemId: 'dew_leaf', quantity: 2 });
    await session.dispatch({ type: 'close-panel' });
    expect(session.openPanel).toBeNull();
    expect(session.state.mode).toBe('exploring');
    expect(session.view().movementAllowed).toBe(true);
    session.step({ move: move({ x: 1, z: 0 }, 61) });
    expect(session.position.x).toBeGreaterThan(before.x);
    await session.dispose();
    save.close();
    const resumed = await GameSession.open({ world, save: await storage('craft-loop'), sessionId: 's5b' });
    expect(resumed.state.inventory.some((stack) => stack?.itemId === 'salve')).toBe(true);
    expect(resumed.state.mode).toBe('exploring');
    expect(resumed.view().inventory.used).toBeGreaterThan(0);
  }, 20000);
  it('heals a hurt friend in camp and refuses the same item afterwards', async () => {
    const fresh = newGame(world);
    const save = await storage('camp-loop', {
      creatures: [{ ...fresh.creatures[0], hp: 10 }],
      inventory: [{ itemId: 'salve', quantity: 1 }, ...Array.from({ length: 23 }, () => null)],
    });
    const session = await GameSession.open({ world, save, sessionId: 's6' });
    session.step({ move: null });
    await session.dispatch({ type: 'open-panel', panel: 'camp' });
    const row = session.view().camp.items.find((item) => item.itemId === 'salve')!;
    expect(row.usable).toBe(true);
    await session.dispatch(row.intent);
    expect(session.state.creatures[0].hp).toBe(30);
    expect(session.view().camp.items.find((item) => item.itemId === 'salve')).toBeUndefined();
    await expect(session.dispatch({ type: 'use-item', itemId: 'salve' })).rejects.toThrow();
    expect(session.state.creatures[0].hp).toBe(30);
  }, 20000);
});

describe('session resilience', () => {
  it('keeps the world closed when the settlement save fails and reopens it after a retry', async () => {
    const save = await storage('recovery');
    let failing = false;
    const flaky = {
      load: () => save.load(),
      transact: (commandId: string, mutate: (draft: WorldState) => void) =>
        commandId.startsWith('settle:') && failing ? Promise.reject(new Error('kayıt hatası')) : save.transact(commandId, mutate),
    };
    const session = await GameSession.open({ world, save: flaky, sessionId: 's7' });
    await walkTo(session, wild.position);
    session.step({ move: null });
    await session.dispatch(session.view().card!.intent);
    expect(session.state.mode).toBe('battle');
    failing = true;
    let guard = 0;
    while (session.state.mode === 'battle' && guard++ < 30) {
      await session.dispatch(session.view().battle!.slots[0].intent);
      session.step({ move: null });
    }
    expect(session.view().adapter.state.mode).toBe('recovery');
    expect(session.view().movementAllowed).toBe(false);
    expect(session.view().hud.message).toBeTruthy();
    expect((await save.load())!.mode).toBe('committing');
    const held = session.position;
    for (let tick = 0; tick < 30; tick++) session.step({ move: move({ x: 1, z: 0 }, tick) });
    expect(session.position).toEqual(held);
    failing = false;
    await session.retry();
    session.step({ move: null });
    expect(session.state.mode).toBe('exploring');
    expect(session.view().movementAllowed).toBe(true);
    expect(session.state.rewardLedger).toHaveLength(1);
  }, 20000);
  it('refuses world interaction while a panel is open and never double-collects', async () => {
    const save = await storage('guard');
    const session = await GameSession.open({ world, save, sessionId: 's8' });
    await walkTo(session, egg.position);
    session.step({ move: null });
    const intent = session.view().card!.intent;
    await session.dispatch({ type: 'open-panel', panel: 'inventory' });
    await session.dispatch(intent);
    expect(session.state.eggs).toEqual([]);
    await session.dispatch({ type: 'close-panel' });
    session.step({ move: null });
    await session.dispatch(intent);
    await session.dispatch(intent);
    await session.dispatch(intent);
    expect(session.state.eggs).toHaveLength(1);
    expect(session.state.consumedEntityIds).toEqual([egg.entityId]);
    expect(session.view().hud.eggs.text).toBe('1/2');
  }, 20000);
});

describe('collection journal', () => {
  it('swaps the active creature from the panel and refuses to do it mid-battle', async () => {
    const fresh = newGame(world);
    const starterMaxHp = stats({ id: 'x', species: creatureById(fresh.creatures[0].speciesId)!, level: 1 }).maxHp;
    const save = await storage('bestiary', {
      creatures: [fresh.creatures[0], { id: 'egg:extra', speciesId: fresh.creatures[0].speciesId, level: 1, xp: 0,
        hp: starterMaxHp, maxHp: starterMaxHp }],
    });
    const session = await GameSession.open({ world, save, sessionId: 's9' });
    await session.dispatch({ type: 'open-panel', panel: 'bestiary' });
    expect(session.openPanel).toBe('bestiary');
    const journal = session.view().bestiary;
    expect(journal.owned).toHaveLength(2);
    expect(journal.owned[0].active).toBe(true);
    expect(journal.knownCount).toBe(1);
    await session.dispatch(journal.owned[1].intent);
    expect(session.state.activeCreatureId).toBe('egg:extra');
    expect(session.view().bestiary.owned[1].active).toBe(true);
    expect((await save.load())!.activeCreatureId).toBe('egg:extra');
    await expect(session.dispatch({ type: 'set-active', creatureId: 'yok' })).rejects.toThrow();
    expect(session.state.activeCreatureId).toBe('egg:extra');
    await session.dispatch({ type: 'close-panel' });

    await walkTo(session, wild.position);
    session.step({ move: null });
    await session.dispatch(session.view().card!.intent);
    expect(session.state.mode).toBe('battle');
    expect(session.view().bestiary.locked).toBeTruthy();
    await expect(session.dispatch({ type: 'set-active', creatureId: 'friend' })).rejects.toThrow();
    expect(session.state.activeCreatureId).toBe('egg:extra');
  }, 20000);
});

describe('pause and delivery box in the loop', () => {
  it('freezes the world on pause and hands over the overflowed reward at camp', async () => {
    const fresh = newGame(world);
    const save = await storage('pause-delivery', {
      inventory: [{ itemId: 'dew_leaf', quantity: 99 }, null, ...Array.from({ length: 22 }, () => null)],
      deliveryBox: [{ kind: 'item', itemId: 'clay_shard', quantity: 2 }],
      creatures: [fresh.creatures[0]],
    });
    const session = await GameSession.open({ world, save, sessionId: 's10' });
    for (let tick = 0; tick < 20; tick++) session.step({ move: move({ x: 1, z: 0 }, tick) });
    const walked = session.position;
    expect(session.togglePause()).toBe(true);
    expect(session.view().hud.paused).toBe(true);
    expect(session.view().movementAllowed).toBe(false);
    for (let tick = 20; tick < 60; tick++) session.step({ move: move({ x: 1, z: 0 }, tick) });
    expect(session.position).toEqual(walked);
    expect(session.togglePause()).toBe(false);
    session.step({ move: move({ x: 1, z: 0 }, 61) });
    expect(session.position.x).toBeGreaterThan(walked.x);

    await walkTo(session, world.camp);
    await session.dispatch({ type: 'open-panel', panel: 'camp' });
    const box = session.view().camp.delivery;
    expect(box.rows[0].label).toContain('×2');
    expect(box.canClaim).toBe(true);
    await session.claimDelivery();
    expect(session.state.deliveryBox).toEqual([]);
    expect(session.state.inventory.some((stack) => stack?.itemId === 'clay_shard' && stack.quantity === 2)).toBe(true);
    expect(session.view().camp.delivery.rows).toEqual([]);
    await expect(session.claimDelivery()).rejects.toThrow();
    expect((await save.load())!.deliveryBox).toEqual([]);
  }, 20000);
});

describe('timed respawn in the loop', () => {
  it('brings a defeated wild creature back into the world after its respawn time', async () => {
    const save = await storage('respawn-loop');
    const session = await GameSession.open({ world, save, sessionId: 's11' });
    await walkTo(session, wild.position);
    session.step({ move: null });
    await session.dispatch(session.view().card!.intent);
    let guard = 0;
    while (session.state.mode === 'battle' && guard++ < 30) {
      await session.dispatch(session.view().battle!.slots[0].intent);
      session.step({ move: null });
    }
    const outcome = session.view().adapter.lastOutcome;
    if (outcome !== 'won') return; // capture is permanent by design; this run defeated it
    expect(session.state.consumedEntityIds).toContain(wild.entityId);
    expect(session.state.respawns[0]).toMatchObject({ entityId: wild.entityId });
    expect(session.visibleEntities().some((target) => target.entityId === wild.entityId)).toBe(false);
    // worldTick reaches the record only at a checkpoint, so drive a bounded number of steps.
    const due = session.state.respawns[0].tick;
    for (let tick = 0; tick <= due + 240; tick++) session.step({ move: null });
    await session.checkpoint();
    expect(session.state.respawns).toEqual([]);
    expect(session.state.consumedEntityIds).not.toContain(wild.entityId);
    expect(session.visibleEntities().some((target) => target.entityId === wild.entityId)).toBe(true);
    expect((await save.load())!.consumedEntityIds).not.toContain(wild.entityId);
  }, 30000);
});

describe('recipe discovery', () => {
  it('teaches the region recipe when a mark is found and opens it in the alchemy panel', async () => {
    const fresh = newGame(world);
    expect(fresh.unlockedRecipeIds).toEqual([STARTING_RECIPE_ID]);
    expect(fresh.secretFlags).toEqual([secretIdFor('meadow')]);
    const save = await storage('discovery', {
      inventory: [{ itemId: 'moss_thread', quantity: 4 }, { itemId: 'echo_bark', quantity: 2 }, ...Array.from({ length: 22 }, () => null)],
      secretFlags: [secretIdFor('meadow'), secretIdFor('forest')],
      unlockedRecipeIds: [STARTING_RECIPE_ID, BIOME_RECIPE.forest],
    });
    const session = await GameSession.open({ world, save, sessionId: 's12' });
    const view = session.view();
    expect(view.alchemy.unlockedCount).toBe(2);
    expect(view.bestiary.secrets.known).toBe(2);
    const forest = view.alchemy.rows.find((row) => row.recipeId === BIOME_RECIPE.forest)!;
    expect(forest).toMatchObject({ unlocked: true, craftable: true });
    await session.dispatch({ type: 'open-panel', panel: 'alchemy' });
    await session.dispatch({ type: 'craft', recipeId: BIOME_RECIPE.forest });
    expect(session.state.inventory.some((stack) => stack?.itemId === 'forest_balm')).toBe(true);
    const locked = session.view().alchemy.rows.find((row) => row.recipeId === BIOME_RECIPE.ice)!;
    expect(locked).toMatchObject({ unlocked: false, name: 'Keşfedilmemiş tarif' });
    await expect(session.dispatch({ type: 'craft', recipeId: BIOME_RECIPE.ice })).rejects.toThrow();
  }, 20000);
});
