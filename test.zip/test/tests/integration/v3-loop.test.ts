import { afterEach, describe, expect, it } from 'vitest';
import type { GameCommand, VecXZ } from '../../src/contracts';
import { creatureById, creatures, itemById } from '../../src/content/catalog';
import { stats } from '../../src/game/combat/core';
import { ROLE_RULES, travelSpeed } from '../../src/game/roles';
import { createWorld } from '../../src/world/generation/world';
import { canOccupy } from '../../src/world/collision/collision';
import { hasLineOfSight } from '../../src/world/encounters/targets';
import { GAME_CONFIG } from '../../src/config';
import { CHUNK_GRID, chunkKey, spawnsForChunk } from '../../src/world/chunks/chunks';
import { DAY_TICKS } from '../../src/world/daynight';
import { nodeFor } from '../../src/world/gathering/gathering';
import { validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { IndexedDbSave } from '../../src/game/save/indexeddb';
import { GameSession, newGame } from '../../src/app/session';

const world = createWorld();
const rider = creatures.find((row) => row.roles.includes('ride'))!;
const clawed = creatures.find((row) => row.roles.includes('claw'))!;
const owned = (id: string, speciesId: string, level: number) => {
  const species = creatureById(speciesId)!;
  const maxHp = stats({ id, species, level }).maxHp;
  return { id, speciesId, level, xp: 0, hp: maxHp, maxHp };
};
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });
async function sessionWith(overrides: Partial<WorldState> = {}) {
  const save = await IndexedDbSave.open<WorldState>({
    name: `v3-${counter++}`, initial: () => ({ ...newGame(world), ...overrides }),
    validate: (value) => validateWorldState(world, value),
  });
  opened.push(save);
  return GameSession.open({ world, save, sessionId: `s${counter}` });
}
const move = (direction: VecXZ, tick: number): GameCommand => ({ type: 'move', direction, commandId: `m${tick}`, tick });
const team = (speciesId: string, level: number) => ({
  creatures: [owned('ally', speciesId, level)], party: ['ally'], activeCreatureId: 'ally',
});
const nearCamp = (position: VecXZ) => ({ playerPosition: { ...position }, lastSafePosition: { ...position } });

describe('the v3 loop on real modules', () => {
  it('mounts a grown creature, moves faster and gets off again', async () => {
    const session = await sessionWith(team(rider.id, ROLE_RULES.ride.unlockLevel));
    expect(session.state.mount).toBeNull();
    await session.toggleRide();
    expect(session.state.mount).toMatchObject({ creatureId: 'ally' });
    const mounted = travelSpeed({ mount: session.state.mount, creatures: session.state.creatures });
    expect(mounted).toBeGreaterThan(1);
    const before = session.position.x;
    for (let tick = 0; tick < 30; tick++) session.step({ move: move({ x: 1, z: 0 }, tick) });
    const ridden = session.position.x - before;

    const walker = await sessionWith(team(rider.id, ROLE_RULES.ride.unlockLevel));
    const start = walker.position.x;
    for (let tick = 0; tick < 30; tick++) walker.step({ move: move({ x: 1, z: 0 }, tick) });
    expect(ridden).toBeGreaterThan(walker.position.x - start);

    await session.toggleRide();
    expect(session.state.mount).toBeNull();
  });
  it('refuses a mount the creature is too young for and says why', async () => {
    const session = await sessionWith(team(rider.id, 2));
    await session.toggleRide();
    expect(session.state.mount).toBeNull();
    expect(session.view().hud.message).toContain('Sv');
  });
  it('picks loose material up in passing, exactly once', async () => {
    const picks = (() => {
      for (let z = 0; z < CHUNK_GRID; z += 2) for (let x = 0; x < CHUNK_GRID; x += 2) {
        for (const spawn of spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z })) {
          const node = nodeFor(world, spawn, [], 'day');
          if (node?.autoPick) return node;
        }
      }
      throw new Error('otomatik alınacak malzeme yok');
    })();
    const session = await sessionWith(nearCamp(picks.position));
    expect(session.state.consumedEntityIds).toEqual([]);
    for (let tick = 0; tick < 6; tick++) session.step({ move: move({ x: 0, z: 0 }, tick) });
    await new Promise((resolve) => setTimeout(resolve, 40));
    expect(session.state.consumedEntityIds).toContain(picks.entityId);
    const held = session.state.inventory.reduce((sum, stack) => sum + (stack?.itemId === picks.itemId ? stack.quantity : 0), 0);
    expect(held).toBeGreaterThan(0);
    // Standing on the same spot never takes it twice.
    for (let tick = 6; tick < 20; tick++) session.step({ move: move({ x: 0, z: 0 }, tick) });
    await new Promise((resolve) => setTimeout(resolve, 40));
    expect(session.state.consumedEntityIds.filter((id) => id === picks.entityId)).toHaveLength(1);
  });
  it('never asks for a key press over loose material, but still does over a tree', async () => {
    const find = (want: (node: ReturnType<typeof nodeFor>) => boolean) => {
      for (let z = 0; z < CHUNK_GRID; z += 2) for (let x = 0; x < CHUNK_GRID; x += 2) {
        for (const spawn of spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z }, 'night')) {
          const node = nodeFor(world, spawn, [clawed.id], 'night');
          if (node && want(node)) return node;
        }
      }
      throw new Error('aranan düğüm yok');
    };
    const loose = find((node) => !!node?.autoPick);
    const tree = find((node) => !!node?.treeKind);
    const stand = { x: loose.position.x + 4, z: loose.position.z };
    const walker = await sessionWith({ ...team(clawed.id, ROLE_RULES.claw.unlockLevel), ...nearCamp(stand), dayTick: DAY_TICKS + 5 });
    walker.step({ move: move({ x: 0, z: 0 }, 1) });
    const overMaterial = walker.view().card;
    expect(overMaterial?.entityId, 'malzeme kart açmaz').not.toBe(loose.entityId);

    const feller = await sessionWith({
      ...team(clawed.id, ROLE_RULES.claw.unlockLevel),
      ...nearCamp({ x: tree.position.x + 1.5, z: tree.position.z }), dayTick: DAY_TICKS + 5,
    });
    feller.step({ move: move({ x: 0, z: 0 }, 1) });
    expect(feller.view().card?.entityId, 'ağaç kart açar').toBe(tree.entityId);
  });
  it('fells a tree with a clawed team and refuses without one', async () => {
    const tree = (() => {
      for (let z = 0; z < CHUNK_GRID; z += 2) for (let x = 0; x < CHUNK_GRID; x += 2) {
        for (const spawn of spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z }, 'night')) {
          if (spawn.treeKind) return spawn;
        }
      }
      throw new Error('ağaç bulunamadı');
    })();
    const soft = creatures.find((row) => !row.roles.includes('claw'))!;
    const without = await sessionWith({ ...team(soft.id, 30), ...nearCamp(tree.target.position), dayTick: DAY_TICKS + 5 });
    await without.dispatch({ type: 'fell', entityId: tree.target.entityId });
    expect(without.state.consumedEntityIds).toEqual([]);
    expect(without.view().hud.message).toContain('pençeli');

    const armed = await sessionWith({
      ...team(clawed.id, ROLE_RULES.claw.unlockLevel), ...nearCamp(tree.target.position), dayTick: DAY_TICKS + 5,
    });
    await armed.dispatch({ type: 'fell', entityId: tree.target.entityId });
    expect(armed.state.consumedEntityIds).toContain(tree.target.entityId);
    expect(armed.state.inventory.some((stack) => stack?.itemId === tree.itemId)).toBe(true);
  });
  it('grafts a move from the camp panel and carries it into the next battle', async () => {
    const graftItem = 'graft_starfall';
    const session = await sessionWith({
      ...team(clawed.id, 20), atCamp: true,
      inventory: [{ itemId: graftItem, quantity: 1 }, null, null, null, null, null, null, null, null, null, null, null],
    });
    const row = session.view().camp.items.find((entry) => entry.itemId === graftItem)!;
    expect(row).toBeDefined();
    // The camp panel offers the graft as a graft, not as a salve.
    expect(row.intent).toEqual({ type: 'graft', creatureId: 'ally', moveId: graftItem });
    expect(row.usable).toBe(true);
    await session.dispatch(row.intent);
    expect(session.state.grafts).toEqual([{ creatureId: 'ally', moveId: 'starfall', tick: session.state.worldTick }]);
    expect(session.state.inventory.every((stack) => stack?.itemId !== graftItem)).toBe(true);
    expect(itemById(graftItem)?.effect?.kind).toBe('graft');
    // A second graft of the same move is refused and nothing is spent.
    await session.dispatch({ type: 'graft', creatureId: 'ally', moveId: graftItem });
    expect(session.state.grafts).toHaveLength(1);
  });
  it('lets an aggressor finish its warning and actually open the fight', async () => {
    // A forest patrol, and a spot within its reach the player can stand on and see it from.
    const gate = world.regions.find((region) => region.biomeId === 'forest')!.entrance;
    const half = GAME_CONFIG.worldSize / 2, size = GAME_CONFIG.chunkSize;
    const cx = Math.floor((gate.x + half) / size), cz = Math.floor((gate.z + half) / size);
    const hunters = [];
    for (let z = cz - 1; z <= cz + 1; z++) for (let x = cx - 1; x <= cx + 1; x++)
      for (const spawn of spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z }, 'day'))
        if (spawn.target.kind === 'creature' && spawn.target.aggressive) hunters.push(spawn.target);
    expect(hunters.length, 'ormanda saldırgan yok').toBeGreaterThan(0);
    const hunter = hunters.sort((a, b) => (a.entityId < b.entityId ? -1 : 1))[0]!;
    let stand: VecXZ | null = null;
    for (let radius = 4; radius <= 12 && !stand; radius++) for (let step = 0; step < 16 && !stand; step++) {
      const angle = step * Math.PI / 8;
      const spot = { x: hunter.position.x + Math.cos(angle) * radius, z: hunter.position.z + Math.sin(angle) * radius };
      if (canOccupy(world, spot) && hasLineOfSight(world, spot, hunter.position)) stand = spot;
    }
    expect(stand, 'duracak yer yok').toBeTruthy();
    const session = await sessionWith({ ...team(rider.id, 24), ...nearCamp(stand!), dayTick: 600 });
    let warnedTicks = 0;
    for (let tick = 0; tick < 400 && !session.view().battle; tick++) {
      session.step({ move: move({ x: 0, z: 0 }, tick) });
      if (session.view().hud.warning) warnedTicks++;
      // The battle is written durably, so the loop has to let that transaction finish.
      if (tick % 20 === 0) await new Promise((resolve) => setTimeout(resolve, 2));
    }
    // The aggressor warned first, and the warning turned into a real fight instead of a frozen world.
    expect(warnedTicks, 'saldırgan önce uyarır').toBeGreaterThan(0);
    expect(session.view().battle, 'uyarı gerçek savaşa dönüşür').toBeTruthy();
    expect(session.state.battle?.encounterId).toBe(hunter.entityId);
    expect(session.view().hud.message).toContain('Saldırıya uğradın');
  });
  it('keeps the world still while a panel is open, even with a mount under the player', async () => {
    const session = await sessionWith(team(rider.id, ROLE_RULES.ride.unlockLevel));
    await session.toggleRide();
    const at = session.position.x;
    await session.dispatch({ type: 'open-panel', panel: 'inventory' });
    for (let tick = 0; tick < 10; tick++) session.step({ move: move({ x: 1, z: 0 }, tick) });
    expect(session.position.x).toBe(at);
    await session.dispatch({ type: 'close-panel' });
    session.step({ move: move({ x: 1, z: 0 }, 11) });
    expect(session.position.x).toBeGreaterThan(at);
  });
});

describe('active tank capacity and movement', () => {
  const tank = creatures.find((row) => row.roles.includes('tank'))!;
  it('adds six slots once, slows walking and removes the bonus without losing items', async () => {
    const party = [owned('tank', tank.id, 14), owned('plain', rider.id, 24)];
    const session = await sessionWith({ creatures: party, party: ['tank', 'plain'], activeCreatureId: 'tank' });
    expect(session.state.inventory).toHaveLength(newGame(world).inventory.length + 6);
    expect(session.state.tankBonusSlots).toBe(6);
    await session.checkpoint();
    expect(session.state.inventory).toHaveLength(newGame(world).inventory.length + 6);
    const normal = await sessionWith(team(rider.id, 24));
    const start = session.position.x, normalStart = normal.position.x;
    for (let tick = 0; tick < 30; tick++) {
      session.step({ move: move({ x: 1, z: 0 }, tick) });
      normal.step({ move: move({ x: 1, z: 0 }, tick) });
    }
    expect((session.position.x - start) / (normal.position.x - normalStart)).toBeCloseTo(.7);
    await session.dispatch({ type: 'set-active', creatureId: 'plain' });
    expect(session.state.inventory).toHaveLength(newGame(world).inventory.length);
    expect(session.state.tankBonusSlots).toBe(0);
    await session.dispatch({ type: 'set-active', creatureId: 'tank' });
    expect(session.state.inventory).toHaveLength(newGame(world).inventory.length + 6);
  });
});
