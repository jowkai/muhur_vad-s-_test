import { readFileSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { describe, expect, it } from 'vitest';
import { creatureAssets, eggAssets, itemAssets, assetLayout } from '../../src/content/asset-manifest';
import { catalog } from '../../src/content/catalog';
import { BIOME_IDS } from '../../src/contracts';

const files = [
  ...Object.values(creatureAssets).flatMap((pair) => [pair.front, pair.back]),
  ...Object.values(eggAssets), ...Object.values(itemAssets),
];
const parseXml = (paths: readonly string[]) => JSON.parse(execFileSync('python3', ['-c', `
import json,sys,xml.etree.ElementTree as ET
result=[]
for path in json.loads(sys.argv[1]):
 root=ET.parse('public'+path).getroot()
 result.append({'path':path,'elements':[{'tag':el.tag.split('}')[-1],'attrs':el.attrib,'text':el.text} for el in root.iter()]})
print(json.dumps(result))
`, JSON.stringify(paths)], { encoding: 'utf8' })) as { path: string; elements: { tag: string; attrs: Record<string, string>; text: string | null }[] }[];

describe('original SVG asset manifest', () => {
  it('covers every catalog entry with 364 distinct local files', () => {
    expect(Object.keys(creatureAssets).sort()).toEqual(catalog.creatures.map((row) => row.id).sort());
    expect(Object.keys(itemAssets).sort()).toEqual(catalog.items.map((row) => row.id).sort());
    expect(Object.keys(eggAssets).sort()).toEqual([...BIOME_IDS].sort());
    expect(files).toHaveLength(364);
    expect(new Set(files).size).toBe(364);
    files.forEach((path) => {
      expect(path).toMatch(/^\/assets\/(creatures|eggs|items)\/[a-z_-]+\.svg$/);
      expect(existsSync(`public${path}`)).toBe(true);
    });
  });
  it('parses every SVG and rejects active content, external references and duplicate IDs', () => {
    const allIds = new Set<string>();
    for (const { path, elements } of parseXml(files)) {
      expect(elements[0].tag).toBe('svg');
      expect(elements[0].attrs.role).toBe('img');
      const expectedSize = path.includes('/creatures/') ? 320 : path.includes('/eggs/') ? 128 : 64;
      expect(elements[0].attrs.viewBox).toBe(`0 0 ${expectedSize} ${expectedSize}`);
      const titles = elements.filter((el) => el.tag === 'title');
      expect(titles).toHaveLength(1);
      expect(titles[0].text?.trim().length).toBeGreaterThan(0);
      expect(elements[0].attrs['aria-labelledby']).toBe(titles[0].attrs.id);
      for (const element of elements) {
        expect(['svg', 'title', 'g', 'path', 'ellipse', 'circle']).toContain(element.tag);
        for (const [key, value] of Object.entries(element.attrs)) {
          expect(key).not.toMatch(/^on|href|style/i);
          expect(value).not.toMatch(/https?:|javascript:|data:|url\(/i);
        }
        if (element.attrs.id) {
          expect(allIds.has(element.attrs.id)).toBe(false);
          allIds.add(element.attrs.id);
        }
      }
      expect(readFileSync(`public${path}`, 'utf8')).not.toMatch(/<!DOCTYPE|<!ENTITY|<script|foreignObject/i);
    }
  });
  it('has separately authored front/back geometry and a consistent anchor', () => {
    expect(assetLayout.creature).toEqual({ width: 320, height: 320, anchorX: 160, anchorY: 264 });
    for (const pair of Object.values(creatureAssets)) {
      const [front, back] = parseXml([pair.front, pair.back]);
      expect(front.elements.some((el) => el.attrs['data-part'] === 'face')).toBe(true);
      expect(back.elements.some((el) => el.attrs['data-part'] === 'face')).toBe(false);
      const paths = (tree: typeof front) => tree.elements.filter((el) => el.tag === 'path').map((el) => el.attrs.d);
      expect(paths(front)).not.toEqual(paths(back));
      expect(readFileSync(`public${pair.back}`, 'utf8')).not.toMatch(/scale\(\s*-1/);
    }
    // Structural checks supplement the rendered contact-sheet review; they cannot prove visual quality.
  });
});
