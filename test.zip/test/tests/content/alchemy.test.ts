import { describe, expect, it } from 'vitest';
import { IndexedDbSave } from '../../src/game/save/indexeddb';
import { craft, validateContentState, type ContentState } from '../../src/content/alchemy';
import { useCampItem } from '../../src/content/camp-use';
import { recipes } from '../../src/content/catalog';

function initial(inventory: ContentState['inventory'] = []): ContentState {
  return { mode: 'panel', atCamp: true, inventory: [...inventory, null, null, null], unlockedRecipeIds: recipes.map((recipe) => recipe.id), creatures: [{ id: 'friend', hp: 10, maxHp: 101 }] };
}
async function open(state: ContentState) {
  const opts = { name: crypto.randomUUID(), initial: () => structuredClone(state), validate: validateContentState };
  const save = await IndexedDbSave.open(opts);
  await save.transact('init', () => undefined);
  return { save, opts };
}
function count(state: ContentState, itemId: string) {
  return state.inventory.reduce((sum, stack) => sum + (stack?.itemId === itemId ? stack.quantity : 0), 0);
}
async function rejectsWithoutChange(state: ContentState, action: (save: IndexedDbSave<ContentState>) => Promise<unknown>, code: string) {
  const { save } = await open(state);
  try {
    const before = await save.exportRaw();
    await expect(action(save)).rejects.toMatchObject({ code });
    expect(await save.exportRaw()).toEqual(before);
  } finally { save.close(); }
}

describe('atomic alchemy', () => {
  it.each(recipes)('crafts $id from the exact ingredients', async (recipe) => {
    const { save } = await open(initial(recipe.inputs.map((input) => ({ ...input }))));
    try {
      const result = await craft(save, `craft-${recipe.id}`, recipe.id);
      expect(count(result, recipe.output.itemId)).toBe(recipe.output.quantity);
      for (const input of recipe.inputs) expect(count(result, input.itemId)).toBe(0);
    } finally { save.close(); }
  });
  it('applies 50 duplicate commands once, including after reopening', async () => {
    const { save, opts } = await open(initial([{ itemId: 'clay_shard', quantity: 50 }, { itemId: 'dew_leaf', quantity: 50 }]));
    const results = await Promise.all(Array.from({ length: 50 }, () => craft(save, 'seal-once', 'seal')));
    expect(results.every((state) => count(state, 'seal') === 2)).toBe(true);
    expect(count((await save.load())!, 'clay_shard')).toBe(48);
    save.close();
    const reopened = await IndexedDbSave.open(opts);
    try { expect(count(await craft(reopened, 'seal-once', 'seal'), 'seal')).toBe(2); }
    finally { reopened.close(); }
  });
  it('rejects incomplete ingredients without consuming the available ones', async () => {
    await rejectsWithoutChange(initial([{ itemId: 'dew_leaf', quantity: 2 }]), (save) => craft(save, 'missing', 'salve'), 'missing-items');
  });
  it('distinguishes a locked recipe from insufficient materials', async () => {
    await rejectsWithoutChange({ ...initial(), unlockedRecipeIds: [] }, (save) => craft(save, 'locked', 'salve'), 'locked');
  });
  it('rejects unknown recipes and battle crafting', async () => {
    await rejectsWithoutChange(initial(), (save) => craft(save, 'unknown', 'no-such-recipe'), 'invalid-recipe');
    await rejectsWithoutChange({ ...initial(), mode: 'battle' }, (save) => craft(save, 'battle', 'salve'), 'context');
  });
  it('rejects a full bag with no output space and preserves all inputs', async () => {
    const state = initial();
    state.inventory = [{ itemId: 'clay_shard', quantity: 4 }, { itemId: 'dew_leaf', quantity: 3 }, { itemId: 'seal', quantity: 20 }];
    await rejectsWithoutChange(state, (save) => craft(save, 'full', 'seal'), 'full');
  });
  it('uses slots freed by ingredients and splits output at stack limits', async () => {
    const state = initial();
    state.inventory = [{ itemId: 'clay_shard', quantity: 2 }, { itemId: 'dew_leaf', quantity: 1 }, { itemId: 'seal', quantity: 19 }];
    const { save } = await open(state);
    try {
      const result = await craft(save, 'split', 'seal');
      expect(result.inventory).toEqual([{ itemId: 'seal', quantity: 1 }, null, { itemId: 'seal', quantity: 20 }]);
    } finally { save.close(); }
  });
  it('rolls back inventory and ledger on storage failure, then retries exactly once', async () => {
    const { save, opts } = await open(initial([{ itemId: 'dew_leaf', quantity: 2 }, { itemId: 'soft_seed', quantity: 1 }]));
    const before = await save.exportRaw(); save.close();
    const faulty = await IndexedDbSave.open({ ...opts, fault: (point) => { if (point === 'after-ledger') throw new DOMException('quota', 'QuotaExceededError'); } });
    await expect(craft(faulty, 'retry', 'salve')).rejects.toMatchObject({ code: 'quota' });
    expect(await faulty.exportRaw()).toEqual(before); faulty.close();
    const reopened = await IndexedDbSave.open(opts);
    try { expect(count(await craft(reopened, 'retry', 'salve'), 'salve')).toBe(1); }
    finally { reopened.close(); }
  });
});

describe('camp item use', () => {
  it.each([['salve', 30], ['forest_balm', 55], ['tide_balm', 90], ['resonant_balm', 101]] as const)('uses %s to heal exactly once', async (itemId, expectedHp) => {
    const { save } = await open(initial([{ itemId, quantity: 2 }]));
    try {
      await Promise.all(Array.from({ length: 50 }, () => useCampItem(save, 'heal-once', itemId, 'friend')));
      const result = (await save.load())!;
      expect(result.creatures[0].hp).toBe(expectedHp);
      expect(count(result, itemId)).toBe(1);
    } finally { save.close(); }
  });
  it('clamps healing at maxHP', async () => {
    const state = initial([{ itemId: 'salve', quantity: 1 }]); state.creatures[0].hp = 100;
    const { save } = await open(state);
    try { expect((await useCampItem(save, 'clamp', 'salve', 'friend')).creatures[0].hp).toBe(101); }
    finally { save.close(); }
  });
  it.each([0, 101])('does not consume salve at invalid target HP %s', async (hp) => {
    const state = initial([{ itemId: 'salve', quantity: 1 }]); state.creatures[0].hp = hp;
    await rejectsWithoutChange(state, (save) => useCampItem(save, 'no-effect', 'salve', 'friend'), 'invalid-target');
  });
  it('revives only a fainted target to ceil(maxHP * .25)', async () => {
    const state = initial([{ itemId: 'waking_salt', quantity: 2 }]); state.creatures[0].hp = 0;
    const { save } = await open(state);
    try {
      const result = await useCampItem(save, 'revive', 'waking_salt', 'friend');
      expect(result.creatures[0].hp).toBe(26);
      expect(count(result, 'waking_salt')).toBe(1);
      const before = await save.exportRaw();
      await expect(useCampItem(save, 'alive', 'waking_salt', 'friend')).rejects.toMatchObject({ code: 'invalid-target' });
      expect(await save.exportRaw()).toEqual(before);
    } finally { save.close(); }
  });
  it.each([['egg_feed', 2], ['ember_incense', 5]] as const)('converts %s into heat herbs only once', async (itemId, quantity) => {
    const { save } = await open(initial([{ itemId, quantity: 2 }]));
    try {
      await Promise.all(Array.from({ length: 50 }, () => useCampItem(save, 'convert', itemId)));
      const result = (await save.load())!;
      expect(count(result, 'heat_herb')).toBe(quantity);
      expect(count(result, itemId)).toBe(1);
    } finally { save.close(); }
  });
  it('preserves the reagent when conversion cannot fit', async () => {
    const state = initial(); state.inventory = [{ itemId: 'egg_feed', quantity: 2 }, { itemId: 'heat_herb', quantity: 99 }];
    await rejectsWithoutChange(state, (save) => useCampItem(save, 'full-conversion', 'egg_feed'), 'full');
  });
  it('blocks field/battle use, invalid targets, missing items and the battle seal', async () => {
    const state = initial([{ itemId: 'salve', quantity: 1 }]);
    await rejectsWithoutChange({ ...state, atCamp: false }, (save) => useCampItem(save, 'field', 'salve', 'friend'), 'context');
    await rejectsWithoutChange({ ...state, mode: 'battle' }, (save) => useCampItem(save, 'battle', 'salve', 'friend'), 'context');
    await rejectsWithoutChange(state, (save) => useCampItem(save, 'target', 'salve', 'missing'), 'invalid-target');
    await rejectsWithoutChange(initial(), (save) => useCampItem(save, 'missing', 'salve', 'friend'), 'missing-items');
    await rejectsWithoutChange(initial([{ itemId: 'seal', quantity: 1 }]), (save) => useCampItem(save, 'seal', 'seal'), 'invalid-item');
  });
  it('rejects malformed projected save data', () => {
    const state = initial([{ itemId: 'salve', quantity: 21 }]);
    expect(() => validateContentState(state)).toThrow();
    state.inventory = [null]; state.creatures[0].hp = NaN;
    expect(() => validateContentState(state)).toThrow();
    expect(() => validateContentState(null)).toThrow();
  });
});
