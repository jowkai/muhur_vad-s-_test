import { describe, expect, it } from 'vitest';
import { BIOME_IDS, CREATURE_ROLES } from '../../src/contracts';
import { catalog, creatures, creaturesInBiome, items, recipes } from '../../src/content/catalog';
import { TRAIT_IDS, UNLOCK_CHANNELS } from '../../src/content/schema';
import { channelOf, cataloguedIn, milestoneFor, REGION_CATALOGUE_TARGET, unlocked } from '../../src/content/unlocks';
import { TRAIT_LABELS } from '../../src/game/combat/traits';

/**
 * v3 shipped twenty-four recipes no channel could ever teach, thirteen materials no recipe
 * consumed and four tools no code referenced. None of that was visible from a passing suite,
 * so this file makes dead content a failing test rather than an archaeology exercise.
 */
describe('nothing in the catalogue is unreachable', () => {
  it('gives every recipe exactly one channel that can pay it out', () => {
    for (const recipe of recipes) {
      const channel = channelOf(recipe.id);
      expect(UNLOCK_CHANNELS, recipe.id).toContain(channel);
    }
    // Every channel is actually used; an empty one would mean a rule nobody can reach.
    const used = new Set(recipes.map((recipe) => channelOf(recipe.id)));
    for (const channel of UNLOCK_CHANNELS) expect([...used], channel).toContain(channel);
  });

  it('can hand the whole recipe book to a player who does everything', () => {
    // A complete journal: every material held, every species seen, a maxed team covering all roles.
    const everything = {
      discoveredItemIds: items.filter((item) => item.biomeId).map((item) => item.id),
      seenSpeciesIds: creatures.map((species) => species.id),
      creatures: CREATURE_ROLES.map((role) => ({
        speciesId: creatures.find((species) => species.roles.includes(role))!.id, level: 50,
      })),
      unlockedRecipeIds: recipes.map((recipe) => recipe.id).filter((id) => channelOf(id) === 'shrine'),
    };
    for (const recipe of recipes) expect(unlocked(everything, recipe.id), recipe.id).toBe(true);
  });

  it('gives a brand new player only the recipe they start with', () => {
    const fresh = { discoveredItemIds: [], seenSpeciesIds: [], creatures: [], unlockedRecipeIds: [] };
    const open = recipes.filter((recipe) => unlocked(fresh, recipe.id));
    expect(open.map((recipe) => recipe.id)).toEqual(['salve']);
  });

  it('opens a region’s components only once that region is catalogued', () => {
    for (const biomeId of BIOME_IDS) {
      const region = creaturesInBiome(biomeId).map((species) => species.id);
      expect(region.length).toBeGreaterThanOrEqual(REGION_CATALOGUE_TARGET);
      const partial = { seenSpeciesIds: region.slice(0, REGION_CATALOGUE_TARGET - 1), unlockedRecipeIds: [] };
      const full = { seenSpeciesIds: region, unlockedRecipeIds: [] };
      expect(cataloguedIn(partial, biomeId)).toBeLessThan(REGION_CATALOGUE_TARGET);
      expect(cataloguedIn(full, biomeId)).toBeGreaterThanOrEqual(REGION_CATALOGUE_TARGET);
    }
  });

  it('spreads the advanced book across the levels rather than dumping it at one', () => {
    const milestones = recipes.filter((recipe) => channelOf(recipe.id) === 'milestone');
    expect(milestones.length).toBeGreaterThan(0);
    const levels = new Set(milestones.map((recipe) => milestoneFor(recipe.id)));
    expect(levels.size).toBeGreaterThanOrEqual(4);
    for (const level of levels) expect(level).toBeGreaterThanOrEqual(10);
  });

  it('consumes every gathered material and produces every crafted one', () => {
    const consumed = new Set(recipes.flatMap((recipe) => recipe.inputs.map((input) => input.itemId)));
    const produced = new Set(recipes.map((recipe) => recipe.output.itemId));
    for (const item of items) {
      if (item.biomeId) expect(consumed.has(item.id) || item.id === 'heat_herb', item.id).toBe(true);
      else expect(produced.has(item.id), item.id).toBe(true);
    }
  });

  it('carries every trait on a species and describes each one for the player', () => {
    for (const trait of TRAIT_IDS) {
      expect(creatures.some((species) => species.trait === trait), trait).toBe(true);
      expect(TRAIT_LABELS[trait]?.name, trait).toBeTruthy();
      expect(TRAIT_LABELS[trait]?.hint.length, trait).toBeGreaterThan(8);
    }
    expect(catalog.creatures.length).toBe(96);
  });
});
