import { afterEach, describe, expect, it } from 'vitest';
import { graftCapacity, MAX_GRAFTS_PER_CREATURE } from '../../src/contracts';
import { catalog, creatureById, movesOf } from '../../src/content/catalog';
import { defaultLoadout } from '../../src/content/loadout';
import { GRAFT_SLOTS, graftMove, graftMoveId, graftRefusal, graftedMoveIds, graftsOf, type GraftState } from '../../src/content/graft';
import { beginBattle, createBattle, movesFor, resolveBattle, stats } from '../../src/game/combat/core';
import { validateBattle } from '../../src/game/combat/rewards';
import { IndexedDbSave } from '../../src/game/save/indexeddb';

const GRAFT_ITEMS = catalog.items.filter((item) => item.effect?.kind === 'graft');
const species = creatureById('dewbud')!;
const own = (id = 'friend', level = 12) => {
  const maxHp = stats({ id, species, level }).maxHp;
  return { id, speciesId: species.id, level, xp: 0, hp: maxHp, maxHp };
};
function state(overrides: Partial<GraftState> = {}): GraftState {
  return {
    mode: 'exploring', atCamp: true,
    inventory: [{ itemId: GRAFT_ITEMS[0].id, quantity: 2 }, { itemId: GRAFT_ITEMS[1].id, quantity: 1 }, null, null],
    unlockedRecipeIds: [], creatures: [own()], grafts: [], worldTick: 90, ...overrides,
  } as GraftState;
}
let counter = 0;
const opened: IndexedDbSave<GraftState>[] = [];
async function storage(initial: GraftState) {
  const save = await IndexedDbSave.open<GraftState>({
    name: `graft-${counter++}`, initial: () => structuredClone(initial), validate: () => undefined,
  });
  opened.push(save); return save;
}
afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });

describe('graft items', () => {
  it('names the move each graft teaches', () => {
    expect(GRAFT_ITEMS.length).toBeGreaterThanOrEqual(8);
    for (const item of GRAFT_ITEMS) {
      const moveId = graftMoveId(item.id)!;
      expect(moveId, item.id).toBeTruthy();
      expect(catalog.moves.some((move) => move.id === moveId), item.id).toBe(true);
    }
    expect(graftMoveId('seal')).toBeNull();
    expect(graftMoveId('yok')).toBeNull();
  });
  it('replaces the finisher first and the middle move second, never the opener or the support', () => {
    // A graft lands in the loadout the creature carries, not across its whole learn set.
    const base = [...defaultLoadout(species.id)];
    const one = graftedMoveIds(species.id, ['starfall']);
    expect(one[GRAFT_SLOTS[0]]).toBe('starfall');
    expect(one[0]).toBe(base[0]);
    expect(one[2]).toBe(base[2]);
    const two = graftedMoveIds(species.id, ['starfall', 'cyclone']);
    expect(two[3]).toBe('starfall');
    expect(two[1]).toBe('cyclone');
    expect(two[0]).toBe(base[0]);
    expect(two[2]).toBe(base[2]);
    // A third graft is ignored below level twenty-five, and taken once the slot opens.
    expect(graftedMoveIds(species.id, ['starfall', 'cyclone', 'sunburst'])).toEqual(two);
    expect(graftedMoveIds(species.id, ['starfall', 'cyclone', 'sunburst'], 25)[GRAFT_SLOTS[2]]).toBe('sunburst');
    expect(graftedMoveIds(species.id, [base[0]])).toEqual(base);
    expect(graftedMoveIds(species.id, ['yok'])).toEqual(base);
  });
});

describe('grafting at camp', () => {
  it('spends the item once and writes the record', async () => {
    const save = await storage(state());
    const item = GRAFT_ITEMS[0].id;
    const after = await graftMove(save, 'graft-1', 'friend', item);
    expect(after.grafts).toEqual([{ creatureId: 'friend', moveId: graftMoveId(item), tick: 90 }]);
    expect(after.inventory[0]).toEqual({ itemId: item, quantity: 1 });
    // The same command twice is one graft.
    expect(await graftMove(save, 'graft-1', 'friend', item)).toEqual(after);
    await expect(graftMove(save, 'graft-2', 'friend', item)).rejects.toThrow();
  });
  it('refuses every case without touching a material', async () => {
    const item = GRAFT_ITEMS[0].id;
    const cases: [string, GraftState, string, string][] = [
      ['not a graft', state(), 'friend', 'seal'],
      ['unknown creature', state(), 'yok', item],
      ['missing item', state({ inventory: [null, null] }), 'friend', item],
      ['away from camp', state({ atCamp: false }), 'friend', item],
      ['in a battle', state({ mode: 'battle' }), 'friend', item],
      ['already known', state(), 'friend', graftItemFor(movesOf(species.id)[3].id) ?? item],
    ];
    for (const [label, current, creatureId, itemId] of cases) {
      const refusal = graftRefusal(current, creatureId, itemId);
      if (label === 'already known' && !graftItemFor(movesOf(species.id)[3].id)) continue;
      expect(refusal, label).toBeTruthy();
      const save = await storage(current);
      await save.transact('init', () => {});
      await expect(graftMove(save, `deny-${label}`, creatureId, itemId), label).rejects.toThrow();
      const stored = (await save.load())!;
      expect(stored.inventory, label).toEqual(current.inventory);
      expect(stored.grafts ?? [], label).toEqual(current.grafts ?? []);
    }
  });
  it('allows two grafts on one creature and refuses the third', async () => {
    const save = await storage(state({
      inventory: [{ itemId: GRAFT_ITEMS[0].id, quantity: 1 }, { itemId: GRAFT_ITEMS[1].id, quantity: 1 }, { itemId: GRAFT_ITEMS[2].id, quantity: 1 }, null],
    }));
    await graftMove(save, 'g1', 'friend', GRAFT_ITEMS[0].id);
    const second = await graftMove(save, 'g2', 'friend', GRAFT_ITEMS[1].id);
    // A young creature holds two; the third and fourth slots are a level reward.
    expect(second.grafts).toHaveLength(graftCapacity(1));
    expect(graftsOf(second.grafts, 'friend')).toHaveLength(2);
    await expect(graftMove(save, 'g3', 'friend', GRAFT_ITEMS[2].id)).rejects.toThrow();
  });
  it('opens a third graft slot at twenty-five and a fourth at forty', () => {
    expect(graftCapacity(1)).toBe(2);
    expect(graftCapacity(24)).toBe(2);
    expect(graftCapacity(25)).toBe(3);
    expect(graftCapacity(39)).toBe(3);
    expect(graftCapacity(40)).toBe(MAX_GRAFTS_PER_CREATURE);
    expect(graftCapacity(0)).toBe(0);
  });
});

describe('a grafted move in a battle', () => {
  const grafted = ['starfall'];
  const fighter = { id: 'friend', species, level: 20, grafts: grafted };
  it('is the move the battle actually offers and uses', () => {
    const plain = movesFor({ id: 'plain', species, level: 20 }).map((move) => move.id);
    const armed = movesFor(fighter).map((move) => move.id);
    expect(armed).not.toEqual(plain);
    expect(armed[3]).toBe('starfall');
    const battle = beginBattle(createBattle({
      battleId: 'b', encounterId: 'e', seed: 21, player: fighter,
      enemy: { id: 'wild', species: creatureById('snowspool')!, level: 8 },
    }));
    const result = resolveBattle(battle, { type: 'attack', slot: 3, commandId: 'a', tick: 1 });
    expect(result.accepted).toBe(true);
    expect(result.state.player.grafts).toEqual(grafted);
    expect(() => validateBattle(result.state)).not.toThrow();
    // The record survives a reload with its grafts intact.
    const reloaded = JSON.parse(JSON.stringify(result.state)) as typeof result.state;
    expect(() => validateBattle(reloaded)).not.toThrow();
    expect(movesFor(reloaded.player).map((move) => move.id)).toEqual(armed);
  });
  it('refuses a battle record with a forged graft list', () => {
    const battle = beginBattle(createBattle({
      battleId: 'b', encounterId: 'e', seed: 3, player: fighter,
      enemy: { id: 'wild', species: creatureById('snowspool')!, level: 8 },
    }));
    for (const forged of [['yok'], ['starfall', 'starfall'], ['starfall', 'cyclone', 'sunburst']]) {
      const broken = { ...structuredClone(battle), player: { ...battle.player, grafts: forged } };
      expect(() => validateBattle(broken), forged.join(',')).toThrow();
    }
  });
});
function graftItemFor(moveId: string): string | null {
  return GRAFT_ITEMS.find((item) => graftMoveId(item.id) === moveId)?.id ?? null;
}
