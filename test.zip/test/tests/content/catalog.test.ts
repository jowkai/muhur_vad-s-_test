import { describe, expect, it } from 'vitest';
import seed from '../../design/catalog.seed.json';
import { catalog, creatureById, creaturesInBiome, eggVariants, itemById, recipeById, tutorialEgg } from '../../src/content/catalog';
import { CatalogError, parseCatalog } from '../../src/content/schema';
import { BIOME_IDS } from '../../src/contracts';
import { TRAIT_IDS } from '../../src/content/schema';

describe('MVP content catalog', () => {
  it('preserves the design species, items and all eighty-eight enabled recipes', () => {
    expect(catalog.creatures).toEqual(seed.creatures);
    expect(catalog.items).toEqual(seed.items);
    expect(catalog.recipes).toEqual(seed.recipes);
    expect(catalog.creatures).toHaveLength(96);
    expect(catalog.items.filter((item) => item.biomeId)).toHaveLength(76);
    // v4's middle tier: crafted, inert, and legal as another recipe's input.
    expect(catalog.items.filter((item) => item.craftTier)).toHaveLength(32);
    expect(catalog.items.filter((item) => item.effect)).toHaveLength(56);
    expect(catalog.items.filter((item) => item.effect?.kind === 'tool')).toHaveLength(8);
    expect(catalog.items.filter((item) => item.effect?.kind === 'graft')).toHaveLength(14);
    expect(catalog.items.filter((item) => item.effect?.kind === 'speed')).toHaveLength(4);
    // Six material classes, every one of them actually used.
    for (const itemClass of ['plant', 'mineral', 'gem', 'part', 'essence', 'wood'] as const) {
      expect(catalog.items.filter((item) => 'itemClass' in item && item.itemClass === itemClass).length, itemClass).toBeGreaterThan(0);
    }
    expect(catalog.recipes).toHaveLength(88);
    expect(catalog.recipes.every((recipe) => recipe.enabledInMvp)).toBe(true);
  });
  it('covers each biome with twelve species, a night dweller and a valid egg variant', () => {
    expect(eggVariants).toHaveLength(8);
    for (const biome of BIOME_IDS) {
      const species = creaturesInBiome(biome);
      expect(species, biome).toHaveLength(12);
      expect(species.filter((entry) => entry.rarity === 'common'), biome).toHaveLength(6);
      expect(species.filter((entry) => entry.rarity === 'uncommon'), biome).toHaveLength(3);
      expect(species.filter((entry) => entry.rarity === 'rare'), biome).toHaveLength(2);
      expect(species.filter((entry) => entry.rarity === 'legendary'), biome).toHaveLength(1);
      expect(species.every((entry) => entry.roles.length <= 2), biome).toBe(true);
      expect(species.every((entry) => entry.baseSpeed >= 0.5 && entry.baseSpeed <= 2.5), biome).toBe(true);
      expect(species.some((entry) => entry.activity === 'night'), biome).toBe(true);
      // v4: a learn set is eight moves; the four carried into a fight are the loadout.
      expect(species.every((entry) => entry.moveIds.length === 8), biome).toBe(true);
      expect(species.every((entry) => TRAIT_IDS.includes(entry.trait)), biome).toBe(true);
      expect(eggVariants.find((egg) => egg.biomeId === biome)?.eligibleSpeciesIds).toEqual(species.map((entry) => entry.id));
    }
    expect(creatureById(tutorialEgg.speciesId)).toMatchObject({ biomeId: 'meadow', rarity: 'common' });
    expect(tutorialEgg.level).toBe(1);
  });
  it('keeps capture in battle and healing/incubation products in camp', () => {
    expect(itemById('seal')?.effect).toEqual({ kind: 'capture_consumable', value: null, context: 'battle' });
    expect(itemById('seal_fine')?.effect).toEqual({ kind: 'capture_consumable', value: 0.05, context: 'battle' });
    expect(itemById('seal_true')?.effect).toEqual({ kind: 'capture_consumable', value: 0.1, context: 'battle' });
    expect(itemById('field_salve')?.effect).toEqual({ kind: 'heal', value: 35, context: 'battle' });
    expect(itemById('waking_salt')?.effect).toEqual({ kind: 'revive_fraction', value: 0.25, context: 'camp' });
    expect(itemById('egg_feed')?.effect).toEqual({ kind: 'grant_heat_herb', value: 2, context: 'camp' });
    expect(itemById('ember_incense')?.effect).toEqual({ kind: 'grant_heat_herb', value: 5, context: 'camp' });
    expect(recipeById('seal')?.output).toEqual({ itemId: 'seal', quantity: 2 });
    expect(creatureById('missing')).toBeUndefined();
    expect(itemById('missing')).toBeUndefined();
    expect(recipeById('missing')).toBeUndefined();
  });
  it('isolates and deeply freezes data so consumers cannot change game balance', () => {
    const source = structuredClone(seed);
    const parsed = parseCatalog(source);
    const at = (id: string) => parsed.creatures.find((entry) => entry.id === id)!;
    source.creatures.find((entry) => entry.id === 'dewbud')!.name = 'changed';
    expect(at('dewbud').name).toBe('Çiytomur');
    expect(Object.isFrozen(parsed.items[25].effect)).toBe(true);
    expect(Object.isFrozen(parsed.recipes[0].inputs)).toBe(true);
    expect(() => Reflect.set(at('dewbud'), 'baseHp', 999)).not.toThrow();
    expect(at('dewbud').baseHp).toBe(8);
  });
  const invalid: [string, (copy: typeof seed) => void][] = [
    ['duplicate species', (copy) => { copy.creatures[1].id = copy.creatures[0].id; }],
    ['missing species', (copy) => { copy.creatures.pop(); }],
    ['wrong biome', (copy) => { copy.creatures[0].biomeId = 'void'; }],
    ['unbalanced biome coverage', (copy) => { copy.creatures[0].biomeId = 'forest'; }],
    ['invalid stats', (copy) => { copy.creatures[0].baseHp = NaN; }],
    ['wrong rarity', (copy) => { copy.items[0].rarity = 'legend'; }],
    ['wrong element', (copy) => { copy.creatures[0].element = 'unknown'; }],
    ['invalid stack', (copy) => { copy.items[0].stackLimit = 0; }],
    ['unknown ingredient', (copy) => { copy.recipes[0].inputs[0].itemId = 'missing'; }],
    ['duplicate ingredient', (copy) => { copy.recipes[0].inputs.push(copy.recipes[0].inputs[0]); }],
    ['negative quantity', (copy) => { copy.recipes[0].output.quantity = -1; }],
    ['fractional quantity', (copy) => { copy.recipes[0].inputs[0].quantity = 0.5; }],
    ['stack overflow', (copy) => { copy.recipes[0].output.quantity = 21; }],
    ['material output', (copy) => { copy.recipes[0].output.itemId = 'dew_leaf'; }],
    ['duplicate output', (copy) => { copy.recipes[0].output.itemId = 'seal'; }],
    ['disabled recipe', (copy) => { copy.recipes[0].enabledInMvp = false; }],
    ['free recipe', (copy) => { copy.recipes[0].inputs = []; }],
    ['battle incubation', (copy) => { copy.items[27].effect!.context = 'battle'; }],
    ['seal without a battle context', (copy) => { copy.items[26].effect!.context = 'camp'; }],
    ['repeated seal tier', (copy) => { copy.items[34].effect!.value = 0.1; }],
    ['seal tier above the cap', (copy) => { copy.items[34].effect!.value = 0.35; }],
    ['unknown effect', (copy) => { copy.items[25].effect!.kind = 'win'; }],
    ['invalid revive', (copy) => { copy.items[30].effect!.value = 2; }],
    ['unsupported schema', (copy) => { copy.schemaVersion = 4; }],
    // v4 guards: dead content is now a parse error, not something to notice years later.
    ['a material no recipe consumes', (copy) => { copy.recipes = copy.recipes.filter((r) => r.id !== 'dew_extract'); }],
    ['a trait no species carries', (copy) => { copy.creatures.forEach((c) => { if (c.trait === 'yanki') c.trait = 'berserk'; }); }],
    ['a finished product used as an input', (copy) => { copy.recipes[0].inputs[0].itemId = 'salve'; }],
  ];
  it.each(invalid)('rejects %s with a diagnostic path', (_label, mutate) => {
    const source = structuredClone(seed); mutate(source);
    expect(() => parseCatalog(source)).toThrow(CatalogError);
  });
  it.each([null, {}, [], { ...seed, items: null }])('rejects malformed root data', (source) => {
    expect(() => parseCatalog(source)).toThrow(CatalogError);
  });
});
