import { describe, expect, it } from 'vitest';
import { creatures, moveById, moves, movesOf } from '../../src/content/catalog';
import { ELEMENTS, NEUTRAL, STRONG, WEAK, elementEffectiveness, strongAgainst } from '../../src/content/elements';
import { elementMultiplier } from '../../src/game/combat/core';
import type { Element } from '../../src/content/schema';
import { UNLOCK_TIERS } from '../../src/content/schema';
import { defaultLoadout } from '../../src/content/loadout';

const SUPPORT = ['guard', 'mend', 'cleanse', 'shield', 'haste', 'bulwark', 'charge'];
const BANDS = [[1, 3, 6], [10, 15, 20], [25, 30, 35], [40, 45, 50]];

describe('move pool', () => {
  it('holds 72 moves in twelve unlock tiers inside the published bands', () => {
    expect(moves).toHaveLength(72);
    expect(new Set(moves.map((move) => move.id)).size).toBe(72);
    for (const level of UNLOCK_TIERS) {
      expect(moves.filter((move) => move.unlockLevel === level), `tier ${level}`).toHaveLength(6);
    }
    for (const move of moves) {
      expect(move.accuracy, move.id).toBeGreaterThanOrEqual(0.7);
      expect(move.accuracy, move.id).toBeLessThanOrEqual(1);
      expect(move.cost, move.id).toBeGreaterThanOrEqual(0);
      expect(move.cost, move.id).toBeLessThanOrEqual(5);
      if (SUPPORT.includes(move.effect ?? '')) expect(move.power, move.id).toBe(0);
      else {
        expect(move.power, move.id).toBeGreaterThanOrEqual(6);
        expect(move.power, move.id).toBeLessThanOrEqual(34);
      }
      if (move.element !== null) expect(ELEMENTS, move.id).toContain(move.element);
    }
    // Stronger moves cost more: the top tier is never cheaper than the opening tier.
    const cheapest = Math.min(...moves.filter((move) => move.unlockLevel === 50).map((move) => move.cost));
    const dearest = Math.max(...moves.filter((move) => move.unlockLevel === 1 && !SUPPORT.includes(move.effect ?? '')).map((move) => move.cost));
    expect(cheapest).toBeGreaterThan(dearest);
    // Every element reaches every band, so no species has a stretch of levels that teaches it nothing.
    for (const element of ELEMENTS) {
      for (const band of BANDS) {
        expect(moves.some((move) => move.element === element && band.includes(move.unlockLevel)),
          `${element} ${band[0]}-${band[band.length - 1]}`).toBe(true);
      }
    }
  });
  it('gives every species an eight-move learn set that keeps opening with level', () => {
    for (const species of creatures) {
      const set = movesOf(species.id);
      expect(set, species.id).toHaveLength(8);
      expect(new Set(set.map((move) => move.id)).size, species.id).toBe(8);
      const supports = set.filter((move) => SUPPORT.includes(move.effect ?? ''));
      expect(supports.length, species.id).toBeGreaterThanOrEqual(1);
      expect(supports.length, species.id).toBeLessThanOrEqual(2);
      expect(set.some((move) => move.element === species.element), species.id).toBe(true);
      expect(set.filter((move) => move.unlockLevel === 1).length, species.id).toBeGreaterThanOrEqual(2);
      // The point of the v4 curve: something still opens above twenty-five.
      expect(set.filter((move) => move.unlockLevel >= 25).length, species.id).toBeGreaterThanOrEqual(2);
      for (const band of BANDS) {
        expect(set.some((move) => band.includes(move.unlockLevel)), `${species.id} ${band[0]}`).toBe(true);
      }
      expect(set.every((move) => moveById(move.id)), species.id).toBe(true);
      // A fresh creature can press all four of its default slots from level one.
      expect(defaultLoadout(species.id), species.id).toHaveLength(4);
    }
    // Species are not clones of one another: at least eight distinct sets across the roster.
    const shapes = new Set(creatures.map((species) => species.moveIds.join('|')));
    expect(shapes.size).toBeGreaterThanOrEqual(8);
    expect(movesOf('yok')).toEqual([]);
  });
  it('carries every status effect the battle layer will need', () => {
    for (const effect of ['poison', 'burn', 'slow', 'weaken', 'drain', 'charge', 'cleanse', 'shield', 'haste', 'bulwark']) {
      expect(moves.filter((move) => move.effect === effect).length, effect).toBeGreaterThan(0);
    }
    expect(moves.filter((move) => move.effect === 'guard')).toHaveLength(1);
    expect(moves.filter((move) => move.effect === 'mend')).toHaveLength(1);
  });
});

describe('element table', () => {
  it('keeps every pairing inside the three published values', () => {
    for (const attack of ELEMENTS) {
      for (const defense of ELEMENTS) {
        expect([WEAK, NEUTRAL, STRONG], `${attack}->${defense}`).toContain(elementEffectiveness(attack, defense));
      }
      expect(elementEffectiveness(attack, attack), attack).toBe(NEUTRAL);
      expect(strongAgainst(attack).length).toBeGreaterThan(0);
    }
    expect(elementEffectiveness(null, 'kor')).toBe(NEUTRAL);
  });
  it('mirrors advantage and disadvantage except for the light/shadow pair', () => {
    for (const attack of ELEMENTS) {
      for (const defense of ELEMENTS) {
        if (attack === defense) continue;
        const forward = elementEffectiveness(attack, defense);
        const back = elementEffectiveness(defense, attack);
        if (forward === STRONG && back === STRONG) {
          expect(new Set([attack, defense])).toEqual(new Set<Element>(['ışık', 'gölge']));
          continue;
        }
        if (forward === STRONG) expect(back, `${defense}->${attack}`).toBe(WEAK);
        if (forward === WEAK) expect(back, `${defense}->${attack}`).toBe(STRONG);
      }
    }
  });
  it('keeps the three designed cycles and grounds the spark', () => {
    expect(elementEffectiveness('çim', 'su')).toBe(STRONG);
    expect(elementEffectiveness('su', 'kor')).toBe(STRONG);
    expect(elementEffectiveness('kor', 'çim')).toBe(STRONG);
    expect(elementEffectiveness('buz', 'taş')).toBe(STRONG);
    expect(elementEffectiveness('taş', 'rüzgâr')).toBe(STRONG);
    expect(elementEffectiveness('rüzgâr', 'buz')).toBe(STRONG);
    expect(elementEffectiveness('ışık', 'gölge')).toBe(STRONG);
    expect(elementEffectiveness('gölge', 'ışık')).toBe(STRONG);
    expect(elementEffectiveness('kıvılcım', 'su')).toBe(STRONG);
    expect(elementEffectiveness('kıvılcım', 'taş')).toBe(WEAK);
  });
  it('is the only table: combat delegates instead of keeping a copy', () => {
    for (const attack of ELEMENTS) {
      for (const defense of ELEMENTS) {
        expect(elementMultiplier(attack, defense), `${attack}->${defense}`).toBe(elementEffectiveness(attack, defense));
      }
    }
    expect(elementMultiplier(null, 'su')).toBe(NEUTRAL);
  });
});
