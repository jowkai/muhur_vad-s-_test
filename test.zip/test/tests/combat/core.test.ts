import { describe, expect, it } from 'vitest';
import { creatureById } from '../../src/content/catalog';

const base = creatureById('puffkip')!;
import { beginBattle, createBattle, damage, elementMultiplier, enemyMove, movesFor, randomStep, resolveBattle, stats } from '../../src/game/combat/core';
import type { GameCommand } from '../../src/contracts';

const fighter = (level = 2) => ({ id: 'friend', species: base, level });
const initial = (level = 2, seed = 1) => beginBattle(createBattle({ battleId: 'battle', encounterId: 'wild', seed, player: fighter(level), enemy: { ...fighter(level), id: 'enemy' } }));
const attack = (slot: 0 | 1 | 2 | 3 = 0, id = 'a'): GameCommand => ({ type: 'attack', slot, commandId: id, tick: 1 });

describe('deterministic combat core', () => {
  it('has a fixed xorshift fixture and zero fallback', () => {
    expect(randomStep(1)).toEqual({ state: 270369, value: 270369 / 4294967296 });
    expect(randomStep(0)).toEqual(randomStep(0x6d2b79f5));
    expect(stats(fighter())).toEqual({ maxHp: 44, atk: 10, def: 5 });
  });
  it('resolves a fixed seed/action fixture without mutating the input', () => {
    const state = initial(); const before = structuredClone(state);
    const result = resolveBattle(state, attack());
    expect(state).toEqual(before);
    expect(result.state).toMatchObject({ playerHp: 32, enemyHp: 28, turn: 2, rngState: 307599695, stamina: 5, enemyStamina: 5 });
    expect(result.receipt?.events).toEqual([
      { type: 'attack', side: 'player', slot: 0, hit: true, damage: 16 },
      { type: 'attack', side: 'enemy', slot: 1, hit: true, damage: 12 }, { type: 'turn-end' },
    ]);
  });
  it('replays 100 commands identically including a serialized resume', () => {
    const commands = Array.from({ length: 100 }, (_, i) => attack(i % 3 === 0 ? 2 : 0, `action-${i}`));
    const run = () => commands.reduce((s, c) => resolveBattle(s, c).state, initial(6, 481));
    const first = commands.slice(0, 2).reduce((s, c) => resolveBattle(s, c).state, initial(6, 481));
    const resumed = commands.slice(2).reduce((s, c) => resolveBattle(s, c).state, JSON.parse(JSON.stringify(first)) as typeof first);
    expect(run()).toEqual(run()); expect(resumed).toEqual(run());
  });
  it('rejects locked, unaffordable, unsupported and malformed actions without changes', () => {
    const state = initial(); state.stamina = 0;
    // Slot 0 and the support slot both cost energy; slot 3 is the finisher this level has not reached.
    for (const command of [attack(0), attack(3), attack(2), { type: 'capture', commandId: 'c', tick: 1 } as GameCommand, { ...attack(), tick: -1 }]) {
      const r = resolveBattle(state, command); expect(r.accepted).toBe(false); expect(r.state).toBe(state);
    }
    // The free opener is exactly what an exhausted fighter still has, so it is accepted.
    expect(movesFor(state.player)[1].cost).toBe(0);
    expect(resolveBattle(state, attack(1, 'free')).accepted).toBe(true);
    for (const phase of ['INTRO', 'RESOLVE_PLAYER', 'RESOLVE_ENEMY', 'TURN_END', 'WON', 'LOST', 'FLED'] as const) {
      const blocked = { ...state, phase };
      expect(resolveBattle(blocked, attack()).accepted).toBe(false);
      expect(resolveBattle(blocked, attack()).state).toBe(blocked);
    }
    expect(resolveBattle({ ...state, playerHp: 0 }, attack()).accepted).toBe(false);
    expect(resolveBattle({ ...state, enemyHp: 0 }, attack()).accepted).toBe(false);
  });
  it('returns original receipts 50 times without rewinding newer state, including reserved keys', () => {
    const first = resolveBattle(initial(), attack(2, '__proto__'));
    const second = resolveBattle(first.state, attack(0, 'second'));
    for (let i = 0; i < 50; i++) {
      const duplicate = resolveBattle(second.state, attack(2, '__proto__'));
      expect(duplicate.state).toBe(second.state); expect(duplicate.duplicate).toBe(true); expect(duplicate.receipt).toEqual(first.receipt);
    }
    expect(resolveBattle(second.state, attack(0, '__proto__')).accepted).toBe(false);
  });
  it('uses exactly two rolls per damaging action, even a miss', () => {
    let seed = 1; while (randomStep(seed).value < .98) seed++;
    const state = initial(2, seed); const r = resolveBattle(state, attack());
    expect(r.receipt?.events[0]).toMatchObject({ hit: false, damage: 0 });
    let expected = seed; for (let i = 0; i < 4; i++) expected = randomStep(expected).state;
    expect(r.state.rngState).toBe(expected);
  });
  it('applies elemental multipliers and guard before flooring', () => {
    const a = fighter(); const b = { ...fighter(), species: { ...base, element: 'su' as const } };
    expect(elementMultiplier('çim', 'su')).toBe(1.25); expect(elementMultiplier('su', 'çim')).toBe(.8);
    expect(elementMultiplier('ışık', 'çim')).toBe(1);
    expect(damage(8, a, b, 0, false)).toBe(12); expect(damage(8, a, b, 0, true)).toBe(6);
    expect(damage(8, a, b, 1 - Number.EPSILON, false)).toBe(14);
    // Same-element moves carry the v4 bonus; a typeless one never does.
    expect(damage(8, a, b, 0, false, false, 'rüzgâr')).toBe(13);
    expect(damage(8, a, b, 0, false, false, null)).toBe(12);
    const tank = { ...b, species: { ...b.species, baseDef: 10000 } };
    expect(damage(8, a, tank, 0, true)).toBe(1);
  });
  it('uses strict hit comparison on both sides of every attack accuracy', () => {
    const slotAccuracy = (slot: 0 | 1 | 3) => movesFor(fighter(6))[slot].accuracy;
    for (const slot of [0, 1, 3] as const) {
      const accuracy = slotAccuracy(slot);
      // Invert xorshift32 to arrange adjacent representable RNG values around the threshold.
      const invert = (value: number) => {
        let x = value; for (let i = 0; i < 7; i++) x = value ^ (x << 5);
        const y = x; for (let i = 0; i < 2; i++) x = y ^ (x >>> 17);
        const z = x; for (let i = 0; i < 3; i++) x = z ^ (x << 13);
        return x >>> 0;
      };
      const above = Math.ceil(accuracy * 4294967296);
      for (const [raw, hit] of [[above - 1, true], [above, false]] as const) {
        const seed = invert(raw); expect(randomStep(seed).state).toBe(raw);
        expect(resolveBattle(initial(6, seed), attack(slot)).receipt?.events[0].hit).toBe(hit);
      }
    }
  });
  it('guard costs energy, consumes no dice and halves the next hit', () => {
    const state = initial(); const result = resolveBattle(state, attack(2));
    expect(result.receipt?.events[0]).toEqual({ type: 'guard', side: 'player', slot: 2 });
    expect(result.state.rngState).toBe(randomStep(randomStep(1).state).state);
    expect(result.state.playerHp).toBe(38); expect(result.state.status.playerGuard).toBe(false);
    expect(result.state.stamina).toBe(5);
  });
  it('expires guard at own action and applies enemy guard before its next action', () => {
    const state = initial(); state.status.playerGuard = true;
    expect(resolveBattle(state, attack()).state.playerHp).toBe(32);
    state.status.enemyGuard = true;
    expect(resolveBattle(state, attack()).receipt?.events[0]).toMatchObject({ damage: 8 });
  });
  it('AI respects level, energy and strict low-health boundary without consecutive guards', () => {
    // The default loadout opens with a free move, so a low-level fighter still has a real attack.
    for (const [level, slot] of [[2, 1], [3, 3], [5, 3], [6, 3]] as const) expect(enemyMove(initial(level))).toBe(slot);
    const s = initial(6); s.enemyStamina = 1; expect(enemyMove(s)).toBe(3);
    s.enemyHp = stats(s.enemy).maxHp * .3; expect(enemyMove(s)).toBe(3);
    s.enemyHp -= .001; expect(enemyMove(s)).toBe(2);
    s.status.enemyLastSlot = 2; expect(enemyMove(s)).toBe(3);
    // Slow can drain a fighter below every price of its set: it rests rather than paying.
    const priced = initial(6);
    priced.enemy.loadout = ['vine_lash', 'strike', 'guard', 'rootquake'];
    priced.enemyStamina = 0;
    expect(enemyMove(priced)).toBeNull();
  });
  it('unlocks player moves and restores only one stamina at turn end', () => {
    const state = initial(6);
    const cost = movesFor(state.player)[3].cost;
    const result = resolveBattle(state, attack(3));
    // One turn spends the move's price and hands exactly one point back.
    expect(result.accepted).toBe(true); expect(result.state.stamina).toBe(5 - cost + 1);
    const again = resolveBattle(result.state, attack(3, 'again'));
    expect(again.accepted).toBe(true); expect(again.state.stamina).toBe(5 - 2 * cost + 2);
    // A slot the creature has not grown into is refused; the tier below it is not.
    expect(resolveBattle(initial(2), attack(3)).accepted).toBe(false);
    expect(resolveBattle(initial(3), attack(3)).accepted).toBe(true);
    expect(resolveBattle(initial(3), attack(1)).accepted).toBe(true);
  });
  it('clamps lethal HP and never answers a lethal player hit or advances terminal turns', () => {
    const s = initial(); s.enemyHp = 1;
    const won = resolveBattle(s, attack());
    expect(won.state).toMatchObject({ phase: 'WON', enemyHp: 0, playerHp: 44, turn: 1 });
    expect(won.receipt?.events).toHaveLength(2);
    expect(resolveBattle(won.state, attack(0, 'late')).state).toBe(won.state);
    const losing = initial(); losing.playerHp = 1;
    const lost = resolveBattle(losing, attack()); expect(lost.state).toMatchObject({ phase: 'LOST', playerHp: 0, turn: 1 });
    expect(resolveBattle(lost.state, attack(0, 'late')).accepted).toBe(false);
  });
  it('flee uses one die on success, with one enemy reply on failure', () => {
    const command: GameCommand = { type: 'flee', commandId: 'escape', tick: 1 };
    expect(resolveBattle(initial(), command).state).toMatchObject({ phase: 'FLED', rngState: 270369 });
    let seed = 1; while (randomStep(seed).value < .75) seed++;
    const r = resolveBattle(initial(2, seed), command);
    expect(r.state.phase).toBe('PLAYER_INPUT'); expect(r.receipt?.events.filter(e => e.side === 'enemy')).toHaveLength(1);
    let mid = 1; while (randomStep(mid).value < .45 || randomStep(mid).value >= .75) mid++;
    const normal = initial(2, mid); expect(resolveBattle(normal, command).state.phase).toBe('FLED');
    normal.aggressive = true; expect(resolveBattle(normal, command).state.phase).toBe('PLAYER_INPUT');
  });
  it('rejects invalid initial HP/levels and isolates input and returned receipt data', () => {
    expect(() => initial(0)).toThrow();
    expect(() => createBattle({ battleId: 'b', encounterId: 'e', seed: 1, player: fighter(), enemy: fighter(), playerHp: 0 })).toThrow();
    const s = initial(); const r = resolveBattle(s, attack());
    r.receipt!.snapshot.playerHp = 999;
    expect(r.state.committedActions.a.snapshot.playerHp).toBe(32);
  });
});
