import { afterEach, describe, expect, it } from 'vitest';
import type { GameCommand } from '../../src/contracts';
import { creatureById, itemById, items } from '../../src/content/catalog';
import {
  battleItemHeal, beginBattle, captureChance, createBattle, resolveBattle, sealChoice, sealTiers, stats,
  type BattleState, type Fighter,
} from '../../src/game/combat/core';
import { applyBattleCommand, createLootPlan, validateBattle, validateProgressState, type ProgressState } from '../../src/game/combat/rewards';
import { IndexedDbSave } from '../../src/game/save/indexeddb';

const player: Fighter = { id: 'friend', species: creatureById('dewbud')!, level: 6 };
const enemy: Fighter = { id: 'wild', species: creatureById('snowspool')!, level: 2 };
const maxHp = stats(player).maxHp;
function battle(inventory: Record<string, number>, playerHp = maxHp - 20, enemyHp?: number): BattleState {
  const state = beginBattle(createBattle({
    battleId: 'b', encounterId: 'e', seed: 31, player, enemy, playerHp,
    inventorySnapshot: inventory, captureCapacity: 1,
  }));
  return enemyHp === undefined ? state : { ...state, enemyHp };
}
const use = (itemId: string, id: string, tick = 1): GameCommand => ({ type: 'use-battle-item', itemId, commandId: id, tick });
const capture = (id: string, tick = 1): GameCommand => ({ type: 'capture', commandId: id, tick });

describe('battle bag', () => {
  it('knows exactly which catalogue items may be used in a battle', () => {
    expect(battleItemHeal('field_salve')).toBe(35);
    // Camp products stay out of the fight, and materials were never items with effects.
    for (const id of ['salve', 'forest_balm', 'resonant_balm', 'waking_salt', 'seal', 'dew_leaf', 'missing']) {
      expect(battleItemHeal(id), id).toBeNull();
    }
    expect(battleItemHeal('field_tonic')).toBe(60);
    expect(battleItemHeal('soothe_dust')).toBe(45);
    // v4 adds a late-game salve to the three the MVP shipped.
    expect(battleItemHeal('grand_salve')).toBe(60);
    expect(items.filter((item) => item.effect?.kind === 'heal' && item.effect.context === 'battle')).toHaveLength(4);
  });
  it('heals, spends one from the record and costs the whole turn', () => {
    const start = battle({ field_salve: 2 });
    const result = resolveBattle(start, use('field_salve', 'salve-1'));
    expect(result.accepted).toBe(true);
    const events = result.receipt!.events;
    expect(events[0]).toEqual({ type: 'item', side: 'player', itemId: 'field_salve', heal: 20 });
    expect(result.receipt!.snapshot.inventorySnapshot.field_salve).toBe(1);
    expect(result.state.inventorySnapshot.field_salve).toBe(1);
    // The salve filled the bar and the enemy's answer is the only thing that took it down again.
    const answer = events.find((event) => event.type === 'attack' && event.side === 'enemy')!;
    expect(result.state.playerHp).toBe(maxHp - answer.damage!);
    // One enemy answer and one turn boundary: using an item is a full turn.
    expect(events.filter((event) => event.type === 'attack' && event.side === 'player')).toEqual([]);
    expect(events.filter((event) => event.type === 'attack' && event.side === 'enemy')).toHaveLength(1);
    expect(events.at(-1)).toEqual({ type: 'turn-end' });
    expect(result.state.turn).toBe(2);
    expect(() => validateBattle(result.state)).not.toThrow();
  });
  it('never heals past the top of the bar', () => {
    const scratched = battle({ field_salve: 1 }, maxHp - 3);
    const result = resolveBattle(scratched, use('field_salve', 'salve-2'));
    expect(result.receipt!.events[0]).toMatchObject({ heal: 3 });
    expect(result.state.playerHp).toBeLessThanOrEqual(maxHp);
    expect(resolveBattle(battle({ field_salve: 1 }, maxHp - 3), use('field_salve', 'x')).receipt!.events[0].heal).toBe(3);
  });
  it('refuses an empty stock, an unusable item and a full bar without spending anything', () => {
    for (const [state, command, reason] of [
      [battle({ field_salve: 0 }), use('field_salve', 'empty'), 'Eşya kalmadı'],
      [battle({}), use('field_salve', 'absent'), 'Eşya kalmadı'],
      [battle({ salve: 3 }), use('salve', 'camp-only'), 'Bu eşya savaşta kullanılamaz'],
      [battle({ seal: 3 }), use('seal', 'not-a-salve'), 'Bu eşya savaşta kullanılamaz'],
      [battle({ field_salve: 1 }, maxHp), use('field_salve', 'full'), 'Can zaten dolu'],
    ] as const) {
      const before = structuredClone(state);
      const result = resolveBattle(state, command);
      expect(result.accepted, reason).toBe(false);
      expect(result.reason).toBe(reason);
      expect(result.state).toBe(state);
      expect(state).toEqual(before);
    }
  });
  it('applies a repeated command exactly once', () => {
    const first = resolveBattle(battle({ field_salve: 2 }), use('field_salve', 'same'));
    const again = resolveBattle(first.state, use('field_salve', 'same'));
    expect(again.duplicate).toBe(true);
    expect(again.state).toBe(first.state);
    expect(again.state.inventorySnapshot.field_salve).toBe(1);
    // A different item under the same identifier is a conflict, not a second use.
    const conflict = resolveBattle(first.state, { type: 'use-battle-item', itemId: 'seal', commandId: 'same', tick: 1 });
    expect(conflict.accepted).toBe(false);
    expect(conflict.reason).toBe('Komut kimliği çakışıyor');
  });
  it('carries four seal tiers that add +0, +.05, +.10 and +.25 to the same formula', () => {
    expect(sealTiers()).toEqual([{ id: 'seal', bonus: 0 }, { id: 'seal_fine', bonus: .05 },
      { id: 'seal_true', bonus: .1 }, { id: 'seal_master', bonus: .25 }]);
    // Halfway down leaves headroom for every tier below the published ceiling.
    const weak = battle({ seal: 1 }, maxHp, Math.round(stats(enemy).maxHp * .5));
    const base = captureChance(weak);
    expect(base + .25).toBeLessThan(.85);
    expect(captureChance({ ...weak, inventorySnapshot: { seal_fine: 1 } })).toBeCloseTo(base + .05, 10);
    expect(captureChance({ ...weak, inventorySnapshot: { seal_true: 1 } })).toBeCloseTo(base + .1, 10);
    // The plainest seal is the one that will be spent, so it is the one that sets the odds.
    expect(sealChoice({ seal_true: 1, seal: 1 })).toEqual({ id: 'seal', bonus: 0 });
    expect(captureChance({ ...weak, inventorySnapshot: { seal: 1, seal_true: 1 } })).toBeCloseTo(base, 10);
    expect(sealChoice({ seal_true: 2, seal_fine: 1 })).toEqual({ id: 'seal_fine', bonus: .05 });
    expect(sealChoice({ seal: 0, missing: 4 })).toBeNull();
    expect(captureChance({ ...weak, inventorySnapshot: { seal_master: 1 } })).toBeCloseTo(base + .25, 10);
    // A nearly beaten target plus the master seal still stops at the published ceiling.
    expect(captureChance({ ...battle({ seal_master: 1 }, maxHp, 4) })).toBe(.85);
    expect(itemById('seal_true')?.effect).toMatchObject({ kind: 'capture_consumable', value: .1 });
    expect(itemById('seal_master')?.effect).toMatchObject({ kind: 'capture_consumable', value: .25 });
  });
  it('spends the tier it priced and refuses a capture with an empty seal pouch', () => {
    const rich = battle({ seal_true: 1 }, maxHp, 6);
    const result = resolveBattle(rich, capture('seal-it'));
    expect(result.accepted).toBe(true);
    expect(result.state.inventorySnapshot.seal_true).toBe(0);
    const empty = battle({ seal: 0 }, maxHp, 6);
    const refused = resolveBattle(empty, capture('no-seal'));
    expect(refused.accepted).toBe(false);
    expect(refused.reason).toBe('Mühür veya boş yaratık yeri yok');
    expect(refused.state).toBe(empty);
  });
});

let counter = 0;
const opened: IndexedDbSave<ProgressState>[] = [];
function progress(inventory: ProgressState['inventory'], playerHp = maxHp - 20, enemyHp?: number): ProgressState {
  const snapshot: Record<string, number> = {};
  for (const stack of inventory) if (stack) snapshot[stack.itemId] = (snapshot[stack.itemId] ?? 0) + stack.quantity;
  const record = battle(snapshot, playerHp, enemyHp);
  return {
    mode: 'battle', atCamp: false, inventory, unlockedRecipeIds: [],
    creatures: [{ id: player.id, speciesId: player.species.id, level: player.level, xp: 0, hp: playerHp, maxHp }],
    creatureCapacity: 4, eggCapacity: 2, eggs: [], battle: record,
    loot: createLootPlan('b', enemy, false),
    rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
    activeCreatureId: player.id, party: [player.id],
  };
}
async function storage(state: ProgressState) {
  const save = await IndexedDbSave.open({
    name: `bag-${counter++}`, initial: () => structuredClone(state), validate: validateProgressState,
  });
  opened.push(save); return save;
}
afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });

describe('battle bag through the save', () => {
  it('takes the salve out of the real bag once, however many times the command arrives', async () => {
    const save = await storage(progress([{ itemId: 'field_salve', quantity: 2 }, null, null]));
    const healed = await applyBattleCommand(save, 'b', use('field_salve', 'heal'));
    expect(healed.inventory[0]).toEqual({ itemId: 'field_salve', quantity: 1 });
    expect(healed.creatures[0].hp).toBe(healed.battle!.playerHp);
    expect(healed.creatures[0].hp).toBeGreaterThan(maxHp - 20);
    for (let repeat = 0; repeat < 5; repeat++) {
      const again = await applyBattleCommand(save, 'b', use('field_salve', 'heal'));
      expect(again.inventory).toEqual(healed.inventory);
      expect(again.creatures[0].hp).toBe(healed.creatures[0].hp);
    }
    const reloaded = await save.load();
    expect(reloaded).not.toBeNull();
    expect(reloaded!.inventory).toEqual(healed.inventory);
  });
  it('rejects a use it cannot pay for and leaves the bag untouched', async () => {
    const state = progress([{ itemId: 'salve', quantity: 3 }, null]);
    const save = await storage(state);
    await save.transact('init', () => {});
    await expect(applyBattleCommand(save, 'b', use('field_salve', 'missing'))).rejects.toThrow();
    await expect(applyBattleCommand(save, 'b', use('salve', 'camp-only'))).rejects.toThrow();
    const stored = await save.load();
    expect(stored!.inventory).toEqual(state.inventory);
    expect(stored!.battle!.turn).toBe(1);
  });
  it('spends the plainest seal from the bag and captures with the tier bonus', async () => {
    const state = progress([{ itemId: 'seal_true', quantity: 1 }, { itemId: 'seal', quantity: 1 }, null], maxHp, 6);
    const save = await storage(state);
    const chance = captureChance(state.battle!);
    const after = await applyBattleCommand(save, 'b', capture('try'));
    expect(after.inventory.find((stack) => stack?.itemId === 'seal')).toBeUndefined();
    expect(after.inventory.find((stack) => stack?.itemId === 'seal_true')).toEqual({ itemId: 'seal_true', quantity: 1 });
    expect(chance).toBeCloseTo(captureChance({ ...after.battle!, inventorySnapshot: { seal: 1 } }), 10);
  });
});
