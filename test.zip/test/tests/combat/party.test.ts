import { afterEach, describe, expect, it } from 'vitest';
import type { GameCommand } from '../../src/contracts';
import { PARTY_LIMIT } from '../../src/contracts';
import { creatureById, creatures } from '../../src/content/catalog';
import { beginBattle, createBattle, resolveBattle, stats, type BattleState, type Fighter } from '../../src/game/combat/core';
import { PARTY_XP_SHARE, standing, switchRefusal, xpShares, type PartyMember } from '../../src/game/party';
import { applyBattleCommand, createLootPlan, validateBattle, validateProgressState, type ProgressState } from '../../src/game/combat/rewards';
import { IndexedDbSave } from '../../src/game/save/indexeddb';

const ROSTER = ['dewbud', 'emberpod', 'shellwisp', 'pebblenib', 'mirrormoth', 'snowspool'];
const member = (index: number, hp?: number): PartyMember => {
  const species = creatureById(ROSTER[index])!;
  const level = 2;
  return { id: `c${index}`, species, level, hp: hp ?? stats({ id: `c${index}`, species, level }).maxHp };
};
function team(size = 3, hps: Record<number, number> = {}): PartyMember[] {
  return Array.from({ length: size }, (_, index) => member(index, hps[index]));
}
function battle(party: PartyMember[], options: { seed?: number; activeIndex?: number; enemyLevel?: number } = {}): BattleState {
  const activeIndex = options.activeIndex ?? 0;
  const active = party[activeIndex];
  const player: Fighter = { id: active.id, species: active.species, level: active.level };
  return beginBattle(createBattle({
    battleId: 'b', encounterId: 'e', seed: options.seed ?? 12345, player,
    enemy: { id: 'wild', species: creatureById('snowspool')!, level: options.enemyLevel ?? 1 },
    party, activeIndex, playerHp: active.hp, inventorySnapshot: { seal: 1 }, captureCapacity: 1,
  }));
}
const attack = (slot: 0 | 1 | 2 | 3, id: string, tick = 1): GameCommand => ({ type: 'attack', slot, commandId: id, tick });
const swap = (index: number, id: string, tick = 1): GameCommand => ({ type: 'switch-party', index, commandId: id, tick });

describe('party rules', () => {
  it('keeps at most six slots and answers every switch with one rule', () => {
    expect(PARTY_LIMIT).toBe(6);
    expect(() => battle(Array.from({ length: 7 }, (_, index) => member(index % ROSTER.length)))).toThrow();
    const party = team(3, { 1: 0 });
    expect(switchRefusal(party, 0, 2, false)).toBeNull();
    expect(switchRefusal(party, 0, 1, false)).toBe('Bayılmış yaratığa geçilemez');
    expect(switchRefusal(party, 0, 0, false)).toBe('Bu yaratık zaten sahada');
    expect(switchRefusal(party, 0, 3, false)).toBe('Takımda böyle bir yuva yok');
    expect(switchRefusal(party, 0, -1, false)).toBe('Takımda böyle bir yuva yok');
    expect(switchRefusal(party, 0, 1.5, false)).toBe('Takımda böyle bir yuva yok');
    expect(standing(party)).toEqual([0, 2]);
  });
  it('spends the turn on a switch: the newcomer waits while the enemy strikes', () => {
    const start = battle(team(3));
    const result = resolveBattle(start, swap(1, 'to-second'));
    expect(result.accepted).toBe(true);
    const types = result.receipt!.events.map((event) => event.type);
    expect(types[0]).toBe('switch');
    // Exactly one attack in the turn, and it is the enemy's.
    expect(result.receipt!.events.filter((event) => event.type === 'attack' && event.side === 'player')).toEqual([]);
    expect(result.receipt!.events.filter((event) => event.type === 'attack' && event.side === 'enemy')).toHaveLength(1);
    expect(types.at(-1)).toBe('turn-end');
    expect(result.state.turn).toBe(2);
    expect(result.state.activeIndex).toBe(1);
    expect(result.state.player.id).toBe('c1');
    expect(result.state.playerCreatureId).toBe('c1');
    expect(result.state.party[0].hp).toBe(start.party[0].hp);
    expect(result.state.playerHp).toBe(result.state.party[1].hp);
    expect(result.state.enemyHp).toBe(stats(result.state.enemy).maxHp);
  });
  it('refuses a switch to a fainted slot, to itself and out of range without touching the state', () => {
    const start = battle(team(3, { 2: 0 }));
    for (const command of [swap(2, 'down'), swap(0, 'self'), swap(9, 'ghost')]) {
      const result = resolveBattle(start, command);
      expect(result.accepted, command.commandId).toBe(false);
      expect(result.state).toBe(start);
    }
  });
  it('leaves the statuses behind with the creature that walked off the field', () => {
    const start = battle(team(3));
    const poisoned = { ...start, status: { ...start.status, playerEffects: [{ kind: 'poison' as const, turns: 3 }] } };
    const result = resolveBattle(poisoned, swap(1, 'fresh'));
    expect(result.state.status.playerEffects).toEqual([]);
    expect(result.state.status.playerGuard).toBe(false);
  });
  it('asks for a forced switch when the active faints and a team mate still stands', () => {
    const start = { ...battle(team(3)), playerHp: 1 };
    const synced = { ...start, party: start.party.map((entry, index) => index === 0 ? { ...entry, hp: 1 } : entry) };
    const fallen = resolveBattle(synced, attack(0, 'trade'));
    expect(fallen.state.phase).toBe('FORCED_SWITCH');
    expect(fallen.state.outcome).toBeNull();
    expect(fallen.state.playerHp).toBe(0);
    expect(fallen.state.party[0].hp).toBe(0);
    expect(fallen.receipt!.events.some((event) => event.type === 'faint' && event.index === 0)).toBe(true);
    // Nothing but a replacement is accepted while the field is empty.
    for (const command of [attack(0, 'fight', 2), { type: 'flee', commandId: 'run', tick: 2 } as GameCommand]) {
      expect(resolveBattle(fallen.state, command).accepted, command.type).toBe(false);
    }
    expect(resolveBattle(fallen.state, swap(0, 'same', 2)).accepted).toBe(false);
    const rescued = resolveBattle(fallen.state, swap(1, 'next', 2));
    expect(rescued.accepted).toBe(true);
    expect(rescued.state.phase).toBe('PLAYER_INPUT');
    expect(rescued.state.activeIndex).toBe(1);
    expect(rescued.state.playerHp).toBeGreaterThan(0);
    // The forced switch closes the turn the fighter fell in; the enemy does not strike twice.
    expect(rescued.receipt!.events.filter((event) => event.type === 'attack')).toEqual([]);
    expect(rescued.state.turn).toBe(fallen.state.turn + 1);
    expect(() => validateBattle(rescued.state)).not.toThrow();
  });
  it('is lost only when the last standing creature falls', () => {
    const start = battle(team(2, { 1: 0 }));
    const synced = { ...start, playerHp: 1, party: start.party.map((entry, index) => index === 0 ? { ...entry, hp: 1 } : entry) };
    const result = resolveBattle(synced, attack(0, 'last-stand'));
    expect(result.state.outcome).toBe('LOST');
    expect(result.state.phase).toBe('LOST');
    expect(standing(result.state.party)).toEqual([]);
    expect(() => validateBattle(result.state)).not.toThrow();
  });
  it('refuses a saved battle that pauses on a fallen fighter with nobody left', () => {
    const start = battle(team(2, { 1: 0 }));
    const forged = {
      ...start, phase: 'FORCED_SWITCH' as const, playerHp: 0,
      party: start.party.map((entry, index) => ({ ...entry, hp: index === 0 ? 0 : entry.hp })),
    };
    expect(() => validateBattle(forged)).toThrow();
    const stillStanding = { ...forged, party: forged.party.map((entry, index) => index === 1 ? { ...entry, hp: 20 } : entry) };
    expect(() => validateBattle(stillStanding)).not.toThrow();
    expect(() => validateBattle({ ...stillStanding, phase: 'LOST' as const, outcome: 'LOST' as const })).toThrow();
  });
  it('shares experience: all of it to the fighter, two fifths to every standing team mate', () => {
    const party = team(4, { 2: 0 });
    expect(PARTY_XP_SHARE).toBe(.4);
    expect(xpShares(party, 1, 100)).toEqual([
      { id: 'c0', xp: 40 }, { id: 'c1', xp: 100 }, { id: 'c3', xp: 40 },
    ]);
    expect(xpShares(party, 1, 0)).toEqual([]);
    expect(xpShares(party, 1, 2)).toEqual([{ id: 'c1', xp: 2 }]);
  });
});

function progress(party: PartyMember[], options: { activeIndex?: number; enemyHp?: number } = {}): ProgressState {
  const record = battle(party, { activeIndex: options.activeIndex, seed: 99 });
  record.enemyHp = options.enemyHp ?? stats(record.enemy).maxHp;
  return {
    mode: 'battle', atCamp: false, inventory: [{ itemId: 'seal', quantity: 1 }, null, null], unlockedRecipeIds: [],
    creatures: party.map((entry) => ({
      id: entry.id, speciesId: entry.species.id, level: entry.level, xp: 0,
      hp: entry.hp, maxHp: stats({ id: entry.id, species: entry.species, level: entry.level }).maxHp,
    })),
    creatureCapacity: 8, eggCapacity: 2, eggs: [], battle: record,
    loot: createLootPlan('b', record.enemy, false),
    rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
    activeCreatureId: record.playerCreatureId, party: party.map((entry) => entry.id),
  };
}
let counter = 0;
const opened: IndexedDbSave<ProgressState>[] = [];
async function storage(state: ProgressState) {
  const save = await IndexedDbSave.open({
    name: `party-${counter++}`, initial: () => structuredClone(state), validate: validateProgressState,
  });
  opened.push(save); return save;
}
afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });

describe('party rewards through the save', () => {
  it('pays the fighter in full and every standing team mate its share, exactly once', async () => {
    const party = team(4, { 3: 0 });
    const state = progress(party, { enemyHp: 1 });
    const save = await storage(state);
    const won = await applyBattleCommand(save, 'b', attack(0, 'finish'));
    expect(won.battle!.outcome).toBe('WON');
    const award = 10 + 6 * won.battle!.enemy.level;
    const xp = (id: string) => won.creatures.find((creature) => creature.id === id)!.xp;
    expect(xp('c0')).toBe(award);
    expect(xp('c1')).toBe(Math.floor(award * .4));
    expect(xp('c2')).toBe(Math.floor(award * .4));
    // The creature that was already down learns nothing.
    expect(xp('c3')).toBe(0);
    for (let repeat = 0; repeat < 50; repeat++) {
      const again = await applyBattleCommand(save, 'b', attack(0, 'finish'));
      expect(again.creatures.map((creature) => creature.xp)).toEqual(won.creatures.map((creature) => creature.xp));
      expect(again.rewardLedger).toEqual(['b']);
      expect(again.consumedEntityIds).toEqual(['e']);
    }
  });
  it('moves the world pointer with the creature that takes the field and survives a reload', async () => {
    const save = await storage(progress(team(3)));
    const switched = await applyBattleCommand(save, 'b', swap(2, 'go-third'));
    expect(switched.activeCreatureId).toBe('c2');
    expect(switched.battle!.activeIndex).toBe(2);
    const reloaded = await save.load();
    expect(reloaded).not.toBeNull();
    expect(reloaded!.battle!.party).toEqual(switched.battle!.party);
    expect(reloaded!.battle!.activeIndex).toBe(2);
    expect(reloaded!.activeCreatureId).toBe('c2');
    // A repeat of the same command changes nothing.
    const repeated = await applyBattleCommand(save, 'b', swap(2, 'go-third'));
    expect(repeated).toEqual(switched);
  });
  it('keeps every team mate HP in the collection in step with the battle record', async () => {
    const save = await storage(progress(team(3)));
    const hurt = await applyBattleCommand(save, 'b', attack(0, 'hit-1'));
    expect(hurt.creatures.find((creature) => creature.id === 'c0')!.hp).toBe(hurt.battle!.playerHp);
    const rotated = await applyBattleCommand(save, 'b', swap(1, 'rotate', 2));
    expect(rotated.battle!.party[0].hp).toBe(hurt.battle!.playerHp);
    const state = await applyBattleCommand(save, 'b', attack(0, 'hit-2', 3));
    for (const entry of state.battle!.party) {
      expect(state.creatures.find((creature) => creature.id === entry.id)!.hp).toBe(entry.hp);
    }
    expect(state.creatures.find((creature) => creature.id === 'c0')!.hp).toBeLessThan(stats({ id: 'c0', species: creatureById(ROSTER[0])!, level: 2 }).maxHp);
  });
  it('gives a sealed creature the free slot and leaves a full team untouched', async () => {
    const small = progress(team(2));
    small.battle!.enemyHp = 1;
    const save = await storage(small);
    const captured = await applyBattleCommand(save, 'b', { type: 'capture', commandId: 'seal', tick: 1 });
    expect(captured.battle!.outcome).toBe('CAPTURED');
    expect(captured.party).toEqual(['c0', 'c1', 'capture:e']);
    const full = progress(team(6));
    full.battle!.enemyHp = 1;
    const packed = await applyBattleCommand(await storage(full), 'b', { type: 'capture', commandId: 'seal', tick: 1 });
    expect(packed.party).toHaveLength(PARTY_LIMIT);
    expect(packed.creatures.some((creature) => creature.id === 'capture:e')).toBe(true);
  });
  it('wakes the whole team up after a defeat', async () => {
    const party = team(2, { 1: 0 });
    const state = progress(party);
    state.battle = { ...state.battle!, playerHp: 1, party: state.battle!.party.map((entry, index) => index === 0 ? { ...entry, hp: 1 } : entry) };
    state.creatures[0].hp = 1;
    const lost = await applyBattleCommand(await storage(state), 'b', attack(0, 'doomed'));
    expect(lost.battle!.outcome).toBe('LOST');
    for (const creature of lost.creatures) expect(creature.hp).toBe(creature.maxHp);
    expect(lost.creatures.every((creature) => creature.xp === 0)).toBe(true);
  });
  it('plays a six-creature battle to the end without breaking an invariant', async () => {
    let state = progress(team(6), { enemyHp: 30 });
    const save = await storage(state);
    for (let turn = 1; turn <= 60 && !state.battle!.outcome; turn++) {
      const record = state.battle!;
      const rotation = (record.activeIndex + 1) % PARTY_LIMIT;
      const command = record.phase === 'FORCED_SWITCH'
        ? swap(standing(record.party).find((index) => index !== record.activeIndex)!, `forced-${turn}`, turn)
        : turn % 7 === 0 && !switchRefusal(record.party, record.activeIndex, rotation, false)
          ? swap(rotation, `rotate-${turn}`, turn)
          : attack(0, `act-${turn}`, turn);
      state = await applyBattleCommand(save, 'b', command);
      expect(state.battle!.party).toHaveLength(6);
      expect(new Set(state.battle!.party.map((entry) => entry.id)).size).toBe(6);
      expect(() => validateProgressState(state)).not.toThrow();
    }
    expect(state.battle!.outcome).not.toBeNull();
    expect(creatures.length).toBeGreaterThan(PARTY_LIMIT);
  });
});
