import { describe, expect, it } from 'vitest';
import { creatures } from '../../src/content/catalog';
import { beginBattle, createBattle, resolveBattle } from '../../src/game/combat/core';
import { validateBattle } from '../../src/game/combat/rewards';

describe('persisted ambush context', () => {
  it('halves the first-turn enemy hit for an active level 14 tank, without consuming extra RNG', () => {
    const species = creatures.find((row) => row.roles.includes('tank'))!;
    let hits = 0;
    for (let seed = 1; seed <= 30; seed++) {
      const initial = beginBattle(createBattle({ battleId: `b${seed}`, encounterId: 'enemy', seed,
        player: { id: 'tank', species, level: 14 }, enemy: { id: 'enemy', species: creatures[0], level: 14 } }));
      const command = { type: 'attack' as const, slot: 2 as const, tick: 0, commandId: `action${seed}` };
      const normal = resolveBattle(initial, command);
      const ambush = resolveBattle({ ...structuredClone(initial), ambushed: true }, command);
      const damage = normal.receipt?.events.find((e) => e.type === 'attack' && e.side === 'enemy')?.damage;
      if (!damage) continue;
      hits++;
      expect(ambush.receipt?.events.find((e) => e.type === 'attack' && e.side === 'enemy')?.damage).toBe(Math.max(1, Math.floor(damage / 2)));
      expect(ambush.state.rngState).toBe(normal.state.rngState);
      validateBattle(ambush.state);
      expect(resolveBattle(ambush.state, command).state).toEqual(ambush.state);
      const second = { ...command, commandId: `second${seed}`, tick: 1 };
      const resumed = structuredClone(ambush.state);
      const protectedSecond = resolveBattle(resumed, second);
      const ordinarySecond = resolveBattle({ ...resumed, ambushed: false }, second);
      expect(protectedSecond.receipt?.events).toEqual(ordinarySecond.receipt?.events);
      expect(protectedSecond.state.playerHp).toBe(ordinarySecond.state.playerHp);
      expect(protectedSecond.state.rngState).toBe(ordinarySecond.state.rngState);
    }
    expect(hits).toBeGreaterThan(10);
  });
  it('reads old battles without a flag and rejects a malformed flag', () => {
    const battle = beginBattle(createBattle({ battleId: 'legacy', encounterId: 'enemy', seed: 1,
      player: { id: 'friend', species: creatures[0], level: 2 }, enemy: { id: 'enemy', species: creatures[1], level: 2 } }));
    delete battle.ambushed;
    expect(() => validateBattle(battle)).not.toThrow();
    expect(() => validateBattle({ ...battle, ambushed: 'yes' } as unknown)).toThrow();
  });
});
