import { describe, expect, it } from 'vitest';
import type { GameCommand, StatusKind } from '../../src/contracts';
import { creatureById, movesOf } from '../../src/content/catalog';
import { SUPPORT_EFFECTS } from '../../src/content/schema';
import {
  STATUS_RULES, beginBattle, createBattle, damage, hasStatus, poisonDamage, randomStep,
  resolveBattle, stats, type BattleState, type Fighter,
} from '../../src/game/combat/core';
import { migrateBattleRecord, validateBattle } from '../../src/game/combat/rewards';
import { EMPTY_TRAIT_STATE } from '../../src/game/combat/traits';

/**
 * v4 separates a learn set from the four moves carried, so a test cannot assume which slot
 * holds a status move. Each carrier is equipped on purpose, with the move under test in slot 3.
 */
const CARRIER: Record<StatusKind, string> = {
  poison: 'bloomhart', burn: 'brightkit', slow: 'arcbadger', weaken: 'gladefox',
  bulwark: 'bloomhart', charge: 'bloomhart',
};
/** The species' own four, rearranged so `kind`'s move sits in the finisher slot. */
function loadoutFor(speciesId: string, kind: StatusKind): string[] {
  const known = movesOf(speciesId);
  const carrier = known.find((move) => move.effect === kind)!;
  const support = known.find((move) => SUPPORT_EFFECTS.some((effect) => effect === move.effect))!;
  const rest = known.filter((move) => move !== carrier && move !== support &&
    !SUPPORT_EFFECTS.some((effect) => effect === move.effect));
  return [rest[0].id, rest[1].id, support.id, carrier.id];
}
const fighter = (speciesId: string, level: number, id = 'friend', kind?: StatusKind): Fighter =>
  ({ id, species: creatureById(speciesId)!, level, ...(kind ? { loadout: loadoutFor(speciesId, kind) } : {}) });
/** Four of the species' own moves that write no status, so only the side under test applies one. */
function plainLoadout(speciesId: string): string[] {
  const known = movesOf(speciesId);
  const support = known.find((move) => SUPPORT_EFFECTS.some((effect) => effect === move.effect))!;
  const plain = known.filter((move) => move !== support && !move.effect);
  return [plain[0].id, plain[1].id, support.id, plain[2].id];
}
function battle(speciesId: string, seed: number, level = 20, enemyLevel = level, kind?: StatusKind): BattleState {
  return beginBattle(createBattle({
    battleId: 'b', encounterId: 'e', seed,
    player: fighter(speciesId, level, 'friend', kind),
    enemy: { ...fighter('snowspool', enemyLevel, 'wild'), loadout: plainLoadout('snowspool') },
  }));
}
const attack = (slot: 0 | 1 | 2 | 3, id: string, tick = 1): GameCommand => ({ type: 'attack', slot, commandId: id, tick });
/** Duration tests care about clocks, not about who faints, so both sides are topped up. */
function keepAlive(state: BattleState): BattleState {
  return { ...state, playerHp: stats(state.player).maxHp, enemyHp: stats(state.enemy).maxHp };
}
/** Finds the first seed whose third die lands on the wanted side of the status chance. */
function seedFor(kind: StatusKind, applied: boolean): number {
  for (let seed = 1; seed < 20000; seed++) {
    const result = resolveBattle(battle(CARRIER[kind], seed, 20, 20, kind), attack(3, 'hit'));
    const event = result.receipt?.events.find((entry) => entry.type === 'status');
    if (event?.hit === applied && result.state.outcome === null) return seed;
  }
  throw new Error(`Uygun seed bulunamadı: ${kind}`);
}

describe('status effects', () => {
  it('applies each of the three effects with a single die and records it', () => {
    for (const kind of ['poison', 'burn', 'slow'] as const) {
      const seed = seedFor(kind, true);
      const clean = battle(CARRIER[kind], seed, 20, 20, kind);
      const result = resolveBattle(clean, attack(3, 'strike'));
      const events = result.receipt!.events;
      const status = events.filter((entry) => entry.type === 'status' && entry.hit !== undefined);
      expect(status, kind).toHaveLength(1);
      expect(status[0]).toMatchObject({ side: 'enemy', status: kind, hit: true });
      // Three dice for a landing status move: hit, damage variation, effect.
      let expected = clean.rngState;
      for (let i = 0; i < 3; i++) expected = randomStep(expected).state;
      if (!result.state.outcome) for (let i = 0; i < 2; i++) expected = randomStep(expected).state;
      expect(result.state.rngState, kind).toBe(expected);
      // The clock already lost the turn that is over.
      expect(result.state.status.enemyEffects).toEqual([{ kind, turns: STATUS_RULES[kind].turns - 1 }]);
      expect(result.state.status.playerEffects).toEqual([]);
    }
  });
  it('spends the die but leaves no effect when it misses the chance', () => {
    for (const kind of ['poison', 'burn', 'slow'] as const) {
      const seed = seedFor(kind, false);
      const result = resolveBattle(battle(CARRIER[kind], seed, 20, 20, kind), attack(3, 'strike'));
      expect(result.receipt!.events.find((entry) => entry.type === 'status')).toMatchObject({ status: kind, hit: false });
      expect(result.state.status.enemyEffects, kind).toEqual([]);
    }
  });
  it('never stacks: a second hit refreshes the same single clock', () => {
    const seed = seedFor('poison', true);
    let state = resolveBattle(battle(CARRIER.poison, seed, 20, 20, 'poison'), attack(3, 'one')).state;
    expect(state.status.enemyEffects).toEqual([{ kind: 'poison', turns: 2 }]);
    state = keepAlive(state);
    for (let turn = 2; turn < 40 && state.status.enemyEffects.length; turn++) {
      const result = resolveBattle(state, attack(3, `again-${turn}`, turn));
      if (!result.accepted) { state = keepAlive({ ...state, stamina: 5 }); continue; }
      state = keepAlive(result.state);
      expect(state.status.enemyEffects.length).toBeLessThanOrEqual(1);
      if (result.receipt!.events.some((entry) => entry.type === 'status' && entry.hit)) {
        expect(state.status.enemyEffects).toEqual([{ kind: 'poison', turns: 2 }]);
        return;
      }
    }
    throw new Error('İkinci zehir isabeti üretilemedi');
  });
  it('expires after its own number of turns', () => {
    for (const kind of ['poison', 'slow'] as const) {
      const seed = seedFor(kind, true);
      let state = keepAlive(resolveBattle(battle(CARRIER[kind], seed, 20, 20, kind), attack(3, 'apply')).state);
      let seen = 1;
      for (let turn = 2; turn < 12 && hasStatus(state.status.enemyEffects, kind); turn++) {
        const result = resolveBattle(state, attack(0, `tick-${turn}`, turn));
        expect(result.accepted, kind).toBe(true);
        state = keepAlive({ ...result.state, stamina: 5 });
        if (hasStatus(state.status.enemyEffects, kind)) seen++;
      }
      // The clock is set on application and loses one turn at every turn end.
      expect(seen, kind).toBe(STATUS_RULES[kind].turns - 1);
      expect(state.status.enemyEffects, kind).toEqual([]);
    }
  });
  it('poison bites for ceil(maxHp/16) at turn end and can end the battle', () => {
    const seed = seedFor('poison', true);
    const first = resolveBattle(battle(CARRIER.poison, seed, 20, 20, 'poison'), attack(3, 'apply'));
    const bite = first.receipt!.events.find((entry) => entry.type === 'status' && entry.damage !== undefined);
    expect(bite).toMatchObject({ side: 'enemy', status: 'poison', damage: poisonDamage(first.state.enemy) });
    const dying = { ...first.state, enemyHp: poisonDamage(first.state.enemy), playerHp: stats(first.state.player).maxHp };
    const finished = resolveBattle(dying, attack(2, 'guard-while-poisoned', 2));
    expect(finished.state.outcome).toBe('WON');
    expect(finished.state.enemyHp).toBe(0);
    expect(finished.receipt!.events.at(-1)).toEqual({ type: 'outcome', outcome: 'WON' });
  });
  it('burn cuts the burned fighter attack to three quarters', () => {
    const attacker = fighter('emberpod', 6);
    const defender = fighter('snowspool', 6, 'wild');
    expect(damage(16, attacker, defender, .5, false, true))
      .toBe(Math.floor(damage(16, attacker, defender, .5, false, false) * .75));
    const seed = 11;
    const clean = resolveBattle(battle(CARRIER.burn, seed, 20, 20, 'burn'), attack(0, 'clean'));
    const burnt = resolveBattle({ ...battle(CARRIER.burn, seed, 20, 20, 'burn'),
      status: { ...battle(CARRIER.burn, seed, 20, 20, 'burn').status, playerEffects: [{ kind: 'burn', turns: 3 }] } }, attack(0, 'clean'));
    const hit = (state: typeof clean) => state.receipt!.events.find((entry) => entry.type === 'attack' && entry.side === 'player')!;
    expect(hit(clean).hit).toBe(true);
    expect(hit(burnt).damage).toBeLessThan(hit(clean).damage!);
    // The same dice were drawn either way: burn changes the sum, not the stream.
    expect(burnt.state.rngState).toBe(clean.state.rngState);
  });
  it('slow stops energy regeneration and can force a rest turn', () => {
    const base = battle(CARRIER.slow, 5, 20, 20, 'slow');
    const slowed = { ...base, status: { ...base.status, playerEffects: [{ kind: 'slow' as const, turns: 2 }], enemyEffects: [{ kind: 'slow' as const, turns: 2 }] } };
    const result = resolveBattle(slowed, attack(0, 'cheap'));
    const cost = 1;
    expect(result.state.stamina).toBe(slowed.stamina - cost);
    expect(result.state.enemyStamina).toBeLessThanOrEqual(slowed.enemyStamina);
    const priced = { ...fighter('dewbud', 20, 'wild'), loadout: ['vine_lash', 'strike', 'guard', 'rootquake'] };
    const exhausted = { ...base, enemyStamina: 0, enemy: priced, status: { ...base.status, enemyEffects: [{ kind: 'slow' as const, turns: 2 }] } };
    const rested = resolveBattle(exhausted, attack(0, 'watch'));
    expect(rested.receipt!.events.some((entry) => entry.type === 'rest' && entry.side === 'enemy')).toBe(true);
    expect(rested.state.enemyStamina).toBe(0);
  });
  it('clears every effect when the battle ends', () => {
    const seed = seedFor('poison', true);
    const applied = resolveBattle(battle(CARRIER.poison, seed, 20, 20, 'poison'), attack(3, 'apply'));
    expect(applied.state.status.enemyEffects).not.toEqual([]);
    const fleeing = { ...applied.state, aggressive: false };
    let escape = 2;
    let result = resolveBattle(fleeing, { type: 'flee', commandId: 'run', tick: escape });
    while (!result.state.outcome && escape < 20) {
      escape++;
      result = resolveBattle(keepAlive(result.state), { type: 'flee', commandId: `run-${escape}`, tick: escape });
    }
    expect(result.state.outcome).toBe('FLED');
    expect(result.state.status.playerEffects).toEqual([]);
    expect(result.state.status.enemyEffects).toEqual([]);
  });
  it('replays the same status chain from the same seed and command list', () => {
    const commands = Array.from({ length: 60 }, (_, index) => attack((index % 4) as 0 | 1 | 2 | 3, `c${index}`, index + 1));
    const run = () => commands.reduce((state, command) => resolveBattle(state, command).state, battle(CARRIER.poison, 4813, 20, 18, 'poison'));
    const first = commands.slice(0, 5).reduce((state, command) => resolveBattle(state, command).state, battle(CARRIER.poison, 4813, 20, 18, 'poison'));
    const resumed = commands.slice(5).reduce((state, command) => resolveBattle(state, command).state, JSON.parse(JSON.stringify(first)) as BattleState);
    expect(run()).toEqual(run());
    expect(resumed).toEqual(run());
    const chain = (state: BattleState) => Object.values(state.committedActions)
      .flatMap((receipt) => receipt.events.filter((event) => event.type === 'status'));
    expect(chain(run()).length).toBeGreaterThan(0);
    expect(chain(resumed)).toEqual(chain(run()));
  });
  it('keeps HP, energy and every clock inside its bounds over 100 randomised battles', () => {
    const carriers = ['dewbud', 'emberpod', 'shellwisp', 'twigveil', 'ashcrown', 'frostchime'];
    for (let index = 0; index < 100; index++) {
      const speciesId = carriers[index % carriers.length];
      let state = battle(speciesId, 1 + index * 7919, 6 + (index % 25), 1 + (index % 20));
      const playerMax = stats(state.player).maxHp, enemyMax = stats(state.enemy).maxHp;
      for (let turn = 1; turn <= 30 && !state.outcome; turn++) {
        const slot = (Math.floor(randomStep(index * 31 + turn).value * 4) % 4) as 0 | 1 | 2 | 3;
        state = resolveBattle(state, attack(slot, `r${index}-${turn}`, turn)).state;
        expect(state.playerHp, `${index}`).toBeGreaterThanOrEqual(0);
        expect(state.playerHp).toBeLessThanOrEqual(playerMax);
        expect(state.enemyHp).toBeGreaterThanOrEqual(0);
        expect(state.enemyHp).toBeLessThanOrEqual(enemyMax);
        for (const effects of [state.status.playerEffects, state.status.enemyEffects]) {
          expect(effects.length).toBeLessThanOrEqual(3);
          expect(new Set(effects.map((effect) => effect.kind)).size).toBe(effects.length);
          for (const effect of effects) {
            expect(effect.turns).toBeGreaterThan(0);
            expect(effect.turns).toBeLessThanOrEqual(STATUS_RULES[effect.kind].turns);
          }
        }
        for (const energy of [state.stamina, state.enemyStamina]) {
          expect(energy).toBeGreaterThanOrEqual(0);
          expect(energy).toBeLessThanOrEqual(5);
        }
      }
      if (state.outcome) {
        expect(state.status.playerEffects).toEqual([]);
        expect(state.status.enemyEffects).toEqual([]);
      }
    }
  });
  it('survives a reload byte for byte and refuses a forged clock', () => {
    const seed = seedFor('poison', true);
    const live = resolveBattle(battle(CARRIER.poison, seed, 20, 18, 'poison'), attack(3, 'apply')).state;
    expect(live.status.enemyEffects).not.toEqual([]);
    const reloaded = JSON.parse(JSON.stringify(live)) as BattleState;
    expect(() => validateBattle(reloaded)).not.toThrow();
    expect(reloaded.status).toEqual(live.status);
    const next = (state: BattleState) => resolveBattle(state, attack(0, 'after-reload', 2));
    expect(next(reloaded).state).toEqual(next(live).state);
    for (const forged of [
      [{ kind: 'poison', turns: 4 }],
      [{ kind: 'poison', turns: 1 }, { kind: 'poison', turns: 1 }],
      [{ kind: 'sleep', turns: 1 }],
      [{ kind: 'poison', turns: 0 }],
    ]) {
      const broken = JSON.parse(JSON.stringify(live)) as BattleState;
      broken.status.enemyEffects = forged as BattleState['status']['enemyEffects'];
      expect(() => validateBattle(broken), JSON.stringify(forged)).toThrow();
    }
  });
  it('upgrades a battle written before status effects existed', () => {
    const live = resolveBattle(battle(CARRIER.poison, 3, 20, 18, 'poison'), attack(0, 'apply')).state;
    const legacy = JSON.parse(JSON.stringify(live)) as Record<string, unknown>;
    legacy.version = 1;
    delete (legacy.status as Record<string, unknown>).playerEffects;
    delete (legacy.status as Record<string, unknown>).enemyEffects;
    for (const receipt of Object.values(legacy.committedActions as Record<string, { snapshot: Record<string, unknown> }>)) {
      receipt.snapshot.version = 1;
      delete (receipt.snapshot.status as Record<string, unknown>).playerEffects;
      delete (receipt.snapshot.status as Record<string, unknown>).enemyEffects;
    }
    const upgraded = migrateBattleRecord(legacy);
    expect(() => validateBattle(upgraded)).not.toThrow();
    // A record written before passives existed cannot carry their counters, so it starts clean;
    // everything the old format did hold is carried over untouched.
    const fresh = { player: EMPTY_TRAIT_STATE, enemy: EMPTY_TRAIT_STATE };
    expect(upgraded).toEqual({ ...live, traits: fresh, dayPhase: 'day', pendingGuard: false,
      committedActions: Object.fromEntries(Object.entries(live.committedActions).map(([id, receipt]) => [id,
        { ...receipt, snapshot: { ...receipt.snapshot, traits: fresh, dayPhase: 'day', pendingGuard: false } }])) });
    // A v2 record — status clocks but no passives — lands on the same shape in one pass.
    const v2 = JSON.parse(JSON.stringify(live)) as Record<string, unknown>;
    v2.version = 2; delete v2.traits; delete v2.dayPhase; delete v2.pendingGuard;
    expect(() => validateBattle(migrateBattleRecord(v2))).not.toThrow();
    // A record that is already current is returned untouched, so a healthy load never rewrites.
    expect(migrateBattleRecord(live)).toBe(live);
  });
});
