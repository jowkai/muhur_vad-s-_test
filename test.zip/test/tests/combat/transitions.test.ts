import { afterEach, describe, expect, it } from 'vitest';
import type { GameCommand, SavePort, VecXZ } from '../../src/contracts';
import { creatures } from '../../src/content/catalog';
import { createWorld } from '../../src/world/generation/world';
import { canOccupy } from '../../src/world/collision/collision';
import { residency, spawnsForChunk } from '../../src/world/chunks/chunks';
import { stats } from '../../src/game/combat/core';
import { createWorldState, validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { EncounterAdapter } from '../../src/game/encounter-adapter';
import { IndexedDbSave, SaveError, type FaultPoint } from '../../src/game/save/indexeddb';

const world = createWorld();
const species = creatures[0];
const maxHp = stats({ id: 'friend', species, level: 2 }).maxHp;
const eggStarter = world.starters.find((starter) => starter.kind === 'egg')!;
const wildStarter = world.starters.find((starter) => starter.kind === 'creature')!;
/** A deterministic aggressive spawn far from the safe camp, used for the ambush path. */
const nearbySpawns = residency({ x: 0, z: 0 }, 6).flatMap((chunk) => [...spawnsForChunk(world, chunk)]);
const hostile = nearbySpawns.find((spawn) => spawn.target.aggressive && canOccupy(world, beside(spawn.target.position)))!;
const apart = (a: VecXZ, b: VecXZ) => Math.hypot(a.x - b.x, a.z - b.z);
/** An isolated resource keeps proximity selection unambiguous for the collection path. */
const resource = nearbySpawns.find((spawn) => spawn.target.kind === 'resource' && canOccupy(world, beside(spawn.target.position)) &&
  nearbySpawns.every((other) => other.target.entityId === spawn.target.entityId || apart(other.target.position, spawn.target.position) > 16) &&
  world.starters.every((starter) => apart(starter.position, spawn.target.position) > 16))!;
function beside(position: VecXZ): VecXZ { return { x: position.x + 3, z: position.z }; }
function base(overrides: Partial<WorldState> = {}): WorldState {
  const state = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [{ itemId: 'seal', quantity: 2 }, null, null, null, null, null], unlockedRecipeIds: [],
    creatures: [{ id: 'friend', speciesId: species.id, level: 2, xp: 0, hp: maxHp, maxHp }],
    creatureCapacity: 3, eggCapacity: 2, eggs: [], battle: null, loot: null,
    rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return { ...state, ...overrides };
}
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
async function storage(initial: WorldState, fault?: (point: FaultPoint) => void, name = `transitions-${counter++}`) {
  const save = await IndexedDbSave.open<WorldState>({
    name, initial: () => structuredClone(initial), validate: (value) => validateWorldState(world, value), fault,
  });
  opened.push(save);
  await save.transact(`seed-${name}`, () => {});
  return save;
}
async function adapterAt(position: VecXZ, overrides: Partial<WorldState> = {}, fault?: (point: FaultPoint) => void) {
  const save = await storage(base({ playerPosition: { ...position }, lastSafePosition: { ...position }, ...overrides }), fault);
  const adapter = await EncounterAdapter.open(world, save, 'oturum');
  return { save, adapter };
}
/** Fails only the settlement transaction, leaving every earlier write to the real store. */
function flaky(save: SavePort<WorldState>, failing: () => boolean): SavePort<WorldState> {
  return {
    load: () => save.load(),
    transact: (commandId, mutate) => commandId.startsWith('settle:') && failing()
      ? Promise.reject(new SaveError('storage', 'Kayıt işlemi tamamlanamadı. Mevcut kayıt silinmedi; tekrar deneyin.'))
      : save.transact(commandId, mutate),
  };
}
const interact = (entityId: string, commandId = 'interact-1'): GameCommand => ({ type: 'interact', entityId, commandId, tick: 1 });
const attack = (commandId: string, tick = 2): GameCommand => ({ type: 'attack', slot: 0, commandId, tick });
afterEach(() => { for (const save of opened) save.close(); opened.length = 0; });

describe('explore to committed encounter', () => {
  it('collects a world egg in one transaction without ever opening a battle', async () => {
    const player = beside(eggStarter.position);
    const { save, adapter } = await adapterAt(player);
    const seen = adapter.tick(player);
    expect(seen.state.mode).toBe('exploring');
    expect(seen.nearby?.entityId).toBe(eggStarter.entityId);
    expect(seen.nearby?.interactionAllowed).toBe(true);
    const result = await adapter.dispatch(player, interact(eggStarter.entityId));
    expect(result.accepted).toBe(true);
    const view = adapter.snapshot();
    expect(view.state.mode).toBe('exploring');
    expect(view.battle).toBeNull();
    expect(view.lastOutcome).toBe('collected');
    expect(view.movementAllowed).toBe(true);
    const stored = (await save.load())!;
    expect(stored.eggs).toHaveLength(1);
    expect(stored.eggs[0]).toMatchObject({ encounterId: eggStarter.entityId, speciesId: eggStarter.speciesId, activeTicks: 0 });
    expect(stored.consumedEntityIds).toEqual([eggStarter.entityId]);
    expect(adapter.chunks.loadedEntityIds).not.toContain(eggStarter.entityId);
    expect(adapter.index.query(player, 24).map((target) => target.entityId)).not.toContain(eggStarter.entityId);
  });
  it('replays an identical interact command without collecting twice', async () => {
    const player = beside(eggStarter.position);
    const { save, adapter } = await adapterAt(player);
    adapter.tick(player);
    const first = await adapter.dispatch(player, interact(eggStarter.entityId));
    const again = await adapter.dispatch(player, interact(eggStarter.entityId));
    expect(first.accepted && again.accepted).toBe(true);
    expect((await save.load())!.eggs).toHaveLength(1);
    const conflicting = await adapter.dispatch(player, { ...interact('başka'), commandId: 'interact-1' });
    expect(conflicting).toEqual({ accepted: false, reason: 'id-conflict' });
    expect((await save.load())!.consumedEntityIds).toEqual([eggStarter.entityId]);
  });
  it('stores a gathered resource once and leaves a full-bag target in the world', async () => {
    const player = beside(resource.target.position);
    const { save, adapter } = await adapterAt(player);
    expect(adapter.tick(player).nearby?.entityId).toBe(resource.target.entityId);
    await adapter.dispatch(player, interact(resource.target.entityId));
    const stored = (await save.load())!;
    expect(stored.inventory.some((stack) => stack?.itemId === resource.itemId && stack.quantity === 1)).toBe(true);
    expect(stored.consumedEntityIds).toEqual([resource.target.entityId]);
    expect(adapter.snapshot().lastOutcome).toBe('collected');
    expect(adapter.chunks.loadedEntityIds).not.toContain(resource.target.entityId);

    const full = await adapterAt(player, { inventory: [{ itemId: 'seal', quantity: 2 }] });
    full.adapter.tick(player);
    await expect(full.adapter.dispatch(player, interact(resource.target.entityId))).rejects.toThrow();
    expect((await full.save.load())!.consumedEntityIds).toEqual([]);
    expect(full.adapter.chunks.loadedEntityIds).toContain(resource.target.entityId);
    expect(full.adapter.snapshot().pending).toMatchObject({ entityId: resource.target.entityId, kind: 'collect' });
    expect(full.adapter.cancel().pending).toBeNull();
    expect(full.adapter.snapshot().state.mode).toBe('exploring');
    expect(full.adapter.snapshot().movementAllowed).toBe(true);
  });
  it('runs exploring → encounter → battle → commit → exploring on one command path', async () => {
    const player = beside(wildStarter.position);
    const { save, adapter } = await adapterAt(player);
    adapter.tick(player);
    await adapter.dispatch(player, interact(wildStarter.entityId));
    const opened = adapter.snapshot();
    expect(opened.state).toMatchObject({ mode: 'battle', encounterId: wildStarter.entityId });
    expect(opened.owner).toBe('battle');
    expect(opened.movementAllowed).toBe(false);
    expect(opened.battle).toMatchObject({ phase: 'PLAYER_INPUT', enemy: { level: wildStarter.level } });
    expect((await save.load())!.mode).toBe('battle');
    const rejected = await adapter.dispatch(player, interact(wildStarter.entityId, 'interact-2'));
    expect(rejected).toEqual({ accepted: false, reason: 'owner' });
    let turns = 0;
    while (adapter.snapshot().state.mode === 'battle' && turns < 20) { await adapter.dispatch(player, attack(`hit-${turns}`, turns + 2)); turns++; }
    // v4 holds time-to-kill in a three-to-five turn band at every level, so the exact
    // count is a balance outcome rather than a fixture.
    expect(turns).toBeGreaterThanOrEqual(3);
    expect(turns).toBeLessThanOrEqual(6);
    const settled = adapter.snapshot();
    expect(settled.lastOutcome).toBe('won');
    expect(settled.state.mode).toBe('exploring');
    expect(settled.battle).toBeNull();
    expect(settled.owner).toBe('world');
    expect(settled.movementAllowed).toBe(true);
    const stored = (await save.load())!;
    expect(stored.mode).toBe('exploring');
    expect(stored.rewardLedger).toEqual([`battle:${wildStarter.entityId}:0`]);
    if (settled.lastOutcome === 'won') {
      expect(stored.consumedEntityIds).toEqual([wildStarter.entityId]);
      expect(adapter.chunks.loadedEntityIds).not.toContain(wildStarter.entityId);
      expect(stored.creatures[0].xp).toBeGreaterThan(0);
    }
  });
  it('always warns before it attacks, and never without a healthy creature', async () => {
    const player = beside(hostile.target.position);
    const { adapter } = await adapterAt(player);
    // v3: creatures patrol, so the warning appears when one comes close; an ambush still warns,
    // it just leaves far less time. What must never happen is a battle with no warning at all.
    let ticks = 0;
    let sawWarning = false;
    while (ticks < 600 && adapter.snapshot().state.mode === 'exploring') {
      adapter.tick(player);
      ticks++;
      const view = adapter.snapshot();
      if (view.state.mode !== 'exploring') break;
      if (view.warning?.entityId) sawWarning = true;
    }
    expect(sawWarning, 'uyarısız saldırı').toBe(true);
    const ambush = adapter.snapshot();
    expect(ambush.state).toMatchObject({ mode: 'encounter', encounterId: hostile.target.entityId });
    expect(ambush.pending).toMatchObject({ kind: 'battle', trigger: 'hostile' });
    expect(ambush.movementAllowed).toBe(false);
    const started = await adapter.begin('ambush');
    expect(started.state.mode).toBe('battle');

    const fainted = await adapterAt(player, { creatures: [{ id: 'friend', speciesId: species.id, level: 2, xp: 0, hp: 0, maxHp }] });
    for (let i = 0; i < 600; i++) fainted.adapter.tick(player);
    expect(fainted.adapter.snapshot().state.mode).toBe('exploring');
    expect(fainted.adapter.snapshot().pending).toBeNull();
    await expect(fainted.adapter.dispatch(player, interact(hostile.target.entityId))).rejects.toThrow();
  });
});

describe('commit failure keeps the world closed', () => {
  // worldTick 2 fixes the battle seed on a first-attempt escape, so the settlement is deterministic.
  async function fleeing(failing: () => boolean = () => false) {
    const player = beside(wildStarter.position);
    const save = await storage(base({ playerPosition: { ...player }, lastSafePosition: { ...player }, worldTick: 2 }));
    const adapter = await EncounterAdapter.open(world, flaky(save, failing), 'oturum');
    adapter.tick(player);
    await adapter.dispatch(player, interact(wildStarter.entityId));
    expect(adapter.snapshot().state.mode).toBe('battle');
    return { save, adapter, player };
  }
  it('ends in recovery on a failed settlement and reopens the record locked', async () => {
    let failing = true;
    const { save, adapter, player } = await fleeing(() => failing);
    await adapter.dispatch(player, { type: 'flee', commandId: 'kaç', tick: 2 });
    const failed = adapter.snapshot();
    expect(failed.state.mode).toBe('recovery');
    expect(failed.owner).toBe('none');
    expect(failed.movementAllowed).toBe(false);
    expect(failed.error).toContain('Kayıt');
    expect(failed.lastOutcome).toBeNull();
    const record = (await save.load())!;
    expect(record.mode).toBe('committing');
    expect(record.battle?.outcome).toBe('FLED');
    expect(record.entityCooldowns).toEqual([]);
    expect(record.playerPosition).toEqual(record.lastSafePosition);
    const reopened = await EncounterAdapter.open(world, save, 'yeniden');
    expect(reopened.snapshot().state.mode).toBe('committing');
    expect(reopened.snapshot().movementAllowed).toBe(false);
    expect(await adapter.dispatch(player, attack('savaş-devam', 5))).toEqual({ accepted: false, reason: 'owner' });
    failing = false;
    const recovered = await adapter.retry();
    expect(recovered.state.mode).toBe('exploring');
    expect(recovered.movementAllowed).toBe(true);
    expect(recovered.lastOutcome).toBe('fled');
    const settled = (await save.load())!;
    expect(settled.mode).toBe('exploring');
    expect(settled.playerPosition).toEqual(settled.lastSafePosition);
    expect(settled.entityCooldowns[0]).toMatchObject({ entityId: wildStarter.entityId });
    expect(adapter.chunks.loadedEntityIds).not.toContain(wildStarter.entityId);
    expect((await adapter.retry()).state.mode).toBe('exploring');
  });
  it('keeps retrying the same transaction id until it lands exactly once', async () => {
    let failing = true;
    const { save, adapter, player } = await fleeing(() => failing);
    await adapter.dispatch(player, { type: 'flee', commandId: 'kaç', tick: 2 });
    for (let i = 0; i < 5; i++) expect((await adapter.retry()).state.mode).toBe('recovery');
    failing = false;
    expect((await adapter.retry()).state.mode).toBe('exploring');
    const settled = (await save.load())!;
    for (let i = 0; i < 20; i++) await adapter.retry();
    expect(await save.load()).toEqual(settled);
    expect(settled.entityCooldowns).toHaveLength(1);
    expect(settled.rewardLedger).toEqual([`battle:${wildStarter.entityId}:2`]);
  });
  it('replays an identical battle command once and refuses battle input after the world reopens', async () => {
    const { save, adapter, player } = await fleeing();
    const first = await adapter.dispatch(player, { type: 'flee', commandId: 'kaç', tick: 2 });
    const replay = await adapter.dispatch(player, { type: 'flee', commandId: 'kaç', tick: 2 });
    expect(first).toEqual(replay);
    const stored = (await save.load())!;
    expect(stored.mode).toBe('exploring');
    expect(stored.entityCooldowns).toHaveLength(1);
    expect(stored.rewardLedger).toEqual([`battle:${wildStarter.entityId}:2`]);
    expect(adapter.snapshot().lastOutcome).toBe('fled');
    expect(await adapter.dispatch(player, attack('geç', 9))).toEqual({ accepted: false, reason: 'owner' });
    expect((await adapter.retry()).state.mode).toBe('exploring');
  });
});
