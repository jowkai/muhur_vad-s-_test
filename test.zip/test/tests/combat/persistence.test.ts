import { afterEach, describe, expect, it } from 'vitest';
import type { GameCommand } from '../../src/contracts';
import { creatures } from '../../src/content/catalog';
import { beginBattle, createBattle, stats, type BattleState } from '../../src/game/combat/core';
import { applyBattleCommand, createLootPlan } from '../../src/game/combat/rewards';
import { IndexedDbSave, SaveError, type FaultPoint } from '../../src/game/save/indexeddb';
import { createWorld } from '../../src/world/generation/world';
import { commitEncounterOutcome, createWorldState, validateWorldState, type WorldState } from '../../src/world/persistence/world-save';
import { EncounterAdapter } from '../../src/game/encounter-adapter';

const world = createWorld();
const species = creatures[0];
const player = { id: 'friend', species, level: 2 };
const enemy = { id: 'wild', species: creatures[1], level: 2 };
const maxHp = stats(player).maxHp;
const attack = (id: string, tick = 1): GameCommand => ({ type: 'attack', slot: 0, commandId: id, tick });
const capture = (id: string, tick = 1): GameCommand => ({ type: 'capture', commandId: id, tick });
function record(overrides: Partial<WorldState> = {}, battle: Partial<BattleState> = {}): WorldState {
  const base = beginBattle(createBattle({
    battleId: 'b', encounterId: 'wild-1', seed: 7, player, enemy,
    inventorySnapshot: { seal: 2 }, captureCapacity: 1,
  }));
  const state = createWorldState(world, {
    mode: 'exploring', atCamp: false, inventory: [{ itemId: 'seal', quantity: 2 }, null, null, null], unlockedRecipeIds: [],
    creatures: [{ id: 'friend', speciesId: species.id, level: 2, xp: 0, hp: maxHp, maxHp }],
    creatureCapacity: 2, eggCapacity: 2, eggs: [], battle: null, loot: null,
    rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [],
  });
  return {
    ...state, activeCreatureId: 'friend', mode: 'battle',
    battle: syncParty({ ...base, ...battle }),
    creatures: state.creatures.map(c => c.id === player.id ? { ...c, hp: battle.playerHp ?? base.playerHp } : c),
    loot: createLootPlan('b', enemy, false),
    ...overrides,
  };
}
/** Keeps the team record in step when a fixture overrides the fighter's HP directly. */
function syncParty(battle: BattleState): BattleState {
  return { ...battle, party: battle.party.map((member, index) => index === battle.activeIndex ? { ...member, hp: battle.playerHp } : member) };
}
let counter = 0;
const opened: IndexedDbSave<WorldState>[] = [];
async function storage(initial: WorldState, name = `persist-${counter++}`, fault?: (point: FaultPoint) => void) {
  const save = await IndexedDbSave.open<WorldState>({
    name, initial: () => structuredClone(initial), validate: (value) => validateWorldState(world, value), fault,
  });
  opened.push(save);
  await save.transact(`seed:${name}`, () => {});
  return save;
}
async function putRaw(name: string, value: unknown): Promise<void> {
  const request = indexedDB.open(name, 1);
  await new Promise<void>((resolve, reject) => {
    request.onupgradeneeded = () => { request.result.createObjectStore('records'); request.result.createObjectStore('commands'); };
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const db = request.result;
      const tx = db.transaction('records', 'readwrite');
      tx.objectStore('records').put(value, 'current');
      tx.oncomplete = () => { db.close(); resolve(); };
      tx.onabort = () => { db.close(); reject(tx.error); };
    };
  });
}
afterEach(() => { for (const save of opened) save.close(); opened.length = 0; });

describe('every battle phase survives a reload', () => {
  const phases: [string, Partial<BattleState>, Partial<WorldState>][] = [
    ['INTRO', { phase: 'INTRO' }, {}],
    ['PLAYER_INPUT', { phase: 'PLAYER_INPUT' }, {}],
    ['damaged turn', { phase: 'PLAYER_INPUT', turn: 4, playerHp: 9, enemyHp: 11, stamina: 2, enemyStamina: 3, status: { playerGuard: true, enemyGuard: false, enemyLastSlot: 2, playerEffects: [], enemyEffects: [] } }, {}],
    ['capture ready', { phase: 'PLAYER_INPUT', enemyHp: 3 }, {}],
  ];
  it.each(phases)('reopens a %s battle with identical numbers', async (label, battle, overrides) => {
    const name = `phase-${label.replace(/\s/g, '-')}`;
    const initial = record(overrides, battle);
    const save = await storage(initial, name);
    save.close();
    const reopened = await storage(initial, name);
    const loaded = (await reopened.load())!;
    expect(loaded.battle).toEqual(initial.battle);
    expect(loaded.mode).toBe('battle');
    const adapter = await EncounterAdapter.open(world, reopened, 'reload');
    expect(adapter.snapshot().state).toMatchObject({ mode: 'battle', battleId: 'b', encounterId: 'wild-1' });
    expect(adapter.snapshot().movementAllowed).toBe(false);
    expect(adapter.snapshot().battle).toEqual(initial.battle);
  });
  it('reopens a settled battle in committing and refuses to walk until the world is closed', async () => {
    const name = 'settled';
    const save = await storage(record({}, { enemyHp: 1 }), name);
    const won = await applyBattleCommand(save, 'b', attack('a1'));
    expect(won.battle!.outcome).toBe('WON');
    expect(won.mode).toBe('committing');
    save.close();
    const reopened = await storage(record(), name);
    const adapter = await EncounterAdapter.open(world, reopened, 'reload');
    expect(adapter.snapshot().state.mode).toBe('committing');
    expect(adapter.snapshot().movementAllowed).toBe(false);
    const settled = await commitEncounterOutcome(world, reopened, 'settle:b', 'b');
    expect(settled.mode).toBe('exploring');
    expect(settled.rewardLedger).toEqual(['b']);
    const again = await commitEncounterOutcome(world, reopened, 'settle:b:again', 'b');
    expect(again).toEqual(settled);
  });
});

describe('no duplicated creature, item or XP', () => {
  it('keeps one capture across 100 replays, two reopens and a fresh adapter', async () => {
    const name = 'replay';
    let save = await storage(record({}, { enemyHp: 1 }), name);
    for (let i = 0; i < 50; i++) await applyBattleCommand(save, 'b', capture('same'));
    save.close();
    save = await storage(record(), name);
    for (let i = 0; i < 50; i++) await applyBattleCommand(save, 'b', capture('same'));
    const state = (await save.load())!;
    expect(state.creatures).toHaveLength(2);
    expect(state.creatures.filter((creature) => creature.id === 'capture:wild-1')).toHaveLength(1);
    expect(state.inventory[0]).toEqual({ itemId: 'seal', quantity: 1 });
    expect(state.rewardLedger).toEqual(['b']);
    expect(state.consumedEntityIds).toEqual(['wild-1']);
    expect(state.creatures[0].xp).toBe(13);
    save.close();
    const reopened = await storage(record(), name);
    expect((await reopened.load())!).toEqual(state);
  });
  it('gives the winning loot once even when the bag is full and the command repeats', async () => {
    const full = record({ inventory: [{ itemId: 'seal', quantity: 2 }, { itemId: 'dew_leaf', quantity: 99 }] }, { enemyHp: 1 });
    const save = await storage(full, 'full-box');
    const won = await applyBattleCommand(save, 'b', attack('hit'));
    expect(won.deliveryBox).toEqual([{ kind: 'item', itemId: 'dew_leaf', quantity: 1 }]);
    for (let i = 0; i < 20; i++) await applyBattleCommand(save, 'b', attack('hit'));
    const state = (await save.load())!;
    expect(state.deliveryBox).toHaveLength(1);
    expect(state.inventory[1]).toEqual({ itemId: 'dew_leaf', quantity: 99 });
    expect(state.creatures[0].xp).toBe(22);
  });
  it('refuses a capture into a full collection without spending a seal or the encounter', async () => {
    const save = await storage(record({ creatureCapacity: 1 }, { enemyHp: 1 }), 'full-team');
    await expect(applyBattleCommand(save, 'b', capture('try'))).rejects.toThrow();
    const state = (await save.load())!;
    expect(state.creatures).toHaveLength(1);
    expect(state.inventory[0]).toEqual({ itemId: 'seal', quantity: 2 });
    expect(state.consumedEntityIds).toEqual([]);
    expect(state.rewardLedger).toEqual([]);
    expect(state.battle!.outcome).toBeNull();
  });
  it('gives no XP or loot on defeat and flight, and moves the player exactly once', async () => {
    const lost = await storage(record({}, { playerHp: 1, enemyHp: stats(enemy).maxHp }), 'defeat');
    const defeated = await applyBattleCommand(lost, 'b', attack('hit'));
    expect(defeated.battle!.outcome).toBe('LOST');
    expect(defeated.creatures[0]).toMatchObject({ xp: 0, hp: maxHp });
    const home = await commitEncounterOutcome(world, lost, 'settle:b', 'b');
    expect(home.playerPosition).toEqual(world.camp);
    expect(home.entityCooldowns).toHaveLength(1);
    const repeat = await commitEncounterOutcome(world, lost, 'settle:b:2', 'b');
    expect(repeat).toEqual(home);
    const fled = await storage(record(), 'flee');
    let state = await applyBattleCommand(fled, 'b', { type: 'flee', commandId: 'run', tick: 1 });
    let guard = 0;
    while (!state.battle!.outcome && guard++ < 20) state = await applyBattleCommand(fled, 'b', { type: 'flee', commandId: `run-${guard}`, tick: guard });
    expect(state.creatures[0].xp).toBe(0);
    expect(state.deliveryBox).toEqual([]);
    expect(state.consumedEntityIds).toEqual([]);
  });
});

describe('fault injection and corrupt records', () => {
  it.each(['after-backup', 'after-state', 'after-ledger'] as const)('rolls back a capture aborted %s and lands it on the retry', async (point) => {
    let armed = false;
    const initial = record({}, { enemyHp: 1 });
    const save = await storage(initial, `fault-${point}`, (p) => { if (armed && p === point) throw new Error('disk'); });
    armed = true;
    await expect(applyBattleCommand(save, 'b', capture('c1'))).rejects.toThrow();
    const rolled = (await save.load())!;
    expect(rolled.creatures).toHaveLength(1);
    expect(rolled.rewardLedger).toEqual([]);
    expect(rolled.inventory[0]).toEqual({ itemId: 'seal', quantity: 2 });
    armed = false;
    const done = await applyBattleCommand(save, 'b', capture('c1'));
    expect(done.creatures).toHaveLength(2);
    expect(done.rewardLedger).toEqual(['b']);
    for (let i = 0; i < 10; i++) await applyBattleCommand(save, 'b', capture('c1'));
    expect((await save.load())!.creatures).toHaveLength(2);
  });
  it('migrates a version 1 envelope in place and keeps the original as a backup', async () => {
    const name = 'legacy';
    const legacy = record({}, { phase: 'PLAYER_INPUT', enemyHp: stats(enemy).maxHp });
    await putRaw(name, { version: 1, data: legacy });
    const save = await storage(legacy, name);
    const loaded = (await save.load())!;
    expect(loaded.battle).toEqual(legacy.battle);
    const raw = await save.exportRaw();
    expect(raw.records.find(([key]) => key === 'current')?.[1]).toMatchObject({ version: 2 });
    expect(raw.records.find(([key]) => key === 'backup')?.[1]).toMatchObject({ version: 1 });
    const resumed = await applyBattleCommand(save, 'b', attack('post-migration'));
    expect(resumed.battle!.turn).toBeGreaterThan(1);
  });
  it('explains an unsupported version and a corrupt battle without deleting anything', async () => {
    for (const [name, raw, code] of [
      ['future', { version: 9, state: record() }, 'version'],
      ['broken-battle', { version: 2, state: { ...record(), battle: { ...record().battle, phase: 'RESOLVE_ENEMY' } } }, 'corrupt'],
      ['missing-owner', { version: 2, state: { ...record(), creatures: [] } }, 'corrupt'],
      ['shape', { version: 2 }, 'corrupt'],
    ] as const) {
      await putRaw(name, raw);
      const save = await IndexedDbSave.open<WorldState>({
        name, initial: () => record(), validate: (value) => validateWorldState(world, value),
      });
      opened.push(save);
      const failure = await save.load().catch((error: unknown) => error);
      expect(failure, name).toBeInstanceOf(SaveError);
      expect((failure as SaveError).code, name).toBe(code);
      expect((failure as SaveError).message, name).toMatch(/dışa aktar/);
      const stored = await save.exportRaw();
      expect(stored.records.find(([key]) => key === 'current')?.[1], name).toEqual(raw);
      await expect(applyBattleCommand(save, 'b', attack('after-corrupt'))).rejects.toThrow();
      expect((await save.exportRaw()).records.find(([key]) => key === 'current')?.[1], name).toEqual(raw);
    }
  });
});
