import { afterEach, describe, expect, it } from 'vitest';
import { creatureById } from '../../src/content/catalog';
import { beginBattle, captureChance, captureSucceeds, createBattle, randomStep, resolveBattle, stats, type BattleState } from '../../src/game/combat/core';
import { applyBattleCommand, collectEgg, createLootPlan, hatchEgg, incubateTick, validateProgressState, type ProgressState } from '../../src/game/combat/rewards';
import { cosmeticStage, grantXp, xpRequired } from '../../src/game/progression';
import { IndexedDbSave, type FaultPoint } from '../../src/game/save/indexeddb';
import { MAX_LEVEL, type GameCommand } from '../../src/contracts';
import { BIOME_RECIPE, STARTING_RECIPE_ID, secretIdFor } from '../../src/content/secrets';

/** Keeps the team record in step when a fixture overrides the fighter's HP directly. */
function syncParty(battle: BattleState): BattleState {
  return { ...battle, party: battle.party.map((member, index) => index === battle.activeIndex ? { ...member, hp: battle.playerHp } : member) };
}
const capture: GameCommand = { type: 'capture', commandId: 'capture', tick: 1 };
const attack: GameCommand = { type: 'attack', slot: 0, commandId: 'attack', tick: 1 };
function initial(): ProgressState {
  const player = { id: 'friend', species: creatureById('dewbud')!, level: 2 };
  const enemy = { id: 'wild', species: creatureById('dewbud')!, level: 1 };
  const battle = beginBattle(createBattle({ battleId: 'b', encounterId: 'e', seed: 1, player, enemy, inventorySnapshot: { seal: 2 }, captureCapacity: 1 }));
  battle.enemyHp = 10;
  return { mode: 'battle', atCamp: false, inventory: [{ itemId: 'seal', quantity: 2 }, null], unlockedRecipeIds: [],
    creatures: [{ id: player.id, speciesId: player.species.id, level: 2, xp: 0, hp: stats(player).maxHp, maxHp: stats(player).maxHp }],
    creatureCapacity: 2, eggCapacity: 2, eggs: [], battle, loot: createLootPlan('b', enemy, false),
    rewardLedger: [], consumedEntityIds: [], secretFlags: [], deliveryBox: [] };
}
let counter = 0;
const opened: IndexedDbSave<ProgressState>[] = [];
async function storage(s = initial(), fault?: (p: FaultPoint) => void, name = `rewards-${counter++}`) {
  const save = await IndexedDbSave.open({ name, initial: () => structuredClone(s), validate: validateProgressState, fault }); opened.push(save); return save;
}
afterEach(() => { for (const db of opened) db.close(); opened.length = 0; });

describe('capture and progression', () => {
  it('accepts .3500, rejects .3501 and dead/nonwild/full/no-seal targets without consumption', () => {
    const s = initial().battle!; const max = stats(s.enemy).maxHp;
    s.enemyHp = max * .35; expect(resolveBattle(s, capture).accepted).toBe(true);
    for (const b of [{ ...s, enemyHp: max * .3501 }, { ...s, enemyHp: 0 }, { ...s, capturable: false },
      { ...s, captureCapacity: 0 }, { ...s, inventorySnapshot: { seal: 0 } }]) {
      const before = structuredClone(b); const r = resolveBattle(b, capture);
      expect(r.accepted).toBe(false); expect(r.state).toBe(b); expect(b).toEqual(before);
    }
  });
  it('uses strict probability boundary and rarity/level clamping', () => {
    const b = initial().battle!; const p = captureChance(b);
    expect(p).toBeCloseTo(.665);
    expect(captureSucceeds(b, p - 1e-10)).toBe(true); expect(captureSucceeds(b, p)).toBe(false); expect(captureSucceeds(b, p + 1e-10)).toBe(false);
    b.enemy.species = { ...b.enemy.species, rarity: 'rare' }; expect(captureChance(b)).toBeCloseTo(p - .2);
    b.player.level = 30; b.enemyHp = 1; expect(captureChance(b)).toBe(.85);
    b.player.level = 1; b.enemy.level = 30; b.enemyHp = stats(b.enemy).maxHp * .35; expect(captureChance(b)).toBe(.1);
  });
  it('consumes one seal and one roll on success; failure gives exactly one enemy turn', () => {
    const b = initial().battle!; const r = resolveBattle(b, capture);
    expect(r.state).toMatchObject({ phase: 'CAPTURED', rngState: 270369, inventorySnapshot: { seal: 1 }, turn: 1 });
    let seed = 1; while (randomStep(seed).value < captureChance(b)) seed++;
    b.rngState = seed; const failed = resolveBattle(b, capture);
    expect(failed.state.inventorySnapshot.seal).toBe(1); expect(failed.state.turn).toBe(2);
    expect(failed.receipt!.events.filter(e => e.side === 'enemy')).toHaveLength(1);
    expect(resolveBattle(failed.state, capture).state).toBe(failed.state);
  });
  it('grants multiple levels with remaining XP, clamps at the ceiling and never revives fainted creatures', () => {
    const c = initial().creatures[0];
    const xp = xpRequired(2) + xpRequired(3) + 7;
    expect(grantXp(c, xp)).toMatchObject({ level: 4, xp: 7, hp: 52, maxHp: 52 });
    expect(grantXp({ ...c, hp: 0 }, xp)).toMatchObject({ level: 4, hp: 0, maxHp: 52 });
    expect(grantXp(c, 100_000_000).level).toBe(MAX_LEVEL);
    expect(MAX_LEVEL).toBe(50);
    expect([4, 5, 9, 10, 50].map(cosmeticStage)).toEqual([0, 1, 1, 2, 2]);
    expect(() => grantXp(c, -1)).toThrow();
  });
});

describe('atomic battle rewards', () => {
  it('50 retries and a reopen retain one capture, one seal use, one XP award and no loot', async () => {
    const name = `reopen-${counter++}`; const save = await storage(initial(), undefined, name);
    for (let i = 0; i < 50; i++) await applyBattleCommand(save, 'b', capture);
    save.close(); const reopened = await storage(initial(), undefined, name);
    const s = (await reopened.load())!;
    expect(s.creatures).toHaveLength(2); expect(s.creatures[0].xp).toBe(9); expect(s.creatures[1]).toMatchObject({ id: 'capture:e', speciesId: 'dewbud', level: 1, hp: 10 });
    expect(s.inventory[0]?.quantity).toBe(1); expect(s.rewardLedger).toEqual(['b']); expect(s.consumedEntityIds).toEqual(['e']); expect(s.deliveryBox).toEqual([]);
    expect(s.mode).toBe('committing');
  });
  it('rejects actual full storage/missing seals atomically even if battle snapshot says space exists', async () => {
    for (const kind of ['capacity', 'seals']) {
      const s = initial();
      if (kind === 'capacity') s.creatureCapacity = 1; else s.inventory = [null];
      const save = await storage(s); await save.transact('init', () => {});
      await expect(applyBattleCommand(save, 'b', capture)).rejects.toThrow();
      expect(await save.load()).toEqual(s);
    }
  });
  it('win grants full XP and sends overflowing habitat loot to the delivery box', async () => {
    const s = initial(); s.battle!.enemyHp = 1; s.inventory = [{ itemId: 'seal', quantity: 20 }];
    s.loot!.essence = 'çim'; s.loot!.secretId = 's1';
    const save = await storage(s); const result = await applyBattleCommand(save, 'b', attack);
    expect(result.creatures[0].xp).toBe(16); expect(result.creatures).toHaveLength(1);
    expect(result.deliveryBox).toEqual([{ kind: 'item', itemId: 'dew_leaf', quantity: 1 }, { kind: 'essence', element: 'çim', quantity: 1 }]);
    expect(result.secretFlags).toEqual(['s1']);
    for (let i = 0; i < 50; i++) await applyBattleCommand(save, 'b', attack);
    expect(await save.load()).toEqual(result);
    await expect(applyBattleCommand(save, 'b', { ...attack, commandId: 'another' })).rejects.toThrow();
    expect(await save.load()).toEqual(result);
  });
  it('generates encounter loot once, with no random gardener mark left in it', () => {
    const enemy = initial().battle!.enemy;
    const plan = createLootPlan('b', enemy, true);
    expect(plan).toEqual({ battleId: 'b', habitat: { itemId: 'dew_leaf', quantity: 1 }, essence: 'çim', secretId: null, bonus: null });
    expect(createLootPlan('b', enemy, true)).toEqual(plan);
    // v2: the region recipe comes from its shrine, so no seed can put a secret in the loot.
    expect(createLootPlan('b', enemy, false)).toMatchObject({ essence: null, secretId: null });
  });
  it('fills an available stack and converts a known secret to an essence reward', async () => {
    const s = initial(); s.battle!.enemyHp = 1; s.inventory = [{ itemId: 'dew_leaf', quantity: 98 }]; s.secretFlags = ['s1']; s.loot!.secretId = 's1';
    const result = await applyBattleCommand(await storage(s), 'b', attack);
    expect(result.inventory[0]?.quantity).toBe(99); expect(result.secretFlags).toEqual(['s1']);
    expect(result.deliveryBox).toEqual([{ kind: 'essence', element: 'çim', quantity: 1 }]);
  });
  it('loss heals the active creature without XP, loot or consumed encounter; flee gives no rewards', async () => {
    const s = initial(); s.battle = syncParty({ ...s.battle!, playerHp: 1, enemyHp: stats(s.battle!.enemy).maxHp }); s.creatures[0].hp = 1;
    const lost = await applyBattleCommand(await storage(s), 'b', attack);
    expect(lost.battle!.outcome).toBe('LOST'); expect(lost.creatures[0]).toMatchObject({ hp: 44, xp: 0 }); expect(lost.consumedEntityIds).toEqual([]); expect(lost.deliveryBox).toEqual([]);
    const fled = await applyBattleCommand(await storage(), 'b', { type: 'flee', commandId: 'f', tick: 1 });
    expect(fled.battle!.outcome).toBe('FLED'); expect(fled.creatures[0].xp).toBe(0); expect(fled.deliveryBox).toEqual([]);
  });
  it.each(['after-backup', 'after-state', 'after-ledger'] as const)('rolls back all capture fields on %s then safely retries', async point => {
    let enabled = false; const s = initial(); const save = await storage(s, p => { if (enabled && p === point) throw new Error('fault'); });
    await save.transact('init', () => {}); enabled = true;
    await expect(applyBattleCommand(save, 'b', capture)).rejects.toThrow(); expect(await save.load()).toEqual(s);
    enabled = false; expect((await applyBattleCommand(save, 'b', capture)).creatures).toHaveLength(2);
  });
});

describe('eggs and saved schema', () => {
  const egg = { id: 'egg1', encounterId: 'egg-world', speciesId: 'dewbud', seed: 4 };
  function camp() { const s = initial(); s.battle = null; s.loot = null; s.mode = 'exploring'; s.atCamp = true; s.inventory = [{ itemId: 'heat_herb', quantity: 2 }]; return s; }
  it('collects an egg once without battle, and only 7200 active camp ticks mature it', async () => {
    const save = await storage(camp()); const collected = await collectEgg(save, 'collect', egg);
    expect(collected.battle).toBeNull(); expect(collected.eggs[0].activeTicks).toBe(0);
    expect(await collectEgg(save, 'collect', egg)).toEqual(collected);
    await expect(collectEgg(save, 'other', egg)).rejects.toThrow();
    for (const s of [{ ...collected, atCamp: false }, { ...collected, mode: 'panel' as const }, { ...collected, mode: 'battle' as const }]) expect(incubateTick(s, false)).toBe(s);
    expect(incubateTick(collected, true)).toBe(collected);
    let active = collected; for (let i = 0; i < 7199; i++) active = incubateTick(active, false);
    expect(active.eggs[0].activeTicks).toBe(7199);
    await save.transact('ticks', s => { s.eggs = active.eggs; });
    await expect(hatchEgg(save, 'early', 'egg1')).rejects.toThrow();
    await save.transact('last-tick', s => { s.eggs = incubateTick(s, false).eggs; });
    for (let i = 0; i < 50; i++) await hatchEgg(save, 'hatch', 'egg1');
    const final = (await save.load())!; expect(final.eggs).toEqual([]); expect(final.inventory[0]?.quantity).toBe(1);
    expect(final.creatures[1]).toMatchObject({ id: 'egg:egg-world', speciesId: 'dewbud', level: 1, hp: 40 });
  });
  it.each(['after-backup', 'after-state', 'after-ledger'] as const)('egg cracking is atomic on %s', async point => {
    let enabled = false; const s = camp(); s.eggs = [{ ...egg, activeTicks: 7200 }]; s.consumedEntityIds = [egg.encounterId];
    const save = await storage(s, p => { if (enabled && point === p) throw new Error('fault'); }); await save.transact('init', () => {});
    enabled = true; await expect(hatchEgg(save, 'h', egg.id)).rejects.toThrow(); expect(await save.load()).toEqual(s);
    enabled = false; expect((await hatchEgg(save, 'h', egg.id)).eggs).toEqual([]);
  });
  it('rejects no herb, full storage and full egg capacity without deleting the egg', async () => {
    for (const kind of ['herb', 'creatures', 'eggs']) {
      const s = camp(); s.eggs = [{ ...egg, activeTicks: 7200 }]; s.consumedEntityIds = [egg.encounterId];
      if (kind === 'herb') s.inventory = [null]; if (kind === 'creatures') s.creatureCapacity = 1; if (kind === 'eggs') s.eggCapacity = 1;
      const save = await storage(s); await save.transact('init', () => {});
      if (kind === 'eggs') await expect(collectEgg(save, 'c', { ...egg, id: 'other', encounterId: 'other' })).rejects.toThrow();
      else await expect(hatchEgg(save, 'h', egg.id)).rejects.toThrow();
      expect(await save.load()).toEqual(s);
    }
  });
  it('rejects corrupt HP, phase, RNG, species, capacity and duplicate egg data', () => {
    const mutations = [(s: ProgressState) => { s.battle!.playerHp = 0; }, (s: ProgressState) => { s.battle!.rngState = NaN; },
      (s: ProgressState) => { s.battle!.enemy.species = { ...s.battle!.enemy.species, baseHp: 99 }; }, (s: ProgressState) => { s.creatureCapacity = 0; },
      (s: ProgressState) => { s.battle!.phase = 'RESOLVE_ENEMY'; }, (s: ProgressState) => { s.eggs = [{ ...egg, activeTicks: -1 }]; }];
    for (const mutate of mutations) { const s = initial(); mutate(s); expect(() => validateProgressState(s)).toThrow(); }
    expect(() => validateProgressState(initial())).not.toThrow();
  });
  it('rejects duplicate egg provenance, already hatched eggs and prematurely rewarded active battles', () => {
    const s = camp(); s.consumedEntityIds = [egg.encounterId];
    s.eggs = [{ ...egg, activeTicks: 7200 }, { ...egg, id: 'duplicate', activeTicks: 7200 }];
    expect(() => validateProgressState(s)).toThrow();
    s.eggs.pop(); s.creatures.push({ ...s.creatures[0], id: `egg:${egg.encounterId}` });
    expect(() => validateProgressState(s)).toThrow();
    const b = initial(); b.rewardLedger = ['b']; expect(() => validateProgressState(b)).toThrow();
    b.rewardLedger = []; b.creatures[0].hp--; expect(() => validateProgressState(b)).toThrow();
  });
  it('rejects corrupted persisted command receipts', async () => {
    const resolved = await applyBattleCommand(await storage(), 'b', capture);
    const badHp = structuredClone(resolved); badHp.battle!.committedActions.capture.snapshot.enemyHp = -1;
    const badRng = structuredClone(resolved); badRng.battle!.committedActions.capture.snapshot.rngState = NaN;
    const badEvent = structuredClone(resolved); badEvent.battle!.committedActions.capture.events[0].damage = -1;
    const wrongOutcome = structuredClone(resolved); wrongOutcome.battle!.committedActions.capture.events.at(-1)!.outcome = 'LOST';
    const missingHit = structuredClone(resolved); delete missingHit.battle!.committedActions.capture.events[0].hit;
    for (const s of [badHp, badRng, badEvent, wrongOutcome, missingHit]) expect(() => validateProgressState(s)).toThrow();
  });
});

describe('gardener marks teach recipes', () => {
  it('unlocks the region recipe on the first mark and pays an essence for a known one', async () => {
    const first = initial();
    first.battle!.enemyHp = 1;
    first.loot!.secretId = secretIdFor('forest');
    first.unlockedRecipeIds = [STARTING_RECIPE_ID];
    const save = await storage(first);
    const taught = await applyBattleCommand(save, 'b', attack);
    expect(taught.secretFlags).toEqual([secretIdFor('forest')]);
    expect(taught.unlockedRecipeIds).toEqual([STARTING_RECIPE_ID, BIOME_RECIPE.forest]);
    for (let i = 0; i < 20; i++) await applyBattleCommand(save, 'b', attack);
    expect((await save.load())!.unlockedRecipeIds).toEqual([STARTING_RECIPE_ID, BIOME_RECIPE.forest]);

    const known = initial();
    known.battle!.enemyHp = 1;
    known.loot!.secretId = secretIdFor('forest');
    known.secretFlags = [secretIdFor('forest')];
    known.unlockedRecipeIds = [STARTING_RECIPE_ID, BIOME_RECIPE.forest];
    const repeat = await applyBattleCommand(await storage(known), 'b', attack);
    expect(repeat.unlockedRecipeIds).toEqual([STARTING_RECIPE_ID, BIOME_RECIPE.forest]);
    expect(repeat.secretFlags).toEqual([secretIdFor('forest')]);
    expect(repeat.deliveryBox.some((entry) => entry.kind === 'essence')).toBe(true);
  });
  it('never teaches a recipe on a loss, a flight or a capture', async () => {
    for (const [label, build] of [
      // The record keeps the active creature's HP in step with the battle, so move both.
      ['lost', () => { const s = initial(); s.battle = syncParty({ ...s.battle!, playerHp: 1, enemyHp: stats(s.battle!.enemy).maxHp }); s.creatures[0].hp = 1; return s; }],
      ['captured', () => { const s = initial(); s.battle!.enemyHp = 1; return s; }],
    ] as const) {
      const s = build();
      s.loot!.secretId = secretIdFor('ice');
      s.unlockedRecipeIds = [STARTING_RECIPE_ID];
      const save = await storage(s);
      const result = await applyBattleCommand(save, 'b', label === 'captured' ? capture : attack);
      expect(result.unlockedRecipeIds, label).toEqual([STARTING_RECIPE_ID]);
      expect(result.secretFlags, label).toEqual([]);
    }
  });
});
