import { describe, expect, it } from 'vitest';
import { MAX_LEVEL, BIOME_IDS } from '../../src/contracts';
import { GAME_CONFIG } from '../../src/config';
import { createWorld } from '../../src/world/generation/world';
import { generateChunk, sampleTerrain } from '../../src/world/terrain/terrain';
import { canOccupy } from '../../src/world/collision/collision';
import { chunkAt, residency, spawnsForChunk, CHUNK_GRID } from '../../src/world/chunks/chunks';
import { hash, randomAt } from '../../src/world/generation/random';
import { creatureById, itemById } from '../../src/content/catalog';
import { worldToMinimap, minimapToWorld } from '../../src/world/minimap-data';

/** 100 distinct seeds; every property below must hold for all of them. */
const SEEDS = Array.from({ length: 100 }, (_, index) => `property-${index * 7919 + 13}`);
const half = GAME_CONFIG.worldSize / 2;
const pick = (seed: string, stream: string, index: number, span: number) => Math.floor(randomAt(seed, stream, index) * span);

describe('world generation properties over 100 seeds', () => {
  it('rebuilds an identical world from the same seed and differs between seeds', () => {
    const fingerprints = new Set<string>();
    for (const seed of SEEDS) {
      const a = createWorld(seed), b = createWorld(seed);
      expect(a).toEqual(b);
      const chunk = chunkAt({ x: pick(seed, 'x', 0, 2000) - 1000, z: pick(seed, 'z', 0, 2000) - 1000 });
      expect(spawnsForChunk(a, chunk)).toEqual(spawnsForChunk(b, chunk));
      fingerprints.add(JSON.stringify(a.regions.map((region) => region.center)));
    }
    expect(fingerprints.size).toBeGreaterThan(90);
  });
  it('keeps the safe camp walkable and the starters calm on every seed', () => {
    for (const seed of SEEDS) {
      const world = createWorld(seed);
      expect(canOccupy(world, world.camp)).toBe(true);
      for (const offset of [[0, 0], [20, 0], [-20, 0], [0, 20], [0, -20], [14, 14], [-14, -14]]) {
        const cell = sampleTerrain(world, { x: world.camp.x + offset[0], z: world.camp.z + offset[1] });
        expect(cell, seed).toMatchObject({ biomeId: 'meadow', traversable: true, hazard: 'none' });
      }
      expect(world.starters).toHaveLength(4);
      for (const starter of world.starters) {
        expect(starter.aggressive).toBe(false);
        expect(starter.level).toBeLessThanOrEqual(2);
        expect(canOccupy(world, starter.position), `${seed} ${starter.entityId}`).toBe(true);
      }
      expect(new Set(world.starters.map((entry) => entry.entityId)).size).toBe(4);
    }
  });
  it('places every generated entity on walkable ground inside its own chunk', () => {
    for (const seed of SEEDS) {
      const world = createWorld(seed);
      const centre = { x: pick(seed, 'cx', 1, 1800) - 900, z: pick(seed, 'cz', 1, 1800) - 900 };
      const ids = new Set<string>();
      for (const chunk of residency(centre, 1)) {
        for (const { target, speciesId, itemId } of spawnsForChunk(world, chunk)) {
          expect(chunkAt(target.position).id, seed).toBe(chunk.id);
          const cell = sampleTerrain(world, target.position);
          expect(cell.traversable, `${seed} ${target.entityId}`).toBe(true);
          expect(cell.hazard).toBe('none');
          expect(ids.has(target.entityId)).toBe(false);
          ids.add(target.entityId);
          expect(target.level).toBeGreaterThanOrEqual(target.kind === 'resource' ? 0 : 1);
          expect(target.level).toBeLessThanOrEqual(MAX_LEVEL);
          if (target.kind === 'egg') expect(creatureById(speciesId!)).toBeTruthy();
          if (target.kind === 'resource') expect(itemById(itemId!)).toBeTruthy();
          if (target.aggressive) expect(target.kind).toBe('creature');
        }
      }
    }
  });
  it('generates chunks independently of visit order on every seed', () => {
    for (const seed of SEEDS.slice(0, 25)) {
      const world = createWorld(seed);
      const x = pick(seed, 'ox', 2, CHUNK_GRID - 2) + 1, z = pick(seed, 'oz', 2, CHUNK_GRID - 2) + 1;
      const forward = [generateChunk(world, x, z), generateChunk(world, x + 1, z), generateChunk(world, x, z + 1)];
      const backward = [generateChunk(world, x, z + 1), generateChunk(world, x + 1, z), generateChunk(world, x, z)];
      expect(backward[2]).toEqual(forward[0]);
      expect(backward[1]).toEqual(forward[1]);
      expect(backward[0]).toEqual(forward[2]);
      for (let i = 0; i < 32; i++) {
        const edge = { x: (x + 1) * GAME_CONFIG.chunkSize - half - 1, z: z * GAME_CONFIG.chunkSize - half + i * 2 + 1 };
        expect(sampleTerrain(world, edge)).toEqual(forward[0].cells.find((cell) => cell.position.x === edge.x && cell.position.z === edge.z));
      }
    }
  });
  it('never returns an out-of-range biome, height or hash value', () => {
    for (const seed of SEEDS) {
      const world = createWorld(seed);
      for (let sample = 0; sample < 12; sample++) {
        const point = { x: pick(seed, `px${sample}`, sample, 2048) - half, z: pick(seed, `pz${sample}`, sample, 2048) - half };
        const cell = sampleTerrain(world, point);
        expect(BIOME_IDS).toContain(cell.biomeId);
        expect(Number.isFinite(cell.height)).toBe(true);
        expect(Math.abs(cell.height)).toBeLessThan(12);
        expect(cell.blend).toBeGreaterThanOrEqual(0);
        expect(cell.blend).toBeLessThanOrEqual(0.5);
        if (cell.secondaryBiome) expect(BIOME_IDS).toContain(cell.secondaryBiome);
        const value = hash(seed, 'property', sample, cell.height | 0);
        expect(Number.isSafeInteger(value) && value >= 0 && value <= 0xffffffff).toBe(true);
      }
    }
  });
  it('keeps every region entrance walkable from camp along its designed road', () => {
    // 20 of the 100 seeds, walked as the game walks: the carved corridor must stay occupiable.
    for (const seed of SEEDS.slice(0, 20)) {
      const world = createWorld(seed);
      const volcanic = world.regions.find((region) => region.biomeId === 'volcanic')!;
      for (const region of world.regions) {
        const from = region.biomeId === 'flame' ? volcanic.entrance : world.camp;
        const span = Math.hypot(region.entrance.x - from.x, region.entrance.z - from.z);
        for (let step = 0; step <= Math.ceil(span); step++) {
          const t = span === 0 ? 1 : Math.min(1, step / span);
          const point = { x: from.x + (region.entrance.x - from.x) * t, z: from.z + (region.entrance.z - from.z) * t };
          expect(canOccupy(world, point), `${seed} → ${region.biomeId} at ${step}m`).toBe(true);
        }
        expect(sampleTerrain(world, region.entrance)).toMatchObject({ biomeId: region.biomeId, traversable: true, hazard: 'none' });
      }
    }
  }, 30_000);
  it('round-trips minimap projection within a pixel for random offsets', () => {
    for (const seed of SEEDS) {
      const player = { x: pick(seed, 'mx', 3, 1600) - 800, z: pick(seed, 'mz', 3, 1600) - 800 };
      for (let sample = 0; sample < 6; sample++) {
        const target = { x: player.x + pick(seed, `tx${sample}`, sample, 180) - 90, z: player.z + pick(seed, `tz${sample}`, sample, 180) - 90 };
        const point = worldToMinimap(target, player, 192, 96);
        const back = minimapToWorld({ x: point.x, y: point.y }, player, 192, 96);
        expect(Math.abs(back.x - target.x)).toBeLessThan(0.01);
        expect(Math.abs(back.z - target.z)).toBeLessThan(0.01);
        expect(point.visible).toBe(Math.hypot(target.x - player.x, target.z - player.z) <= 96);
      }
    }
  });
});
