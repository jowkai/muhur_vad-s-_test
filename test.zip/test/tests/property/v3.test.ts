import { describe, expect, it } from 'vitest';
import { CREATURE_ROLES, MAX_LEVEL, TREE_KINDS, type MountRecord } from '../../src/contracts';
import { defaultLoadout } from '../../src/content/loadout';
import { catalog, creatureById, creatures, itemById } from '../../src/content/catalog';
import { graftedMoveIds, graftMoveId } from '../../src/content/graft';
import { ROLE_RULES, roleUnlocked, travelSpeed } from '../../src/game/roles';
import { stats } from '../../src/game/combat/core';
import { createWorld } from '../../src/world/generation/world';
import { canOccupy } from '../../src/world/collision/collision';
import { BANDS, CHUNK_GRID, chunkKey, spawnsForChunk } from '../../src/world/chunks/chunks';
import { sampleTerrain } from '../../src/world/terrain/terrain';
import { nodeFor } from '../../src/world/gathering/gathering';
import { ambushes, patrolPosition, PATROL_RADIUS } from '../../src/world/encounters/patrol';
import { randomAt } from '../../src/world/generation/random';

const SEEDS = Array.from({ length: 100 }, (_, index) => `v3-${index * 101 + 3}`);
const RUNS = 100;

describe('v3 content holds together over many seeds', () => {
  it('keeps every species inside its band, size and speed envelope', () => {
    for (const species of creatures) {
      expect(species.roles.length, species.id).toBeLessThanOrEqual(2);
      expect([1, 2, 3], species.id).toContain(species.size);
      expect(species.baseSpeed, species.id).toBeGreaterThanOrEqual(.5);
      expect(species.baseSpeed, species.id).toBeLessThanOrEqual(2.5);
      for (const role of species.roles) expect(CREATURE_ROLES).toContain(role);
      // A carrier is worth riding: it moves the player faster than their own feet.
      if (species.roles.includes('ride') || species.roles.includes('fly')) {
        expect(species.baseSpeed, species.id).toBeGreaterThan(1.2);
      }
      // A tank is the slow, sturdy one and never carries the player.
      if (species.roles.includes('tank')) {
        expect(species.baseSpeed, species.id).toBeLessThan(1);
        expect(species.roles.some((role) => ROLE_RULES[role].carries), species.id).toBe(false);
      }
      // Anything that does carry is at least as quick as walking.
      if (species.roles.some((role) => ROLE_RULES[role].carries)) {
        expect(species.baseSpeed, species.id).toBeGreaterThanOrEqual(1);
      }
    }
  });
  it('lets every role be reached by a real creature at a real level', () => {
    for (const role of CREATURE_ROLES) {
      const species = creatures.filter((row) => row.roles.includes(role));
      expect(species.length, role).toBeGreaterThan(0);
      const rule = ROLE_RULES[role];
      expect(rule.unlockLevel).toBeLessThanOrEqual(MAX_LEVEL);
      const grown = { id: 'probe', speciesId: species[0].id, level: MAX_LEVEL, xp: 0, hp: 1, maxHp: 1 };
      expect(roleUnlocked(grown, role), role).toBe(true);
    }
  });
  it('prices a hundred mounts without ever exceeding the speed cap', () => {
    const riders = creatures.filter((row) => row.roles.some((role) => ROLE_RULES[role].carries));
    for (let run = 0; run < RUNS; run++) {
      const species = riders[run % riders.length];
      const role = species.roles.find((entry): entry is MountRecord['role'] => ROLE_RULES[entry].carries)!;
      const level = Math.max(ROLE_RULES[role].unlockLevel, 1 + (run % MAX_LEVEL));
      const maxHp = stats({ id: 'm', species, level }).maxHp;
      const creature = { id: 'm', speciesId: species.id, level, xp: 0, hp: maxHp, maxHp };
      const speed = travelSpeed({ mount: { creatureId: 'm', role }, creatures: [creature] });
      expect(speed, `${species.id}/${role}`).toBeGreaterThan(0);
      expect(speed, `${species.id}/${role}`).toBeLessThanOrEqual(3);
      if (roleUnlocked(creature, role)) expect(speed, `${species.id}/${role}`).toBeGreaterThanOrEqual(1);
    }
  });
  it('grafts only real moves and never loses the opener or the support slot', () => {
    const grafts = catalog.items.filter((item) => item.effect?.kind === 'graft');
    for (const species of creatures) {
      // The opener and the support slot belong to the loadout, which is what a graft edits.
      const base = defaultLoadout(species.id);
      for (const item of grafts) {
        const moveId = graftMoveId(item.id)!;
        const set = graftedMoveIds(species.id, [moveId]);
        expect(set, `${species.id}/${moveId}`).toHaveLength(4);
        expect(set[0]).toBe(base[0]);
        expect(set[2]).toBe(base[2]);
        expect(new Set(set).size).toBe(4);
        for (const id of set) expect(catalog.moves.some((move) => move.id === id)).toBe(true);
      }
    }
  });
});

describe('v3 worlds over one hundred distinct seeds', () => {
  it('plants trees, veins and caches everywhere, always reachable', () => {
    for (const seed of SEEDS) {
      const world = createWorld(seed);
      let trees = 0, picks = 0, checked = 0;
      for (let index = 0; index < 40; index++) {
        const x = Math.floor(randomAt(seed, 'probe-x', index) * CHUNK_GRID);
        const z = Math.floor(randomAt(seed, 'probe-z', index) * CHUNK_GRID);
        for (const spawn of spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z }, 'night')) {
          if (spawn.target.kind !== 'resource') continue;
          checked++;
          const node = nodeFor(world, spawn, [], 'night')!;
          expect(canOccupy(world, node.position), `${seed}/${node.entityId}`).toBe(true);
          if (node.method === 'fell') {
            trees++;
            expect(TREE_KINDS).toContain(spawn.treeKind);
            expect(itemById(node.itemId)).toBeDefined();
          }
          if (node.autoPick) picks++;
        }
      }
      expect(checked, seed).toBeGreaterThan(10);
      expect(trees, seed).toBeGreaterThan(0);
      expect(picks, seed).toBeGreaterThan(0);
    }
  });
  it('keeps creature levels inside the raised bands in every seed', () => {
    for (const seed of SEEDS.slice(0, 6)) {
      const world = createWorld(seed);
      for (let index = 0; index < 30; index++) {
        const x = Math.floor(randomAt(seed, 'lvl-x', index) * CHUNK_GRID);
        const z = Math.floor(randomAt(seed, 'lvl-z', index) * CHUNK_GRID);
        for (const spawn of spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z })) {
          if (spawn.target.kind !== 'creature') continue;
          const [low, high] = BANDS[sampleTerrain(world, spawn.target.position).biomeId];
          expect(spawn.target.level, `${seed}/${spawn.target.entityId}`).toBeGreaterThanOrEqual(low);
          expect(spawn.target.level, `${seed}/${spawn.target.entityId}`).toBeLessThanOrEqual(high);
          expect(creatureById(spawn.speciesId!)).toBeDefined();
        }
      }
    }
  });
  it('walks patrols on stable routes and draws ambushes the same way twice', () => {
    for (const seed of SEEDS.slice(0, 6)) {
      const world = createWorld(seed);
      for (let index = 0; index < 20; index++) {
        const x = Math.floor(randomAt(seed, 'patrol-x', index) * CHUNK_GRID);
        const z = Math.floor(randomAt(seed, 'patrol-z', index) * CHUNK_GRID);
        for (const spawn of spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z })) {
          if (!spawn.target.aggressive) continue;
          for (const tick of [0, 37, 180]) {
            const at = patrolPosition(world, spawn.target.entityId, spawn.target.position, tick, true);
            expect(patrolPosition(world, spawn.target.entityId, spawn.target.position, tick, true)).toEqual(at);
            expect(Math.hypot(at.x - spawn.target.position.x, at.z - spawn.target.position.z)).toBeLessThanOrEqual(PATROL_RADIUS + 1e-6);
          }
          const first = ambushes(world, spawn.target.entityId, spawn.target.level, 'night', 2);
          expect(ambushes(world, spawn.target.entityId, spawn.target.level, 'night', 2)).toBe(first);
        }
      }
    }
  });
});
