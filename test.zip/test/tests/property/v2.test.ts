import { describe, expect, it } from 'vitest';
import { BIOME_IDS, PARTY_LIMIT } from '../../src/contracts';
import { GAME_CONFIG } from '../../src/config';
import { creatureById, creatures } from '../../src/content/catalog';
import { beginBattle, createBattle, resolveBattle, stats, type BattleState } from '../../src/game/combat/core';
import { standing, switchRefusal, type PartyMember } from '../../src/game/party';
import { createWorld } from '../../src/world/generation/world';
import { canOccupy } from '../../src/world/collision/collision';
import { sampleTerrain } from '../../src/world/terrain/terrain';
import { CHUNK_GRID, chunkKey, spawnsForChunk } from '../../src/world/chunks/chunks';
import { DAY_CYCLE_TICKS, advanceDayTick, phaseAt, skyLight } from '../../src/world/daynight';
import { shrinesFor, SHRINE_MAX_DISTANCE, SHRINE_MIN_DISTANCE } from '../../src/world/shrines/shrines';
import { nodeFor } from '../../src/world/gathering/gathering';
import { randomAt } from '../../src/world/generation/random';

const RUNS = 100;
const SEEDS = Array.from({ length: 20 }, (_, index) => `tohum-${index * 31 + 7}`);

describe('v2 worlds over twenty seeds', () => {
  it('stands eight walkable shrines in every world it can generate', () => {
    for (const seed of SEEDS) {
      const world = createWorld(seed);
      const shrines = shrinesFor(world);
      expect(shrines, seed).toHaveLength(8);
      expect(new Set(shrines.map((shrine) => shrine.biomeId)).size).toBe(8);
      for (const shrine of shrines) {
        const terrain = sampleTerrain(world, shrine.position);
        expect(terrain.traversable, `${seed}/${shrine.id}`).toBe(true);
        expect(terrain.hazard).toBe('none');
        expect(canOccupy(world, shrine.position)).toBe(true);
        const entrance = world.regions.find((region) => region.biomeId === shrine.biomeId)!.entrance;
        const distance = Math.hypot(shrine.position.x - entrance.x, shrine.position.z - entrance.z);
        expect(distance).toBeGreaterThanOrEqual(SHRINE_MIN_DISTANCE - GAME_CONFIG.cellSize);
        expect(distance).toBeLessThanOrEqual(SHRINE_MAX_DISTANCE + GAME_CONFIG.cellSize);
      }
    }
  });
  it('keeps the day and night worlds the same size and deterministic', () => {
    for (const seed of SEEDS.slice(0, 6)) {
      const world = createWorld(seed);
      for (let index = 0; index < 8; index++) {
        const x = Math.floor(randomAt(seed, 'probe-x', index) * CHUNK_GRID);
        const z = Math.floor(randomAt(seed, 'probe-z', index) * CHUNK_GRID);
        const chunk = { id: chunkKey(x, z), chunkX: x, chunkZ: z };
        const day = spawnsForChunk(world, chunk, 'day');
        const night = spawnsForChunk(world, chunk, 'night');
        expect(night).toHaveLength(day.length);
        expect(spawnsForChunk(world, chunk, 'night')).toEqual(night);
        for (let slot = 0; slot < day.length; slot++) {
          expect(night[slot].target.position).toEqual(day[slot].target.position);
          expect(night[slot].target.kind).toBe(day[slot].target.kind);
        }
      }
    }
  });
  it('gives every resource in a hundred chunks exactly one reachable method', () => {
    const world = createWorld();
    const counts = { pick: 0, dig: 0, cache: 0, garden: 0, chest: 0, fell: 0 };
    let nightOnly = 0, checked = 0;
    for (let index = 0; index < RUNS; index++) {
      const x = Math.floor(randomAt(world.seed, 'chunk-x', index) * CHUNK_GRID);
      const z = Math.floor(randomAt(world.seed, 'chunk-z', index) * CHUNK_GRID);
      for (const spawn of spawnsForChunk(world, { id: chunkKey(x, z), chunkX: x, chunkZ: z }, 'night')) {
        const node = nodeFor(world, spawn, [], 'night');
        if (!node) { expect(spawn.target.kind).not.toBe('resource'); continue; }
        checked++;
        counts[node.method]++;
        if (node.nightOnly) nightOnly++;
        expect(node.entityId).toBe(spawn.target.entityId);
        expect(node.itemId).toBe(spawn.itemId);
      }
    }
    expect(checked).toBeGreaterThan(80);
    expect(counts.pick).toBeGreaterThan(0);
    expect(counts.dig).toBeGreaterThan(0);
    expect(counts.cache).toBeGreaterThan(0);
    expect(nightOnly).toBeGreaterThan(0);
    expect(counts.garden + counts.chest).toBe(0);
    expect(counts.fell).toBeGreaterThan(0);
  });
  it('walks the ten minute clock through a full day without drifting', () => {
    let tick = 0;
    let days = 0;
    for (let step = 0; step < DAY_CYCLE_TICKS * 2; step++) {
      const next = advanceDayTick(tick, 1);
      if (next < tick) days++;
      tick = next;
      expect(tick).toBeGreaterThanOrEqual(0);
      expect(tick).toBeLessThan(DAY_CYCLE_TICKS);
      expect(['day', 'night']).toContain(phaseAt(tick));
      const light = skyLight(tick);
      expect(light.ambient).toBeGreaterThan(0);
      expect(light.sun).toBeGreaterThanOrEqual(0);
    }
    expect(days).toBe(2);
    expect(tick).toBe(0);
  });
});

describe('six creature battles over a hundred runs', () => {
  const member = (index: number, level: number, hp?: number): PartyMember => {
    const species = creatures[index % creatures.length];
    const id = `p${index}`;
    const maxHp = stats({ id, species, level }).maxHp;
    return { id, species, level, hp: hp ?? maxHp };
  };
  it('never breaks HP, energy, party or status bounds', () => {
    for (let run = 0; run < RUNS; run++) {
      const size = 1 + (run % PARTY_LIMIT);
      const party = Array.from({ length: size }, (_, index) => member(run + index, 3 + ((run + index) % 20)));
      const activeIndex = run % size;
      const active = party[activeIndex];
      let state: BattleState = beginBattle(createBattle({
        battleId: `b${run}`, encounterId: `e${run}`, seed: 1 + run * 7919,
        player: { id: active.id, species: active.species, level: active.level },
        enemy: { id: 'wild', species: creatures[(run * 3) % creatures.length], level: 2 + (run % 25) },
        party, activeIndex, playerHp: active.hp, inventorySnapshot: { seal: run % 3, field_salve: run % 2 }, captureCapacity: run % 2,
      }));
      for (let turn = 1; turn <= 40 && !state.outcome; turn++) {
        const roll = randomAt(`battle-${run}`, 'action', turn);
        const forced = state.phase === 'FORCED_SWITCH';
        const target = standing(state.party).find((index) => index !== state.activeIndex);
        const command = forced
          ? target === undefined ? null : { type: 'switch-party' as const, index: target, commandId: `f${turn}`, tick: turn }
          : roll < .1 && target !== undefined && !switchRefusal(state.party, state.activeIndex, target, false)
            ? { type: 'switch-party' as const, index: target, commandId: `s${turn}`, tick: turn }
            : roll < .2 && (state.inventorySnapshot.field_salve ?? 0) > 0
              ? { type: 'use-battle-item' as const, itemId: 'field_salve', commandId: `i${turn}`, tick: turn }
              : { type: 'attack' as const, slot: (Math.floor(roll * 4) % 4) as 0 | 1 | 2 | 3, commandId: `a${turn}`, tick: turn };
        if (!command) break;
        state = resolveBattle(state, command).state;
        expect(state.party.length, `${run}`).toBe(size);
        expect(state.party[state.activeIndex].id).toBe(state.player.id);
        expect(state.party[state.activeIndex].hp).toBe(state.playerHp);
        expect(state.playerHp).toBeGreaterThanOrEqual(0);
        expect(state.playerHp).toBeLessThanOrEqual(stats(state.player).maxHp);
        expect(state.enemyHp).toBeGreaterThanOrEqual(0);
        for (const energy of [state.stamina, state.enemyStamina]) {
          expect(energy).toBeGreaterThanOrEqual(0);
          expect(energy).toBeLessThanOrEqual(5);
        }
        for (const effects of [state.status.playerEffects, state.status.enemyEffects]) {
          expect(effects.length).toBeLessThanOrEqual(3);
          expect(new Set(effects.map((effect) => effect.kind)).size).toBe(effects.length);
          for (const effect of effects) expect(effect.turns).toBeGreaterThan(0);
        }
        for (const [itemId, quantity] of Object.entries(state.inventorySnapshot)) {
          expect(quantity, itemId).toBeGreaterThanOrEqual(0);
        }
      }
      if (state.outcome) {
        expect(state.status.playerEffects).toEqual([]);
        expect(state.status.enemyEffects).toEqual([]);
        if (state.outcome === 'LOST') expect(standing(state.party)).toEqual([]);
      }
    }
  });
  it('gives every catalogue species a usable battle set', () => {
    for (const species of creatures) {
      const fighter = { id: 'probe', species: creatureById(species.id)!, level: 10 };
      const battle = beginBattle(createBattle({
        battleId: 'b', encounterId: 'e', seed: 7, player: fighter,
        enemy: { id: 'wild', species: creatures[0], level: 5 },
      }));
      const result = resolveBattle(battle, { type: 'attack', slot: 0, commandId: 'a', tick: 1 });
      expect(result.accepted, species.id).toBe(true);
      expect(BIOME_IDS).toContain(species.biomeId);
    }
  });
});
