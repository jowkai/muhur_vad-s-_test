import { describe, expect, it } from 'vitest';
import type { GameCommand } from '../../src/contracts';
import { MAX_LEVEL } from '../../src/contracts';
import { UNLOCK_TIERS } from '../../src/content/schema';
import { creatures, items, recipes } from '../../src/content/catalog';
import { planInventory, type ContentState } from '../../src/content/alchemy';
import {
  beginBattle, captureChance, createBattle, movesFor, randomStep, resolveBattle, stats, type BattleState,
} from '../../src/game/combat/core';
import { grantXp, xpRequired } from '../../src/game/progression';
import { randomAt } from '../../src/world/generation/random';

const RUNS = 100;
const seed = (index: number) => `battle-${index * 7919 + 17}`;
const roll = (index: number, stream: string, turn: number) => randomAt(seed(index), stream, turn);
function fixture(index: number): BattleState {
  const player = { id: 'friend', species: creatures[index % creatures.length], level: 1 + (index % 30) };
  const enemy = { id: 'wild', species: creatures[(index + 3) % creatures.length], level: 1 + ((index * 5) % 30) };
  return beginBattle(createBattle({
    battleId: `b${index}`, encounterId: `e${index}`, seed: 1 + index * 104729, player, enemy,
    inventorySnapshot: { seal: index % 4 }, captureCapacity: index % 3,
  }));
}
function command(index: number, turn: number): GameCommand {
  const value = roll(index, 'command', turn);
  const id = `c${index}-${turn}`;
  if (value < 0.1) return { type: 'flee', commandId: id, tick: turn };
  if (value < 0.2) return { type: 'capture', commandId: id, tick: turn };
  return { type: 'attack', slot: (Math.floor(value * 4) % 4) as 0 | 1 | 2 | 3, commandId: id, tick: turn };
}

describe('battle invariants over 100 randomised runs', () => {
  it('never leaves HP, energy, phase or ledger in an impossible state', () => {
    for (let index = 0; index < RUNS; index++) {
      let state = fixture(index);
      const playerMax = stats(state.player).maxHp, enemyMax = stats(state.enemy).maxHp;
      const accepted: string[] = [];
      for (let turn = 1; turn <= 40 && !state.outcome; turn++) {
        const result = resolveBattle(state, command(index, turn));
        if (result.accepted && !result.duplicate) accepted.push(result.receipt!.command.commandId);
        state = result.state;
        expect(state.playerHp, `${index}`).toBeGreaterThanOrEqual(0);
        expect(state.playerHp).toBeLessThanOrEqual(playerMax);
        expect(state.enemyHp).toBeGreaterThanOrEqual(0);
        expect(state.enemyHp).toBeLessThanOrEqual(enemyMax);
        expect(state.stamina).toBeGreaterThanOrEqual(0);
        expect(state.stamina).toBeLessThanOrEqual(5);
        expect(state.enemyStamina).toBeGreaterThanOrEqual(0);
        expect(state.enemyStamina).toBeLessThanOrEqual(5);
        expect(state.rngState).toBeGreaterThan(0);
        expect(state.rngState).toBeLessThanOrEqual(0xffffffff);
        expect(Object.keys(state.committedActions)).toEqual(accepted);
        expect((state.inventorySnapshot.seal ?? 0)).toBeGreaterThanOrEqual(0);
      }
      if (state.outcome) {
        expect(state.phase).toBe(state.outcome);
        if (state.outcome === 'WON') expect(state.enemyHp).toBe(0);
        if (state.outcome === 'LOST') expect(state.playerHp).toBe(0);
        if (state.outcome === 'CAPTURED') expect(state.enemyHp).toBeGreaterThan(0);
        expect(resolveBattle(state, command(index, 99)).accepted).toBe(false);
      }
    }
  });
  it('replays the identical battle from the same seed and command list', () => {
    for (let index = 0; index < RUNS; index++) {
      const play = () => {
        let state = fixture(index);
        for (let turn = 1; turn <= 25 && !state.outcome; turn++) state = resolveBattle(state, command(index, turn)).state;
        return state;
      };
      expect(play()).toEqual(play());
      expect(JSON.parse(JSON.stringify(play()))).toEqual(play());
    }
  });
  it('keeps capture chance inside its clamps and only above the health threshold', () => {
    for (let index = 0; index < RUNS; index++) {
      const state = fixture(index);
      const weakened = { ...state, enemyHp: Math.max(1, Math.floor(stats(state.enemy).maxHp * roll(index, 'hp', 1))) };
      const chance = captureChance(weakened);
      expect(chance).toBeGreaterThanOrEqual(0.1);
      expect(chance).toBeLessThanOrEqual(0.85);
      const attempt = resolveBattle({ ...weakened, capturable: true, captureCapacity: 1, inventorySnapshot: { seal: 1 } }, { type: 'capture', commandId: 'try', tick: 1 });
      const allowed = weakened.enemyHp <= stats(weakened.enemy).maxHp * 0.35;
      expect(attempt.accepted, `${index}`).toBe(allowed);
      if (!allowed) expect(attempt.state).toBe(weakened.capturable ? attempt.state : weakened);
    }
  });
  it('moves the RNG forward monotonically inside its 32-bit range', () => {
    for (let index = 0; index < RUNS; index++) {
      let value = 1 + index * 104729;
      const seen = new Set<number>();
      for (let step = 0; step < 50; step++) {
        const next = randomStep(value);
        expect(next.value).toBeGreaterThanOrEqual(0);
        expect(next.value).toBeLessThan(1);
        expect(Number.isSafeInteger(next.state)).toBe(true);
        expect(next.state).toBeGreaterThan(0);
        expect(next.state).toBeLessThanOrEqual(0xffffffff);
        seen.add(next.state);
        value = next.state;
      }
      expect(seen.size).toBe(50);
    }
  });
});

describe('progression and inventory invariants', () => {
  it('never loses XP or overshoots level 30', () => {
    for (let index = 0; index < RUNS; index++) {
      const species = creatures[index % creatures.length];
      const level = 1 + (index % 29);
      const maxHp = stats({ id: 'c', species, level }).maxHp;
      let creature = { id: 'c', speciesId: species.id, level, xp: 0, hp: maxHp, maxHp };
      let granted = 0;
      for (let step = 0; step < 12; step++) {
        const amount = Math.floor(roll(index, 'xp', step) * 400);
        granted += amount;
        creature = grantXp(creature, amount);
        expect(creature.level).toBeGreaterThanOrEqual(level);
        expect(creature.level).toBeLessThanOrEqual(30);
        expect(creature.xp).toBeGreaterThanOrEqual(0);
        if (creature.level < 30) expect(creature.xp).toBeLessThan(xpRequired(creature.level));
        expect(creature.hp).toBeLessThanOrEqual(creature.maxHp);
        expect(creature.maxHp).toBe(stats({ id: 'c', species, level: creature.level }).maxHp);
      }
      expect(granted).toBeGreaterThanOrEqual(0);
    }
  });
  it('conserves items through randomised craft plans', () => {
    for (let index = 0; index < RUNS; index++) {
      const recipe = recipes[index % recipes.length];
      const inventory: ContentState['inventory'] = recipe.inputs.map((input) => ({ itemId: input.itemId, quantity: input.quantity + (index % 5) }));
      while (inventory.length < 12) inventory.push(null);
      const before = inventory.reduce((sum, stack) => sum + (stack?.quantity ?? 0), 0);
      const after = planInventory(inventory, recipe.inputs, [recipe.output]);
      const spent = recipe.inputs.reduce((sum, input) => sum + input.quantity, 0);
      expect(after.reduce((sum, stack) => sum + (stack?.quantity ?? 0), 0)).toBe(before - spent + recipe.output.quantity);
      for (const stack of after) {
        if (!stack) continue;
        const item = items.find((entry) => entry.id === stack.itemId)!;
        expect(stack.quantity).toBeGreaterThan(0);
        expect(stack.quantity).toBeLessThanOrEqual(item.stackLimit);
      }
      expect(inventory.reduce((sum, stack) => sum + (stack?.quantity ?? 0), 0)).toBe(before);
    }
  });
  it('keeps every species slot set inside its published budget', () => {
    for (const species of creatures) {
      const slots = movesFor({ id: 'probe', species, level: 1 });
      expect(slots, species.id).toHaveLength(4);
      for (const move of slots) {
        expect(move.cost).toBeGreaterThanOrEqual(0);
        expect(move.cost).toBeLessThanOrEqual(5);
        expect(move.accuracy).toBeGreaterThan(0.5);
        expect(move.accuracy).toBeLessThanOrEqual(1);
        expect(move.unlockLevel).toBeGreaterThanOrEqual(1);
        expect(move.unlockLevel).toBeLessThanOrEqual(MAX_LEVEL);
        expect(UNLOCK_TIERS).toContain(move.unlockLevel);
      }
      // A default loadout always grows into something: its finisher is gated above level one.
      expect(slots[3].unlockLevel, species.id).toBeGreaterThan(1);
      // Exactly one support slot, and it always sits in the third button.
      expect(slots.filter((move) => move.power === 0)).toHaveLength(1);
      expect(slots[2].power).toBe(0);
      expect(slots[0].unlockLevel).toBe(1);
    }
  });
});
