import { describe, expect, it } from 'vitest';
import { MAX_LEVEL, type GameCommand } from '../../src/contracts';
import { creatureById, creatures, moveById } from '../../src/content/catalog';
import { movesOf } from '../../src/content/catalog';
import { SUPPORT_EFFECTS } from '../../src/content/schema';
import { beginBattle, createBattle, resolveBattle, stats, type BattleState } from '../../src/game/combat/core';

/**
 * The balance gate. v3's fights stretched from under four turns at level two to over sixteen at
 * fifty, because health grew without bound while damage converged on a ceiling; at the same time
 * base stats faded to four percent of a level-50 bar, so every species converged on the same
 * sponge. Both are measured here rather than argued about.
 */
const LEVELS = [1, 3, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50] as const;
const SAMPLE = ['dewbud', 'puffkip', 'pebblenib', 'snowspool', 'phoenixvale', 'bedrocktitan', 'sprigcalf'];

/**
 * What an informed player carries at this level: the three strongest attacks the creature has
 * grown into, plus its support move. The starting loadout deliberately does not grow on its
 * own — re-picking it at camp is the progression — so balance is measured against a player who
 * actually does that, not against a level-50 creature still swinging its level-1 opener.
 */
function bestLoadout(speciesId: string, level: number): string[] {
  const known = movesOf(speciesId).filter((move) => move.unlockLevel <= level);
  const support = known.find((move) => SUPPORT_EFFECTS.some((effect) => effect === move.effect))
    ?? known[0];
  const attacks = known.filter((move) => move !== support && !SUPPORT_EFFECTS.some((effect) => effect === move.effect));
  // A sensible set always keeps something cheap to fall back on when energy runs out, then
  // spends the other two slots on the hardest hitters available.
  const cheapest = [...attacks].sort((a, b) => a.cost - b.cost || b.power - a.power || a.id.localeCompare(b.id))[0];
  const heavy = attacks.filter((move) => move !== cheapest)
    .sort((a, b) => b.power - a.power || a.id.localeCompare(b.id)).slice(0, 2)
    .sort((a, b) => a.power - b.power || a.id.localeCompare(b.id));
  const slots = [cheapest?.id, heavy[0]?.id, support.id, heavy[1]?.id]
    .filter((id): id is string => typeof id === 'string');
  for (const move of known) { if (slots.length >= 4) break; if (!slots.includes(move.id)) slots.push(move.id); }
  return slots.slice(0, 4);
}
const fighter = (speciesId: string, level: number, id: string) =>
  ({ id, species: creatureById(speciesId)!, level, loadout: bestLoadout(speciesId, level) });

/** The strongest slot this creature has grown into and can pay for right now. */
function bestSlot(speciesId: string, level: number, stamina: number): 0 | 1 | 3 {
  const carried = bestLoadout(speciesId, level);
  const usable = ([0, 1, 3] as const).filter((slot) => {
    const move = moveById(carried[slot]);
    return !!move && move.unlockLevel <= level && move.cost <= stamina;
  });
  return usable.length ? usable[usable.length - 1] : 0;
}
/** Plays a battle to its end with both sides pressing the best slot they can afford. */
function playOut(player: { id: string; level: number }, enemy: { id: string; level: number }, seed: number) {
  let state: BattleState = beginBattle(createBattle({
    battleId: 'b', encounterId: 'e', seed,
    player: fighter(player.id, player.level, 'friend'), enemy: fighter(enemy.id, enemy.level, 'wild'),
    capturable: false,
  }));
  for (let turn = 0; turn < 60; turn++) {
    if (state.outcome) return { turns: turn, outcome: state.outcome };
    const slot = bestSlot(player.id, player.level, state.stamina);
    const next = resolveBattle(state, { type: 'attack', slot, commandId: `t${turn}`, tick: turn + 1 } as GameCommand);
    // A rejected command would mean the chooser is wrong, not that the fight is over.
    expect(next.accepted, `${player.id} slot ${slot} @${player.level}`).toBe(true);
    state = next.state;
  }
  return { turns: 60, outcome: state.outcome };
}
function turnsToResolve(speciesId: string, level: number, seed: number): number {
  return playOut({ id: speciesId, level }, { id: speciesId, level }, seed).turns;
}
const median = (values: number[]) => [...values].sort((a, b) => a - b)[Math.floor(values.length / 2)];

describe('combat stays the same length as creatures grow', () => {
  it('holds time-to-kill flat as a creature levels, and inside a readable band', () => {
    const readings: { species: string; level: number; turns: number }[] = [];
    for (const level of LEVELS) {
      for (const speciesId of SAMPLE) {
        const turns = median([1, 7, 13, 29, 51, 83, 131, 197, 271].map((seed) => turnsToResolve(speciesId, level, seed)));
        readings.push({ species: speciesId, level, turns });
        // A sturdy species is allowed to read as sturdy; nothing is allowed to become a slog.
        expect(turns, `${speciesId} @${level}`).toBeGreaterThanOrEqual(3);
        expect(turns, `${speciesId} @${level}`).toBeLessThanOrEqual(8);
      }
    }
    // The invariant that actually matters: one creature's fights do not get longer as it grows.
    // v3 went from 3.7 turns at level two to 16.3 at fifty — a drift of more than twelve.
    for (const speciesId of SAMPLE) {
      const mine = readings.filter((reading) => reading.species === speciesId).map((reading) => reading.turns);
      // Turns are whole numbers and the dice are real, so a level or two of sampling wobble is
      // expected; what this forbids is the monotone climb v3 had.
      const drift = Math.max(...mine) - Math.min(...mine);
      expect(drift, `${speciesId} drift ${Math.min(...mine)}→${Math.max(...mine)}`).toBeLessThanOrEqual(3);
    }
    // Across the whole roster: v3's median went from roughly four turns early to sixteen late.
    // Two turns of spread is what the rebalance is worth, and it must not regress past that.
    const early = median(readings.filter((r) => r.level <= 5).map((r) => r.turns));
    const late = median(readings.filter((r) => r.level >= 40).map((r) => r.turns));
    expect(Math.abs(late - early), `early ${early} vs late ${late}`).toBeLessThanOrEqual(2);
  });

  it('keeps a species recognisable at the ceiling instead of drowning it in levels', () => {
    const top = creatures.map((species) => stats({ id: 'x', species, level: MAX_LEVEL }));
    const lo = Math.min(...top.map((entry) => entry.maxHp));
    const hi = Math.max(...top.map((entry) => entry.maxHp));
    // v3 left an eight-to-seventeen base-HP spread worth four percent of a level-50 bar.
    expect((hi - lo) / hi).toBeGreaterThan(.12);
    const atkLo = Math.min(...top.map((entry) => entry.atk));
    const atkHi = Math.max(...top.map((entry) => entry.atk));
    expect((atkHi - atkLo) / atkHi).toBeGreaterThan(.12);
  });

  it('still rewards raising a rarer creature without making the fight a formality', () => {
    const trials = 40;
    let wins = 0;
    for (let seed = 1; seed <= trials; seed++) {
      const result = playOut({ id: 'phoenixvale', level: 30 }, { id: 'dewbud', level: 30 }, seed * 977);
      if (result.outcome === 'WON') wins++;
    }
    const rate = wins / trials;
    expect(rate, `rare win rate ${rate}`).toBeGreaterThan(.6);
    expect(rate, `rare win rate ${rate}`).toBeLessThanOrEqual(1);
  });
});
