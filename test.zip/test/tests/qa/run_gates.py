"""Run real gates and bind each result and its artifacts to the source that ran it.

Usage: python3 tests/qa/run_gates.py [--only unit|property|browser|build|static]
Reports are immutable per run; older reports are never relabelled with a new identity.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import uuid

ROOT = Path(__file__).resolve().parents[2]


def identity():
    return json.loads(subprocess.check_output(
        ['python3', 'qa/score_current.py', '--identity'], cwd=ROOT, text=True))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(only=None):
    folder = ROOT / '.reports' / 'runs' / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:8])
    folder.mkdir(parents=True)
    commands = {
        'static': [['npm', 'run', 'typecheck'], ['npm', 'run', 'lint']],
        'unit': [['npm', 'test', '--', '--run', '--reporter=default', '--reporter=json', f'--outputFile={folder / "unit.json"}']],
        'property': [['npm', 'run', 'test:property', '--', '--reporter=default', '--reporter=json', f'--outputFile={folder / "property.json"}']],
        'build': [['npm', 'run', 'build']],
        'browser': [['npm', 'run', 'test:e2e', '--', '--reporter=list,json']],
    }
    index_path = ROOT / '.reports' / 'current-checks.json'
    index = json.loads(index_path.read_text()) if index_path.exists() else {}
    failed = False
    for group, entries in commands.items():
        if only and only != group:
            continue
        results = []
        for number, argv in enumerate(entries):
            before = identity()
            started = datetime.now(timezone.utc).isoformat()
            start = time.monotonic()
            env = {**os.environ, 'PLAYWRIGHT_JSON_OUTPUT_FILE': str(folder / 'browser.json'), 'NO_COLOR': '1'}
            log = folder / f'{group}-{number}.log'
            print('RUN', ' '.join(argv), flush=True)
            with log.open('w') as output:
                try:
                    proc = subprocess.run(argv, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=1800)
                    code = proc.returncode
                except subprocess.TimeoutExpired:
                    code = 124
            after = identity()
            files = [log]
            if group in ('unit', 'property', 'browser') and (folder / f'{group}.json').exists():
                files.append(folder / f'{group}.json')
            if group == 'browser':
                # Only artifacts rewritten during this command may be attached to this source.
                files += [p for p in (ROOT / '.reports' / 'qa').glob('*')
                          if p.is_file() and p.stat().st_mtime >= datetime.fromisoformat(started).timestamp()]
            result = {**before, 'after': after, 'command': argv, 'exitCode': code,
                      'startedAt': started, 'durationSeconds': round(time.monotonic() - start, 3),
                      'artifacts': [{'path': str(p.relative_to(ROOT)), 'sha256': digest(p)} for p in files]}
            results.append(result)
            print(f'{group}: exit {code}, source stable={before == after}, log={log.relative_to(ROOT)}', flush=True)
            failed |= code != 0 or before != after
        record = folder / f'{group}-checks.json'
        record.write_text(json.dumps({'checks': results}, indent=2))
        index[group] = str(record.relative_to(ROOT))
        index_path.write_text(json.dumps(index, indent=2))
    return 1 if failed else 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--only', choices=['static', 'unit', 'property', 'build', 'browser'])
    raise SystemExit(run(parser.parse_args().only))
