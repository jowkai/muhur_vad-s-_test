import { mkdirSync } from 'node:fs';
import { expect, test, type Page } from '@playwright/test';
import { BIOME_LABEL } from '../../src/ui/hud/labels';
import type { BiomeId } from '../../src/contracts';

type Point = { x: number; z: number };
interface BridgeWorld { seed: string; camp: Point; regions: { biomeId: string; entrance: Point }[] }
/**
 * Designed roads run camp → every region entrance, and the flame road starts at the volcano, so
 * every leg returns to camp first and the walk stays on carved, obstacle-free corridors.
 */
function route(world: BridgeWorld): { id: BiomeId; hops: Point[] }[] {
  const entrance = (biomeId: BiomeId) => world.regions.find((region) => region.biomeId === biomeId)!.entrance;
  return [
    { id: 'meadow', hops: [{ x: world.camp.x + 24, z: world.camp.z + 24 }] },
    { id: 'forest', hops: [world.camp, entrance('forest')] },
    { id: 'earth', hops: [world.camp, entrance('earth')] },
    { id: 'desert', hops: [world.camp, entrance('desert')] },
    { id: 'sea', hops: [world.camp, entrance('sea')] },
    { id: 'ice', hops: [world.camp, entrance('ice')] },
    { id: 'volcanic', hops: [world.camp, entrance('volcanic')] },
    { id: 'flame', hops: [world.camp, entrance('volcanic'), entrance('flame')] },
  ];
}
interface BridgeHost {
  __muhurTestBridge: {
    walkTo(x: number, z: number): boolean;
    snapshot(): { biome: string; position: Point; mode: string };
    world(): BridgeWorld;
  };
}
const walk = (page: Page, point: Point) =>
  page.evaluate(([x, z]) => (globalThis as unknown as BridgeHost).__muhurTestBridge.walkTo(x, z) as boolean, [point.x, point.z]);
/**
 * The road crosses regions whose patrols hunt on their own, and a walk stops when one of them
 * strikes. The route runs away from every such fight and picks the leg up again, so the capture
 * still happens in the biome it is meant to show.
 */
async function travel(page: Page, point: Point): Promise<void> {
  for (let attempt = 0; attempt < 12; attempt++) {
    if (await walk(page, point)) return;
    // Escape runs from the fight and Enter clears the banner that follows; both are the player's
    // own keys, so nothing here reaches past the interface.
    for (let escape = 0; escape < 20; escape++) {
      const fighting = await page.locator('.mv-battle:not([hidden])').isVisible().catch(() => false);
      const banner = await page.locator('.mv-reward:not([hidden])').isVisible().catch(() => false);
      if (!fighting && !banner) break;
      await page.keyboard.press(banner ? 'Enter' : 'Escape');
      await page.waitForTimeout(500);
    }
  }
}
const snapshot = (page: Page) => page.evaluate(() => (globalThis as unknown as BridgeHost).__muhurTestBridge.snapshot());

test('draws all eight biomes in real WebGL on one walked route', async ({ page }) => {
  test.setTimeout(300_000);
  mkdirSync('.reports/qa', { recursive: true });
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.addInitScript(() => indexedDB.deleteDatabase('muhur-vadisi'));
  await page.goto('/');
  await page.waitForFunction(() => '__muhurTestBridge' in globalThis, null, { timeout: 30_000 });
  await expect(page.locator('.mv-stage canvas').first()).toBeVisible();

  const world = await page.evaluate(() => (globalThis as unknown as BridgeHost).__muhurTestBridge.world());
  expect(world.regions).toHaveLength(8);
  const visited: { biome: string; expected: string; position: Point }[] = [];
  for (const stop of route(world)) {
    for (const hop of stop.hops) await travel(page, hop);
    // The renderer needs a frame to mount the new visual window before the capture.
    await page.waitForTimeout(900);
    const state = await snapshot(page);
    visited.push({ biome: state.biome, expected: BIOME_LABEL[stop.id], position: state.position });
    await expect(page.locator('.mv-hud .mv-sub')).toContainText(state.biome);
    await page.screenshot({ path: `.reports/qa/biome-${stop.id}.png` });
    const drawn = await page.evaluate(() => {
      const canvas = document.querySelector('.mv-stage canvas') as HTMLCanvasElement;
      return { width: canvas.width, height: canvas.height, lost: canvas.getContext('webgl2')?.isContextLost() ?? true };
    });
    expect(drawn.width, stop.id).toBeGreaterThan(0);
    expect(drawn.lost, stop.id).toBe(false);
  }
  expect(visited.map((entry) => entry.biome)).toEqual(visited.map((entry) => entry.expected));
  expect(new Set(visited.map((entry) => entry.biome)).size).toBe(8);
  expect(errors).toEqual([]);
});
