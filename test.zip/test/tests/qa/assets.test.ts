import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { describe, expect, it } from 'vitest';
import { creatures, items, recipes } from '../../src/content/catalog';
import { creatureAssets, eggAssets, itemAssets } from '../../src/content/asset-manifest';
import { BIOME_IDS } from '../../src/contracts';

const root = join(import.meta.dirname, '..', '..');
const publicDir = join(root, 'public');
function walk(directory: string): string[] {
  return readdirSync(directory).flatMap((entry) => {
    const full = join(directory, entry);
    return statSync(full).isDirectory() ? walk(full) : [full];
  });
}
const svgFiles = walk(join(publicDir, 'assets')).filter((file) => file.endsWith('.svg'));
const localPath = (url: string) => join(publicDir, url.replace(/^\//, ''));
/** Names we must never borrow; the brief allows genre inspiration, never another game's IP. */
const FOREIGN_MARKS = [
  'pokemon', 'pokémon', 'pikachu', 'pokeball', 'poké', 'nintendo', 'game freak', 'digimon',
  'league of legends', 'riot games', 'teemo', 'dota', 'temtem', 'palworld', 'monster hunter',
];
const sourceFiles = walk(join(root, 'src')).filter((file) => /\.(ts|css)$/.test(file));

describe('asset safety and originality review', () => {
  it('ships one local, script-free SVG per catalogue entry', () => {
    expect(svgFiles.length).toBeGreaterThanOrEqual(creatures.length * 2 + BIOME_IDS.length + items.filter((item) => item.biomeId).length);
    for (const file of svgFiles) {
      const svg = readFileSync(file, 'utf8');
      const name = relative(root, file);
      expect(svg.trim().startsWith('<svg') || svg.trim().startsWith('<?xml'), name).toBe(true);
      expect(svg, name).toMatch(/viewBox="0 0 \d+ \d+"/);
      for (const forbidden of ['<script', 'javascript:', 'onload=', 'onerror=', 'onclick=', '<foreignObject', '<iframe', '@import']) {
        expect(svg.toLowerCase().includes(forbidden), `${name} contains ${forbidden}`).toBe(false);
      }
      expect(/https?:\/\//.test(svg.replace(/xmlns(:\w+)?="[^"]*"/g, '')), `${name} references a remote host`).toBe(false);
      expect(/<image\b/.test(svg), `${name} embeds a bitmap`).toBe(false);
      expect(svg.length, name).toBeGreaterThan(200);
    }
  });
  it('gives every creature a distinct front and back drawing that exists on disk', () => {
    for (const species of creatures) {
      const entry = creatureAssets[species.id as keyof typeof creatureAssets];
      expect(entry, species.id).toBeTruthy();
      const front = readFileSync(localPath(entry.front), 'utf8');
      const back = readFileSync(localPath(entry.back), 'utf8');
      expect(front, species.id).not.toBe(back);
      // A back view is a separate drawing, not a mirrored front.
      expect(back.includes('scale(-1')).toBe(false);
      expect(front.length).toBeGreaterThan(200);
      expect(back.length).toBeGreaterThan(200);
    }
    for (const biome of BIOME_IDS) expect(readFileSync(localPath(eggAssets[biome]), 'utf8').length).toBeGreaterThan(200);
    for (const item of items) {
      if (!item.biomeId) continue;
      const url = itemAssets[item.id as keyof typeof itemAssets];
      expect(url, item.id).toBeTruthy();
      expect(readFileSync(localPath(url), 'utf8').length).toBeGreaterThan(120);
    }
  });
  it('keeps every name, id and string free of another game\'s marks', () => {
    const haystack = [
      ...creatures.flatMap((species) => [species.id, species.name, species.visualBrief]),
      ...items.map((item) => `${item.id} ${item.name}`),
      ...recipes.map((recipe) => recipe.id),
      ...svgFiles.map((file) => `${relative(root, file)} ${readFileSync(file, 'utf8')}`),
      ...sourceFiles.map((file) => readFileSync(file, 'utf8')),
    ].join('\n').toLowerCase();
    for (const mark of FOREIGN_MARKS) expect(haystack.includes(mark), `found "${mark}"`).toBe(false);
  });
  it('loads no remote font, image or script from application code', () => {
    for (const file of sourceFiles) {
      const source = readFileSync(file, 'utf8');
      const name = relative(root, file);
      const remote = source.match(/https?:\/\/[^\s"'`)]+/g) ?? [];
      for (const url of remote) {
        expect(url.startsWith('http://www.w3.org/') || url.startsWith('https://threejs.org/'), `${name} fetches ${url}`).toBe(true);
      }
      expect(/@import\s+url\(/.test(source), name).toBe(false);
      expect(/fetch\(\s*['"`]https?:/.test(source), name).toBe(false);
    }
  });
});
