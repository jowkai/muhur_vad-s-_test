import { mkdirSync, writeFileSync } from 'node:fs';
import { expect, test } from '@playwright/test';
import { creatureAssets } from '../../src/content/asset-manifest';

// The catalogue module imports its seed as JSON, which Playwright's loader will not take, so the
// species list comes from the manifest the game itself draws from.
const species = Object.keys(creatureAssets);

interface SpriteReport { id: string; view: string; url: string; ink: number; hash: string }
const CELL = 96;
/**
 * Rasterises every creature drawing in a real browser and proves they are 32 separate pieces of
 * artwork: each one paints, each front differs from its own back, and no two are the same image.
 * The contact sheet it writes is what a human reviews for originality and quality.
 */
test('renders 64 species as 128 distinct drawings and leaves a contact sheet', async ({ page }) => {
  test.setTimeout(180_000);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.goto('/');
  await page.waitForFunction(() => '__muhurTestBridge' in globalThis, null, { timeout: 30_000 });
  const entries = Object.entries(creatureAssets).flatMap(([id, pair]) => [
    { id, view: 'front', url: pair.front }, { id, view: 'back', url: pair.back },
  ]);
  expect(entries).toHaveLength(species.length * 2);
  expect(species).toHaveLength(96);

  const measured = await page.evaluate(async ({ entries, cell }) => {
    const load = (url: string) => new Promise<HTMLImageElement | null>((resolve) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => resolve(null);
      image.src = url;
    });
    const columns = 8;
    const sheet = document.createElement('canvas');
    sheet.width = columns * cell;
    sheet.height = Math.ceil(entries.length / columns) * cell;
    const sheetContext = sheet.getContext('2d')!;
    sheetContext.fillStyle = '#12201c';
    sheetContext.fillRect(0, 0, sheet.width, sheet.height);
    const results: { id: string; view: string; url: string; ink: number; hash: string }[] = [];
    for (const [index, entry] of entries.entries()) {
      const image = await load(entry.url);
      const canvas = document.createElement('canvas');
      canvas.width = cell; canvas.height = cell;
      const context = canvas.getContext('2d')!;
      if (image) {
        context.drawImage(image, 0, 0, cell, cell);
        sheetContext.drawImage(image, (index % columns) * cell, Math.floor(index / columns) * cell, cell, cell);
      }
      const pixels = context.getImageData(0, 0, cell, cell).data;
      let ink = 0;
      let hash = 2166136261;
      for (let offset = 0; offset < pixels.length; offset += 4) {
        if (pixels[offset + 3] > 24) ink++;
        // Quantised colour keeps the hash stable across antialiasing noise.
        const value = ((pixels[offset] >> 4) << 8) | ((pixels[offset + 1] >> 4) << 4) | (pixels[offset + 2] >> 4);
        hash = Math.imul(hash ^ (value + (pixels[offset + 3] > 24 ? 1 : 0)), 16777619) >>> 0;
      }
      results.push({ ...entry, ink: ink / (cell * cell), hash: hash.toString(16) });
    }
    return { results, sheet: sheet.toDataURL('image/png') };
  }, { entries, cell: CELL });

  mkdirSync('.reports/qa', { recursive: true });
  writeFileSync('.reports/qa/creature-contact-sheet.png', Buffer.from(measured.sheet.split(',')[1], 'base64'));

  const results = measured.results as SpriteReport[];
  expect(results).toHaveLength(192);
  for (const sprite of results) {
    // A blank or nearly blank cell is not a drawing.
    expect(sprite.ink, `${sprite.id}-${sprite.view}`).toBeGreaterThan(0.04);
    expect(sprite.ink, `${sprite.id}-${sprite.view}`).toBeLessThan(0.9);
  }
  for (const id of species) {
    const front = results.find((sprite) => sprite.id === id && sprite.view === 'front')!;
    const back = results.find((sprite) => sprite.id === id && sprite.view === 'back')!;
    expect(front.hash, `${id} front/back`).not.toBe(back.hash);
  }
  // Every one of the sixty-four is its own image.
  expect(new Set(results.map((sprite) => sprite.hash)).size).toBe(results.length);
  writeFileSync('.reports/qa/creature-sprites.json', JSON.stringify({
    generatedAt: new Date().toISOString(), species: species.length, sprites: results,
  }, null, 2));
  expect(errors).toEqual([]);
});
