import { execFileSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { createWorld } from '../../src/world/generation/world';
import { newGame } from '../../src/app/session';
import { validateWorldState } from '../../src/world/persistence/world-save';
import { creatureById } from '../../src/content/catalog';
import { beginBattle, createBattle } from '../../src/game/combat/core';
import { createLootPlan } from '../../src/game/combat/rewards';

describe('production performance fixtures', () => {
  it('writes validated deterministic saved route stops without a production mutation hook', () => {
    const world = createWorld();
    const biomes = ['meadow', 'forest', 'desert', 'ice', 'volcanic'] as const;
    const stops = biomes.map((biome) => {
      const state = newGame(world);
      const position = biome === 'meadow' ? world.camp : world.regions.find((region) => region.biomeId === biome)!.entrance;
      state.playerPosition = { ...position }; state.lastSafePosition = { ...position };
      state.atCamp = biome === 'meadow';
      if (biome === 'meadow') {
        const starter = world.starters.find((spawn) => spawn.kind === 'creature')!;
        const player = { id: state.creatures[0].id, species: creatureById(state.creatures[0].speciesId)!, level: 2 };
        const enemy = { id: starter.entityId, species: creatureById(starter.speciesId)!, level: starter.level };
        const battleId = `battle:${starter.entityId}`;
        state.mode = 'battle';
        state.battle = beginBattle(createBattle({ battleId, encounterId: starter.entityId, seed: 12345,
          player, enemy, inventorySnapshot: { seal: 2, heat_herb: 1 }, captureCapacity: 59 }));
        state.loot = createLootPlan(battleId, enemy, false, 100000);
      }
      validateWorldState(world, state);
      return { biome, position, state };
    });
    expect(stops).toHaveLength(5);
    mkdirSync('.reports', { recursive: true });
    writeFileSync('.reports/performance-fixtures.json', JSON.stringify({ ...JSON.parse(execFileSync('python3', ['qa/score_current.py', '--identity'], { encoding: 'utf8' })), seed: world.seed, stops }));
  });
});
