import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { TEST_BRIDGE_KEY } from '../../src/app/test-bridge';

const root = join(import.meta.dirname, '..', '..');
// A private output folder keeps this check hermetic: it never races the real `dist` build gate.
const dist = join(root, '.reports', 'bundle-check');
/** Builds on demand so the check never silently skips when the bundle is missing or stale. */
function bundle(nodeEnv = 'production'): { files: string[]; source: string; bytes: number } {
  execFileSync('npx', ['vite', 'build', '--outDir', dist, '--emptyOutDir'], { cwd: root, stdio: 'pipe', env: { ...process.env, NODE_ENV: nodeEnv } });
  const assets = join(dist, 'assets');
  const files = readdirSync(assets).filter((file) => file.endsWith('.js'));
  expect(files.length).toBeGreaterThan(0);
  return {
    files,
    source: files.map((file) => readFileSync(join(assets, file), 'utf8')).join('\n'),
    bytes: files.reduce((sum, file) => sum + statSync(join(assets, file)).size, 0),
  };
}

describe('production bundle', () => {
  it('drops the test bridge and every dev-only hook', () => {
    expect(existsSync(join(root, 'index.html'))).toBe(true);
    const built = bundle('production');
    expect(built.source.includes(TEST_BRIDGE_KEY), 'test bridge leaked into the bundle').toBe(false);
    expect(built.source.includes('installTestBridge')).toBe(false);
    expect(built.source.includes('bridge:'), 'bridge walk commands leaked').toBe(false);
    expect(built.source.includes('createBootstrapScene'), 'the G00 demo scene is gone').toBe(false);
    expect(built.bytes).toBeGreaterThan(100_000);
    const html = readFileSync(join(dist, 'index.html'), 'utf8');
    expect(html).toContain('<div id="app">');
    expect(html).not.toContain('test-bridge');
  }, 120_000);
  it('still drops the bridge when the build inherits a test NODE_ENV', () => {
    // Found in review: with NODE_ENV=test Vite keeps import.meta.env.DEV true, so the guard
    // also checks MODE, which vite build always sets to production.
    const built = bundle('test');
    expect(built.source.includes(TEST_BRIDGE_KEY), 'test bridge leaked under NODE_ENV=test').toBe(false);
    expect(built.source.includes('walkTo(')).toBe(false);
  }, 120_000);
  it('keeps the shipped page free of remote script and style hosts', () => {
    const html = readFileSync(join(dist, 'index.html'), 'utf8');
    const remote = html.match(/(src|href)="https?:\/\/[^"]+"/g) ?? [];
    expect(remote).toEqual([]);
  });
});
