import { resolve } from 'node:path';
import { defineConfig, mergeConfig } from 'vite';
import base from '../../vite.config';

// The game entry is the ordinary production entry. The separate lifecycle page owns its
// shell locally so teardown can be tested without exposing a game-mutating global.
export default mergeConfig(base, defineConfig({
  build: { outDir: '.reports/performance-build', rollupOptions: { input: {
    game: resolve('index.html'), lifecycle: resolve('tests/performance/lifecycle.html'),
  } } },
}));
