import { execFileSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { expect, test, type Page } from '@playwright/test';
import type { TelemetrySummary } from '../../src/app/telemetry';

const VIEWPORT = { width: 1440, height: 900 };
const WARMUP = 10;
const SEGMENT_SECONDS = 24;
interface Snapshot { position: { x: number; z: number }; mode: string; chunks: { visible: number; resident: number }; seed: string }
interface Host { __muhurTelemetry: { reset(): void; summary(): TelemetrySummary; samples(): number[]; snapshot(): Snapshot } }
interface Stop { biome: string; position: { x: number; z: number }; state: unknown }
const identity = () => JSON.parse(execFileSync('python3', ['qa/score_current.py', '--identity'], { encoding: 'utf8' })) as { commit: string; source_sha256: string };
const summary = (page: Page) => page.evaluate(() => (globalThis as unknown as Host).__muhurTelemetry.summary());
const snapshot = (page: Page) => page.evaluate(() => (globalThis as unknown as Host).__muhurTelemetry.snapshot());
const reset = (page: Page) => page.evaluate(() => (globalThis as unknown as Host).__muhurTelemetry.reset());
const percentile = (values: number[], q: number) => [...values].sort((a, b) => a - b)[Math.max(0, Math.ceil(values.length * q) - 1)];
function hardware() {
  const read = (cmd: string, args: string[]) => { try { return execFileSync(cmd, args, { encoding: 'utf8' }).trim(); } catch { return 'unknown'; } };
  const power = read('pmset', ['-g', 'batt']);
  return { chip: read('sysctl', ['-n', 'machdep.cpu.brand_string']), memoryBytes: Number(read('sysctl', ['-n', 'hw.memsize'])),
    os: read('sw_vers', ['-productVersion']), power, acPower: power.includes('AC Power') };
}
/** Fixture setup is outside measurement, in an isolated Playwright context, before the app boots. */
async function seed(page: Page, state: unknown): Promise<void> {
  await page.route('**/__performance_setup', (route) => route.fulfill({ contentType: 'text/html', body: '<title>Ölçüm hazırlığı</title>' }));
  await page.goto('/__performance_setup');
  await page.evaluate(async (state) => {
    localStorage.clear();
    await new Promise<void>((resolve, reject) => {
      const request = indexedDB.deleteDatabase('muhur-vadisi');
      request.onsuccess = () => resolve(); request.onerror = () => reject(request.error);
      request.onblocked = () => reject(new Error('Isolated benchmark database is blocked'));
    });
    await new Promise<void>((resolve, reject) => {
      const request = indexedDB.open('muhur-vadisi', 1);
      request.onupgradeneeded = () => { request.result.createObjectStore('records'); request.result.createObjectStore('commands'); };
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const db = request.result;
        const tx = db.transaction(['records'], 'readwrite');
        tx.objectStore('records').put({ version: 2, state }, 'current');
        tx.oncomplete = () => { db.close(); resolve(); }; tx.onabort = () => { db.close(); reject(tx.error); };
      };
    });
  }, state);
  await page.goto('/?performance=1');
  await page.bringToFront();
  await page.waitForFunction(() => '__muhurTelemetry' in globalThis);
  expect(await page.evaluate(() => '__muhurTestBridge' in globalThis)).toBe(false);
  await page.mouse.click(700, 350);
}
async function settleBattle(page: Page): Promise<void> {
  for (let attempt = 0; attempt < 20; attempt++) {
    const mode = (await snapshot(page)).mode;
    if (mode === 'exploring') {
      if (await page.locator('.mv-reward:not([hidden])').isVisible()) await page.keyboard.press('Enter');
      return;
    }
    await page.keyboard.press('Escape');
    await page.waitForTimeout(150);
  }
  throw new Error('Battle did not return to exploration through the real Escape input');
}

// Native foreground Chromium, never a headless throughput run. No software GPU override.
test.use({ viewport: VIEWPORT, deviceScaleFactor: 1, headless: false });

test('production reference protocol: three identical 120 second sampled routes', async ({ page, browser }) => {
  test.setTimeout(900_000);
  const before = identity();
  const fixtures = JSON.parse(readFileSync('.reports/performance-fixtures.json', 'utf8')) as { seed: string; stops: Stop[]; commit: string; source_sha256: string };
  expect({ commit: fixtures.commit, source_sha256: fixtures.source_sha256 }).toEqual(before);
  expect(fixtures.stops.map((s) => s.biome)).toEqual(['meadow', 'forest', 'desert', 'ice', 'volcanic']);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('crash', () => errors.push('page crashed'));
  mkdirSync('.reports', { recursive: true });
  const device = hardware();
  const runs = [];
  let foreground = true;
  for (let run = 0; run < 3; run++) {
    const frameSamples: number[] = [];
    const segments: { biome: string; summary: TelemetrySummary; samples: number[] }[] = [];
    let battleObserved = false, panelObserved = false, activeChunks = 0, residentChunks = 0;
    for (const stop of fixtures.stops) {
      await seed(page, stop.state);
      await page.waitForTimeout(WARMUP * 1000);
      await reset(page);
      const start = Date.now();
      if (stop.biome === 'meadow') {
        battleObserved = await page.locator('.mv-battle:not([hidden])').isVisible();
        expect(battleObserved).toBe(true);
        await settleBattle(page);
        await page.keyboard.press('i');
        await expect(page.locator('.mv-panel:not([hidden])').first()).toBeVisible();
        panelObserved = true;
        await page.keyboard.press('Escape');
      }
      let index = 0;
      while (Date.now() - start < SEGMENT_SECONDS * 1000) {
        await settleBattle(page);
        const key = ['KeyW', 'KeyD', 'KeyS', 'KeyA'][index++ % 4];
        await page.keyboard.down(key);
        await page.waitForTimeout(Math.max(1, Math.min(1000, SEGMENT_SECONDS * 1000 - (Date.now() - start))));
        await page.keyboard.up(key);
        const state = await snapshot(page);
        activeChunks = Math.max(activeChunks, state.chunks.visible);
        residentChunks = Math.max(residentChunks, state.chunks.resident);
        foreground &&= await page.evaluate(() => !document.hidden && document.hasFocus());
      }
      const measured = await summary(page);
      expect(measured.truncated).toBe(false);
      const samples = await page.evaluate(() => (globalThis as unknown as Host).__muhurTelemetry.samples());
      frameSamples.push(...samples);
      segments.push({ biome: stop.biome, summary: measured, samples });
      await page.screenshot({ path: `.reports/reference-${run}-${stop.biome}.png` });
    }
    const peak = (read: (summary: TelemetrySummary) => number) => Math.max(...segments.map((s) => read(s.summary)));
    runs.push({ sampleSeconds: segments.reduce((sum, s) => sum + s.summary.seconds, 0),
      biomes: fixtures.stops.map((s) => s.biome), battleObserved, panelObserved, frames: frameSamples.length,
      p95Ms: percentile(frameSamples, .95), p99Ms: percentile(frameSamples, .99),
      drawCalls: peak((s) => s.peak.calls), triangles: peak((s) => s.peak.triangles),
      queryMs: peak((s) => s.queryMs.p95), simPerTickMs: peak((s) => s.simPerTickMs.p95),
      maxSubsteps: peak((s) => s.maxSubsteps), activeChunks, residentChunks, segments });
    writeFileSync('.reports/reference-performance.partial.json', JSON.stringify({ ...before, device, runs }, null, 2));
  }
  // Twenty real keyboard crossings at the camp's chunk boundary in a single live renderer.
  const camp = fixtures.stops[0];
  const state = structuredClone(camp.state) as Record<string, unknown>;
  Object.assign(state, { mode: 'exploring', battle: null, loot: null });
  await seed(page, state);
  const cycles = [];
  const chunkXs = new Set<number>();
  for (let lap = 0; lap < 20; lap++) {
    await page.keyboard.down(lap % 2 ? 'KeyD' : 'KeyA');
    await page.waitForTimeout(1500);
    await page.keyboard.up(lap % 2 ? 'KeyD' : 'KeyA');
    await page.waitForTimeout(200);
    const at = await snapshot(page);
    chunkXs.add(Math.floor(at.position.x / 64));
    expect(at.chunks.resident).toBeLessThanOrEqual(49);
    cycles.push((await summary(page)).last);
  }
  expect(chunkXs.size, 'real chunk crossings').toBeGreaterThan(1);
  const last = cycles.slice(-5);
  expect(Math.max(...last.map((c) => c.geometries)) - Math.min(...last.map((c) => c.geometries))).toBeLessThanOrEqual(8);
  expect(new Set(last.map((c) => c.textures)).size).toBe(1);
  const gpu = await page.evaluate(() => {
    const gl = document.querySelector('canvas')!.getContext('webgl2')!;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    return { renderer: ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : 'unknown', dpr: devicePixelRatio };
  });
  await page.evaluate(() => document.querySelector('canvas')!.getContext('webgl2')!.getExtension('WEBGL_lose_context')!.loseContext());
  await expect(page.locator('[role="status"]').filter({ hasText: 'Grafik' }).first()).toBeVisible();
  await page.evaluate(() => document.querySelector('canvas')!.getContext('webgl2')!.getExtension('WEBGL_lose_context')!.restoreContext());
  await expect.poll(() => page.evaluate(() => document.querySelector('canvas')!.getContext('webgl2')!.isContextLost())).toBe(false);
  await page.goto('/tests/performance/lifecycle.html?performance=1');
  await page.waitForFunction(() => '__muhurTelemetry' in globalThis);
  await page.locator('#dispose').click();
  await expect(page.locator('#dispose')).toHaveText('Kapandı');
  await expect(page.locator('.mv-stage canvas')).toHaveCount(0);
  await expect(page.locator('.mv-layer')).toHaveCount(0);
  expect(await page.evaluate(() => '__muhurTelemetry' in globalThis || '__muhurTestBridge' in globalThis)).toBe(false);
  const after = identity();
  expect(after).toEqual(before);
  const software = /swiftshader|llvmpipe|software|unknown/i.test(gpu.renderer);
  const onReference = device.chip === 'Apple M1' && device.memoryBytes === 8 * 1024 ** 3;
  const report = { ...before, after, status: onReference ? 'MEASURED_ON_REFERENCE' : 'MEASURED_OFF_REFERENCE',
    device, browser: browser.version(), gpu, dpr: gpu.dpr, viewport: VIEWPORT, seed: fixtures.seed,
    headless: false, production: true, foreground, software, warmupSeconds: WARMUP, runs, errors,
    route: 'Five saved stops, 24 seconds each in the same order per run; load and warmup excluded, real keyboard gameplay measured. This is not a continuous cross-map walk.',
    recovery: { restoredLost: false }, resourceCyclesVerified: true, disposalVerified: true, cycles };
  writeFileSync('.reports/reference-performance.json', JSON.stringify(report, null, 2));
  expect(errors).toEqual([]);
  expect(foreground).toBe(true);
  expect(software).toBe(false);
  for (const run of runs) {
    expect(run.sampleSeconds).toBeGreaterThanOrEqual(120);
    expect(run.frames).toBeGreaterThanOrEqual(2400);
    expect(run.p95Ms).toBeLessThanOrEqual(20); expect(run.p99Ms).toBeLessThanOrEqual(33.4);
    expect(run.drawCalls).toBeLessThanOrEqual(150); expect(run.triangles).toBeLessThanOrEqual(300000);
    expect(run.queryMs).toBeLessThanOrEqual(2); expect(run.simPerTickMs).toBeLessThanOrEqual(4);
    expect(run.maxSubsteps).toBeLessThanOrEqual(5); expect(run.activeChunks).toBeLessThanOrEqual(25);
    expect(run.residentChunks).toBeLessThanOrEqual(49);
  }
});

test('production protocol smoke: observe gameplay and dispose without mutation hooks', async ({ page }) => {
  const fixtures = JSON.parse(readFileSync('.reports/performance-fixtures.json', 'utf8')) as { stops: Stop[] };
  await seed(page, fixtures.stops[0].state);
  expect((await snapshot(page)).mode).toBe('battle');
  await settleBattle(page);
  await page.keyboard.press('i');
  await expect(page.locator('.mv-panel:not([hidden])').first()).toBeVisible();
  await page.keyboard.press('Escape');
  await reset(page);
  await page.keyboard.down('KeyD');
  await page.waitForTimeout(500);
  await page.keyboard.up('KeyD');
  expect((await summary(page)).frames).toBeGreaterThan(0);
  expect((await summary(page)).maxSubsteps).toBeLessThanOrEqual(5);
  await page.goto('/tests/performance/lifecycle.html?performance=1');
  await page.waitForFunction(() => '__muhurTelemetry' in globalThis);
  await page.locator('#dispose').click();
  await expect(page.locator('#dispose')).toHaveText('Kapandı');
  await expect(page.locator('.mv-stage canvas')).toHaveCount(0);
  expect(await page.evaluate(() => '__muhurTelemetry' in globalThis || '__muhurTestBridge' in globalThis)).toBe(false);
  await page.goto('/');
  await expect(page.locator('.mv-stage canvas').first()).toBeVisible();
  expect(await page.evaluate(() => '__muhurTelemetry' in globalThis || '__muhurTestBridge' in globalThis)).toBe(false);
});
