import { expect, test } from '@playwright/test';

/** Boots the real game in a real browser: WebGL world, HUD, minimap and the first encounter card. */
test('boots the playable world with HUD, minimap and a reachable first target', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.addInitScript(() => indexedDB.deleteDatabase('muhur-vadisi'));
  await page.goto('/');
  const canvas = page.locator('.mv-stage canvas').first();
  await expect(canvas).toBeVisible();
  const context = await canvas.evaluate((element: HTMLCanvasElement) => {
    const gl = element.getContext('webgl2');
    if (!gl) throw new Error('Actual WebGL2 context is required');
    return { width: gl.drawingBufferWidth, height: gl.drawingBufferHeight, lost: gl.isContextLost() };
  });
  expect(context.width).toBeGreaterThan(0);
  expect(context.lost).toBe(false);
  await expect(page.locator('.mv-hud h2')).toContainText('Sv 2');
  await expect(page.locator('.mv-hud .mv-sub')).toContainText('Şafak Çayırı');
  await expect(page.locator('.mv-message')).toContainText('WASD');
  await expect(page.locator('.mv-minimap canvas')).toBeVisible();
  await page.screenshot({ path: '.reports/g03-boot.png' });

  await canvas.click({ position: { x: 400, y: 300 } });
  await page.keyboard.down('KeyS');
  await expect.poll(() => page.locator('.mv-card').isVisible(), { timeout: 15_000 }).toBe(true);
  await page.keyboard.up('KeyS');
  await expect(page.locator('.mv-card h3')).not.toBeEmpty();
  await expect(page.locator('.mv-hint')).toContainText('Enter');
  await page.screenshot({ path: '.reports/g03-target.png' });

  await page.keyboard.press('KeyI');
  await expect(page.locator('[role="dialog"][aria-label="Çanta"]')).toBeVisible();
  await expect(page.locator('.mv-panel:not([hidden]) .mv-grid-cell')).toHaveCount(24);
  await page.keyboard.press('Escape');
  await expect(page.locator('[role="dialog"][aria-label="Çanta"]')).toBeHidden();

  await page.setViewportSize({ width: 390, height: 844 });
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth)).toBe(390);
  await expect.poll(() => page.locator('.mv-minimap canvas').evaluate((node) => node.clientWidth)).toBe(144);
  await page.screenshot({ path: '.reports/g03-mobile.png' });
  expect(errors).toEqual([]);
});
