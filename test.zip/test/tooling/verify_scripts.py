import json
from pathlib import Path
import sys
try:
    pkg=json.loads(Path('package.json').read_text())
    for name in ('dev','build','typecheck','lint','test','test:e2e','test:property','bench'):
        command=pkg.get('scripts',{}).get(name)
        assert isinstance(command,str) and command.strip(), 'Missing npm script: '+name
        assert '--if-present' not in command and 'passWithNoTests' not in command, 'Gate can silently pass'
    assert Path('package-lock.json').is_file(), 'Missing package lock'
    assert 'three' in pkg.get('dependencies',{}), 'Real Three.js dependency required'
    print('Script contract present. Actual gameplay is verified by other gates.')
except (ValueError,OSError,AssertionError) as e:
    print(e,file=sys.stderr)
    raise SystemExit(1)
