# Mühür Vadisi v2 — oynanış derinliği tasarım sözleşmesi

Bu belge v1 sözleşmelerinin (COMBAT/CONTENT/WORLD/UI/RENDER) **üstüne** gelir ve çeliştiği
yerde v2 geçerlidir. Çelişen maddeler burada açıkça yazılıdır. v1 belgeleri silinmez;
tamamlanmış paketin kaydı olarak kalır.

## 0. v1 ile bilinçli çelişkiler

| Konu | v1 | v2 | Gerekçe |
|---|---|---|---|
| Takım boyutu | 3 aktif / 60 koleksiyon | **6 aktif / 60 koleksiyon** | Ürün sahibi kararı; ekranda altı yuvalı şerit gösterilecek |
| Tarif açılışı | savaş ganimetinde %10 rastgele işaret | **bahçıvan tapınağı ziyaretiyle garantili** | Keşfin görünür bir hedefi olsun |
| Savaşta eşya | yasak | **iyileştirme eşyası serbest, bir tur harcar** | Savaşta karar çeşitliliği |
| Hareket seti | 4 ortak hareket | **türe özel 4 hareket, 24'lük havuzdan** | 16 türün aynı oynanması v1'in en büyük zayıflığı |

Değişmeyenler: XZ dünya, 1/60 sabit adım, IndexedDB tek transaction + ledger, deterministik
savaş RNG'si, oynanış RNG'si ile görsel RNG'nin ayrılığı, Türkçe arayüz, özgün varlıklar.

## 1. Savaş derinliği (combat)

### 1.1 Hareket havuzu
24 hareket; her biri `{ id, name, element, power, accuracy, cost, unlockLevel, effect? }`.
Güç bandı 6–24, isabet .70–1.00, enerji 0–4, açılma seviyeleri 1 / 3 / 6 / 10.
Her tür bu havuzdan **dört** hareket taşır (`CreatureDefinition.moveIds`), en az biri kendi
elementinden ve tam biri savunma/destek. Slot düzeni v1 ile aynı kalır: 4 buton, kilitli slot
yerinde durur ve açılma seviyesini yazar.

### 1.2 Durum etkileri
Üç etki, hepsi savaş RNG'sinden tek zar ile uygulanır ve savaş kaydına yazılır:

| Etki | Uygulama | Süre | Sonuç |
|---|---|---|---|
| Zehir | `poison` etkili hareket, %35 | 3 tur | Tur sonu `ceil(maxHp/16)` hasar |
| Yanık | `burn` etkili hareket, %30 | 3 tur | Saldırı gücü ×0.75 |
| Yavaşlatma | `slow` etkili hareket, %40 | 2 tur | Enerji yenilenmesi 0 |

Aynı etki üst üste binmez, süresi yenilenir. Etkiler savaş bitince temizlenir. Replay
determinizmi zorunlu: aynı seed + komut listesi aynı durum zincirini üretir.

### 1.3 Tam element tablosu
Dokuz element için 9×9 tablo; üstünlük 1.25, zayıflık 0.8, geri kalan 1.0.
Döngüler: çim→su→kor→çim; buz→taş→rüzgâr→buz; ışık↔gölge karşılıklı 1.25; kıvılcım su ve
rüzgâra 1.25, taşa 0.8. Tablo tek kaynakta (`src/game/combat/elements.ts`) tanımlanır ve
simetri/aralık testi ile doğrulanır.

### 1.4 Altı yuvalı takım ve değiştirme
- `WorldState.party: string[]` — en çok 6 yaratık kimliği, sırası ekrandaki sırayı belirler.
- Aktif yaratık `party[activeIndex]`; koleksiyondaki diğerleri savaşa giremez.
- Savaşta **Değiştir** eylemi bir tur harcar: rakip kendi hamlesini yapar, gelen yaratık
  ilk turunda saldıramaz. Baygın yaratığa geçilemez.
- Aktif yaratık bayılırsa savaş bitmez: ayakta yaratık varsa zorunlu değiştirme istenir,
  yoksa LOST. (v1'de tek yaratık bayılınca savaş bitiyordu.)
- Yakalanan yaratık takımda yer varsa takıma, yoksa koleksiyona gider.

### 1.5 XP paylaşımı ve eğitim
- Aktif yaratık %100, takımdaki diğer ayakta yaratıklar **%40** XP alır.
- Eğitim tonikleri (simya): `training_tonic` +150 XP, `focus_tonic` bir sonraki savaşta
  isabet +%10. Tonikler yalnız kampta kullanılır, XP formülünü değiştirmez.

## 2. Dünyada amaç (world)

### 2.1 Bahçıvan tapınakları
Sekiz bölgenin her birinde, bölge girişine 30–60 m mesafede deterministik konumlu bir yapı.
- İlk ziyaret: bölgenin tarifini **garantili** öğretir, bir hikâye parçası düşürür, tapınağı
  hızlı seyahat çapası yapar ve tek seferlik bir sandık verir (2 bölge materyali + 1 mühür).
- Tekrar ziyaret: yalnız hızlı seyahat.
- Savaş ganimetindeki rastgele sır kaldırılır; esanslar nadir ganimet olarak kalır.

### 2.2 Hedef listesi
Kayıttan türetilen sekiz hedef; hiçbiri ayrı bir "görev durumu" saklamaz, hepsi mevcut
verilerden hesaplanır: tapınak sayısı, mühürlenen tür sayısı, üretilen tarif sayısı, en yüksek
seviye, çatlayan yumurta, gece yakalanan tür, altı yuvanın dolması, sekizinci tapınak.

### 2.3 Hızlı seyahat
Keşfedilmiş tapınaklar ve kamp arasında; panelden seçilir, 60 saniye dünya zamanı ilerletir
(kuluçka ve bekleme sayaçları bundan etkilenir), savaş/panel açıkken kapalıdır.

### 2.4 Gece/gündüz
Dünya zamanı 10 dakikalık döngü: gündüz 6 dk, gece 4 dk. Gece algılama yarıçapı 24 → 16 m,
saldırgan oranı +%15, bazı türler yalnız gece doğar. Işık ve sis rengi döngüye bağlanır.

### 2.5 Eşya elde etme yolları (v1'de tek yol vardı)
1. **Yürürken Enter** — mevcut kaynak düğümleri.
2. **Damar kazma** — kaya düğümü; 3 saniye basılı tutma **veya** takımda `taş` elementli
   yaratık varsa anında. Cevher ve nadir mineral verir.
3. **Savaş ganimeti** — yenilen yaratık bölge materyali düşürür; nadirlik tablosuna göre
   %15 ihtimalle ikinci, nadir bir materyal.
4. **Yaratık yardımı** — takımın element çeşitliliği 24 m içindeki gizli zulaları minimap'te
   gösterir (her element bir zula türü açar).
5. **Kamp bahçesi** — kampta ekilen tohum 180 saniye aktif dünya zamanında ürün verir.
6. **Tapınak sandığı** — bölge başına tek sefer.
7. **Gece kaynakları** — `moon_spore` gibi üç materyal yalnız gece toplanabilir.

Hepsi tek transaction + commandId ile tekilleşir; dolu çantada teslim kutusuna gider.

## 3. İçerik genişlemesi (content)

- **Türler 16 → 32**: biyom başına dört (2 sık, 1 seyrek, 1 ender). Her tür: dört hareket,
  gece/gündüz tercihi, iki görsel evre (seviye 10'da değişen silüet).
- **Eşyalar 33 → 52**: 8 yeni materyal (gece ve damar), 4 alet (kazma, fener, ağ, kova),
  4 eğitim toniği, 3 mühür kademesi (yakalama bonusu +0 / +.05 / +.10).
- **Tarifler 8 → 16**: mevcut sekiz + 4 tonik + 2 alet + 2 mühür yükseltmesi.
  Tarifler tapınak ziyaretiyle açılır; bölge başına iki tarif (biri temel biri ileri).
- SVG kuralları v1 ile aynı: yerel, script'siz, ön/arka ayrı çizim, marka kopyası yok.

## 4. Arayüz düzeni (ui) — ürün sahibinin isteği

```
┌─────────────────────────────────────────────────────────┐
│ ┌───────────────┐                                       │
│ │ Çiytomur Sv 7 │  ← sol panel YALNIZ: ad/seviye, can,   │
│ │ Can  ▓▓▓▓░░   │     tecrübe, biyom, uyarı              │
│ │ Tecrübe ▓░░░  │                                       │
│ └───────────────┘                                       │
│                                                         │
│                      (dünya)                            │
│                                                         │
│  ╭──────╮                                               │
│  │minimap│      [1][2][3][4][5][6]  ← altı yuvalı takım  │
│  ╰──────╯      ( Çanta  Simya  Kamp  Defter  Hedefler )  │
└─────────────────────────────────────────────────────────┘
```
- **Sol panel**: yalnız can ve tecrübe barları + ad/seviye/biyom/uyarı. Sayaçlar ve düğmeler
  buradan çıkar.
- **Alt orta sekme çubuğu**: Çanta (I) · Simya (C) · Kamp (K) · Defter (B) · Hedefler (H);
  44 px hedef, klavye kısayolları korunur, açık sekme `aria-pressed` ile işaretlenir.
- **Altı yuvalı takım şeridi**: sekme çubuğunun üstünde yatay; her yuva sprite + seviye +
  can barı; 1–6 tuşları veya tıklama aktif yaratığı değiştirir (savaş dışında anında,
  savaşta bir tur harcar); boş yuva "boş" olarak görünür.
- Ayarlar paneli (ses, hareket azaltma, tuş atama), kayıt yuvaları (3 yuva + yeni oyun)
  ve **bozuk kayıt kurtarma ekranı** (ham kaydı dışa aktar / yeni oyun) eklenir.
- Mobil: sol altta sanal çubuk, sekme çubuğu tam genişlik, kart ve savaş düzeni tek sütun.

## 5. Three.js yapısı (render)

1. **Sprite atlası**: tüm yaratık/yumurta/item dokuları tek atlasa; materyal sayısı tür başına
   birden atlas başına bire iner.
2. **Animasyon**: her yaratık için 3 kare (idle-A, idle-B, vuruş) atlas UV değişimiyle; 6 FPS
   idle, vuruşta tek kare. Hareket azaltma tercihinde tek kare.
3. **Parçacıklar**: toplama kıvılcımı, mühür halkası, seviye atlama patlaması — tek
   `Points` sistemi ve havuzlanmış parçacıklar, kare başına tek draw call.
4. **Hasar sayıları**: savaş sayfasında CSS animasyonu; dünyada yükselen sprite yok.
5. **Gece/gündüz**: directional + hemisphere ışığı ve sis rengi dünya saatinden türetilir;
   gölge yalnız gündüz.
6. **Worker chunk**: `buildChunkTerrain` + `collectDecor` bir web worker'a taşınır
   (`ChunkRenderer.build` hook'u zaten bunu bekliyor); generation token kuralı korunur.
7. **LOD**: 1 halkanın dışındaki chunk'lar 8 m ızgarayla üretilir (şu an hepsi 2 m).
8. **Kamera**: savaş başında hafif yakınlaşma, vuruşta 80 ms sarsıntı — ikisi de hareket
   azaltma tercihinde kapalı.

## 6. Kayıt şeması v3 ve göç

Yeni alanlar: `party`, `activeIndex`, `shrines`, `objectives` (türetilmiş, saklanmaz),
`statuses` (savaş içinde), `dayTick`, `garden`, `toolIds`.
v2 → v3 göçü: mevcut `activeCreatureId` tek elemanlı `party`ye taşınır, `secretFlags`
tapınak kaydına çevrilir. Göç tek transaction'da yapılır, eski kayıt `backup` olarak kalır,
başarısızlıkta açıklayıcı hata verir ve veri silinmez.

## 7. Bitti sayılma ölçütü

Bir düğüm ancak şunlar sağlanınca biter: kabul maddelerinin hepsi testli, `npm run typecheck`,
`npm run lint`, ilgili vitest dosyası ve `npm run build` sıfır çıkış kodu, kanıt `.reports`
altında, ve **uygulayıcıdan farklı bir rol** kodu okuyarak onaylamış olur.
