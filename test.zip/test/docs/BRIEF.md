# Oyun kapsamı
Oyuncu karakteri üstten görünümde haritada dört yöne hareket eder ve kamera takip eder.
Geniş dünya çim, yoğun orman, çöl, deniz, beyaz buzul, kahverengi kanyon, lacivert volkan
ve alev bölgelerine ayrılır. Sol alt dairesel minimap coğrafyayı, karakteri ve yakın hedefleri gösterir.
Yaratık/yumurta yaklaşınca büyük özgün SVG portre ve isim görünür. Enter hedef etkileşimini açar.
Yumurta alınır; yaratıkla savaş ekranına geçilir. Bazı saldırganlar oyuncuya meydan okur.
Savaşta dost sırtı dönük, rakip önden; dört saldırı slotu ve zayıflayan rakibi yakalama.
Başlangıç zayıf yaratıklar/yumurtalarla öğreticidir. Zafer ve yakalama XP sağlar; seviye ve
kozmetik evrim açılır. Düşman zaferleri materyal ve sır parçaları verir.
Çeşitli simya malzemeleri, grid çanta ve tarif penceresi stratejik hazırlık sağlar.
Bu teslim bu oyunu üretecek geliştirme paketi ve tasarımdır; oyun kodu henüz üretilmedi.
