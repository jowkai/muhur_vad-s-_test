# Mühür Vadisi v2 — çok ajanlı geliştirme rehberi

Bu rehber `workflow/graph-v2.json` ile birlikte okunur. Grafik motorun şemasına uygundur ve
doğrulanmıştır: **23 düğüm, 32 kenar, döngüsüz**. Tasarım kararları `docs/V2-DESIGN.md`
içindedir; çelişen v1 maddeleri orada açıkça listelenmiştir.

## Nasıl çalıştırılır

```bash
# v1 durumu arşivle (grafik değişince eski başarılar taşınamaz)
mv .loop .loop-v1-$(date +%Y%m%d) 2>/dev/null || true

python3 task_engine.py --graph workflow/graph-v2.json plan
python3 task_engine.py --graph workflow/graph-v2.json run --max-tasks 1 --max-codex-calls 6 --timeout 900
python3 task_engine.py --graph workflow/graph-v2.json status
```

Motor **sıralı tek yazıcıdır**: aynı anda tek düğüm yazılır, ardından farklı bir rol salt-okunur
incelemeye girer. Yedi rol tanımı motorun şartıdır; v2 işinin ağırlığı beş uygulayıcıdadır
(`content`, `combat`, `world`, `ui`, `render`), `coordinator` sözleşme/göç/entegrasyonu,
`qa` kanıt ve gauntlet'i taşır.

## Döngü: beş tur

```
T1 Sözleşme ──▶ T2 Savaş ──▶ T3 Dünya ──▶ T4 Sunum ──▶ T5 Kalite
   coordinator    combat       world        ui+render     qa
        │            │            │             │            │
        └── her turun sonunda: farklı rol incelemesi + .reports kanıtı ──┘
```

Bir tur ancak içindeki bütün düğümler gate'lerden geçip **uygulayıcıdan farklı bir rol**
tarafından onaylanınca kapanır. Bir sonraki tur kapanmamış turun üstüne yazmaz.

### T1 — Sözleşme ve göç (lider: coordinator, 2 düğüm)
| Düğüm | İş |
|---|---|
| `V1-CONTRACTS` | party/activeIndex, durum etkisi, tapınak, gün döngüsü ve alet tipleri tek kaynakta; yeni intent'ler ve sahiplik ayrımı |
| `V1-MIGRATION` | Kayıt v3 göçü: `activeCreatureId` → tek elemanlı `party`, `secretFlags` → tapınak kaydı; eski kayıt `backup` olarak korunur |

**Neden önce:** altı yuvalı takım ve tapınaklar kayıt şemasını değiştirir. Şema son anda
değişirse T2–T4'ün bütün testleri yeniden yazılır.

### T2 — Savaşı oyun hâline getir (lider: combat, 4 düğüm)
`V2-MOVES` (24 hareket havuzu + türe özel dört hareket + 9×9 element tablosu) →
`V2-STATUS` (zehir/yanık/yavaşlatma) → `V2-PARTY` (altı yuva, bir tur harcayan değiştirme,
zorunlu geçiş, %40 takım XP'si) → `V2-BATTLEBAG` (savaşta iyileştirme, üç mühür kademesi).

**Bitti ölçütü:** aynı seed + komut listesi aynı durum zincirini üretiyor; 50 tekrar komut tek
ödül veriyor; savaş reload sonrası durum etkileriyle birlikte geri geliyor.

### T3 — Dünyaya amaç ver (lider: world, 6 düğüm)
`V3-SHRINES` (bahçıvan tapınakları: garantili tarif + hikâye + sandık + seyahat çapası) →
`V3-OBJECTIVES` (kayıttan türetilen sekiz hedef) → `V3-TRAVEL` (hızlı seyahat, 60 sn dünya
zamanı) → `V3-DAYNIGHT` (10 dk döngü, gece türleri) → `V3-GATHER` (yedi toplama yolu) →
`V3-CONTENT` (32 tür, 52 eşya, 16 tarif).

**Bu tur "neden oynuyorum?" sorusunu cevaplar.** Tarif keşfi rastgelelikten çıkar, harita
gezilecek yer kazanır, eşya toplamak tek tuş olmaktan çıkar.

### T4 — Sunum ve his (lider: ui + render, 7 düğüm)
| Düğüm | İş |
|---|---|
| `V4-LAYOUT` | Sol panelde yalnız can/tecrübe; **alt ortada sekme çubuğu** (Çanta/Simya/Kamp/Defter/Hedefler) |
| `V4-PARTYBAR` | **Altı yuvalı yatay takım şeridi**; 1–6 ve tıklama ile aktif değişimi |
| `V4-PANELS` | Hedefler, ayarlar, üç kayıt yuvası, bozuk kayıt kurtarma ekranı |
| `V4-SPRITES` | Sprite atlası, üç kareli animasyon, `cosmeticStage`'in gerçekten çizilmesi |
| `V4-FX` | Parçacıklar, hasar sayıları, gece/gündüz ışığı |
| `V4-WORKER` | Worker'da chunk üretimi + uzak halkada 8 m LOD |
| `V4-MOBILE` | Sanal çubuk ve dar ekran düzeni |

### T5 — Üretim kalitesi (lider: qa, 4 düğüm)
`V5-INTEGRATION` (tek oynanabilir akış) → `V5-GAUNTLET` (gerçek tarayıcı uçtan uca) →
`V5-PERF` (üç 120 sn rota, aynı bütçeler) → `V5-RELEASE` (kanıt + puanlama).

## İstekler → düğüm eşlemesi

| İstek | Düğüm |
|---|---|
| Sol panelde yalnız can ve tecrübe | `V4-LAYOUT` |
| Çanta/simya sekmeleri ekranın alt ortasına | `V4-LAYOUT` |
| 6 yaratık yakalama, Pokémon benzeri takım | `V1-CONTRACTS`, `V1-MIGRATION`, `V2-PARTY` |
| Ekranda altı yuvalı yatay takım şeridi | `V4-PARTYBAR` |
| Amaç: yaratıkları dövüştürerek ve simyayla geliştirmek | `V2-PARTY` (XP paylaşımı), `V3-CONTENT` (tonikler), `V3-OBJECTIVES` |
| Simya çeşitliliği | `V3-CONTENT` (8 → 16 tarif), `V3-SHRINES` (açılış) |
| Yaratık çeşitliliği | `V3-CONTENT` (16 → 32 tür), `V2-MOVES` (türe özel hareket) |
| Eşya çeşitliliği ve yeni toplama yolları | `V3-GATHER` (7 yol), `V3-CONTENT` (52 eşya) |
| Three.js yapısının geliştirilmesi | `V4-SPRITES`, `V4-FX`, `V4-WORKER`, `V5-PERF` |
| Savaş derinliği (durum, değiştirme, eşya, element) | `V2-MOVES`, `V2-STATUS`, `V2-PARTY`, `V2-BATTLEBAG` |
| Keşfin amacı ve hikâye | `V3-SHRINES`, `V3-OBJECTIVES` |

## Her düğümde uyulacak kurallar (AGENTS.md'den taşınır)

1. Yalnız `scope` yollarına yaz; sonraki düğümün işini ekleme.
2. Motor, grafik, AGENTS, skill'ler ve QA scorer değiştirilmez; gate'ler kaynak yazmaz.
3. Test skip, boş suite başarısı, koşulsuz exit 0 ve sahte performans raporu yasak.
4. Kanıt `.reports/<DÜĞÜM>.md` + `<düğüm>-checks.json` olarak bırakılır; iddia edilen her
   sayı gerçek komut çıktısından gelir.
5. Uygulayıcı kendi işini onaylamaz; inceleyici kodu ve kanıtı okur, açıklamaya güvenmez.
6. Araç veya erişim yoksa sonuç açıkça **BLOCKED** yazılır.

## Riskler ve önlemler

| Risk | Önlem |
|---|---|
| Kayıt göçü veri kaybı | T1'de tek transaction + `backup`; 50 tekrar göç testi; bozuk kayıtta açıklayıcı hata |
| Determinizm kaybı (durum etkileri) | Her etki tek zar; 100 rastgele savaşta replay eşitliği testi |
| Performans düşüşü (32 tür, atlas, parçacık) | `V5-PERF` aynı bütçeleri uygular; draw call v1 ölçümünün üstüne çıkamaz |
| Arayüz kalabalığı (şerit + sekme + minimap) | 390 px testleri her UI düğümünün gate'inde |
| Kapsam kayması | Her düğümün üç kabul maddesi var; dördüncüsü yeni düğüm demektir |

## Tahmini büyüklük

| Tur | Düğüm | Tahmini yeni test | Ana risk |
|---|---:|---:|---|
| T1 | 2 | ~15 | göç |
| T2 | 4 | ~45 | determinizm |
| T3 | 6 | ~55 | dünya zamanı tutarlılığı |
| T4 | 7 | ~50 | düzen ve erişilebilirlik |
| T5 | 4 | ~20 | referans cihaz |

Toplam ~23 düğüm, mevcut 298 testin üstüne kabaca 185 yeni test.
