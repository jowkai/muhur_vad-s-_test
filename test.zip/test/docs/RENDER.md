# Three.js görüntüleme sözleşmesi

Bu belge uygulama hedefidir; hiçbir FPS veya GPU bütçesi ölçülmüş sonuç olarak sunulmaz. Three.js sürümü bootstrap sırasında tam sürüm olarak package.json ve lockfile içinde sabitlenir. Uygulama TypeScript, Vite ve WebGLRenderer ile başlar; WebGPU zorunluluğu yoktur.

## Koordinat ve sorumluluk

Dünya zemini XZ, yükseklik Y; kuzey -Z, doğu +X. Oyun mantığı metre ve saniye kullanır. Harita, çarpışma ve karşılaşma sorguları saf simülasyona aittir; renderer yalnızca salt okunur snapshot tüketir. Mesh konumu oyun durumunun kaynağı değildir. Her entity kalıcı ID taşır. Aynı ID chunk boşaltıldığında kaybolmaz.

```ts
interface VecXZ { x: number; z: number }
interface RenderEntity { id: string; position: VecXZ; height: number; yaw: number; visualId: string }
interface WorldFrame { tick: number; playerId: string; entities: readonly RenderEntity[]; visibleChunkIds: readonly string[] }
interface RendererPort {
  mount(host: HTMLElement): void;
  render(previous: WorldFrame, current: WorldFrame, alpha: number, realDelta: number): void;
  resize(width: number, height: number): void;
  dispose(): void;
}
```

Bu tipler entegratörün merkezi contracts modülünden içe aktarılır; rol kendi kopyasını üretmez. Birim hareket WASD/ok tuşlarıdır. Çapraz giriş normalize edilir. Son sıfır olmayan hareket yaw yönünü belirler. Key repeat hareketi hızlandırmaz; pencere blur durumunda giriş temizlenir.

## Kamera ve zaman

OrthographicCamera, takip edilen karakterin üstünde 60 derece eğimli sabit kuzey yönelimli açı kullanır. Ekranın dikey dünya kapsamı başlangıçta 32 birimdir; yatay kapsam en/boy oranından türetilir. Resize sonrası projection matrix güncellenir. Oyuncu dönüşü kamerayı döndürmez. Kamera hedefi player konumudur; yumuşatma katsayısı `1 - exp(-10 * realDelta)` ile FPS bağımsız hesaplanır. Teleport ve yükleme durumlarında kamera hedefe sıfırlanır. Kamera sınırlarında harita dışı boşluk gösterilecekse sis/okyanus zeminiyle kapatılır.

Simülasyon 60 Hz sabit adım kullanır. Her karede gelen delta en fazla 5/60 s, en fazla 5 simülasyon adımıdır; aşan birikim atılır ve telemetry sayacı artar. Render previous/current snapshot arasında interpolation yapar. Gizli sekmeden dönüşte zaman birikimi sıfırlanır; karakter ileri fırlamaz. Battle ve modal durumunda dünyadaki hareket/aggro durur; UI animasyonu çalışabilir. Mantık RNG ile görsel parçacık RNG ayrı kaynaklardır.

## Chunk yaşam döngüsü

Chunk boyutu dünya rolünün ortak sabitinden gelir. Kamera frustum kapsamındaki chunk'lar ve bir güvenlik halkası yüklenir; aktif görsel pencere 5x5 (25) chunk, simülasyon penceresi 3x3; en fazla 24 ek cache chunk ile unload hysteresis dahil en çok 49 resident chunk. Uzaklaştırma için ekstra bir halka hysteresis kullanılır; aynı sınırda gezinme thrash üretmez. Worker sonuçları generation token taşır: artık gerekli olmayan asenkron sonuçlar sahneye eklenmez.

Ağaç, çalı ve taşlar tür/malzeme/chunk bazında InstancedMesh olarak gruplanır. Her ağaç için ayrı mesh, materyal ve texture yasaktır. Instance transform değişince instanceMatrix güncellenir; bounds yeniden hesaplanır. Hasat sonrası instance-ID eşlemesi bozulmaz. Arazi düşük poligon chunk mesh, kıyı ve biyom geçişleri vertex color veya az sayıda paylaşılan materyaldir. SVG yaratıklar atlas/sprite ya da düşük poligon yardımcı gövdelerle dünyada görünür; büyük SVG portre UI tarafındadır.

Kaynak kayıtçısı geometri, materyal, texture ve render target sahipliğini izler. Chunk'a özel kaynak unload'da dispose edilir; paylaşılan kaynak referans sayısı sıfıra düşünce serbest bırakılır. Scene.remove GPU serbest bırakma kabulü değildir. Olay dinleyicileri, animation loop ve canvas da son dispose'da kaldırılır. Context kaybında anlaşılır yeniden yükleme arayüzü gösterilir; boş siyah ekran kabul edilmez.

## Bütçe ve doğrulama

Referans profil: fiziksel Apple Silicon M1 8 GB Mac, 1440x900 CSS piksel, DPR üst sınırı 1.5, güç adaptörü, görünür sekme, tarayıcı ve işletim sistemi sürümü kaydedilmiş. Bu cihaz yoksa sonuç pending olur; yazılım WebGL çıktısı fiziksel GPU ölçümü yerine geçmez.

- Isınma 10 s, sabit seed rota 120 s: yoğun orman, su kıyısı ve volkan dahil. p95 frame interval <= 20 ms, p99 <= 33.4 ms hedef.
- En fazla 150 draw call ve 300 bin görünür üçgen/kare; renderer.info snapshot ile ölç. Gölge tek directional light; düşük profilde blob shadow kullan.
- Tahmini texture+render-target ayrılmış bellek <=128 MiB. Bu hesaplanan bütçedir; renderer.info toplam VRAM baytı değildir. Gerçek VRAM ölçüldü denmez.
- Aynı 20 chunk giriş/çıkış döngüsü sonrası resident <=49; cache ısındıktan sonra geometry/texture sayıları son beş turda monoton artmamalı; kaynak sahiplik kaydı sonunda boş olmalı.
- 30/60/120 render FPS altında 10 saniyelik aynı giriş replay'i simülasyon sonunda aynı koordinata ulaşmalı; kamera durduktan 0.5 s sonra hedef sapması <=0.1 dünya birimi.
- 1280x720 ve 1920x1080 ekran görüntüsü: karakter görünür, biyom sınırları okunur, HUD kesilmez. Hiçbir pass yalnızca ekran görüntüsüne bakılarak performans puanı kazanmaz.

Kanıt JSON: commit, seed, route, browser, hardware, resolution, dpr, warmupSeconds, sampleSeconds, samples, p95Ms, p99Ms, maxDrawCalls, maxTriangles, residentChunks, resourceCounts. Eksik ölçüm `not_run`; başarılı varsayılmaz.

Kaynak: [Three.js resmi API kataloğu](https://threejs.org/docs/). Buradaki koordinatlar, eşikler ve bütçeler projeye özgü tasarım kararlarıdır.
