# Graph ve gauntlet yürütmesi

Düğüm bir teslim edilebilir geliştirme işidir. Edge A→B, B'nin A çıktısını gerektirdiğini belirtir.
Workflow DAG'dir; onarım tekrarları düğümün içinde gerçekleşir. Yeni bir bağımlılık öğrenilirse
aktif uygulama turunda graph değiştirilmez; coordinator dışarıda planı gözden geçirir.

Yedi rol: coordinator, world, render, combat, content, ui, qa. Her implement/review çağrısında
atanmış rolün gerçek skill içeriği ve AGENTS.md prompt'a konur. Bu yalnız rol etiketi değildir.
Motor tek yazıcı kullanır; aynı anda yedi Codex süreci çalıştırdığı iddia edilmez.
Bu tasarım hazırlanırken ana koordinatör + altı uzman paralel çalıştı; paket runtime'ı sıralıdır.

```mermaid
flowchart TD
  A[Bağımlılıkları doğrula] --> B[Uzman rol ile uygula]
  B --> C[Kapsam kontrolü]
  C --> D[Gerçek gate komutları]
  D -->|Geçti| E[Farklı rol ile review]
  E -->|Onay ve bulgu yok| F[Checkpoint passed]
  D -->|Hata| G[Kanıtla onarım]
  E -->|Bulgu| G
  G -->|Deneme kaldı| B
  G -->|Sınır doldu| H[Blocked]
```

## Durdurma ve kanıt
Node başına3 deneme; bir çalıştırmada görev ve Codex çağrı üst sınırı. Her alt süreç timeout ile
sonlanır. Bu bütçeler token veya para tavanı değildir. Toplam wall-clock tavanı uygulanmamıştır.
İki model çağrısı (uygulama+review) bütçesi yoksa yeni deneme başlamaz.
Gate exit!=0 veya reviewer bulgusu varsa passed olmaz; eksik sonuç fail-closed olur.
Kaynak kapsamı ihlali otomatik geri alınmaz; BLOCKED ve değişen dosyalar raporlanır.
Checkpoint dışı kaynak değişince eski başarılar doğrudan kullanılmaz. Reset seçili düğümü ve
tüm descendants'larını açar; kaynak geri alınmaz. Etki kapsamından emin değilsen G00'dan reset et.
Kilit dosyası varsa ikinci çalıştırıcı başlamaz. Crash sonrası PID'nin bittiğini doğrulamadan kilidi silme.
Tam graph değişikliğinde eski .loop/state.json arşivlenir ve tüm işler yeniden değerlendirilir.
Agent'in testleri değiştirebildiği unutulmaz: reviewer assertion kalitesini ve gate zayıflatılmasını inceler.
Dosya hash kontrolü sandbox veya kötü niyetli kod izolasyonu değildir.

## Puanlama
Node gate'leri görev için; final gauntlet bütün oyun için. Release score>=85 ve her kriter>=60
ve tüm hard gate PASS olmalı. Eksik oyun kanıtı null puan üretir; tasarım skoru yerine konmaz.
qa/score_current.py mevcut HEAD + kaynak fingerprint ile kanıtı bağlar. Raporlar .loop/evidence içindedir.
Kaynak kod değişirse eski raporun fingerprint'i geçmez. SHA kanıtın kaynağını bağlar; rapor
içeriğinin doğruluğunu bağımsız QA doğrular, kriptografik CI provenance bu sürümde yoktur.
