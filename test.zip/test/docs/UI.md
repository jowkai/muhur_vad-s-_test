# Arayüz ve etkileşim sözleşmesi

Dil Türkçe; özgün fantastik arayüz. Koyu mürekkep paneller, kemik beyazı metin, pirinç vurgu. Biyom renkleri world kataloğundan alınır. Pokémon veya LoL logoları, isimleri ve görselleri kullanılmaz. SVG'ler projede üretilen özgün varlıklardır; front/back ayrı çizimlerdir. Arkadan görünüş yalnızca önden görseli yatay çevirmek değildir.

## Durum ve komut sınırı

UI snapshot okur, command gönderir; HP, item, XP ve yakalama sonucunu kendisi değiştirmez. Durumlar: loading, explore, encounter, battle, reward, defeat, paused. Inventory/alchemy/bestiary modal state'i explore altında tutulur. Bir modal açıkken dünya hareketi ve aggro askıdadır. UI komutu `{id, type, payload}` içerir; command id tekrarları domain katmanında reddedilir. Battle animasyonu sonucu belirlemez.

## Keşif ekranı

Sol alt köşede 192 px çapında dairesel minimap, 16 px güvenli kenar boşluğu. 1280x720 altında 144 px. Canvas2D veya SVG mask ile gerçek dairesel clipping; ikinci Three.js dünya render'ı gerekmez. Kuzey üsttedir, oyuncu merkezde, görüş alanı daire yarıçapına karşılık gelen 96 metre dünya mesafesidir. `dx=x-player.x`, `dy=z-player.z`; `screenX=centerX+dx*scale`, `screenY=centerY+dy*scale`. Uzak işaretler daire dışına taşmaz. Kuzey oku ve biyom adı bulunur. Statik arazi atlası chunk değişiminde, dinamik marker katmanı en az 10 Hz yenilenir. Fog-of-war keşif kaydından okunur; keşfedilmemiş yaratıklar gösterilmez.

Marker: oyuncu üçgen, yumurta oval, yaratık pençe, saldırgan yaratık kırmızı konturlu pençe, simya itemi elmas, keşfedilmiş sır yıldız. Renk tek bilgi taşıyıcısı değildir. Tek minimap işareti DOM tab sırasını doldurmaz; seçili hedef adı metin olarak okunur.

24 metre algılama alanında hedef işaretlenir; 6 metre etkileşim alanında ve görüş hattındaki en yakın hedef, domain target seçicisinden gelir. Bağlı mesafede kararlı ID ile seçim; bir hedef diğerinden belirgin yakın olmadıkça kart titreşerek değişmez. Alt orta encounter kartında en az 128x128 SVG, isim, seviye, element, davranış ve `Enter: İncele / Savaş` bulunur. Yumurta için `Enter: Topla`, çanta doluysa gerekçeli disabled durum. Toplama ve yakalama ayrı kavramlar. Yaratık yakalama savaş içindedir. Saldırgan yaklaşım domain olayıyla savaş başlatır; kısa görünür uyarı, sonrasında yeniden tetiklenmeyi önleyen cooldown gerekir.

## Battle page

Keşif ekranının üzerinde tam battle sahnesi. Sol altta oyuncunun yaratığının sırt SVG'si; sağ üstte düşmanın ön SVG'si. Her iki tarafta isim, seviye, HP sayısı+bar, element ve durum etkisi. Oyuncu XP barı görünür. Biyom battle arkaplanını belirler ama okunurluk korunur.

Alt bölümde 2x2 düzende tam dört saldırı butonu. Her birinde ad, element, güç, isabet, kalan kullanım/bedel. Düşük seviyede kilitli hareket aynı yerde kalır ve açılma seviyesi yazılır; dört güçlü saldırı verilmez. Ayrı `Yakala`, `Çanta`, `Kaç` kontrolleri. Yakala stok ve hedef uygunluğunu gösterir; zayıflayınca oran yükselir, kesin başarı iddia edilmez. Sonuç domain RNG'sinden gelir. Bayılmış hedef yakalanamaz.

Oyuncu kararı dışındaki resolving/animating/enemyTurn/result durumlarında bütün eylemler kilitlenir. Çift tık tek tur tüketir. Yakalama başarısızlığı domain kurallarına göre karşı tura geçer. Kazanç penceresinde yalnızca domain reward ledger içindeki item/XP/sır gösterilir. Kapatıp yeniden açma ikinci ödül vermez. Yenilgi sonrası güvenli başlangıç noktasına dönüş ve takımın toparlanması açıkça anlatılır.

## Strateji panelleri

`I` envanter, `C` simya, `B` yaratık defteri; Escape üstteki paneli kapatır ve odağı eski düğmeye döndürür. Envanter 6 sütun grid, ikon, adet, kalite/element ve seçili item açıklaması. Klavye okları hücreyi gezer; Enter seçer. Dokunmatik sürükleme zorunlu değildir. Sıralama/filtreler inventory verisini değiştirmez. Takım değiştirme battle içinde ancak izin verilen command ile gerçekleşir.

Simya paneli sol tarif listesi, orta 3 malzeme yuvası, sağ sonuç/olasılık ve üret butonu. Katalogda iki girdili tarif varsa üçüncü boş yuva zorunlu kılınmaz. Stok eksiği miktarla yazılır; atomic craft komutu tüm girdileri ve alan yeterliliğini birlikte doğrular. Butona çift basmak eksi stok üretemez. Keşfedilmemiş tarif isimleri/sırları spoiler olarak gösterilmez. Yumurtalar kuluçka sekmesinde mesafe/XP gereksinimi ile takip edilir.

## Kabul kanıtı

- 1280x720 ve 1920x1080 screenshot seti: çayır keşfi, seçili yumurta, saldırgan encounter, battle, başarısız/başarılı yakalama, envanter dolu, simya eksik stok, ödül.
- Minimap koordinat testi dört kardinal yön, çapraz, yarıçap sınırı; piksellerde <=1 px dönüşüm hatası; görünmeyen hedef gösterilmez.
- Gerçek tarayıcı akışı: hareket → kart → Enter → battle → saldırı → Yakala → takım güncelleme → dünya dönüşü. UI testleri domain API'sini mock ederek tek başına end-to-end kabul edilmez.
- Enter basılı tutulunca tek encounter; modalda hareket yok; battle çift tık tek command; aynı reward iki kez alınamıyor.
- Klavye ile tüm eylemler erişilir; görünür focus, dialog adı, focus trap ve Escape dönüşü vardır. Metin kontrastı normal yazıda en az 4.5:1; aksiyon hedefi en az 44x44 CSS px.
- Hareket azaltma tercihi kamera sarsıntısını/flash'i kapatır. Ses kullanıcı etkileşimi sonrası başlar, ayrı sessize alma kontrolü bulunur.

Testlerin her biri pass/fail/not_run olarak kaydedilir. Görsellerin hazırlanmış olması uygulama akışının çalıştığı anlamına gelmez.
