# Mühür Vadisi v3 — dünya, roller ve ekonomi tasarım sözleşmesi

v2'nin üstüne gelir; çeliştiği yerde v3 geçerlidir. v1/v2 belgeleri silinmez.

## 0. v2 ile bilinçli çelişkiler
| Konu | v2 | v3 | Gerekçe |
|---|---|---|---|
| Materyal toplama | Enter ile yakınlık kartı | **görünce alınır** (yürüyünce otomatik), kart yalnız yaratık/yumurta/ağaç/damar için | Oyuncu isteği: malzeme için mesafe kartı gereksiz |
| Tür sayısı | 32 | **64** (biyom başına 8) | Çeşitlilik |
| Eşya | 52 | **112+** (materyal, parça, taş, esans, alet, tonik, mühür) | Simya ekonomisi |
| Yaratık işlevi | yalnız savaş | **roller**: binek, uçucu, yüzücü, kazıcı, tank, pençeli | Haritada ilerleme yaratıkla açılır |
| Harita tehlikesi | saldırgan yaratık savaş açar | **dolaşan ve pusu kuran** yaratıklar, yenilirsen kampa dönersin | Sürpriz ve risk |

## 1. Yaratık rolleri (`CreatureRole`)
`ride` · `fly` · `swim` · `dig` · `tank` · `claw` · `none`. Bir türün en çok iki rolü olur.

| Rol | Açılış seviyesi | Ne verir |
|---|---|---|
| ride | 20 | Binildiğinde hız ×(1.6–2.4), nadirlik arttıkça hızlı |
| fly | 28 | Uçuşta engel ve su yok sayılır; yalnız **boyut evresi 2** (Sv 10+) kanatlılar |
| swim | 12 | Derin su geçilebilir |
| dig | 16 | Damar anında açılır, yeraltı geçidi kullanılabilir |
| tank | 14 | Hız ×0.7, pusu hasarı ×0.5, taşıma kapasitesi +6 yuva |
| claw | 10 | Ağaç kesilebilir |

Hız: `taban × rol çarpanı × nadirlik bonusu × tonik bonusu`. Tonikler (`swift_tonic`,
`gale_tonic`) 180 saniye dünya zamanı sürer ve kayda yazılır.

## 2. Ağaç kesimi ve kaynak düğümleri
Ağaçlar dekor değil, **kaynak**: `oak` (sık), `amber` (seyrek), `ghostwood` (ender, yalnız gece),
`emberbark` (volkanik), `frostpine` (buz). Kesmek için takımda **claw** rolü olan yaratık şart;
kesilen ağaç kendi odununu + biyom esansını verir ve 300 sn sonra geri gelir. Nadir ağaçlar
bölge seviyesine göre dağılır.

## 3. Harita tehlikesi
- **Dolaşan yaratık**: saldırgan doğuşlar artık 12 m yarıçapta deterministik devriye gezer.
- **Pusu**: gece veya yüksek seviye bölgede %12 olasılıkla yaklaşırken savaş doğrudan açılır.
- **Yenilgi**: LOST sonucunda oyuncu kampa döner, takım iyileşir, çantadaki materyalin
  **%10'u** düşer (mühür ve alet düşmez).

## 4. Simya ekonomisi
- Materyal sınıfları: `plant`, `mineral`, `gem`, `part` (yaratık parçası), `essence`, `wood`.
- Yaratık parçaları yenilen yaratıktan düşer (türün elementine göre).
- Taşlar yalnız damar ve ender ağaçlardan çıkar.
- 40+ tarif: tonikler, hız tonikleri, **hareket aşısı** (`graft`), alet, mühür, iyileştirme.
- **Hareket aşısı**: bir tarif bir yaratığa havuzdan bir hareket ekler (dördüncü slotu değiştirir);
  aşı kalıcıdır, kayda yazılır ve aynı hareket iki kez aşılanamaz.

## 5. Bölge seviyeleri
Seviye bantları yükselir: çayır 1–5, orman 5–12, deniz 8–16, çöl 12–22, toprak 18–28,
buz 24–34, volkanik 30–40, alev 36–50. Seviye tavanı 50.

## 6. Arayüz
- **Profil kartı**: sol üstte, oyuncu adı düzenlenebilir (kayıtta `playerName`), unvan
  (hedeflere göre), toplanan tür sayısı, oynama süresi.
- **Takım şeridi**: yuvalar 76 → 104 px, rol rozetleri ve binek göstergesi.
- **Fantastik panel teması**: parşömen dokusu, altın çerçeve, oyulmuş başlık; çanta, simya ve
  defter paneli aynı temayı kullanır.
