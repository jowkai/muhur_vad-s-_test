# Devam notu
Başlangıç durumu: hazırlık paketi var; oyun henüz oluşturulmadı. İlk görev G00.
Gerçek ilerleme engine tarafından .loop/state.json içine yazılır; bu dosya başarı otoritesi değildir.
Oturum başında AGENTS.md, verilen düğüm, ilgili skill ve context belgelerini oku.
Sabit kararlar docs/DECISIONS.md; oyun kanıtı .loop/evidence; node kanıtları .loop/NODE/ATTEMPT.
Test edilmemiş ekranı/performansı bu dosyaya bitmiş olarak yazma.
