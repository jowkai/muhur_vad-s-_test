# Katmanlar ve veri akışı

| Modül | Sorumluluk | Yasak bağımlılık |
|---|---|---|
| src/contracts | VecXZ, input, world/battle event, save port, item/tür kimlikleri | Three.js veya DOM import |
| src/world | seed terrain, collision, movement, discovery, encounter | UI panelini doğrudan açmak |
| src/render | Three.js scene/camera/chunks/resources | mesh konumunu authoritative gameplay state saymak |
| src/game/combat | saf battle reducer, RNG ve komutlar | animasyon callback'inden ödül vermek |
| src/game/save | IndexedDB transaction, version, ledger, migrations | partial overwrite/sessiz reset |
| src/content | katalog, tarif, toplama/üretim ve camp use | ayrı savaş formülü |
| src/ui | HUD, SVG, battle/inventory/alchemy DOM | doğrudan HP veya inventory değiştirmek |
| src/app | yaşam döngüsü, event routing, input ownership | diğer katmanların iş kuralını çoğaltmak |

Boot → LoadSave → Exploring ↔ Panel → EncounterIntro → Battle → CommitOutcome → Exploring.
Commit başarısızsa Recovery durumunda kal; dünya kilidi açılmaz, aynı transaction tekrar denenir.
Oyun tek bir command bus ile eylem alır. UI intent gönderir, domain event üretir, adapter save eder,
renderer snapshot tüketir. Böylece aynı seed ve komut kaydı baştan oynatılabilir.

## Ortak sözleşme taslakları
```ts
type GameMode = 'boot'|'exploring'|'panel'|'encounter'|'battle'|'committing'|'recovery';
type BiomeId = 'meadow'|'forest'|'earth'|'desert'|'sea'|'ice'|'volcanic'|'flame';
interface VecXZ { x: number; z: number }
interface NearbyTarget {
  entityId: string; kind: 'egg'|'creature'|'resource'; name: string;
  spriteId: string; distance: number; level: number; interactionAllowed: boolean;
}
interface GameCommand { commandId: string; tick: number; type: string; payload: unknown }
interface SavePort {
  load(): Promise<unknown>;
  transact(commandId: string, mutate: (draft: unknown) => void): Promise<unknown>;
}
```
Bunlar uygulama kodu değil, G01'in ayrıntılı discriminated-union ve şema ile somutlaştıracağı sınırlardır.
SavePort transaction callback'inde ağ veya await yapılmaz; IndexedDB transaction aktifliği korunur.
Kullanıcı girdisi transaction commit olduktan sonra görsel event'e çevrilir; commandId tekrarında
önceki sonuç dönülür. Yazma hatasında komple önceki durum geri yüklenir.

## Save şeması
version, generatorVersion, seed, rngStreams, playerPosition, discoveredCells, consumedEntityIds,
creatureInstances, activeCreatureId, inventory, deliveryBox, eggs, secretFlags, battleState,
rewardLedger ve appliedCommands birlikte sürümlenir. IndexedDB single transaction store sınırı
gerçek browser testinde doğrulanır. Kota/bozuk save için export/retry; otomatik veri silme yok.
Offline süre kuluçka ilerletmez. Sekme gizliyken simülasyon durur.

## Test katmanları
Vitest: saf domain/seed/mapping/formüller. Fake IndexedDB yardımcı test + gerçek browser transaction testi.
Playwright: WebGL görünüm, klavye ve panel/savaş yolları. Fiziksel cihaz: performans rotası.
Test runner boş test kümesini fail eder. Setup testleri gelecekteki oyun testlerinin yerine geçmez.
