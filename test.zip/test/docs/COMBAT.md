# Mühür Vadisi — Savaş, yakalama ve ilerleme sözleşmesi

Bu belge uygulama hedefidir; uygulanmış veya test edilmiş özellik iddiası değildir. TypeScript saf çekirdek Three.js ve DOM'dan bağımsızdır. Grafik animasyonları yalnızca çekirdeğin ürettiği olayları gösterir.

## Model ve görünüm

`BattleState`: version, battleId, encounterId, phase, turn, rngState, playerCreatureId, enemy, playerHp, enemyHp, stamina, enemyStamina, status, inventorySnapshot, committedActions, outcome. Fazlar: `INTRO`, `PLAYER_INPUT`, `RESOLVE_PLAYER`, `RESOLVE_ENEMY`, `TURN_END`, `WON`, `CAPTURED`, `LOST`, `FLED`. Terminal fazlardan işlem alınmaz. Savaşta tek aktif dost ve tek rakip bulunur; takım değiştirme ilk sürüm dışındadır.

Ekranda kendi yaratığımız sol altta sırt silüetiyle; rakip sağ üstte ön görünümle yer alır. İki SVG aynı türün aynı renk, boynuz, kanat ve kuyruk özelliklerini korur. Üstte ad, seviye, HP; altta dört saldırı, ayrı Yakala ve Kaç düğmesi, kısa olay günlüğü bulunur. Animasyon sırasındaki düğmeler kilitlenir. Hareket ve dünya etkileşim girdileri savaş açıkken tüketilmez. Klavye 1–4 saldırı, C yakala, Escape kaç; Enter yalnızca dünya karşılaşma panelini açar, saldırıyı tetiklemez.

## Deterministik çözüm

Bütün zarlar sürümlenmiş xorshift32 PRNG ile çekirdek içinde üretilir. Sıfır seed `0x6d2b79f5` olur. Her adımda unsigned 32-bit olarak `x ^= x << 13; x ^= x >>> 17; x ^= x << 5`; `u=(x>>>0)/4294967296`. Görsel efektler ayrı rastgele kaynak kullanır. Komut id'si daha önce uygulanmışsa durum değişmeden önceki sonuç döner. Geçersiz komut RNG, envanter veya turu değiştirmez. Geçerli saldırı tam iki zar tüketir: isabet ve hasar değişkenliği; ıskalamada da ikinci zar tüketilir. Yakalama ve kaçma birer zar tüketir. AI hareket seçimi zar tüketmez.

HP statı `18 + baseHp + 4*level`; saldırı `baseAtk + 2*level`; savunma `baseDef + level`. Başlangıç türleri baseHp 6–12, baseAtk 3–6, baseDef 2–5 aralığındadır. Başlangıç dostu level 2; güvenli başlangıçta yumurtalar ve level 1–2 yaratıklar bulunur.

Dört slot: Dokunuş (power 8, accuracy .98, cost 0), Element Darbesi (power 14, accuracy .90, cost 2), Siper (power 0, cost 1; bir sonraki alınan vuruşu .5 ile çarpar, sonraki oyuncu turunda silinir), Yıldız Atımı (power 22, accuracy .78, cost 4). Stamina başlangıç ve üst sınırı 5, her TURN_END +1. Yetersiz stamina düğmeyi devre dışı bırakır ve çekirdek komutu reddeder. Düşük seviye düşman level 1–2 yalnız Dokunuş ve Siper kullanır. Level 3–5 Element Darbesi, 6+ Yıldız Atımı açar. Dost başlangıçta dört slotu görür, henüz açılmayanlar seviye koşuluyla kilitlidir.

Hasar `max(1, floor(((power + attackerAtk) * 10 / (10 + defenderDef)) * elementMultiplier * (.90 + .20*uDamage) * guardMultiplier))`. Hasar HP'yi sıfırın altına indirmez. Kritik vuruş ilk sürümde yoktur. Döngü avantajı: çim > su > kor > çim; avantaj 1.25, ters yön .80, diğerleri 1.00. Buz, taş ve gölge birbirine nötrdür. Element ve güç tür verisidir; UI kopyası formül içermez.

Oyuncu geçerli eylemden sonra rakip HP sıfırsa doğrudan WON olur. Aksi halde rakip cevap verir. Rakip AI: kendi HP oranı <.3 ve önceki eylemi Siper değilse, stamina uygunsa Siper; değilse açılmış ve karşılayabildiği en güçlü saldırı, eşitlikte sabit slot sırası. Rakip eyleminden sonra dost HP sıfırsa LOST; aksi halde TURN_END ve PLAYER_INPUT. Her tarafın siper süresi açıkça kendi sonraki eylemi başında sona erer; Siper seçimi yeniden kurar.

## Yakalama, yumurta, kaçış

Yakala için rakip canlı, vahşi/yakalanabilir, HP oranı <=.35, envanterde en az bir Mühür ve takımda ya da depoda boş yer gerekir. Olmayan koşul zar ve eşya tüketmeden açıklanır. Geçerli deneme bir Mühür tüketir; `p=clamp(.20 + .60*(1-hp/maxHp) + .015*(playerLevel-enemyLevel) - rarityPenalty, .10, .85)`. Nadirlik cezası common 0, uncommon .10, rare .20. `u<p` başarıdır. Başarı CAPTURED ve tekil yaratık kaydı üretir; başarısızlık rakip turunu başlatır. Bayılmış rakip yakalanamaz; HP göstergesindeki %35 işareti bu riski anlatır.

Dünya yumurtası savaş başlatmaz. Yakınlık panelinde Al eylemi atomik olarak encounterId'yi tüketip tekil yumurta itemi ekler. Boş kapasite yoksa yumurta dünyada kalır. Yumurtanın tür/seed'i doğarken sabittir; yeniden yükleyerek değiştirilemez. Kuluçka güvenli kampta 120 saniye aktif dünya oyunu + 1 Isı Otu ile tamamlanır; pause/offline süre ilerletmez. Çatlama eşya silme ve yaratık eklemeyi aynı işlemde yapar. Erken yumurta level 1 common yaratık verir.

Kaçış normal vahşide `p=.75`, saldırgan karşılaşmada `.45`; başarısızlık rakip cevabı, başarı FLED. Başarıda encounter 8 saniye tekrar tetiklenmez; dünya konumu güvenli son yürünebilir noktadır. WON/CAPTURED karşılaşmayı kalıcı tüketir; LOST oyuncuyu kampa taşır, aktif yaratığı tam iyileştirir, ödül vermez; saldırgan karşılaşma 30 saniye soğumaya girer. İlk sürüm yenilgi eşya kaybettirmez.

## XP ve ödül işlemi

Bir sonraki seviyeye gereken XP `20 + 10*level + 5*level*level`. XP seviye içi bakiyedir; aşınca gereksinim düşülür, level artar, üst sınır 30. Level artışında maxHP farkı mevcut HP'ye eklenir; bayılmış yaratık ancak kamp iyileşmesinde canlanır. WON XP `10 + 6*enemyLevel`; CAPTURED XP bunun `floor(.60*xp)` değeri, aktif dosta gider. Kaybetme/kaçış XP vermez. Seviye 5 ve 10'da kozmetik evrim görünümü açılır; tür kimliği ve birey id'si değişmez.

Loot tablosu karşılaşma yaratıldığında seed'den belirlenir, savaş yeniden yüklemelerinde yeniden atılmaz. Common zafer 1 habitat malzemesi; saldırgan zafer buna +1 element özü ekler. Sır parçası düşüşü karşılaşma yaratılışında .10 şans, tekil `secretId`; bulunmuş sır tekrar bilgi açmaz, yerine 1 öz verir. Yakalama savaş loot'u vermez; yaratık ve XP verir. Envanter doluysa ödüller kaybolmaz, kalıcı kamp teslim kutusuna gider.

Terminal sonucu `rewardLedger[battleId]` ile aynı IndexedDB transaction içinde savaş, yaratık, karşılaşma ve envantere işlenir. Çift tıklama, retry ve reload ödülü çoğaltamaz. Başarılı transaction sonrası görsel zafer sayfası gösterilir. Yazma hatasında önceki durum korunur, tekrar dene görünür; dünya hareketi açılmaz. Her geçerli komut transaction commit edilince animasyona geçirilir; reload kayıtlı çözümlenmiş durumu gösterir, animasyonu atlayabilir. Şema migrasyonu bilinmeyen sürümü sessizce sıfırlamaz; dışa aktarma ve açıklayıcı hata verir.

## Kabul kanıtları

- Aynı seed + 100 komut dizisi aynı final snapshot ve olay dizisini verir; görsel FPS sonucu etkilemez.
- HP eşikleri: .3500 yakalama izinli, .3501 reddedilir, sıfır HP reddedilir; red durumunda seed ve Mühür sayısı sabit.
- Sabit zarlar p−epsilon, p ve p+epsilon için yalnız ilk başarı; başarısızlık tam bir rakip turu üretir.
- Saldırı/yenilgi/capture sonrası terminalden ikinci eylem HP ve XP değiştirmez; son vuruşta rakip cevap vermez.
- 50 kez aynı commandId ve battleId yeniden işlenince tek Mühür tüketimi, tek ödül ve tek yaratık kaydı kalır.
- Transaction her yazma adımında fault injection ile kesilir: yükleme tamamen önce veya tamamen sonra durumunu görür.
- Bir ödül çoklu seviye atlatır, kalan XP doğru; seviye 30 aşılmaz; düşük seviyeli düşman kilitli hareket kullanmaz.
- Playwright: dünya → Enter → savaş → dört slot → zayıflat → yakala → dünya. Kapalı slotlar, dolu depo, kaçış, yenilgi ve reload ayrı akışlarla kanıtlanır.
