# Kararlar ve çelişki çözümü

| ID | Kabul edilen karar |
|---|---|
| D01 | Proje adı Mühür Vadisi; seed `wildseal-01` teknik kararlı kimliktir. |
| D02 | 2048m kare XZ dünya, 64m chunk, 2m hücre; 8 makro biyom. |
| D03 | 5×5 aktif görsel (25), 3×3 simülasyon (9); en fazla 24 ek cache ile resident üst sınırı49. |
| D04 | Sabit1/60s, max5 substep, frame delta en fazla5/60s. |
| D05 | Minimap kuzey yukarı,192 px (dar ekranda144),96m yarıçap; büyük portre UI'de. |
| D06 | Kamp40m aggro güvenli; kamp yaratıkları1–2, çayırın dış kısmı1–3. |
| D07 | Genel dönüş koruması3s; kaçılan aynı encounter8s, yenilgide aynı düşman30s cooldown. |
| D08 | Yakalama formülü/XP/RNG için COMBAT.md otoritedir; content combat formülü eklemez. |
| D09 | 4 slot görünür; güçlü slotlar seviyeye bağlı kilitli. Siper savunma eylemidir. |
| D10 | Biome IDs: meadow,forest,earth,desert,sea,ice,volcanic,flame; Türkçe ad yalnız gösterim. |
| D11 | Isı Otu=`heat_herb`, Mühür=`seal`. Tam8 simya tarifi MVP; kamp-only etkiler CONTENT.md. |
| D12 | Denizde başlangıçta kıyı erişimi var; derin su geçilmez. Yüzme/multiplayer/gerçek zamanlı MOBA combat yok. |
| D13 | UI savaşı U02'nin işi; combat rolü reducer/transition adapter üretir, aynı paneli iki rol yazmaz. |
| D14 | Referans hedef M1 8GB1440×900,DPR<=1.5,3×120s, p95<=20ms,p99<=33.4ms,draw<=150,tri<=300k. |
| D15 | Başka donanım raporu ayrı sonuçtur. Referans koşulu ölçülmeden performance gate pass olmaz. |
| D16 | Paket7 rol içerir; CLI motoru rolleri sırayla çalıştırır. Eşzamanlı worktree scheduler dahil değil. |

Biyom şifreleri ve sır parçaları keşif ödülleridir. P1: suda hareket, hava olayları, ilave evrim
ağaçları; temel8 biyom/16 tür/8 tarif bunları beklemeden tamamlanır.
Uzman belgeleri arasında ölçü veya ad farkı kalırsa bu karar tablosunu uygula ve farkı raporla.
