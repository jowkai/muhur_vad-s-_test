# Dünya sözleşmesi — Mühür Vadisi

Bu belge uygulama hedefidir; aşağıdaki kabul koşulları çalıştırılmadan özellikler tamamlandı sayılmaz. Dünya agent'ı dünya verisi, hareket ve karşılaşma seçiminden sorumludur; çizim render agent'ına, panel ve etkileşim UI agent'ına aittir.

## Koordinatlar ve deterministik üretim

- Oynanabilir alan: 2.048 × 2.048 metre; düzlem XZ, Y yükseklik; merkez (0,0). Seed, generatorVersion ve saveVersion kayıt altında tutulur. İlk sürüm seed `wildseal-01`.
- Chunk: 64 × 64 metre; toplam 32 × 32 chunk. Hücre: 2 metre. Görsel chunk yükleme çevresi ve simulation çevresi ayrıdır: oyuncunun bulunduğu chunk etrafında görsel 5×5, etkin simulation 3×3. Kenarlarda alan kırpılır.
- Rastgelelik, global sıralı random çağrısına bağlı değildir: `hash(seed, subsystem, chunkX, chunkZ, entityIndex)`. Chunk yükleme sırası dünyayı değiştirmez. Savaş RNG ayrı akıştır.
- Terrain verisi: height, biomeId, traversable, hazard, regionId. Entity kimlikleri seed+chunk+index ile kararlıdır. Toplanan item ve yakalanan yaratık tombstone kaydıyla yeniden doğmaz; respawn ayrıca oyun zamanı ile yönetilir.

## Birbirine bağlı biyomlar

Renk tek başına bilgi taşımaz: her biyom farklı siluet, zemin deseni, isim ve minimap simgesi taşır. Yaklaşık kara/su hedefleri aşağıdadır; oranlar üretim hedefidir, her seed için yüzdeye zorlanan doğrulama değildir.

| Bölge | Pay | Görünüm | Oyun rolü |
|---|---:|---|---|
| Şafak Çayırı | %22 | Açık yeşil, kısa çimen, çiçek kümeleri | Güvenli başlangıç, yumurtalar, seviye 1–3 |
| Fısıltı Ormanı | %18 | Koyu yeşil, yoğun ağaç kümeleri | Otlar, gizli yollar, seviye 3–8 |
| Kehribar Çölü | %13 | Altın kum, dalga dokusu | Mineraller, gündüz tehlikesi, seviye 6–12 |
| Mercan Kıyısı / Deniz | %15 | Turkuaz kıyı, mavi derin su | Kıyı itemleri; derin su ilk sürümde kapalı |
| Akbuz Yaylası | %10 | Beyaz/mavi, çatlak buz ve kristaller | Buz yaratıkları, seviye 10–18 |
| Paslı Kanyon | %10 | Kahverengi katmanlar, kuru kayalar | Simya cevheri, seviye 8–16 |
| Gecebazalt | %8 | Lacivert/siyah bazalt, mor damarlar | Nadir kaynaklar, seviye 15–23 |
| Kor Çanağı | %4 | Kırmızı/turuncu lav, duman | Son bölge; ateş lekeleri, seviye 20–30 |

Biyomlar hücre başına bağımsız rastgele renkler değildir: sabit makro bölge merkezleri, düşük frekanslı sınır sapması ve nem/sıcaklık alanları kullanılır. Çöl kıyıya, buz kuzey yükseltisine, lav bazaltın içine yerleşir. Bölge sınırlarında 12–24 m geçiş şeridi bulunur. Tasarlanmış ana yollar ve köprüler üretimden sonra carve edilir. Başlangıç kampından bütün kara bölgesi girişlerine yürünebilir yol flood-fill ile kanıtlanır. Deniz adaları ilk sürümde dekor veya köprüyle bağlıdır; ulaşılamaz adaya görev hedefi konmaz.

## Hareket ve takip kamera sözleşmesi

WASD / yön tuşları kamera düzleminde hareket eder. Çapraz vektör normalize edilir; tuş sayısı hızı artırmaz. Oyun simulation'ı sabit 1/60 sn adımla ilerler; frame birikimi en fazla 5 adıma kırpılır. Sekme geri geldiğinde teleport oluşmaz. Dünya sınırı, ağaç gövdesi, kaya ve derin su karakter kapsülü/daire yaklaşımı ile engellenir; duvar boyunca kayma desteklenir. Kamera yüksekten eğimli ortografik görünüm kullanır; hedef konum oyuncu+bakış ötelemesidir. Takip yumuşatma frame hızından bağımsız exponential damping kullanır. Savaş, panel odaklı metin girişi ve pause durumunda dünya hareketi kapalıdır. Simülasyon kamera koordinatlarına bağlı değildir.

## Yakınlık ve karşılaşma

Spatial hash en yakın chunk komşularını sorgular; her frame tüm dünya yaratıkları taranmaz. Görünür yakınlık 24 m, etkileşim 6 m, düşman aggro 10 m. Uzaklaşma eşiği etkileşim için 8 m (histerezis). Seçim: erişilebilir etkileşim hedefi, ardından mesafe, ardından kararlı entityId. Engel arkasındaki hedefle savaş başlatılmaz. Tek bir `nearbyTarget` olayı UI'ya gider; payload entityId, kind, name, spriteId, distance, level, interactionAllowed alanlarını taşır. UI büyük SVG portresini, ismini ve Enter ipucunu gösterir; minimap aynı hedefi vurgular.

Yumurta doğrudan toplama paneli açar; vahşi yaratık Enter ile savaşa geçer. Saldırgan yaratık önce 1,2 sn uyarı verir, güvenli başlangıç yarıçapında aggro oluşturmaz. Tek karşılaşma kilidi aynı anda iki savaş açılmasını önler. Savaş dönüşünde 3 sn aggro bağışıklığı vardır. Kaçış oyuncuyu son güvenli konuma getirir. Yakalanan/yenilen hedef dünya state'inden atomik kaldırılır; save işlemi aynı sonuca iki kez ödül veremez.

## Dairesel minimap

Sol alt köşede kuzey-yukarı, dairesel 192 CSS px harita (dar ekranda 144 px). Arazi düşük çözünürlüklü atlas olarak chunk değişiminde güncellenir; işaretçiler en fazla 10 Hz güncellenir. Oyuncu merkezde yön oku; 96 m görüş yarıçapı; yalnız keşfedilmiş alan ve algılama yarıçapındaki yaratık/yumurta görünür. Daire dışı işaretçiler kırpılır. Konum dönüşümü x ekran-sağ, z ekran-aşağı sözleşmesini kullanır ve birim testlidir. İkonlar yumurta, sakin yaratık, saldırgan yaratık ve kaynak için biçimle ayrılır. UI agent'ı çerçeve/tooltip'i; render agent'ı atlas üretimini; dünya agent'ı keşif ve işaretçi verisini sağlar.

## Performans ve kanıt

60 FPS masaüstü hedefi, mobilde 30 FPS hedefi ölçüm olmadan başarı sayılmaz. Render agent'ıyla paylaşılan hedefler: etkin sahne draw calls ≤150, görünür triangles ≤300k, 120 sn sabit rota sonunda GPU kaynak sayılarında sürekli büyüme yok. Bunlar başlangıç bütçeleridir; ölçülen cihaz, viewport ve DPR raporlanır. Dünya query p95 ≤2 ms ve simulation p95 ≤4 ms hedefi aynı kayıtlı rotada ölçülür. CI headless CPU süreleri GPU/FPS kanıtı yerine geçmez.

Zorunlu testler: 20 sabit seed için başlangıç güvenliği, bütün zorunlu bölge girişlerinin bağlılığı, seed tekrar üretimi, chunk sırası bağımsızlığı, sınır çarpışması, çapraz hız, pause/sekme geri dönüşü, hedef seçim histerezisi, çift encounter kilidi, yakalanan yaratığın reload sonrası kaybolması, minimap dört yön ve clipping doğruluğu. Her gate exit code ve makine okunur rapor üretir; henüz yazılmamış test başarı değildir.
