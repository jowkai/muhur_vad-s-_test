# Gauntlet: kanıtla ilerleyen oyun geliştirme döngüsü

Bu paket çalışan bir oyun değildir. Aşağıdaki puanlar hedeflerdir; gerçek oyun puanı test kanıtı gelene kadar `NOT_MEASURED` kalır.

## Kontrol sırası

1. Girdi sözleşmelerini ve graph bağımlılıklarını doğrula. Task sahibi değiştirilen dosyaları, beklenen davranışı ve riskleri kaydeder.
2. Temiz checkout üzerinde lockfile ile bağımlılıkları kur; typecheck, lint, unit ve production build çalıştır. Çıkış kodu, tam komut, süre ve HEAD commit kaydedilir.
3. Sabit seed testleri ve özellik testleri çalıştır. Başarısız seed aynen yeniden çalıştırılır; başarısızlığı gizlemek için seed veya test kaldırılmaz.
4. Tarayıcıda gerçek WebGL renderer ve klavye etkileşimlerini test et. Sentetik DOM başarılı olması oyun render kanıtı değildir.
5. Bağımsız QA agent değişiklik ve kanıtları inceler. Kod yazan agent kendi çıktısını onaylayamaz.
6. `score.py` kanıtları doğrular. Eksik / yanlış commit / başarısız hard gate sonucu yayın engellenir. En fazla üç düzeltme denemesi; sonra blocked ve teşhis raporu.

## Zorunlu hard gates

- `build`: temiz kurulum, typecheck ve production build başarılı.
- `world_safety`: tüm test seedlerinde spawn yürünebilir, spawn çevresinde başlangıç bölgesi bağlıdır; karakter su, lav veya katı engel içinden geçemez; NaN konum üretilemez.
- `battle_integrity`: HP sınırları, tek turda tek aksiyon, yakalama olasılığı sınırları, savaş sonu ödülünün bir kere verilmesi.
- `save_integrity`: versiyonlu save roundtrip; bozuk save kontrollü hata; eski sürüm migration; item/XP çoğaltma yok.
- `browser_smoke`: gerçek WebGL ekranı, hareket, yakınlık imleci, Enter karşılaşması, dört saldırı, yakalama, panel aç/kapat, save-load doğrulanır.
- `performance`: aşağıdaki sabit cihaz protokolünde hedefler geçilir; cihaz bilgisi eksikse geçmez.

## Dünya / harita kanıtları

- Seed listesi: 1, 7, 42, 137, 2026; ayrıca en az 100 sabit PRNG seed ile property test. Ölçülen seed ve parametreler raporda yer alır.
- Çim, sık orman, çöl, deniz, buzul, kahverengi kaya, lacivert volkanik zemin ve ateş bölgeleri ayrı biyom kimlikleridir. Hücrelere rastgele renk serpmek bölge testi değildir: connected-component alanı ve komşuluk kuralları denetlenir.
- Harita boyutu, chunk boyutu ve encounter mesafesi konfigürasyonda açıkça belirtilir. Başlangıç yumurtaları erişilebilir; yüksek seviye düşmanlar spawn güvenlik yarıçapında oluşamaz.
- Chunk sınırı geçişinde collider ve terrain sürekliliği, boşluklar, dispose edilen GPU kaynakları ve yeniden yükleme test edilir.
- En az 20 seed'de bağlantılı başlangıç alanı; chunk yükleme sırası değişse de aynı seed aynı dünya üretir. Toplanan item/yumurta ve yakalanan yaratık unload/reload sonrası geri doğmaz. Encounter aynı anda yalnızca bir kere açılır; pause sırasında simülasyon durur.
- Minimap world→map→world dönüşümü bilinen köşe / merkez koordinatlarında tolerans içinde roundtrip yapar. Dairesel clipping, kuzey yönü, oyuncu işareti, yakın yaratık/ yumurta işareti, isim ve büyük SVG kartı ayrı testtir. Uzak encounter kartı görünmez.
- Kamera oyuncuyu takip eder, yumuşak takip frame-rate bağımsızdır. WASD ve oklar; diagonal hız normalizasyonu; panel açıkken hareket girdi politikası test edilir.

## Savaş / envanter kanıtları

Oyuncu yaratığı arkadan, rakip önden görünür. Dört saldırının isim, hasar/etki ve cooldown/enerji davranışı ayrı ölçülür. Düşük HP yakalama şansını arttırır; chance [0,1] içinde kalır. Seed kontrollü Monte Carlo sonucu formül toleransını doğrular. Yakalama garantisi varsayılmaz. Yenilgi, kaçış, çanta doluluğu ve çift Enter test edilir.

Grid envanter: stacking üst sınırı, transfer, item açıklaması, filtre ve klavye kapanışı. Simya işlemi malzemeleri atomik tüketir; başarısız tarif hiçbir şey tüketmez. XP eşikleri, seviye atlama, yumurta açılma ve sır ödülleri save roundtrip sonrası korunur.

İçerik hard gate'lerin kapsamına dahildir: 8 biyom kimliği, en az 16 farklı yaratık ve 24 farklı toplanabilir item veri şemasında geçerli benzersiz kimliklere sahiptir. SVG dosya referansları çözümlenir, yaratıklar biyom/level tablosuna bağlıdır; eksik sayılar ilgili world_safety veya battle_integrity gate'ini başarısız yapar. Sadece ad varyasyonu işlevsel tür çeşitliliği sayılmaz.

## Tarayıcı ve performans protokolü

Kanıt `device.json`: CPU, GPU, RAM, OS, tarayıcı tam sürüm, WebGL renderer string, ekran, viewport, DPR, güç modu, commit, seed ve quality ayarlarını içerir. Hedef referans cihaz **önce** seçilir; ölçümden sonra daha güçlü cihazla sonuç değiştirilmez.

Referans cihaz hedefi: Apple M1, 8 GB RAM. Referans koşul: 1440×900 viewport, DPR üst sınırı 1.5, foreground sekme, production build, 10 saniye ısınma ardından aynı 120 saniye kayıtlı rota. Çim→orman→çöl→buzul→volkan rotası, bir battle ve panel açılması. Üç bağımsız koşu; her koşuda p95 frame time ≤ 20 ms, p99 ≤ 33.4 ms hedeflenir. Draw call ≤150, triangles ≤300.000, aktif chunk ≤25, cache toplamı ≤49, frame başına simulation substep ≤5. FPS ortalaması tek başına geçiş sağlamaz. Context loss ve uncaught error sıfır. Beş dünya turundan sonra aktif geometry/texture sayısı başlangıç steady-state değerine dönmelidir (önceden tanımlı cache bütçesi hariç). Kullanıcının farklı cihazındaki sonuçlar ayrı raporlanır; referans cihaz gate'i yerine geçmez.

Headless / yazılımsal GPU sonuçları fonksiyonel kanıttır; referans cihaz performans sonucu yerine kullanılamaz. Native Chrome/Chromium üzerinde ölçüm gerekir. GPU olmayan ortamda gate `NOT_MEASURED` kalır.

World modülü profil hedefleri aynı rotada spatial query p95 ≤ 2 ms, simulation tick p95 ≤ 4 ms. Dünya node'larının alt gate'leri (`world-generation`, `connectivity`, `movement`, `collision`, `encounters`, `minimap-data`, `lifecycle`, `persistence`, `performance`) ilgili üst hard gate altında raporlanır; bir alt testin başarısızlığı üst gate'i de başarısız yapar.

Ekran görüntüleri: başlangıç spawn, her biyom, dairesel minimap, yakın encounter kartı, battle, inventory, alchemy, yumurta açılma. Viewport/seed sabitlenir; screenshot varlığı yeterli değildir, clipping/kontrast/arkadan görünüş QA tarafından incelenir ve not yazılır.

## Kanıt dosyası

`evidence.json`: `commit`, `source_sha256`, `gates`, `criteria`. `source_sha256`, engine.snapshot(root) içeriğinin deterministik digest değeridir; commit edilmemiş kaynak değişikliklerini de bağlar. Kaynak fingerprint eşleşmez veya eksikse FAIL ve puan null. Her gate `{status: "PASS"|"FAIL"|"NOT_MEASURED", artifacts:["relative/report.json"]}`; her kriter `{score:0..100, artifacts:[...], rationale:"ölçülen sonuç"}`. Bütün yollar evidence dosyasının dizinine göre çözülür. Dosyalar commit ve kaynak fingerprint'e bağlı CI/QA üretimi olmalıdır; scorer dosya varlığını kontrol eder, testlerin dürüstlüğünü tek başına kanıtlayamaz. QA imzası / CI kaynağı ayrıca incelenir.

Çalıştırma: `python3 qa/score.py --evidence artifacts/evidence.json --commit <HEAD> --source-sha256 <CURRENT_SOURCE_SHA256>`. `qa/score_current.py` entegrasyonu mevcut HEAD ve kaynak fingerprint'ini otomatik hesaplayabilir. Yukarıdaki protokol uygulanacak kabul planıdır; bu tasarım paketinde canlı oyun veya temiz checkout build'i çalıştırıldığı anlamına gelmez.
