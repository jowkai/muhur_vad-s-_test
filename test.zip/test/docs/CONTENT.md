# Mühür Vadisi — içerik sözleşmesi

Özgün yaratık toplama oyunu. Dünya bir zamanlar simya bahçesiydi; kayıp bahçıvanların işaretleri bölgelerde tarif parçaları bırakır. Oyuncu yaratıkları tüketmez: mühürle bağ kurar, yumurtaları mesafe ve bakım ile açar. Savaşlar ölüm yerine bayılma ile biter. Tasarım sayıları ilk dengeleme hedefidir; oynanış testiyle doğrulanmadan kalite kanıtı sayılmaz.

## Sekiz biyom ve ilerleme

| ID | Bölge | Görünüm ve dolaşım | Önerilen seviye | Kimlik / sır |
|---|---|---|---|---|
| meadow | Şafak Çayırı | Yeşil çim, açık patikalar, güvenli merkez | 1–4 | İlk mühür sunağı; eğitim burada |
| forest | Fısıltı Ormanı | Sık orman, çimen adaları; ağaç kümeleri arasında yollar | 3–7 | Üç taşın yönü gizli tarifi açar |
| earth | Paslı Kanyon | Kahverengi toprak, kademeli kayalar, köprüler | 5–10 | Terk edilmiş simya ocağı |
| desert | Kehribar Çölü | Kum tepeleri, kurumuş su yolları | 8–13 | Gölge sütunlarının sırası |
| sea | Mercan Kıyısı | Deniz, sığ kıyılar, adalar; derin su başlangıçta engel | 10–16 | Köpük şişesinde tarif parçası |
| ice | Akbuz Yaylası | Beyaz buzul, mavi çatlaklar; kayganlık kontrollü | 13–19 | Buz altında çan |
| volcanic | Gecebazalt | Lacivert bazalt, soğuk lav, kristaller | 16–23 | Dört rezonans taşı |
| flame | Kor Çanağı | Alev cepleri ve siyah toprak; güvenli taş yollar | 20–28 | Bahçıvanın son mührü |

Volkanik bölge katı bazalt ve minerallerle; alev bölgesi etkin sıcaklık ve köz bitkileriyle ayrılır. Biyomlar gürültüyle rastgele serpiştirilmez: bitişik geniş bölgeler, geçiş şeritleri, yeniden üretilebilir tohum ve geçilebilir bağlantılar gerekir. Başlangıç bölgesinden tüm diğer bölgelere bir kara yolu veya açıkça tanımlı açılabilir geçit bulunur.

## Yaratık kataloğu

Tablodaki baseHp / baseAtk / baseDef, COMBAT.md formüllerine verilen taban statlardır. JSON kataloğu aynı değerleri taşır. `common` sık, `uncommon` seyrek, `rare` ender anlamına gelir. Her biyomda yerel yumurta görünümü vardır; açılacak tür yumurta üretilirken kayda alınır. Eğitim yumurtası deterministik olarak Çiytomur verir.

| ID | Ad | Biyom / element | Nadirlik | baseHp / baseAtk / baseDef | Siluet ve karakter |
|---|---|---|---|---|---|
| dewbud | Çiytomur | meadow / çim | common | 8 / 4 / 3 | Dört kısa kök bacak, tek eğri yaprak; ürkek |
| puffkip | Pufçıt | meadow / rüzgâr | common | 8 / 4 / 3 | Üç loblu tüylü tohum, ince kuyruk; meraklı |
| mossbell | Yosunçan | forest / çim | common | 12 / 7 / 5 | Çan gövdeli yosun canlısı, iki dal kol |
| twigveil | Dalörtü | forest / gölge | uncommon | 12 / 7 / 5 | Asimetrik yaprak pelerini, üç ince ayak |
| pebblenib | Çakıldiş | earth / taş | common | 12 / 7 / 5 | Yassı taş gövde, küçük kazıcı burun |
| coppercoil | Bakırtel | earth / kıvılcım | uncommon | 12 / 7 / 5 | Yay biçimli bakır kabuk ve dört pençe |
| duneear | Kumkulak | desert / taş | common | 12 / 7 / 5 | Yelken kulaklı altı ayaklı çöl canlısı |
| mirrormoth | Serapul | desert / ışık | rare | 12 / 7 / 5 | Katlı cam kanatlar, damla gövde |
| shellwisp | Sedefiz | sea / su | common | 12 / 7 / 5 | Spiral değil yelpaze kabuk, iki yüzgeç |
| tideknot | Gelgitdüğüm | sea / su | uncommon | 12 / 7 / 5 | Düğüm biçimli şerit beden, inci organ |
| snowspool | Karyumak | ice / buz | common | 12 / 7 / 5 | Yassı kar yumağı, kristal kaşlar |
| frostchime | Buztını | ice / buz | rare | 12 / 7 / 5 | Asılı üç buz çanı, küçük gövde |
| basaltpup | Bazaltık | volcanic / taş | uncommon | 12 / 7 / 5 | Altıgen sırt plakalı alçak dört ayaklı |
| indigospark | Lacikıvıl | volcanic / kıvılcım | rare | 12 / 7 / 5 | İki dönen halka arasında kristal çekirdek |
| emberpod | Közkapsül | flame / kor | uncommon | 12 / 7 / 5 | Üç yarıklı sıcak tohum kabuğu |
| ashcrown | Kültaç | flame / kor | rare | 12 / 7 / 5 | Geniş kül yaka, üç ayak, alçak kor tacı |

## Savaş verisinin sahibi

Stat formülleri, hareket slotları, açılma seviyeleri, stamina, yakalama, XP ve kuluçka için **COMBAT.md tek otoritedir**. Bu belge bunları yeniden tanımlamaz. Element görsel etiketleri rüzgâr, ışık ve kıvılcım ilk sürümde nötrdür; çim/su/kor döngüsü dışındaki tüm etkileşimler nötrdür. Tür tekniği adları ileriki sürüm için yalnız görsel öneridir; ilk sürüm dört standart combat hareketini kullanır.

## Eşya kataloğu

Tüm ID'ler kalıcıdır. Materyaller 99; sarf malzemeleri 20; anahtar eşyalar 1 yığın sınırına sahiptir. Aşağıdaki 24 materyal ve 8 ürün birbirinden farklıdır.

| Biyom | Sık materyal | Seyrek materyal | Ender materyal |
|---|---|---|---|
| meadow | dew_leaf: Çiy Yaprağı | soft_seed: Yumuşak Tohum | amber_drop: Kehribar Damlası |
| forest | moss_thread: Yosun İpliği | echo_bark: Yankı Kabuğu | moon_spore: Ay Sporu |
| earth | clay_shard: Kil Parçası | copper_flake: Bakır Pulu | earth_heart: Toprak Kalbi |
| desert | fine_sand: İnce Kum | sun_salt: Güneş Tuzu | mirage_glass: Serap Camı |
| sea | shell_chip: Sedef Kırığı | tide_kelp: Gelgit Yosunu | pearl_dust: İnci Tozu |
| ice | snow_crystal: Kar Kristali | frost_moss: Buz Yosunu | ancient_ice: Kadim Buz |
| volcanic | basalt_chip: Bazalt Kırığı | cobalt_shard: Kobalt Parçası | storm_ore: Fırtına Cevheri |
| flame | ash_petal: Kül Yaprağı | ember_seed: Köz Tohumu | living_coal: Canlı Kömür |

Toplama düğümleri bir materyali verir; görünür yenilenme süresi 180 saniyedir. Bölge materyal dağılımı %70 sık / %25 seyrek / %5 ender başlangıç hedefidir. Savaş ganimeti düğüm yenilenmesini etkilemez; kaynak kimliği ve alınma zamanı kayıtta tutulur.

## Sekiz oynanabilir MVP simya tarifi

Bütün tarifler ilk sürümde uygulanır; tarif açılmaları keşifle gelir. Savaş içinde sarf kullanımı yoktur. Ürün kullanım komutu yalnız güvenli kampta kabul edilir. Aşağıdaki etkiler COMBAT.md'nin savaş, XP, yakalama ve kuluçka formüllerini değiştirmez.

| Ürün ID / ad | Girdiler | Çıktı ve kesin etki | Açılma |
|---|---|---|---|
| salve / Çiy Merhemi | 2 dew_leaf + 1 soft_seed | 1; canlı tek dosta +20 HP, maxHP'ye kırp | Başlangıç |
| seal / Bağ Mührü | 2 clay_shard + 1 dew_leaf | 2; COMBAT.md yakalama sarfı | İlk eğitim |
| egg_feed / Yuva Özü | 2 soft_seed + 1 moss_thread | 1; kampta 2 heat_herb üretir, kuluçka süresini değiştirmez | İlk yumurta |
| forest_balm / Koru Balsamı | 2 moss_thread + 1 echo_bark | 1; canlı tek dosta +45 HP, maxHP'ye kırp | Koru sırrı |
| tide_balm / Gelgit Balsamı | 2 shell_chip + 1 tide_kelp | 1; canlı tek dosta +80 HP, maxHP'ye kırp | Kıyı şişesi |
| waking_salt / Uyanış Tuzu | 2 snow_crystal + 1 sun_salt | 1; baygın tek dostu ceil(maxHP×0.25) HP ile kaldırır | Buz çanı |
| ember_incense / Köz Tütsüsü | 2 ash_petal + 1 ember_seed | 1; kampta 5 heat_herb üretir | Bazalt sırrı |
| resonant_balm / Yankılı Balsam | 1 pearl_dust + 1 storm_ore + 1 amber_drop | 1; canlı tek dostu maxHP'ye iyileştirir | Dört rezonans taşı |

Üretim ve kullanım ayrı atomik işlemlerdir. Eksik girdide hiçbir eşya eksilmez; çıktı için yer yoksa işlem başlamaz. Aynı commandId tekrarında önceki sonuç döner. Yanlış hedef (tam HP, iyileştirme için baygın, Uyanış için canlı), kamp dışında kullanım veya dolu envantere reagent dönüşümü tüketim yapmadan açıklayıcı hata verir. Ürün ancak gerçek etkisiyle aynı transaction içinde tüketilir. Tarif kilidi ve malzeme eksikliği panelde ayrı nedenlerdir; çıktı önizlemesi ve seçili yaratığın önce/sonra HP'si gösterilir. Kampın LOST sonrası zorunlu ücretsiz iyileştirmesi COMBAT.md'ye göre devam eder; isteğe bağlı sarflar oyuncunun kamptaki diğer dostlarına hızlı bakım sağlar.

## Koleksiyon ve ekonomi

Yakalama, yumurta süresi, XP ve ödül idempotency kuralları COMBAT.md'den gelir. Takım 3, koleksiyon 60 kapasitelidir. İki kuluçka yuvası vardır; doluyken sessiz kayıp olmaz. Kuluçkanın kullandığı `heat_herb` / Isı Otu başlangıç çayırında bulunan 25. materyaldir. Sekiz tarifin tamamı `enabledInMvp:true` taşır. Tarif açılması malzemeye erişimden ayrıdır. Serbest kamp iyileştirmesi yalnız kaybedilen savaşın aktif dostuna uygulanır; genel tüm-takım ücretsiz iyileştirme eklenmez, böylece simya bakımının oyun değeri korunur.

## SVG görsel dili

64×64 eşya ikonları; 128×128 dünya işaretleri; 320×320 savaş figürleri. `viewBox`, benzersiz gradient ID, sabit ankraj ve saydam arka plan kullan. Palet biyomla eşleşir; 2 ana renk + gölge + vurgu, kalın kömür kontur, geometrik fakat özgün siluet. Nadirlik yalnız renkle anlatılmaz: sık tek nokta, seyrek iki çizgi, ender üçgen rozeti. İsimler HTML metin olarak kalır, SVG içine erişilemez metin gömülmez.

Ön ve arka görünüş **aynı SVG'nin aynalanması değildir**. Ön: gözler, göğüs/ön kabuk ve öne çıkan uzuvlar. Arka: göz yok; ayrı sırt plakaları, kuyruk kökü, omuz/kanat bağları ve ters örtüşme sırası. Çiytomur arkasında damar çizgili büyük yaprak; Bazaltık arkasında altıgen sırt dizisi; Sedefiz arkasında kabuğun kapalı dış yüzü. Dört yön dünya silueti veya yön oku ile dönüşü anlat; sprite yalnız yatay çevrilerek dört yön iddiası kurulmaz.

Büyük yakınlık paneli yaratık SVG'si + adı + seviye + etkileşim metni gösterir. Egg icon belirgin kabuk çatlağı ve biyom rozeti taşır. Ateş, buz ve kıvılcım efektleri hareket azaltma ayarına uyar. Başka oyunların karakter siluetleri, topları, isimleri veya arayüz düzeni kopyalanmaz.
