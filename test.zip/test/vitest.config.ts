import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
    exclude: ['tests/e2e/**', 'tests/performance/**'],
    passWithNoTests: false,
    setupFiles: ['tests/setup/indexeddb.ts'],
    coverage: { reportsDirectory: '.reports/coverage' },
  },
});
