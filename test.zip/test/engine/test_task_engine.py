import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('engine',Path(__file__).with_name('task_engine.py'))
e=importlib.util.module_from_spec(spec); spec.loader.exec_module(e)

class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        (self.root/'agents').mkdir(); (self.root/'workflow').mkdir()
        (self.root/'AGENTS.md').write_text('Project rules')
        roles=['coordinator','world','render','combat','content','ui','qa']
        for r in roles: (self.root/'agents'/f'{r}.md').write_text('Specific role '+r)
        self.graph={'version':1,'agents':{r:{'instructions':f'agents/{r}.md'} for r in roles},'nodes':[{'id':'world','agent':'world','review_agent':'qa','scope':['src'],'depends_on':[],'prompt':'Create world','gates':[{'id':'test','argv':['fake-test']}],'max_attempts':2}]}
        self.save_graph(); self.calls=[]
    def tearDown(self): self.tmp.cleanup()
    def save_graph(self): (self.root/'workflow/graph.json').write_text(json.dumps(self.graph))
    def runner(self,argv,cwd,timeout,stdin=None):
        self.calls.append((argv,stdin))
        if argv[0]=='codex':
            out=Path(argv[argv.index('--output-last-message')+1])
            if '--output-schema' in argv: out.write_text(json.dumps({'approved':True,'findings':[]}))
            else:
                (self.root/'src').mkdir(exist_ok=True); (self.root/'src/world.js').write_text('world')
                out.write_text('Done')
        return {'argv':argv,'returncode':0,'output':'passed'}
    def engine(self,runner=None): return e.Engine(self.root,'workflow/graph.json',runner or self.runner)
    def test_happy_path_and_resume(self):
        engine=self.engine(); engine.run(); self.assertEqual(engine.state['nodes']['world']['status'],'passed')
        self.assertEqual(engine.state['codex_calls'],2)
        self.assertIn('Specific role world',self.calls[0][1]); self.assertIn('Project rules',self.calls[0][1])
        self.assertIn('read-only',self.calls[-1][0])
        self.engine().run(); self.assertEqual(len(self.calls),3)
    def test_gate_failure_never_reviews_and_blocks_after_budget(self):
        def runner(argv,*args):
            r=self.runner(argv,*args)
            if argv[0]=='fake-test': r['returncode']=1
            return r
        engine=self.engine(runner); engine.run(); self.assertEqual(engine.state['nodes']['world']['status'],'blocked')
        self.assertEqual(engine.state['codex_calls'],2)
        self.assertFalse(any('--output-schema' in call[0] for call in self.calls))
    def test_scope_violation_blocks(self):
        def runner(argv,*args):
            r=self.runner(argv,*args); (self.root/'AGENTS.md').write_text('tampered'); return r
        engine=self.engine(runner); engine.run(); self.assertEqual(engine.state['nodes']['world']['status'],'blocked')
        self.assertEqual(engine.state['codex_calls'],1)
    def test_dependency_not_started_when_parent_fails(self):
        node=dict(self.graph['nodes'][0],id='combat',agent='combat',depends_on=['world']); self.graph['nodes'].append(node); self.save_graph()
        def runner(argv,*args): return {'argv':argv,'returncode':1,'output':'failed'}
        engine=self.engine(runner); engine.run(max_tasks=2); self.assertNotIn('combat',engine.state['nodes'])
    def test_call_budget_preserves_pending(self):
        engine=self.engine(); engine.run(max_calls=1); self.assertEqual(engine.state['codex_calls'],0)
        self.assertEqual(engine.state['nodes']['world']['attempts'],0)
    def test_lock_preserved_when_busy(self):
        (self.root/'.loop').mkdir(); lock=self.root/'.loop/engine.lock'; lock.write_text('123')
        with self.assertRaises(e.EngineError): self.engine().run()
        self.assertTrue(lock.exists())
    def test_malformed_review_fails_closed(self):
        def runner(argv,*args):
            r=self.runner(argv,*args)
            if '--output-schema' in argv: Path(argv[argv.index('--output-last-message')+1]).write_text('{}')
            return r
        engine=self.engine(runner); engine.run(); self.assertEqual(engine.state['nodes']['world']['status'],'blocked')
    def test_graph_cycle(self):
        self.graph['nodes'][0]['depends_on']=['world']
        with self.assertRaises(e.EngineError): e.validate(self.graph)
    def test_edges_disagree(self):
        self.graph['edges']=[{'from':'ghost','to':'world'}]
        with self.assertRaises(e.EngineError): e.validate(self.graph)
    def test_graph_change_checkpoint_rejected(self):
        engine=self.engine(); engine.save(); self.graph['nodes'][0]['prompt']='Different'; self.save_graph()
        with self.assertRaises(e.EngineError): self.engine()
    def test_interrupted_run_requires_reset(self):
        engine=self.engine(); engine.state['nodes']['world']={'status':'running','attempts':1}; engine.save()
        with self.assertRaises(e.EngineError): self.engine().run()
        self.assertFalse((self.root/'.loop/engine.lock').exists())
    def test_review_changes_block(self):
        def runner(argv,*args):
            r=self.runner(argv,*args)
            if '--output-schema' in argv: (self.root/'src/world.js').write_text('changed by reviewer')
            return r
        engine=self.engine(runner); engine.run(); self.assertEqual(engine.state['nodes']['world']['status'],'blocked')
    def test_path_escape(self):
        with self.assertRaises(e.EngineError): e.contained(self.root,'../outside')
    def test_stale_workspace_refused_repeatedly(self):
        self.engine().run(); (self.root/'src/world.js').write_text('external edit')
        for _ in range(2):
            with self.assertRaises(e.EngineError): self.engine().run()
    def test_gate_source_mutation_blocks(self):
        def runner(argv,*args):
            r=self.runner(argv,*args)
            if argv[0]=='fake-test': (self.root/'src/world.js').write_text('mutating gate')
            return r
        engine=self.engine(runner); engine.run(); self.assertEqual(engine.state['nodes']['world']['status'],'blocked')
    def test_approved_with_findings_fails(self):
        def runner(argv,*args):
            r=self.runner(argv,*args)
            if '--output-schema' in argv: Path(argv[argv.index('--output-last-message')+1]).write_text(json.dumps({'approved':True,'findings':['bug']}))
            return r
        engine=self.engine(runner); engine.run(); self.assertEqual(engine.state['nodes']['world']['status'],'blocked')
    def test_stale_review_not_reused(self):
        engine=self.engine(); engine.run()
        engine.state['nodes']={}; engine.save()
        def runner(argv,*args):
            if '--output-schema' in argv: return {'argv':argv,'returncode':0,'output':'no file'}
            return self.runner(argv,*args)
        engine=self.engine(runner); engine.run(); self.assertEqual(engine.state['nodes']['world']['status'],'blocked')
    def test_directory_symlinks_recorded(self):
        before=e.snapshot(self.root); (self.root/'evil').symlink_to('/tmp',target_is_directory=True)
        self.assertIn('evil',e.changed(before,e.snapshot(self.root)))
    def test_empty_graph_rejected(self):
        self.graph['nodes']=[]
        with self.assertRaises(e.EngineError): e.validate(self.graph)
    def test_execute_timeout_and_missing_command(self):
        import sys
        self.assertEqual(e.execute([sys.executable,'-c','import time;time.sleep(2)'],self.root,0.05)['returncode'],124)
        self.assertEqual(e.execute(['/definitely/missing/cmd'],self.root,1)['returncode'],127)

if __name__=='__main__': unittest.main()
