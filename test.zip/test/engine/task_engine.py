#!/usr/bin/env python3
"""Bounded graph executor. Python 3.9+, stdlib only. Run from repository root."""
import argparse
import hashlib
import json
import os
import signal
from pathlib import Path
import subprocess
import sys
import time

class EngineError(Exception): pass

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def atomic_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
    os.replace(tmp, path)

def contained(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()): raise EngineError('Path escapes repository: '+relative)
    return path

def validate(graph):
    if graph.get('version') != 1: raise EngineError('Graph version must be 1')
    roles = graph.get('agents', {})
    if len(roles) != 7: raise EngineError('Exactly seven logical agents are required')
    nodes = graph.get('nodes', [])
    if not nodes: raise EngineError('Empty graph')
    ids = [n['id'] for n in nodes]
    if len(set(ids)) != len(ids): raise EngineError('Duplicate node IDs')
    for n in nodes:
        if not n['id'].replace('-', '').replace('_', '').isalnum(): raise EngineError('Unsafe node ID')
        if n.get('agent') not in roles or n.get('review_agent') not in roles: raise EngineError('Unknown agent')
        if n['agent'] == n['review_agent']: raise EngineError('Reviewer must differ from implementer')
        if not n.get('scope') or not n.get('gates'): raise EngineError('Scope and real gates required')
        if not 1 <= n.get('max_attempts', 3) <= 5: raise EngineError('Attempts must be 1..5')
        for dep in n.get('depends_on', []):
            if dep not in ids: raise EngineError('Unknown dependency '+dep)
        for gate in n['gates']:
            if not isinstance(gate.get('timeout',120),(int,float)) or gate.get('timeout',120)<=0: raise EngineError('Gate timeout must be positive')
            if not gate.get('argv') or not all(isinstance(x,str) for x in gate['argv']): raise EngineError('Gate argv must be nonempty string list')
    actual = {(d,n['id']) for n in nodes for d in n.get('depends_on', [])}
    if 'edges' in graph and {(e['from'],e['to']) for e in graph['edges']} != actual: raise EngineError('Edges and dependencies disagree')
    done = set()
    while len(done) != len(ids):
        ready = [n for n in nodes if n['id'] not in done and set(n.get('depends_on', [])) <= done]
        if not ready: raise EngineError('Cycle in graph')
        done.update(n['id'] for n in ready)
    return graph

def execute(argv, cwd, timeout, stdin=None):
    try:
        p = subprocess.Popen(argv, cwd=cwd, stdin=subprocess.PIPE, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            output,_=p.communicate(stdin,timeout=timeout)
            return {'argv':argv,'returncode':p.returncode,'output':output[-80000:]}
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL)
            output,_=p.communicate()
            return {'argv':argv,'returncode':124,'output':output[-80000:]+'\nTIMEOUT: process group terminated'}
        except KeyboardInterrupt:
            # Stop child writers before the outer finally releases the repository lock.
            try: os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError: pass
            p.communicate()
            raise
    except OSError as exc:
        return {'argv':argv,'returncode':127,'output':str(exc)}

def snapshot(root):
    result = {}
    excluded = {'.git','.loop','node_modules','dist','coverage','.venv','__pycache__','.pytest_cache','.reports','test-results','.vite'}
    for directory, dirs, files in os.walk(root):
        for d in dirs:
            candidate=Path(directory)/d
            if candidate.is_symlink(): result[str(candidate.relative_to(root))]='symlink:'+os.readlink(candidate)
        dirs[:] = [d for d in dirs if d not in excluded and not (Path(directory)/d).is_symlink()]
        for name in files:
            if name == '.DS_Store' or name.endswith('.pyc'): continue
            p = Path(directory)/name
            if p.is_symlink(): result[str(p.relative_to(root))] = 'symlink:'+os.readlink(p)
            else: result[str(p.relative_to(root))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return result

def changed(before, after):
    return [p for p in set(before)|set(after) if before.get(p) != after.get(p)]

def in_scope(path, scopes):
    return any(path == s.rstrip('/') or path.startswith(s.rstrip('/')+'/') for s in scopes)

class Engine:
    def __init__(self, root, graph_path, runner=execute):
        self.root=Path(root).resolve(); self.graph_path=contained(self.root, graph_path)
        self.graph=validate(read_json(self.graph_path)); self.runner=runner
        self.folder=self.root/'.loop'; self.state_path=self.folder/'state.json'
        self.digest=hashlib.sha256(self.graph_path.read_bytes()).hexdigest()
        self.state=read_json(self.state_path) if self.state_path.exists() else {'graph_sha256':self.digest,'nodes':{},'codex_calls':0}
        if self.state['graph_sha256'] != self.digest: raise EngineError('Graph changed: archive .loop/state.json and review completed work before restarting')
        for role in self.graph['agents'].values():
            if not contained(self.root,role['instructions']).is_file(): raise EngineError('Missing role instructions '+role['instructions'])
        for n in self.graph['nodes']:
            for scope in n['scope']:
                contained(self.root,scope)
                if scope in ('','.'): raise EngineError('Whole-repository scope is prohibited')
        self.protected=[str(self.graph_path.relative_to(self.root)), 'AGENTS.md','SKILLS.md','engine','workflow','agents','.agents']+[r['instructions'] for r in self.graph['agents'].values()]
    def save(self): atomic_json(self.state_path,self.state)
    def checkpoint(self):
        self.state['workspace_snapshot']=snapshot(self.root)
        self.save()
    def ready(self):
        done={k for k,v in self.state['nodes'].items() if v['status']=='passed'}
        return [n for n in self.graph['nodes'] if n['id'] not in done and self.state['nodes'].get(n['id'],{}).get('status') not in ('blocked','running','reviewing') and set(n.get('depends_on',[]))<=done]
    def prompt(self,n,review=False):
        role=n['review_agent'] if review else n['agent']
        instructions=contained(self.root,self.graph['agents'][role]['instructions']).read_text()
        root_rules=(self.root/'AGENTS.md').read_text(encoding='utf-8')
        result=f'ROOT RULES:\n{root_rules}\nROLE: {role}\n{instructions}\nTASK: {n["id"]}\n{n["prompt"]}\nALLOWED WRITE PATHS: {json.dumps(n["scope"])}\nRead AGENTS.md. Never modify engine, workflow, agents, .agents, AGENTS.md, SKILLS.md, .git or .loop. Do not publish, deploy, send messages, or modify remote services.\n'
        if review: result+='READ-ONLY REVIEW: inspect code and gate evidence below. Return JSON matching the supplied schema. Approve only if acceptance criteria are met.\n'
        return result
    def codex(self,n,review,timeout,prompt,attempt_dir):
        self.state['codex_calls']+=1; self.save()
        out=attempt_dir/('review.json' if review else 'implementation.txt')
        out.unlink(missing_ok=True)
        argv=['codex','--ask-for-approval','never','exec','--sandbox','read-only' if review else 'workspace-write','--output-last-message',str(out)]
        if review:
            schema=attempt_dir/'review-schema.json'
            atomic_json(schema,{'type':'object','properties':{'approved':{'type':'boolean'},'findings':{'type':'array','items':{'type':'string'}}},'required':['approved','findings'],'additionalProperties':False})
            argv+=['--output-schema',str(schema)]
        argv+=['-']
        res=self.runner(argv,self.root,timeout,prompt)
        atomic_json(attempt_dir/('review-process.json' if review else 'implementation-process.json'),res)
        return res,out
    def run(self,max_tasks=1,max_calls=6,timeout=900):
        self.folder.mkdir(exist_ok=True)
        lock=self.folder/'engine.lock'
        try: fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        except FileExistsError: raise EngineError('Engine lock exists. Check recorded PID before manually removing a stale lock')
        os.write(fd,str(os.getpid()).encode()); os.close(fd)
        initial_calls=self.state['codex_calls']; count=0; started=False
        try:
            if self.state.get('workspace_snapshot') is not None and self.state['workspace_snapshot'] != snapshot(self.root):
                raise EngineError('Workspace changed outside engine. Review changes and reset affected node before resuming')
            if any(v['status'] in ('running','reviewing') for v in self.state['nodes'].values()):
                raise EngineError('Interrupted task detected. Inspect evidence and use reset NODE to allow a retry')
            while count<max_tasks:
                ready=self.ready()
                if not ready: break
                n=ready[0]; count+=1
                print(f'NODE {n["id"]}: {n["agent"]} -> reviewer {n["review_agent"]}',flush=True)
                entry=self.state['nodes'].setdefault(n['id'],{'status':'pending','attempts':0})
                while entry['attempts']<n.get('max_attempts',3):
                    if self.state['codex_calls']-initial_calls+2>max_calls:
                        entry['status']='pending'; self.save(); return
                    started=True
                    entry.update(status='running',attempts=entry['attempts']+1); self.save()
                    attempt_dir=self.folder/n['id']/str(entry['attempts']); attempt_dir.mkdir(parents=True,exist_ok=True)
                    before=snapshot(self.root)
                    feedback=entry.get('feedback','')
                    result,_=self.codex(n,False,timeout,self.prompt(n)+'\nPrevious feedback:\n'+feedback,attempt_dir)
                    implemented=snapshot(self.root)
                    changes=changed(before,implemented)
                    illegal=[p for p in changes if not in_scope(p,n['scope']) or in_scope(p,self.protected)]
                    if illegal:
                        entry.update(status='blocked',feedback='Out-of-scope changes; inspect manually: '+json.dumps(illegal)); self.save(); break
                    gates=[]
                    if result['returncode']==0:
                        for gate in n['gates']:
                            print('GATE '+gate['id'],flush=True)
                            gates.append(dict(id=gate['id'],**self.runner(gate['argv'],self.root,min(gate.get('timeout',120),timeout))))
                    atomic_json(attempt_dir/'gates.json',gates)
                    gate_changes=changed(implemented,snapshot(self.root))
                    illegal=gate_changes
                    if illegal:
                        entry.update(status='blocked',feedback='Gate changed protected/out-of-scope files: '+json.dumps(illegal)); self.save(); break
                    approved=False
                    if result['returncode']==0 and gates and all(g['returncode']==0 for g in gates):
                        entry['status']='reviewing'; self.save()
                        review_before=snapshot(self.root)
                        review,out=self.codex(n,True,timeout,self.prompt(n,True)+json.dumps(gates),attempt_dir)
                        try: verdict=read_json(out)
                        except (OSError,ValueError): verdict={}
                        if changed(review_before,snapshot(self.root)):
                            entry.update(status='blocked',feedback='Read-only reviewer changed repository files'); self.save(); break
                        approved=review['returncode']==0 and isinstance(verdict,dict) and set(verdict)=={'approved','findings'} and verdict.get('approved') is True and verdict.get('findings') == []
                        feedback=json.dumps(verdict)
                    else: feedback=json.dumps({'implementation':result,'gates':gates})[-30000:]
                    entry.update(status='passed' if approved else 'pending',feedback=feedback,evidence=str(attempt_dir.relative_to(self.root)))
                    self.checkpoint()
                    if approved: break
                if entry['status']!='passed':
                    if entry['attempts']>=n.get('max_attempts',3): entry['status']='blocked'; self.save()
                    break
        finally:
            if started: self.checkpoint()
            lock.unlink(missing_ok=True)


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--graph',default='workflow/graph.json')
    sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('plan'); sub.add_parser('status')
    run=sub.add_parser('run'); run.add_argument('--max-tasks',type=int,default=1); run.add_argument('--max-codex-calls',type=int,default=6); run.add_argument('--timeout',type=int,default=900)
    reset=sub.add_parser('reset'); reset.add_argument('node')
    args=p.parse_args()
    try:
        e=Engine(Path.cwd(),args.graph)
        if args.command=='plan':
            for n in e.graph['nodes']: print(f'{n["id"]}: {n["agent"]} -> review {n["review_agent"]}; after {n.get("depends_on",[])}')
        elif args.command=='status': print(json.dumps({k:{x:y for x,y in v.items() if x!='verified_snapshot'} for k,v in e.state['nodes'].items()},indent=2))
        elif args.command=='reset':
            if (e.folder/'engine.lock').exists(): raise EngineError('Cannot reset while lock exists')
            if args.node not in e.state['nodes']: raise EngineError('Unknown checkpoint node')
            # Invalidate transitive dependents; reset grants a fresh bounded budget explicitly.
            affected={args.node}
            while True:
                new=affected|{n['id'] for n in e.graph['nodes'] if set(n.get('depends_on',[]))&affected}
                if new==affected: break
                affected=new
            for node in affected: e.state['nodes'].pop(node,None)
            e.checkpoint(); print('Reset checkpoints: '+', '.join(sorted(affected)))
        else:
            if min(args.max_tasks,args.max_codex_calls,args.timeout)<1: raise EngineError('Budgets must be positive')
            e.run(args.max_tasks,args.max_codex_calls,args.timeout)
            counts={}
            for v in e.state['nodes'].values(): counts[v['status']]=counts.get(v['status'],0)+1
            print(json.dumps({'status_counts':counts,'lifetime_codex_calls':e.state['codex_calls']}))
            if counts.get('blocked',0): return 1
            if counts.get('pending',0): return 3
    except (EngineError,ValueError,KeyError,OSError,TypeError) as exc: print('ERROR:',exc,file=sys.stderr); return 2
    return 0

if __name__=='__main__': sys.exit(main())
