# Bounded graph engine

Python 3.9+, macOS/Linux, standard library only. Invoke from repository root:

```bash
python3 engine/task_engine.py plan
python3 engine/task_engine.py run --max-tasks 1 --max-codex-calls 6 --timeout 900
python3 engine/task_engine.py status
python3 engine/test_task_engine.py
```

This is an executable development orchestrator, not the Three.js game. Seven logical roles are defined in the graph; the Python scheduler is coordinator. Specialist implementation and independent read-only review use fresh Codex processes with each role's actual instruction file and root AGENTS.md embedded in context. Runtime concurrency is **one**, deliberately: no simultaneous worktrees, no claim of seven simultaneous agents. Codex CLI must already be installed and authenticated. CLI calls use `codex --ask-for-approval never exec`, workspace-write for implementation and read-only for reviewer; no approval bypass flag is used. Environment restrictions can block a task and must be resolved deliberately.

## Graph schema

`workflow/graph.json` must contain `version: 1`, exactly seven `agents` (each `instructions` is a relative Markdown path), and nonempty `nodes`. Every node requires `id`, `agent`, different `review_agent`, nonempty `scope` path prefixes, `prompt`, `depends_on`, nonempty `gates` (`id`, `argv` string array, optional positive `timeout`) and optional `max_attempts` (1–5, default 3). Optional `edges` (`from`, `to`) must exactly match dependencies. Cycles, missing roles, missing role docs, path escape, and duplicate IDs fail validation. Gate commands execute directly without shell interpolation.

## Gauntlet and evidence

A dependency becomes eligible only after all predecessor nodes passed. Implementation exit 0 → source scope integrity → real gate exit codes → source immutability across gates → independent reviewer → strict `{ "approved": true, "findings": [] }` → passed checkpoint. Gate and subprocess evidence is saved in `.loop/NODE/ATTEMPT/`. Existing review outputs are deleted before fresh invocation. A gate cannot mutate tracked source; generated reports must use ignored report directories. Scope violations block immediately and are not automatically reverted. Protected runner/graph/role files cannot be changed even if a node's scope accidentally allows them. Path hashing detects symlink directory changes too. This is integrity checking, not a replacement for OS sandboxing.

Atomic checkpoints, an exclusive PID lock, graph digest, and a full workspace snapshot prevent silent continuation after graph/source edits. `.git`, `.loop`, dependencies, build outputs and report caches are excluded. No automatic rollback or remote publishing. On crash, inspect evidence first; check that the lock's PID is no longer running before removing a stale lock. Then `python3 engine/task_engine.py reset NODE` invalidates the selected node and all transitive dependents, renews their retry budget, and accepts the current workspace as baseline. Reset does not undo source changes. Graph changes require archiving the old state and explicitly reviewing completed work.

Budgets: at most `--max-tasks` eligible tasks per invocation, `--max-codex-calls` actual model calls, per-node attempt limit, and per-process `--timeout` (also caps gate timeouts). Two calls are reserved before each attempt so its review can fit. The process group is killed on timeout. There is **no total wall-clock, token, or financial budget**; process limits do not imply a currency spending cap. Gate time adds to model-call time. Root `.loop` is trusted local engine state.

CLI exit: 0 selected work passed or nothing ready, 1 blocked task, 2 invalid configuration/preflight, 3 call-budget stop with pending work. Status summarizes node state and cumulative calls. Zero does not mean every task in the graph is complete: inspect status against the plan. Evidence proves configured gates, not absence of all game bugs. Real Three.js, browser, visual, and Codex execution are not proven by the fake-process unit tests.
